# Quickstart

Get this toolkit running and configured for the first time. Read this
before `PROJECT_SUMMARY.md`, which covers how the app is built — this
covers what you actually have to type in to make each widget work.

## 1. Install and launch

1. Make sure the whole project folder is together — `run.bat` needs
   `app.py`, `requirements.txt`, and `templates/` sitting next to it, not
   moved out on its own.
2. Double-click `run.bat` (or run `python app.py` from an activated
   `venv`). First run creates a virtual environment and installs
   `requirements.txt` — this takes a minute or two; every run after that
   is fast.
3. Once you see `Launching app.py...` and no errors, open
   `http://127.0.0.1:5000` in a browser. The app only listens on
   `localhost` — nothing about it is reachable from another machine.
4. The **SE Tools** tab opens first. You'll see empty fields everywhere —
   that's expected. Nothing works yet because nothing is configured.

Every credential you enter is saved in a plaintext JSON file next to
`app.py` (`config.json`, `cloud_config.json`, or `training_config.json`
depending on which one) — deliberate, since this is a single-user local
tool, not something exposed to a network. None of those files are ever
included when you use **Publish to GitHub** (see §7).

## 2. The three separate credentials this app uses

This is the single most confusing part of the toolkit if you haven't set
it up before: there are **three unrelated credentials**, for three
different Airlock API surfaces, stored in three different places. Mixing
them up is the #1 cause of "why isn't this working."

| Credential | Where you set it | What it's for | What breaks without it |
|---|---|---|---|
| **Airlock Digital API key** (per-tenant, on-prem REST API) | Settings → **Airlock API Settings** | Timed Audit Mode, ISO 27001 Compliance, and any script run from the **Scripts** tab | Those three stop working; everything under SE Tools is unaffected |
| **Cloud admin API key** (Cloud multi-tenant API) | SE Tools → **NFR Tracking** → Cloud base domain + Admin API key | NFR Tracking *and* Provision Training Instances — both widgets share this one key | All of SE Tools stops working |
| **VirusTotal API key** | Settings → **VirusTotal API** | Scanning a compiled `.exe` from the Editor widget | Only "Upload to VirusTotal" is unavailable — everything else in Editor still works |

Start with whichever row matches what you actually want to use today —
you don't need all three just to try one widget.

## 3. Airlock Digital API key (for Timed Audit Mode, ISO 27001, Scripts)

1. Settings → **Airlock API Settings** → "Add a connection".
2. **Label** — anything memorable, e.g. `Client A - Production`.
3. **Tenant** — the tenant hostname/URL Airlock gave you for this server.
4. **Port** — defaults to `3129` if you leave it blank.
5. **API key** — generated from that tenant's own Airlock console.
6. "Save new connection". You can save several connections this way —
   only one is ever "active" at a time, and switching it takes effect
   immediately everywhere that uses it (no restart).

## 4. Cloud admin API key (for SE Tools — NFR Tracking & Provision Training Instances)

This is a **different key from §3** — it authenticates against Airlock's
Cloud multi-tenant management API, not a single tenant's on-prem API, and
it's what lets one key see across all your partner/NFR tenants at once.

1. SE Tools → **NFR Tracking** tile.
2. **Cloud base domain** — e.g. `am.appenforcement.com` (matches the
   region your Cloud console itself lives on).
3. **Admin API key** — from your Cloud console, not a per-tenant one.
4. "Save connection".

Once saved, this same key also powers **Provision Training Instances** —
you don't configure it a second time there.

## 5. Directory ID and settings for Provision Training Instances

Provisioning tenants needs a few more fields, all under SE Tools →
**Provision Training Instances** → **Tenant creation settings**:

- **Directory ID** — the 24-character parent directory new tenants get
  created under. Found via your browser's dev tools while looking at the
  Cloud console (it isn't shown anywhere in the UI directly). This is
  *not* the same as any individual tenant's own Directory ID shown under
  NFR Tracking's partner tenant list — it's the parent directory itself.
- **Tenant license allocation** — how many licenses each new tenant gets.
  The field shows a live "N of M available" count once a Directory ID is
  saved, pulled from your Cloud directory.
- **Instructor full name / email** — whichever instructor account should
  automatically get access to every new tenant right after it finishes
  provisioning (the automated equivalent of clicking "Add Me to Tenant"
  in the console the first time you open a brand-new tenant — Airlock
  requires this before baselines or policy can be touched). Leave both
  blank to skip this and add yourself to each tenant by hand instead.
  This is also the pair of fields you'd change to hand this toolkit to a
  *different* instructor later — same Cloud admin key, different name/email.
- **Reference baseline (FullName)** — which baseline gets added to every
  new tenant automatically. Use the two dropdowns above the field (OS
  family, then specific baseline) to browse the catalog instead of typing
  an exact name from memory — picking one fills the field in for you. See
  §6 for what happens here the very first time, before any tenant exists.
- **Policy group** — which policy group the baseline gets assigned to
  right after it's added. Defaults to `Workstations`, which Airlock
  auto-provisions on every new tenant — only change this if your tenants'
  policy groups have been renamed.

**Don't forget to click "Save settings"** after changing any of these —
picking a baseline from the dropdowns fills the text field in, but
doesn't actually save it. A yellow "⚠ Unsaved changes" warning appears
near the button as a reminder, and "Create tenants" will refuse to run
at all while it's showing.

## 6. First-time tenant deployment (the cold-start baseline problem)

The **Reference baseline** dropdowns need to authenticate a lookup
against Airlock's Cloud API, and that lookup needs *some* real tenant to
check permissions against — it can't be done with zero tenants and no
Directory-level shortcut. Practically, that means:

- **Before you've ever provisioned a tenant**, the dropdowns may show
  "Catalog unavailable" with a 403 error. This is expected — type the
  baseline's exact `FullName` into the text field by hand for your very
  first class (get it from Airlock's console: Baselines → Add Baseline
  from Reference, and copy the name exactly).
- **After your first tenant successfully provisions**, the app caches
  the full baseline catalog. From then on, the dropdowns keep working
  even if every tenant later gets deleted — you'll see a note saying
  it's showing a cached catalog from whenever it was last fetched live,
  and it refreshes automatically the next time a tenant completes.

So: the very first class you ever create is the one time you have to
type a baseline name by hand. Every class after that can use the
dropdowns.

Once §3 through §5 are set and saved:

1. SE Tools → **Provision Training Instances** → **New class**.
2. **Class name** — anything descriptive.
3. **Roster** — one line per student: `Full Name, email@example.com`.
4. "Create tenants". Each row queues its own tenant-creation job; the
   list below polls automatically every 15 seconds until every tenant
   either completes or fails.
5. Watch the checklist per student fill in: tenant created → instructor
   access → baseline added → policy assigned. Any step can be retried
   individually if it fails, without re-creating the tenant.
6. **Creating a tenant emails its student a real invite from Airlock** —
   double-check the roster before clicking "Create tenants".
7. When the class is over, use "Delete tenant" per student, "Delete N
   tenants" per class, or "Delete all tenants" above the whole list. This
   is permanent. A row only ever disappears from the list once its tenant
   is actually confirmed deleted — there's no way to just hide a row
   while its tenant still exists in Airlock.

## 7. NFR Tracking

Once §4 is saved:

1. Add partner tenants under **Partner tenants**: a **Label** (anything
   memorable), the tenant's **Tenant ID** and **Directory ID** — both
   found in that tenant's own console URL / dev tools, same way as §5's
   Directory ID but for that specific tenant, not the parent directory.
2. Check which tenants you want included, then "Generate report" (opens
   in a new tab), or export the same data as **Excel** or **XML**
   instead.

## 8. Timed Audit Mode and ISO 27001 (need §3)

Both widgets are under **Custom Widgets** and use the active Airlock
connection from §3 — nothing extra to configure beyond that.

- **Timed Audit Mode**: pick a source group and a destination (audit)
  group, select which agents to move, set a duration, and start it.
  Reverts automatically even across an `app.py` restart, as long as it's
  running again by the time the timer's up.
- **ISO 27001 Compliance**: "Run assessment" scores your policy groups
  against the controls in `iso_mapping.json` — some are automated, some
  are marked "manual" (honest placeholders, not guessed logic). Download
  the results as a self-contained HTML report if you need to share it.

## 9. Editor and Scripts

- **Editor** (Custom Widgets tab): paste Python, click Run for immediate
  output, or Compile to build a standalone `.exe` — Upload to VirusTotal
  appears after a successful compile if §2's VirusTotal key is set.
- **Scripts** tab: runs `.py` files from your script folder (Settings →
  **Script folder & execution** — defaults to an `api_scripts` folder
  next to `app.py` if you don't set one) with the active Airlock
  connection injected as environment variables
  (`AIRLOCK_API_KEY`/`AIRLOCK_TENANT`/`AIRLOCK_PORT`, plus `VT_API_KEY`).

## 10. Backing this up to GitHub

You mentioned you already use this for exactly one purpose — a safety
net if this VM disappears — so two settings cards matter here, and only
one of them is what you want for that:

- **Publish to GitHub** (Settings) is the one you want. It zips up this
  app's own source — `app.py`, `templates/index.html`,
  `iso_mapping.json`, this file, `README.md`, `PROJECT_SUMMARY.md`,
  `requirements.txt`, `run.bat`, `.gitignore` — and pushes it as one new
  version-named zip in a repo you choose. Your actual data
  (`config.json`, `cloud_config.json`, `training_config.json`, and
  anything in `venv/`) is never included. Needs a token with **write**
  access. Past versions are never overwritten, so you always have a
  history to restore from.
- **GitHub sync** (also under Settings) is the opposite direction and
  for a different purpose — it pulls `.py` scripts *into* your script
  folder from a repo, for the Scripts tab. Not what you're using this
  for, and safe to leave disabled.

## 11. If something isn't working

- Settings → **Logging** → turn it on. It covers everything the terminal
  prints, including third-party API calls, and also writes to `app.log`
  next to `app.py` so it isn't lost once the terminal scrolls past it.
  Takes effect immediately, no restart needed.
- Flask's dev server doesn't hot-reload — after any `app.py` or
  `templates/index.html` change, fully stop and restart it.
- If a browser tab still shows old behavior after a real update on disk,
  hard-refresh it (Ctrl+Shift+R) — it may just be a cached page.
- The terminal window's own startup output prints the exact working
  directory and config file paths — worth checking first if something
  looks like a save didn't take, since a second copy of the folder or a
  leftover `python app.py` process on port 5000 is a more common cause
  than an actual bug.
