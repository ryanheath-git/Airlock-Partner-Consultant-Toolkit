"""MSP Manager — engine and routes for the SE Toolkit's MSP Manager tab
(and, later, the standalone MSP tool).

(The file keeps its original name, msp_policy_packs.py, from the first
version of this feature, a widget built around hand-built packs; that became
a reference-tenant widget on 2026-11-03 and the MSP Manager tab on
2026-11-08. Keeping the name avoids leaving an orphan file behind.)

Built so it can be lifted out of the SE Toolkit unchanged: this module never
imports app.py. Every Cloud API call goes through an *adapter* (see
REQUIRED_ADAPTER_FUNCTIONS), the page is its own template
(templates/msp_manager.html, served at /msp/ui and embedded in the toolkit's
MSP Manager tab), and the data lives in its own config file
(msp_config.json): the MSP's name, its own Cloud connection, a reference
tenant and a managed-tenant list (entered from scratch, never shared with NFR
Tracking), the cached reference library, and run history. One MSP per
install.

The model (Ryan, 2026-11-08):
  - The MSP builds everything in the *reference tenant* in the Airlock
    console itself. This tool only ever READS the reference tenant: it's a
    *library* (not a blueprint) of blocklists, allowlists, baselines and
    group settings to pick from.
  - On the Policies Replication page the MSP ticks managed tenants (center),
    target policy groups (left, the reference's tree; matched by NAME on
    each tenant — the MSP keeps the same group structure everywhere) and
    library items (right). Every ticked item is applied to every ticked
    group on every ticked tenant.
  - Items are colored like the console, for the ticked tenants x groups:
    green = assigned, red = available but not assigned, blue = inherited
    from a parent group, purple = doesn't exist on the tenant yet, so
    replicating would create it. Several tenants/groups -> a mixed count.
  - "Apply Changes" stages the selection: a preview (read-only) per tenant.
    "Replicate Changes Now" pushes exactly the staged selection.

What a push does on each managed tenant:
  - creates what's missing (blocklist, its rules, baseline) and assigns to
    the ticked groups — assigning only when Airlock clearly reports "not
    applied"; an unrecognized status is left alone;
  - allowlists: created (in the same-named top-level category) if the
    tenant has none by that name, missing metadata rules added with their
    elevation setting, and assigned to the ticked groups — like blocklists
    (allowlists in a subcategory, and file/hash entries, aren't copied yet);
  - an existing blocklist or allowlist rule whose definition differs is
    reported and left alone, unless the run's "Also update items that
    differ" is ticked;
  - the notification message is set on the ticked groups wherever it
    differs;
  - nothing is ever deleted, and the reference tenant is never written to.
"""

import copy
import json
import logging
import os
import re
import threading
import uuid
from datetime import datetime, timezone

from flask import Blueprint, jsonify, render_template, request

log = logging.getLogger("app.msp")

MAX_RUN_HISTORY = 25
MAX_NAME_LENGTH = 120

AIRLOCK_SYSTEM_POLICY_PARENT = "Airlock Policies"
POLICY_GLOBAL_SETTINGS_PARENT = "global-policy-settings"
OS_TYPES = ("Windows", "MacOS", "Linux")

# Criteria fields that only exist for Windows rules (from the captured
# tenant-blocklist-metarule-options-list). Used to infer a reference rule's
# OS when the rule list doesn't report it.
WINDOWS_ONLY_FIELDS = {"description", "thumbprint", "rootprint", "tbshash", "digest", "group", "csgroup"}

# Library item types the Policies Replication page can replicate. Trusted
# publishers are keyed "<OSType>::<Name>" and trusted per policy group with
# the Bulk Add page's call (captured 2026-11-15) — they come either from the
# reference's Publishers list or from the Bulk Add pool (the Publisher
# Summary of the reference + every managed tenant). Allowlists are matched
# by name: created in the same-named top-level category if missing, their
# metadata rules copied (elevation included), and assigned (all captured
# 2026-11-15). Subcategories and file/hash entries aren't copied yet.
ITEM_TYPES = ("blocklists", "allowlists", "baselines", "publishers")
READ_ONLY_TYPES = ()

PUBLISHER_WINDOWS = (("1d", "1 Day"), ("1w", "1 Week"), ("2w", "2 Weeks"), ("1mo", "1 Month"))
PUBLISHER_POOL_CACHE_SECONDS = 300
# The Publisher Summary's bucket for unsigned files — not a publisher you can trust.
PUBLISHER_NOT_SIGNED = "Not Signed"

# Per (tenant, policy group, item) states — the console's colors.
STATE_ASSIGNED = "assigned"            # green
STATE_NOT_ASSIGNED = "not_assigned"    # red
STATE_INHERITED = "inherited"          # blue
STATE_CREATE = "create"                # purple: not on the tenant; replicating creates it
STATE_CANT_CREATE = "cant_create"      # not on the tenant and can't be created yet (allowlists)
STATE_GROUP_MISSING = "group_missing"  # the tenant has no policy group with this name
STATE_UNKNOWN = "unknown"              # Airlock returned a status this tool can't place

STATUS_CACHE_SECONDS = 120
STATUS_WORKERS = 6

REQUIRED_ADAPTER_FUNCTIONS = (
    "connection",                   # (base_domain, api_key) -> context manager: Cloud calls in it use these credentials
    "nfr_connection",               # () -> {base_domain, api_key} from NFR Tracking (for the optional copy button)
    "list_policies",                # (tid, did) -> ([{id, name, parent}], err)
    "list_blocklists",              # (tid, did) -> ([{ID, Name, ...}], err)
    "create_blocklist",             # (tid, did, name) -> (blocklist_id, err)
    "list_blocklist_rules",         # (tid, did, blocklist_id) -> ([{ID, Name, Criteria, Setting, ...}], err)
    "save_blocklist_rule",          # (tid, did, blocklist_id, spec) -> (ok, err)  creates, or updates a same-named rule
    "list_blocklist_hashes",        # (tid, did, blocklist_id) -> (raw_response_dict, err)
    "blocklist_statuses",           # (tid, did, group_ref) -> ([{ID, Status}], err)
    "assign_blocklist",             # (tid, did, group_ref, blocklist_id, name) -> (ok, err)
    "list_reference_baselines",     # (tid, did) -> ([{FullName, ...}], err)
    "add_reference_baseline",       # (tid, did, reference_entry) -> (ok, err)
    "list_tenant_baselines",        # (tid, did) -> ([{ID, Name, Timestamp}], err)
    "baseline_statuses",            # (tid, did, group_ref) -> ([{ID, Name, Status, IsInherited, IsApproved}], err)
    "assign_baseline",              # (tid, did, group_ref, baseline_id, baseline_name) -> (ok, err)
    "get_policy_settings",          # (tid, did, group_ref) -> (settings_dict, err)
    "save_notification_message",    # (tid, did, group_ref, loaded_settings, message) -> (ok, err)
    "list_allowlists",              # (tid, did) -> ([{ID, Name, Category, Fcount, ...}], err)
    "list_allowlist_rules",         # (tid, did, allowlist_id) -> ([{ID, Name, OSType, IntegrityLevel, Criteria}], err)
    "create_allowlist_rule",        # (tid, did, allowlist_id, spec) -> (ok, err)
    "list_group_publishers",        # (tid, did, group_ref) -> ([{ID, Name, FriendlyName, OSType, IsInherited}], err)
    "publisher_summary",            # (tid, did, window) -> ([{Name, FriendlyName, OSType, Count, CommonlyTrusted}], err)
    "trust_publishers",             # (tid, did, group_ref, [{name, os_type}]) -> (ok, err)
    "allowlist_group_statuses",     # (tid, did, group_ref) -> ([{ID, Text, Status, Type}], err)
    "list_allowlist_categories",    # (tid, did) -> ([{ID, Name}], err)
    "create_allowlist",             # (tid, did, category_id, name) -> (allowlist_entry, err)
    "assign_allowlist",             # (tid, did, group_ref, allowlist_entry) -> (ok, err)
    "update_allowlist_rule",        # (tid, did, allowlist_id, existing_rule, spec) -> (ok, err)
    "dashboard_get",                # (tid, did, path, params) -> (json, err)  reporting/v1/dashboard/<path>
    "discover_tenants",             # (email, directory_id) -> ([{tenant_id, directory_id, name, path, roles, source}], method, err)
)

# Dashboard filter values, as the console's filter-list calls return them
# (captured 2026-11-08). Execution types are sent by Index; only "All" has
# been seen on the wire, so a specific type is not yet live-confirmed.
DASHBOARD_TIME_OPTIONS = [("today", "Today"), ("15m", "15 Minutes"), ("1h", "1 Hour"), ("1d", "1 Day"),
                          ("3d", "3 Days"), ("1w", "1 Week"), ("2w", "2 Weeks"), ("1mo", "1 Month")]
DASHBOARD_EXECUTION_TYPES = [(-1, "All"), (1, "Blocked Execution"), (2, "Untrusted Execution [Audit]"),
                             (3, "Untrusted Execution [OTP]"), (-2, "Untrusted Execution"), (0, "Trusted Hash Execution"),
                             (4, "Trusted Path Execution"), (5, "Trusted Publisher Execution"), (8, "Trusted Process Execution"),
                             (10, "Trusted Metadata Execution"), (17, "Trusted Installer Execution"), (9, "Constrained Execution"),
                             (6, "Blocklist Execution"), (7, "Blocklist Execution [Audit]")]
DASHBOARD_COUNTS = [f"{kind}/{measure}" for kind in ("blocked", "untrusted") for measure in ("total", "unique", "unreviewed")]
DASHBOARD_CACHE_SECONDS = 60
DASHBOARD_TOP_N = 15


def _now():
    return datetime.now(timezone.utc).isoformat()


# --------------------------------------------------------------------------
# Pure helpers (no I/O)
# --------------------------------------------------------------------------

_NAME_UNSAFE = re.compile(r"[^A-Za-z0-9 ]+")


def airlock_safe_name(name):
    """The name with everything but letters, digits and spaces removed —
    some create calls (tenant-blocklist-create, seen 2026-11-15) reject
    anything else with "input must only contain alpha-numeric characters",
    even though the console shows names like "... (main)"."""
    return re.sub(r"\s+", " ", _NAME_UNSAFE.sub(" ", name or "")).strip()


def is_name_rejection(err):
    text = str(err or "").lower()
    return "alpha-numeric" in text or "alphanumeric" in text


def find_named(items, name, key="Name"):
    """Items whose name is the reference's name, or — when none is — its
    cleaned-up form (what replication creates when Airlock rejects the
    original), so a copy created under the cleaned name still matches."""
    exact = [i for i in items or [] if i.get(key) == name]
    if exact:
        return exact
    safe = airlock_safe_name(name)
    if not safe or safe == name:
        return []
    return [i for i in items or [] if i.get(key) == safe]


def normalize_baseline_name(value):
    """Reference catalog FullNames and tenant baseline Names are formatted
    differently ("Windows 11-25H2-x64-April 2026.tar.gz" vs "Windows 11 25H2
    x64 April 2026 (Reference)"). Maps both to one comparable form. Only the
    Windows shape is confirmed from a real capture; the learned
    baseline_name_map covers anything this gets wrong after the first add."""
    s = str(value or "").strip().lower()
    s = re.sub(r"\.tar\.gz$", "", s)
    s = s.replace("(reference)", "")
    s = re.sub(r"[-\s]+", " ", s)
    return s.strip()


def is_user_group(policy):
    return policy.get("parent") != AIRLOCK_SYSTEM_POLICY_PARENT and policy.get("id") != POLICY_GLOBAL_SETTINGS_PARENT


def build_policy_group_ref(policies, group_name):
    """Console-shaped ref (ID/Name/Parent/parentid/children) for a user-facing
    policy group, from an already-fetched policy list. None if not found."""
    group = next((p for p in policies if p.get("name") == group_name and is_user_group(p)), None)
    if not group:
        return None
    parent = group.get("parent") or POLICY_GLOBAL_SETTINGS_PARENT
    children = [p for p in policies if p.get("parent") == group["id"]]
    return {
        "ID": group["id"],
        "Name": group["name"],
        "Parent": parent,
        "parentid": parent,
        "children": [
            {"ID": c["id"], "Name": c["name"], "Parent": group["id"], "parentid": group["id"], "children": []}
            for c in children
        ],
    }


def blocklist_status_is_applied(status):
    """BlGreen = applied directly; BlInherited* = applied via the parent."""
    return status == "BlGreen" or str(status or "").startswith("BlInherited")


def baseline_assignment_state(entry):
    """"applied" / "not_applied" / "unknown" for one TenantBaselineStatusList
    entry. Status values aren't all confirmed, so anything unplaceable is
    "unknown" — and the engine never assigns on "unknown"."""
    if not entry:
        return "not_applied"
    status = str(entry.get("Status") or "")
    if entry.get("IsInherited") is True or entry.get("IsApproved") is True or "Green" in status or "Inherited" in status:
        return "applied"
    if "Red" in status or entry.get("IsApproved") is False:
        return "not_applied"
    return "unknown"


def baseline_directly_assigned(entry):
    """Applied on this group itself, not inherited from its parent (inherited
    assignments follow automatically once the parent's is copied)."""
    return (
        baseline_assignment_state(entry) == "applied"
        and entry.get("IsInherited") is not True
        and "Inherited" not in str(entry.get("Status") or "")
    )


def blocklist_state(status):
    if status == "BlGreen":
        return STATE_ASSIGNED
    if str(status or "").startswith("BlInherited"):
        return STATE_INHERITED
    if status == "BlRed" or not status:
        return STATE_NOT_ASSIGNED
    return STATE_UNKNOWN


def baseline_state(entry):
    if not entry:
        return STATE_NOT_ASSIGNED
    if entry.get("IsInherited") is True or "inherit" in str(entry.get("Status") or "").lower():
        return STATE_INHERITED
    return {"applied": STATE_ASSIGNED, "not_applied": STATE_NOT_ASSIGNED}.get(baseline_assignment_state(entry), STATE_UNKNOWN)


def allowlist_assignment_state(entry):
    """One tenant-policy-allowlist-list TenantCategoryInfoList entry (Type
    "capture", ID = the allowlist's ID). Only "red" is confirmed from a
    capture; green/inherited are matched the way the console colors them."""
    if not entry:
        return STATE_NOT_ASSIGNED
    status = str(entry.get("Status") or "").lower()
    if "inherit" in status or "blue" in status:
        return STATE_INHERITED
    if "green" in status:
        return STATE_ASSIGNED
    if "red" in status:
        return STATE_NOT_ASSIGNED
    return STATE_UNKNOWN


def reference_rule_os(rule):
    """Returns (os_type, how): how is "reported" (the API said), "inferred"
    (a Windows-only criteria field is used) or "assumed" (defaulted to
    Windows — flagged in the UI and run results)."""
    for key in ("MetadataRuleNameOS", "NameOS", "OS", "OSType", "OperatingSystem", "Os"):
        value = rule.get(key)
        for os_type in OS_TYPES:
            if isinstance(value, str) and value.strip().lower() == os_type.lower():
                return os_type, "reported"
    fields = {str(c.get("Field") or "").lower() for c in rule.get("Criteria") or [] if isinstance(c, dict)}
    if fields & WINDOWS_ONLY_FIELDS:
        return "Windows", "inferred"
    return "Windows", "assumed"


def rule_message(rule):
    notify = ((rule.get("Setting") or {}).get("CustomNotify")) or {}
    return str(notify.get("Text") or "") if notify.get("Enabled") else ""


def rule_spec_from_airlock(rule):
    """A reference tenant's rule -> the engine's rule spec."""
    os_type, how = reference_rule_os(rule)
    ordered = sorted([c for c in rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    return {
        "name": rule.get("Name") or "",
        "os_type": os_type,
        "os_source": how,
        "criteria": [{"field": c.get("Field") or "", "operation": c.get("Operation") or "", "value": c.get("Value") or ""} for c in ordered],
        "message": rule_message(rule),
    }


def rule_matches(airlock_rule, spec):
    ordered = sorted([c for c in airlock_rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    got = [(c.get("Field"), c.get("Operation"), c.get("Value")) for c in ordered]
    want = [(c["field"], c["operation"], c["value"]) for c in spec["criteria"]]
    return got == want and rule_message(airlock_rule) == (spec.get("message") or "")


def allowlist_rule_spec_from_airlock(rule):
    """A reference tenant's allowlist rule -> the engine's rule spec. The
    allowlist rule list reports OSType (captured), and FriendlyField /
    FriendlyOperation, which the create call also sends."""
    os_type, how = reference_rule_os(rule)
    ordered = sorted([c for c in rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    try:
        integrity = int(rule.get("IntegrityLevel") or 0)
    except (TypeError, ValueError):
        integrity = 1
    return {
        "name": rule.get("Name") or "",
        "os_type": os_type,
        "os_source": how,
        # Confirmed 2026-11-15: a rule created with elevate_process true
        # lists as IntegrityLevel 1, false as 0. Copied as elevate_process.
        "elevated": integrity != 0,
        "criteria": [
            {"field": c.get("Field") or "", "operation": c.get("Operation") or "", "value": c.get("Value") or "",
             "friendly_field": c.get("FriendlyField") or "", "friendly_operation": c.get("FriendlyOperation") or ""}
            for c in ordered
        ],
    }


def allowlist_rule_matches(airlock_rule, spec):
    ordered = sorted([c for c in airlock_rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    got = [(c.get("Field"), c.get("Operation"), c.get("Value")) for c in ordered]
    try:
        elevated = int(airlock_rule.get("IntegrityLevel") or 0) != 0
    except (TypeError, ValueError):
        elevated = True
    return (got == [(c["field"], c["operation"], c["value"]) for c in spec["criteria"]]
            and elevated == bool(spec.get("elevated")))


def extract_named_items(data, skip=("Atro", "TenantDatabaseRegisterList")):
    """Pulls [{name, id, status}] out of a list response whose item key isn't
    confirmed (trusted publishers: the only capture had none). Takes every
    top-level list of dicts except known bookkeeping keys."""
    items = []
    if not isinstance(data, dict):
        return items
    for key, value in data.items():
        if key in skip or not isinstance(value, list):
            continue
        for entry in value:
            if not isinstance(entry, dict):
                continue
            name = next((entry.get(k) for k in ("Name", "Text", "Publisher", "PublisherName", "CommonName", "Subject") if entry.get(k)), None)
            if name:
                items.append({"name": str(name), "id": entry.get("ID") or "", "status": entry.get("Status") or ""})
    return items


def publisher_key(name, os_type):
    return f"{os_type or 'Windows'}::{name}"


def parse_publisher_key(key):
    """'Windows::Broadcom Inc' -> ('Broadcom Inc', 'Windows'); None if malformed."""
    os_type, sep, name = str(key or "").partition("::")
    if not sep or not name.strip() or os_type not in OS_TYPES:
        return None
    return name, os_type


def clean_tenant_entry(raw):
    raw = raw if isinstance(raw, dict) else {}
    entry = {
        "label": str(raw.get("label") or "").strip(),
        "tenant_id": str(raw.get("tenant_id") or "").strip(),
        "directory_id": str(raw.get("directory_id") or "").strip(),
    }
    if not entry["label"]:
        return None, "Give the tenant a label (e.g. the customer's name)."
    if not entry["tenant_id"]:
        return None, "Enter the tenant ID (it's in the tenant's console URL)."
    if not entry["directory_id"]:
        return None, "Enter the directory ID."
    return entry, None


def clean_selection(raw):
    """The Policies Replication page's selection -> {tenant_ids, groups,
    items: {blocklists, allowlists, baselines}, message_from, update_differing}.
    Returns (selection, None) or (None, error)."""
    raw = raw if isinstance(raw, dict) else {}

    def names(values):
        out, seen = [], set()
        for v in values or []:
            v = str(v or "").strip()
            if v and v not in seen:
                seen.add(v)
                out.append(v)
        return out

    items = raw.get("items") if isinstance(raw.get("items"), dict) else {}
    sel = {
        "tenant_ids": names(raw.get("tenant_ids")),
        "groups": names(raw.get("groups")),
        "items": {t: names(items.get(t)) for t in ITEM_TYPES},
        "message_from": str(raw.get("message_from") or "").strip(),
        "update_differing": bool(raw.get("update_differing")),
        "trust_on_reference": bool(raw.get("trust_on_reference")),
    }
    bad = [k for k in sel["items"]["publishers"] if not parse_publisher_key(k)]
    if bad:
        return None, f"Unrecognized publisher: {bad[0]}"
    if not sel["items"]["publishers"]:
        sel["trust_on_reference"] = False
    if not sel["tenant_ids"]:
        return None, "Tick at least one managed tenant."
    if not sel["groups"]:
        return None, "Tick at least one policy group on the left."
    if not any(sel["items"].values()) and not sel["message_from"]:
        return None, "Tick at least one item on the right (a baseline, allowlist, blocklist, publisher or group setting)."
    return sel, None


def selection_label(sel):
    counts = [f"{len(v)} {k}" for k, v in sel["items"].items() if v]
    if sel.get("message_from"):
        counts.append("notification message")
    if sel.get("trust_on_reference"):
        counts.append("+ reference")
    groups = ", ".join(sel["groups"][:3]) + (f" +{len(sel['groups']) - 3}" if len(sel["groups"]) > 3 else "")
    return f"{', '.join(counts)} → {groups}"


# --------------------------------------------------------------------------
# Reading the reference tenant
# --------------------------------------------------------------------------

class ReferenceReader:
    """Reads the reference tenant. Used for the inventory (everything) and at
    run time (only the selected items)."""

    def __init__(self, adapter, ref_tenant, learned_names):
        self.a = adapter
        self.tid = ref_tenant["tenant_id"]
        self.did = ref_tenant["directory_id"]
        self.learned = learned_names or {}
        self.errors = []
        self._policies = None
        self._group_cache = {}

    def policies(self):
        if self._policies is None:
            policies, err = self.a.list_policies(self.tid, self.did)
            if err:
                raise ReferenceReadError(f"Couldn't list the reference tenant's policy groups: {err}")
            self._policies = policies
        return self._policies

    def user_groups(self):
        return [p for p in self.policies() if is_user_group(p) and p.get("parent")]

    def group_ref(self, name):
        return build_policy_group_ref(self.policies(), name)

    def _per_group(self, kind, fn):
        """{group_name: result} for every user-facing group, cached per kind.
        A failing group is recorded in self.errors and skipped."""
        if kind not in self._group_cache:
            out = {}
            for g in self.user_groups():
                ref = self.group_ref(g["name"])
                result, err = fn(self.tid, self.did, ref)
                if err:
                    self.errors.append(f"{kind} for '{g['name']}': {err}")
                    continue
                out[g["name"]] = result
            self._group_cache[kind] = out
        return self._group_cache[kind]

    def blocklist_assignments(self):
        """{blocklist_id: [group names where directly applied (BlGreen)]}"""
        result = {}
        for group, statuses in self._per_group("blocklist assignments", self.a.blocklist_statuses).items():
            for s in statuses or []:
                if s.get("Status") == "BlGreen":
                    result.setdefault(s.get("ID"), []).append(group)
        return result

    def baseline_assignments(self):
        result = {}
        for group, statuses in self._per_group("baseline assignments", self.a.baseline_statuses).items():
            for s in statuses or []:
                if baseline_directly_assigned(s):
                    result.setdefault(s.get("ID"), []).append(group)
        return result

    def blocklists(self):
        items, err = self.a.list_blocklists(self.tid, self.did)
        if err:
            raise ReferenceReadError(f"Couldn't list the reference tenant's blocklists: {err}")
        return items

    def blocklist_detail(self, bl):
        rules, err = self.a.list_blocklist_rules(self.tid, self.did, bl.get("ID"))
        if err:
            raise ReferenceReadError(f"Couldn't read the rules of blocklist '{bl.get('Name')}': {err}")
        if rules:
            log.info("MSP reference rule fields (for OS detection): %s", sorted(rules[0].keys()))
        specs = [rule_spec_from_airlock(r) for r in rules]
        hash_count = None
        raw, err = self.a.list_blocklist_hashes(self.tid, self.did, bl.get("ID"))
        if not err:
            hash_count = sum(
                len(v) for k, v in (raw or {}).items()
                if k not in ("Atro", "TenantDatabaseRegisterList") and isinstance(v, list)
            )
        return specs, hash_count

    def tenant_baselines(self):
        items, err = self.a.list_tenant_baselines(self.tid, self.did)
        if err:
            raise ReferenceReadError(f"Couldn't list the reference tenant's baselines: {err}")
        return items

    def allowlists(self):
        items, err = self.a.list_allowlists(self.tid, self.did)
        if err:
            raise ReferenceReadError(f"Couldn't list the reference tenant's allowlists: {err}")
        return items

    def allowlist_rules(self, al):
        rules, err = self.a.list_allowlist_rules(self.tid, self.did, al.get("ID"))
        if err:
            raise ReferenceReadError(f"Couldn't read the rules of allowlist '{al.get('Name')}': {err}")
        return [allowlist_rule_spec_from_airlock(r) for r in rules]

    def catalog(self):
        items, err = self.a.list_reference_baselines(self.tid, self.did)
        if err:
            self.errors.append(f"Airlock's reference baseline catalog: {err}")
            return []
        return items

    def full_name_for(self, baseline_name, catalog):
        """Maps a tenant baseline's Name back to the catalog FullName it was
        added from. None = a custom baseline (or one this can't place)."""
        for full, learned in self.learned.items():
            if learned == baseline_name:
                return full
        if "(reference)" not in str(baseline_name or "").lower():
            return None
        wanted = normalize_baseline_name(baseline_name)
        return next((c.get("FullName") for c in catalog if normalize_baseline_name(c.get("FullName")) == wanted), None)

    def notification_messages(self):
        out = {}
        for group, settings in self._per_group("policy settings", self.a.get_policy_settings).items():
            out[group] = {
                "message": str((settings or {}).get("NotificationMessage") or ""),
                "enabled": bool((settings or {}).get("ClientNotification")),
            }
        return out

    def trusted_publishers(self):
        """Every publisher trusted on any user-facing group: [{key, name,
        friendly, os_type, groups (direct), inherited_groups}]."""
        items = {}
        for group, rows in self._per_group("trusted publishers", self.a.list_group_publishers).items():
            for r in rows or []:
                key = publisher_key(r.get("Name"), r.get("OSType"))
                entry = items.setdefault(key, {"key": key, "name": r.get("Name"), "friendly": r.get("FriendlyName") or r.get("Name"),
                                               "os_type": r.get("OSType") or "Windows", "groups": [], "inherited_groups": []})
                entry["inherited_groups" if r.get("IsInherited") else "groups"].append(group)
        return sorted(items.values(), key=lambda x: (x["name"].lower(), x["os_type"]))

    # -- the library (what the Policies Replication page lists) -----------------
    def inventory(self):
        """The reference tenant's library: its policy group tree (the targets
        on the left), and the blocklists, allowlists, baselines and group
        notification messages to pick from (right). Assignments on the
        reference itself aren't read here — colors come from /msp/status."""
        inv = {"fetched_at": _now(), "groups": [], "tree": [], "blocklists": [], "baselines": [], "policy_settings": [],
               "allowlists": [], "publishers": [], "errors": []}
        users = self.user_groups()
        ids = {g["id"] for g in users}
        inv["groups"] = [g["name"] for g in users]
        inv["tree"] = [{"id": g["id"], "name": g["name"], "parent_id": g["parent"] if g["parent"] in ids else None} for g in users]

        for bl in self.blocklists():
            try:
                rules, hash_count = self.blocklist_detail(bl)
            except ReferenceReadError as e:
                self.errors.append(str(e))
                rules, hash_count = [], None
            inv["blocklists"].append({
                "name": bl.get("Name"),
                "rules": [{"name": r["name"], "os_type": r["os_type"], "os_source": r["os_source"], "criteria_count": len(r["criteria"])} for r in rules],
                "hash_count": hash_count,
            })

        allowlists = self.allowlists()
        name_counts = {}
        for al in allowlists:
            name_counts[al.get("Name")] = name_counts.get(al.get("Name"), 0) + 1
        for al in allowlists:
            try:
                rules = self.allowlist_rules(al)
            except ReferenceReadError as e:
                self.errors.append(str(e))
                rules = []
            inv["allowlists"].append({
                "name": al.get("Name"),
                "category": al.get("Category") or "",
                "top_category": al.get("TopCategory") or al.get("Category") or "",
                "in_subcategory": bool(al.get("InSubcategory")),
                "rules": [{"name": r["name"], "os_type": r["os_type"], "criteria_count": len(r["criteria"]), "elevated": r["elevated"]} for r in rules],
                "file_count": al.get("Fcount") or 0,
                "duplicate_name": name_counts.get(al.get("Name"), 0) > 1,
            })

        catalog = self.catalog()
        catalog_os = {c.get("FullName"): c.get("OSType") for c in catalog}
        for b in self.tenant_baselines():
            full = self.full_name_for(b.get("Name"), catalog)
            inv["baselines"].append({
                "name": b.get("Name"),
                "full_name": full,
                "os_type": catalog_os.get(full) or b.get("OSType") or "",
                "replicable": bool(full),
                "reason": "" if full else "Custom baseline (not from Airlock's reference catalog) — can't be copied yet.",
            })

        for group, info in self.notification_messages().items():
            inv["policy_settings"].append({"group": group, "message": info["message"], "enabled": info["enabled"]})

        inv["publishers"] = self.trusted_publishers()
        inv["errors"] = list(self.errors)
        return inv

    # -- run-time resolution of a selection ---------------------------------------
    def resolve_selection(self, sel):
        """Reads the ticked library items' *current* definitions from the
        reference tenant and targets them at the ticked groups. Returns (spec,
        notes): spec is what TenantRun applies; notes are warnings shown at
        the top of the run (e.g. an item no longer on the reference)."""
        notes = []
        groups = list(sel["groups"])
        items = sel["items"]
        spec = {"blocklists": [], "allowlists": [], "baselines": [], "policy_settings": [], "publishers": []}
        for key in items.get("publishers") or []:
            parsed = parse_publisher_key(key)
            if parsed:
                spec["publishers"].append({"key": key, "name": parsed[0], "os_type": parsed[1], "assign_groups": groups})

        if items.get("blocklists"):
            by_name = {b.get("Name"): b for b in self.blocklists()}
            for name in items["blocklists"]:
                bl = by_name.get(name)
                if not bl:
                    notes.append(f"Blocklist '{name}' is no longer on the reference tenant — skipped.")
                    continue
                rules, hash_count = self.blocklist_detail(bl)
                for r in rules:
                    if r["os_source"] == "assumed":
                        notes.append(f"Blocklist '{name}', rule '{r['name']}': Airlock didn't report the rule's OS, so Windows is assumed.")
                if hash_count:
                    notes.append(f"Blocklist '{name}' has {hash_count} hash entr{'y' if hash_count == 1 else 'ies'} that can't be copied yet — only its metadata rules are.")
                spec["blocklists"].append({"name": name, "rules": rules, "assign_groups": groups})

        if items.get("allowlists"):
            all_lists = self.allowlists()
            for name in items["allowlists"]:
                matches = [a for a in all_lists if a.get("Name") == name]
                if not matches:
                    notes.append(f"Allowlist '{name}' is no longer on the reference tenant — skipped.")
                    continue
                if len(matches) > 1:
                    notes.append(f"The reference tenant has {len(matches)} allowlists named '{name}' — skipped; rename one so the name is unique.")
                    continue
                al = matches[0]
                rules = []
                for r in self.allowlist_rules(al):
                    if r["os_source"] == "assumed":
                        notes.append(f"Allowlist '{name}', rule '{r['name']}': Airlock didn't report the rule's OS, so Windows is assumed.")
                    rules.append(r)
                if al.get("Fcount"):
                    notes.append(f"Allowlist '{name}' has {al['Fcount']} file entr{'y' if al['Fcount'] == 1 else 'ies'} that can't be copied — only its metadata rules are.")
                spec["allowlists"].append({"name": name, "rules": rules, "assign_groups": groups,
                                           "category": al.get("TopCategory") or al.get("Category") or "",
                                           "in_subcategory": bool(al.get("InSubcategory"))})

        if items.get("baselines"):
            tenant_baselines = {b.get("Name"): b for b in self.tenant_baselines()}
            catalog = self.catalog()
            for name in items["baselines"]:
                if name not in tenant_baselines:
                    notes.append(f"Baseline '{name}' is no longer on the reference tenant — skipped.")
                    continue
                full = self.full_name_for(name, catalog)
                if not full:
                    notes.append(f"Baseline '{name}' is a custom baseline — can't be copied yet, skipped.")
                    continue
                spec["baselines"].append({"full_name": full, "label": name, "assign_groups": groups})

        if sel.get("message_from"):
            src = sel["message_from"]
            info = self.notification_messages().get(src)
            if info is None:
                notes.append(f"Policy group '{src}' is no longer on the reference tenant (or its settings couldn't be read) — notification message skipped.")
            elif not info["message"]:
                notes.append(f"Policy group '{src}' has no notification message on the reference tenant — skipped.")
            else:
                for g in groups:
                    spec["policy_settings"].append({"group": g, "block_notification_message": info["message"], "source_group": src})

        notes.extend(f"Reference read problem: {e}" for e in self.errors)
        return spec, notes


class ReferenceReadError(Exception):
    pass


# --------------------------------------------------------------------------
# Applying to one managed tenant
# --------------------------------------------------------------------------

class TenantRun:
    def __init__(self, adapter, tenant, dry_run, update_differing, learned_names):
        self.a = adapter
        self.tid = tenant.get("tenant_id") or ""
        self.did = tenant.get("directory_id") or ""
        self.dry_run = dry_run
        self.update_differing = update_differing
        self.learned = learned_names
        self.steps = []
        self._policies = None
        self._blocklists = None
        self._tenant_baselines = None
        self._reference = None
        self._allowlists = None

    def step(self, kind, item, outcome, detail=""):
        """outcome: planned | done | exists | differs | skipped | error"""
        if outcome == "error" and "Tenant Role(s) NOT Found" in str(detail):
            detail = (f"{detail} — the Cloud admin account doesn't have a role on this tenant yet. "
                      "Open the tenant once in the Cloud console (or use its \"Add Me to Tenant\" button), then run again.")
        self.steps.append({"kind": kind, "item": item, "outcome": outcome, "detail": detail})

    def act(self, kind, item, planned_detail, fn):
        if self.dry_run:
            self.step(kind, item, "planned", planned_detail)
            return True
        ok, err = fn()
        if ok:
            self.step(kind, item, "done", planned_detail)
            return True
        self.step(kind, item, "error", err or "Failed.")
        return False

    def named_act(self, kind, item, planned_detail, name, fn):
        """Like act(), but fn(name) -> (result, err) creates something
        named. If Airlock rejects the name for its punctuation, it's
        retried once with the cleaned-up name and the step says so.
        Returns (result, name actually used) — result None on failure."""
        safe = airlock_safe_name(name)
        if self.dry_run:
            hint = f" If Airlock rejects the symbols in the name, it'll be created as '{safe}'." if safe and safe != name else ""
            self.step(kind, item, "planned", planned_detail + hint)
            return True, name
        result, err = fn(name)
        used = name
        if not result and is_name_rejection(err) and safe and safe != name:
            result, err = fn(safe)
            used = safe
        if result:
            note = f" Created as '{used}' — Airlock only accepts letters, numbers and spaces in this name." if used != name else ""
            self.step(kind, item, "done", planned_detail + note)
            return result, used
        self.step(kind, item, "error", err or "Failed.")
        return None, used

    def policies(self):
        if self._policies is None:
            policies, err = self.a.list_policies(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's policy groups: {err}")
            self._policies = policies
        return self._policies

    def group_ref(self, name):
        return build_policy_group_ref(self.policies(), name)

    def blocklists(self):
        if self._blocklists is None:
            items, err = self.a.list_blocklists(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's blocklists: {err}")
            self._blocklists = items
        return self._blocklists

    def tenant_baselines(self, refresh=False):
        if self._tenant_baselines is None or refresh:
            items, err = self.a.list_tenant_baselines(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's baselines: {err}")
            self._tenant_baselines = items
        return self._tenant_baselines

    def run(self, spec):
        for bl in spec.get("blocklists") or []:
            self.guarded(self.do_blocklist, bl, "blocklist", f"Blocklist '{bl['name']}'")
        for al in spec.get("allowlists") or []:
            self.guarded(self.do_allowlist, al, "allowlist", f"Allowlist '{al['name']}'")
        for b in spec.get("baselines") or []:
            self.guarded(self.do_baseline, b, "baseline", f"Baseline '{b.get('label') or b['full_name']}'")
        for s in spec.get("policy_settings") or []:
            self.guarded(self.do_policy_setting, s, "policy_setting", f"Notification message on '{s['group']}'")
        if spec.get("publishers"):
            self.guarded(self.do_publishers, spec["publishers"], "publisher", "Trusted publishers")
        return self.steps

    def do_publishers(self, pubs):
        """Trusts the publishers on each ticked group that doesn't already
        trust them (directly or inherited) — one call per group. Parent
        groups go first, so a child that inherits the result is a no-op."""
        groups = []
        for p in pubs:
            for g in p.get("assign_groups") or []:
                if g not in groups:
                    groups.append(g)
        by_id = {x.get("id"): x for x in self.policies()}

        def depth(name):
            node = next((x for x in self.policies() if x.get("name") == name), None)
            d = 0
            while node and node.get("parent") in by_id and d < 20:
                node, d = by_id[node.get("parent")], d + 1
            return d
        groups.sort(key=depth)

        for g in groups:
            wanted = [p for p in pubs if g in (p.get("assign_groups") or [])]
            ref = self.group_ref(g)
            if not ref:
                for p in wanted:
                    self.step("publisher", f"Publisher '{p['name']}' ({p['os_type']}) → trust on '{g}'", "skipped",
                              f"No policy group named '{g}' on this tenant.")
                continue
            rows, err = self.a.list_group_publishers(self.tid, self.did, ref)
            if err:
                for p in wanted:
                    self.step("publisher", f"Publisher '{p['name']}' ({p['os_type']}) → trust on '{g}'", "error",
                              f"Couldn't read the group's trusted publishers: {err}")
                continue
            have = {publisher_key(r.get("Name"), r.get("OSType")): r for r in rows or []}
            missing = []
            for p in wanted:
                label = f"Publisher '{p['name']}' ({p['os_type']}) → trust on '{g}'"
                hit = have.get(p["key"])
                if hit:
                    self.step("publisher", label, "exists",
                              "Already trusted (inherited from a parent group)." if hit.get("IsInherited") else "Already trusted.")
                else:
                    missing.append((p, label))
            if not missing:
                continue
            if self.dry_run:
                for p, label in missing:
                    self.step("publisher", label, "planned", "Trust this publisher on the policy group.")
                continue
            ok, err = self.a.trust_publishers(self.tid, self.did, ref, [{"name": p["name"], "os_type": p["os_type"]} for p, _ in missing])
            for p, label in missing:
                if ok:
                    self.step("publisher", label, "done", "Trusted on the policy group.")
                else:
                    self.step("publisher", label, "error", err or "Failed.")

    def guarded(self, fn, item, kind, label):
        try:
            fn(item)
        except TenantReadError as e:
            self.step(kind, label, "error", str(e))
        except Exception as e:
            log.exception("MSP step failed (%s)", label)
            self.step(kind, label, "error", f"Unexpected error: {e}")

    def do_blocklist(self, bl):
        label = f"Blocklist '{bl['name']}'"
        existing = next(iter(find_named(self.blocklists(), bl["name"])), None)
        blocklist_id = existing.get("ID") if existing else None
        tenant_name = existing.get("Name") if existing else bl["name"]

        if existing:
            note = f" (as '{tenant_name}')" if tenant_name != bl["name"] else ""
            self.step("blocklist", label, "exists", f"Already on the tenant{note}.")
        else:
            created, tenant_name = self.named_act(
                "blocklist", label, "Create blocklist.", bl["name"],
                lambda n: self.a.create_blocklist(self.tid, self.did, n))
            if not created:
                return
            if not self.dry_run:
                blocklist_id = created

        existing_rules = []
        if blocklist_id:
            existing_rules, err = self.a.list_blocklist_rules(self.tid, self.did, blocklist_id)
            if err:
                self.step("blocklist_rule", f"{label} rules", "error", f"Couldn't list the blocklist's rules: {err}")
                existing_rules = None
        for rule in bl.get("rules") or []:
            rlabel = f"{label} → rule '{rule['name']}'"
            if existing_rules is None:
                self.step("blocklist_rule", rlabel, "skipped", "Rules couldn't be read, so nothing was changed.")
                continue
            spec = {"rule_name": rule["name"], "os_type": rule["os_type"], "criteria": rule["criteria"], "message": rule.get("message") or ""}
            crit = "; ".join(f"{c['field']} {c['operation']} '{c['value']}'" for c in rule["criteria"]) or "no criteria"
            os_note = " (OS assumed — Airlock didn't report it)" if rule.get("os_source") == "assumed" else ""
            match = next(iter(find_named(existing_rules, rule["name"])), None)
            if match and rule_matches(match, rule):
                self.step("blocklist_rule", rlabel, "exists", "Already matches the reference.")
                continue
            if match and not self.update_differing:
                self.step("blocklist_rule", rlabel, "differs",
                          "Exists with different criteria or message — left unchanged. Tick \"Also update items that differ\" to overwrite it.")
                continue
            if match:
                spec["rule_name"] = match.get("Name") or rule["name"]
                self.act("blocklist_rule", rlabel, f"Update to match the reference: {crit}{os_note}.",
                         lambda spec=spec: self.a.save_blocklist_rule(self.tid, self.did, blocklist_id, spec))
            else:
                self.named_act("blocklist_rule", rlabel, f"Create {rule['os_type']} rule: {crit}{os_note}.", rule["name"],
                               lambda n, spec=spec: self.a.save_blocklist_rule(self.tid, self.did, blocklist_id, dict(spec, rule_name=n)))

        for group in bl.get("assign_groups") or []:
            alabel = f"{label} → assign to '{group}'"
            ref = self.group_ref(group)
            if not ref:
                self.step("blocklist_assign", alabel, "skipped", f"No policy group named '{group}' on this tenant.")
                continue
            if blocklist_id:
                statuses, err = self.a.blocklist_statuses(self.tid, self.did, ref)
                if err:
                    self.step("blocklist_assign", alabel, "error", f"Couldn't read the group's blocklists: {err}")
                    continue
                status = next((s.get("Status") for s in statuses or [] if s.get("ID") == blocklist_id), "")
                if blocklist_status_is_applied(status):
                    self.step("blocklist_assign", alabel, "exists", "Already applied (directly or inherited).")
                    continue
            self.act("blocklist_assign", alabel, "Assign blocklist to the policy group.",
                     lambda ref=ref: self.a.assign_blocklist(self.tid, self.did, ref, blocklist_id, tenant_name))

    def do_allowlist(self, al):
        """Creates the allowlist if the tenant doesn't have one with this
        name (in the same-named top-level category), adds missing rules,
        updates differing ones when the run allows it, and assigns it to the
        ticked groups — all calls captured 2026-11-15."""
        label = f"Allowlist '{al['name']}'"
        if self._allowlists is None:
            items, err = self.a.list_allowlists(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's allowlists: {err}")
            self._allowlists = items
        matches = find_named(self._allowlists, al["name"])
        if len(matches) > 1:
            self.step("allowlist", label, "skipped", f"The tenant has {len(matches)} allowlists with this name — rename one so it's unique.")
            return
        allowlist = matches[0] if matches else None

        if allowlist:
            self.step("allowlist", label, "exists", f"Already on the tenant (in {allowlist.get('Category') or 'its category'}).")
        else:
            if al.get("in_subcategory"):
                self.step("allowlist", label, "skipped",
                          "Not on this tenant, and it sits in a subcategory on the reference — creating subcategories isn't supported yet. Create it in the console once, then run again.")
                return
            cats, err = self.a.list_allowlist_categories(self.tid, self.did)
            if err:
                self.step("allowlist", label, "error", f"Couldn't list the tenant's allowlist categories: {err}")
                return
            cat = next((c for c in cats or [] if c.get("Name") == al.get("category")), None)
            if not cat:
                self.step("allowlist", label, "skipped",
                          f"Not on this tenant, and the tenant has no '{al.get('category')}' category to create it in. Create the category in the console, then run again.")
                return
            created, _ = self.named_act(
                "allowlist", label, f"Create allowlist in '{cat['Name']}'.", al["name"],
                lambda n: self.a.create_allowlist(self.tid, self.did, cat["ID"], n))
            if not created:
                return
            if not self.dry_run:
                allowlist = created
                self._allowlists.append(created)

        # Rules
        existing = []
        if allowlist:
            existing, err = self.a.list_allowlist_rules(self.tid, self.did, allowlist["ID"])
            if err:
                self.step("allowlist", f"{label} rules", "error", f"Couldn't list the allowlist's rules: {err}")
                existing = None
        for rule in al.get("rules") or []:
            rlabel = f"{label} → rule '{rule['name']}'"
            if existing is None:
                self.step("allowlist_rule", rlabel, "skipped", "Rules couldn't be read, so nothing was changed.")
                continue
            crit = "; ".join(f"{c['field']} {c['operation']} '{c['value']}'" for c in rule["criteria"]) or "no criteria"
            elev = ", runs elevated" if rule.get("elevated") else ""
            match = next(iter(find_named(existing, rule["name"])), None)
            if match and allowlist_rule_matches(match, rule):
                self.step("allowlist_rule", rlabel, "exists", "Already matches the reference.")
                continue
            if match and not self.update_differing:
                self.step("allowlist_rule", rlabel, "differs",
                          "Exists with different criteria or elevation — left unchanged. Tick \"Also update items that differ\" to overwrite it.")
                continue
            if match:
                self.act("allowlist_rule", rlabel, f"Update to match the reference: {crit}{elev}.",
                         lambda rule=rule, match=match: self.a.update_allowlist_rule(self.tid, self.did, allowlist["ID"], match, rule))
            else:
                self.named_act("allowlist_rule", rlabel, f"Create {rule['os_type']} rule: {crit}{elev}.", rule["name"],
                               lambda n, rule=rule: self.a.create_allowlist_rule(self.tid, self.did, allowlist["ID"], dict(rule, name=n)))

        # Assignments
        for group in al.get("assign_groups") or []:
            alabel = f"{label} → assign to '{group}'"
            ref = self.group_ref(group)
            if not ref:
                self.step("allowlist_assign", alabel, "skipped", f"No policy group named '{group}' on this tenant.")
                continue
            if allowlist:
                statuses, err = self.a.allowlist_group_statuses(self.tid, self.did, ref)
                if err:
                    self.step("allowlist_assign", alabel, "error", f"Couldn't read the group's allowlists: {err}")
                    continue
                state = allowlist_assignment_state(next((x for x in statuses or [] if x.get("ID") == allowlist["ID"]), None))
                if state in (STATE_ASSIGNED, STATE_INHERITED):
                    self.step("allowlist_assign", alabel, "exists", "Already assigned (directly or inherited).")
                    continue
                if state == STATE_UNKNOWN:
                    self.step("allowlist_assign", alabel, "skipped", "Couldn't tell whether it's assigned — left alone.")
                    continue
            self.act("allowlist_assign", alabel, "Assign allowlist to the policy group.",
                     lambda ref=ref: self.a.assign_allowlist(self.tid, self.did, ref, allowlist))

    def find_tenant_baseline(self, full_name):
        wanted = {normalize_baseline_name(full_name)}
        if self.learned.get(full_name):
            wanted.add(normalize_baseline_name(self.learned[full_name]))
        return next((b for b in self.tenant_baselines() if normalize_baseline_name(b.get("Name")) in wanted), None)

    def do_baseline(self, b):
        label = f"Baseline '{b.get('label') or b['full_name']}'"
        baseline = self.find_tenant_baseline(b["full_name"])
        if baseline:
            self.step("baseline", label, "exists", f"Already on the tenant as '{baseline.get('Name')}'.")
        else:
            if self._reference is None:
                catalog, err = self.a.list_reference_baselines(self.tid, self.did)
                if err:
                    self.step("baseline", label, "error", f"Couldn't read Airlock's reference baseline catalog: {err}")
                    return
                self._reference = catalog
            entry = next((r for r in self._reference if r.get("FullName") == b["full_name"]), None)
            if not entry:
                self.step("baseline", label, "error",
                          f"'{b['full_name']}' isn't in Airlock's current reference catalog — it may have been retired for a newer monthly build.")
                return
            if self.dry_run:
                self.step("baseline", label, "planned", "Add from Airlock's reference catalog.")
            else:
                before = {x.get("ID") for x in self.tenant_baselines()}
                ok, err = self.a.add_reference_baseline(self.tid, self.did, entry)
                if not ok:
                    self.step("baseline", label, "error", err or "Failed to add.")
                    return
                new = [x for x in self.tenant_baselines(refresh=True) if x.get("ID") not in before]
                baseline = new[0] if len(new) == 1 else self.find_tenant_baseline(b["full_name"])
                if not baseline:
                    self.step("baseline", label, "error", "Add reported success, but the new baseline couldn't be found on the tenant afterwards.")
                    return
                self.learned[b["full_name"]] = baseline.get("Name") or ""
                self.step("baseline", label, "done", f"Added as '{baseline.get('Name')}'.")

        for group in b.get("assign_groups") or []:
            alabel = f"{label} → assign to '{group}'"
            ref = self.group_ref(group)
            if not ref:
                self.step("baseline_assign", alabel, "skipped", f"No policy group named '{group}' on this tenant.")
                continue
            if baseline:
                statuses, err = self.a.baseline_statuses(self.tid, self.did, ref)
                if err:
                    self.step("baseline_assign", alabel, "error", f"Couldn't read the group's baselines: {err}")
                    continue
                entry = next((s for s in statuses or [] if s.get("ID") == baseline.get("ID")), None)
                state = baseline_assignment_state(entry)
                if state == "applied":
                    self.step("baseline_assign", alabel, "exists", "Already assigned (directly or inherited).")
                    continue
                if state == "unknown":
                    self.step("baseline_assign", alabel, "skipped",
                              f"Couldn't tell whether it's assigned (Airlock status '{entry.get('Status')}') — left alone.")
                    continue
            self.act("baseline_assign", alabel, "Assign baseline to the policy group.",
                     lambda ref=ref: self.a.assign_baseline(self.tid, self.did, ref, baseline["ID"], baseline.get("Name") or ""))

    def do_policy_setting(self, s):
        label = f"Notification message on '{s['group']}'"
        ref = self.group_ref(s["group"])
        if not ref:
            self.step("policy_setting", label, "skipped", f"No policy group named '{s['group']}' on this tenant.")
            return
        loaded, err = self.a.get_policy_settings(self.tid, self.did, ref)
        if err:
            self.step("policy_setting", label, "error", f"Couldn't load the group's settings: {err}")
            return
        message = s["block_notification_message"]
        if loaded.get("NotificationMessage") == message and loaded.get("ClientNotification"):
            self.step("policy_setting", label, "exists", "Already matches the reference.")
            return
        current = str(loaded.get("NotificationMessage") or "").strip()
        preview = (current[:80] + "…") if len(current) > 80 else current
        self.act("policy_setting", label, f"Set to the reference's message (currently: '{preview or 'blank'}').",
                 lambda: self.a.save_notification_message(self.tid, self.did, ref, loaded, message))


class TenantReadError(Exception):
    pass


def tenant_item_states(adapter, tenant, library, groups, message_from, learned):
    """Colors for one tenant: for every library item and every ticked policy
    group, one of the STATE_* values. Read-only. Returns
      {"groups_missing": [...],
       "items": {"blocklists": {name: {group: state}}, "allowlists": {...}, "baselines": {...}},
       "message": {group: state}}            (only when message_from is set)
    Raises TenantReadError if the tenant can't be read at all."""
    tid, did = tenant.get("tenant_id") or "", tenant.get("directory_id") or ""

    policies, err = adapter.list_policies(tid, did)
    if err:
        raise TenantReadError(f"Couldn't list policy groups: {err}")
    refs = {g: build_policy_group_ref(policies, g) for g in groups}
    present = [g for g in groups if refs[g]]
    result = {"groups_missing": [g for g in groups if not refs[g]],
              "items": {t: {} for t in ITEM_TYPES}, "message": {}}

    def fill(kind, name, per_group):
        """per_group: function(group) -> state for groups that exist."""
        result["items"][kind][name] = {g: (per_group(g) if refs[g] else STATE_GROUP_MISSING) for g in groups}

    # Blocklists
    lib_bl = [b["name"] for b in library.get("blocklists") or []]
    if lib_bl:
        tenant_bl, err = adapter.list_blocklists(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list blocklists: {err}")
        ids = {b.get("Name"): b.get("ID") for b in tenant_bl}
        statuses = {}
        if any(n in ids or airlock_safe_name(n) in ids for n in lib_bl):
            for g in present:
                rows, err = adapter.blocklist_statuses(tid, did, refs[g])
                if err:
                    raise TenantReadError(f"Couldn't read blocklist assignments on '{g}': {err}")
                statuses[g] = {r.get("ID"): r.get("Status") for r in rows or []}
        for name in lib_bl:
            bid = ids.get(name) or ids.get(airlock_safe_name(name))
            if not bid:
                fill("blocklists", name, lambda g: STATE_CREATE)
            else:
                fill("blocklists", name, lambda g, bid=bid: blocklist_state(statuses.get(g, {}).get(bid)))

    # Allowlists
    lib_al = [a["name"] for a in library.get("allowlists") or []]
    if lib_al:
        tenant_al, err = adapter.list_allowlists(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list allowlists: {err}")
        by_name = {}
        for a in tenant_al:
            by_name.setdefault(a.get("Name"), []).append(a.get("ID"))
        statuses = {}
        def found_for(n):
            return by_name.get(n) or by_name.get(airlock_safe_name(n)) or []
        if any(len(found_for(n)) == 1 for n in lib_al):
            for g in present:
                rows, err = adapter.allowlist_group_statuses(tid, did, refs[g])
                if err:
                    raise TenantReadError(f"Couldn't read allowlist assignments on '{g}': {err}")
                statuses[g] = {r.get("ID"): r for r in rows or [] if isinstance(r, dict)}
        lib_by_name = {a["name"]: a for a in library.get("allowlists") or []}
        cat_names = None
        for name in lib_al:
            found = found_for(name)
            if len(found) == 0:
                info = lib_by_name.get(name) or {}
                if cat_names is None:
                    cats, err = adapter.list_allowlist_categories(tid, did)
                    if err:
                        raise TenantReadError(f"Couldn't list allowlist categories: {err}")
                    cat_names = {c.get("Name") for c in cats or []}
                creatable = not info.get("in_subcategory") and (info.get("top_category") or info.get("category")) in cat_names
                fill("allowlists", name, lambda g, ok=creatable: STATE_CREATE if ok else STATE_CANT_CREATE)
            elif len(found) > 1:
                fill("allowlists", name, lambda g: STATE_UNKNOWN)
            else:
                fill("allowlists", name, lambda g, aid=found[0]: allowlist_assignment_state(statuses.get(g, {}).get(aid)))

    # Trusted publishers: what each ticked group trusts (green / blue). A
    # publisher not listed is "not trusted" (red) — the page treats any key
    # missing here (e.g. a Bulk Add publisher) the same way.
    pub_states, pub_names = {}, {}
    for g in present:
        rows, err = adapter.list_group_publishers(tid, did, refs[g])
        if err:
            raise TenantReadError(f"Couldn't read trusted publishers on '{g}': {err}")
        for r in rows or []:
            key = publisher_key(r.get("Name"), r.get("OSType"))
            pub_states.setdefault(key, {})[g] = STATE_INHERITED if r.get("IsInherited") else STATE_ASSIGNED
            pub_names[key] = r.get("FriendlyName") or r.get("Name")
    for p in library.get("publishers") or []:
        if p.get("key"):
            pub_states.setdefault(p["key"], {})
    for key, per in pub_states.items():
        for g in groups:
            per.setdefault(g, STATE_NOT_ASSIGNED if refs[g] else STATE_GROUP_MISSING)
    result["items"]["publishers"] = pub_states
    result["publisher_names"] = pub_names  # friendly names, e.g. "<GUID> [Mozilla]"

    # Baselines (matched by catalog FullName, like replication does)
    lib_bs = library.get("baselines") or []
    if lib_bs:
        tenant_bs, err = adapter.list_tenant_baselines(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list baselines: {err}")

        def find(b):
            wanted = {normalize_baseline_name(b["name"])}
            if b.get("full_name"):
                wanted.add(normalize_baseline_name(b["full_name"]))
                if learned.get(b["full_name"]):
                    wanted.add(normalize_baseline_name(learned[b["full_name"]]))
            return next((x for x in tenant_bs if normalize_baseline_name(x.get("Name")) in wanted), None)

        matches = {b["name"]: find(b) for b in lib_bs}
        statuses = {}
        if any(matches.values()):
            for g in present:
                rows, err = adapter.baseline_statuses(tid, did, refs[g])
                if err:
                    raise TenantReadError(f"Couldn't read baseline assignments on '{g}': {err}")
                statuses[g] = {r.get("ID"): r for r in rows or [] if isinstance(r, dict)}
        for b in lib_bs:
            m = matches[b["name"]]
            if not m:
                fill("baselines", b["name"], lambda g, ok=b.get("replicable"): STATE_CREATE if ok else STATE_CANT_CREATE)
            else:
                fill("baselines", b["name"], lambda g, bid=m.get("ID"): baseline_state(statuses.get(g, {}).get(bid)))

    # Group setting: the notification message copied from one reference group
    if message_from:
        msg = next((p["message"] for p in library.get("policy_settings") or [] if p.get("group") == message_from), None)
        for g in groups:
            if not refs[g]:
                result["message"][g] = STATE_GROUP_MISSING
                continue
            loaded, err = adapter.get_policy_settings(tid, did, refs[g])
            if err:
                raise TenantReadError(f"Couldn't read settings on '{g}': {err}")
            same = loaded.get("NotificationMessage") == msg and loaded.get("ClientNotification")
            result["message"][g] = STATE_ASSIGNED if same else STATE_NOT_ASSIGNED
    return result


class StatusChecker:
    """Runs tenant_item_states for several tenants in parallel (each worker
    enters the MSP connection itself — the credential override is per
    thread), with a short cache so ticking boxes doesn't re-read everything."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.lock = threading.Lock()

    def clear(self):
        with self.lock:
            self.cache.clear()

    def check(self, conn, tenants, library, groups, message_from, learned, refresh=False):
        from concurrent.futures import ThreadPoolExecutor
        import time as _time

        def one(t):
            key = (t.get("tenant_id"), tuple(groups), message_from, library.get("fetched_at"))
            with self.lock:
                hit = self.cache.get(key)
            if hit and not refresh and _time.monotonic() - hit[0] < STATUS_CACHE_SECONDS:
                return hit[1]
            out = {"id": t.get("id"), "label": t.get("label"), "is_reference": bool(t.get("is_reference")), "error": None}
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    out.update(tenant_item_states(self.a, t, library, groups, message_from, learned))
            except TenantReadError as e:
                out["error"] = str(e)
            except Exception as e:
                log.exception("MSP status check failed for %s", t.get("label"))
                out["error"] = f"Unexpected error: {e}"
            if out["error"] and "Tenant Role(s) NOT Found" in out["error"]:
                out["error"] += " — the Cloud admin account has no role on this tenant yet (open it once in the Cloud console, or use \"Add Me to Tenant\")."
            if not out["error"]:
                with self.lock:
                    self.cache[key] = (_time.monotonic(), out)
            return out

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            return list(pool.map(one, tenants))


def tenant_dashboard(adapter, tenant, f):
    """Every dashboard panel for one tenant. f = {start_time, end_time,
    policy_group ("All" or a name), include_children, execution_type
    ("All" or an Index)}. Raises TenantReadError on the first failing call."""
    tid, did = tenant.get("tenant_id") or "", tenant.get("directory_id") or ""
    out = {"group_missing": False}
    policy_id = "All"
    if f["policy_group"] != "All":
        policies, err = adapter.list_policies(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list policy groups: {err}")
        group = next((p for p in policies if p.get("name") == f["policy_group"] and is_user_group(p)), None)
        if not group:
            out["group_missing"] = True
            return out
        policy_id = group["id"]
    base = {"start_time": f["start_time"], "end_time": f["end_time"]}
    scoped = dict(base, policy_id=policy_id, include_children="true" if f["include_children"] else "false")
    typed = dict(scoped, execution_type=f["execution_type"])

    def get(path, params):
        data, err = adapter.dashboard_get(tid, did, path, dict(params, browser_exec="false") if params is not None else None)
        if err:
            raise TenantReadError(f"{path}: {err}")
        return data if isinstance(data, dict) else {}

    et = get("execution-types", typed)
    out["execution_types"] = {k: int(v or 0) for k, v in (et.get("counts") or {}).items()}
    vd = et.get("volumeDelta") or {}
    out["volume"] = {"current": int(vd.get("current") or 0), "previous": int(vd.get("previous") or 0)}
    out["counts"] = {k: int(get(f"execution-counts/{k}", scoped).get("count") or 0) for k in DASHBOARD_COUNTS}
    out["new_files"] = [r for r in get("new-files", base).get("data") or [] if isinstance(r, dict)]
    for key, path in (("top_users", "top-users"), ("top_hostnames", "top-hostnames"), ("top_policy_groups", "top-policy-groups")):
        out[key] = {k: int(v or 0) for k, v in (get(path, typed).get("counts") or {}).items()}
    cov = get("audit-enforcement-coverage", None)
    out["coverage"] = {"audit": int(cov.get("auditAgents") or 0), "enforcement": int(cov.get("enforcementAgents") or 0)}
    return out


def aggregate_dashboard(per_tenant):
    """per_tenant: [{id, label, error, group_missing, ...panels}] -> totals
    plus the per-tenant numbers the tiles' breakdowns show."""
    ok = [t for t in per_tenant if not t.get("error") and not t.get("group_missing")]
    agg = {
        "counts": {k: sum(t["counts"].get(k, 0) for t in ok) for k in DASHBOARD_COUNTS},
        "execution_types": {},
        "volume": {"current": sum(t["volume"]["current"] for t in ok), "previous": sum(t["volume"]["previous"] for t in ok)},
        "coverage": {"audit": sum(t["coverage"]["audit"] for t in ok), "enforcement": sum(t["coverage"]["enforcement"] for t in ok)},
        "new_files": [],
        "breakdown": [{"id": t["id"], "label": t["label"], "counts": t.get("counts"), "error": t.get("error"),
                       "group_missing": t.get("group_missing", False)} for t in per_tenant],
        "tenants_ok": len(ok),
        "tenants_total": len(per_tenant),
    }
    for t in ok:
        for k, v in t["execution_types"].items():
            agg["execution_types"][k] = agg["execution_types"].get(k, 0) + v
        for row in t["new_files"]:
            agg["new_files"].append(dict(row, _tenant=t["label"]))
    for key in ("top_users", "top_hostnames", "top_policy_groups"):
        rows = [{"name": name, "tenant": t["label"], "count": n} for t in ok for name, n in t[key].items()]
        agg[key] = sorted(rows, key=lambda r: (-r["count"], r["name"].lower()))[:DASHBOARD_TOP_N]
    return agg


class PublisherPool:
    """The Bulk Add list: the Publisher Summary (publishers seen in untrusted
    executions) of the reference and every managed tenant, merged by
    publisher + OS. Read in parallel, cached per time window."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.lock = threading.Lock()

    def read(self, conn, reference, tenants, window, refresh=False):
        from concurrent.futures import ThreadPoolExecutor
        import time as _time

        sources = ([dict(reference, label=f"{reference.get('label') or 'Reference'} (reference)")] if reference else []) + list(tenants)
        key = (window, tuple(sorted(str(t.get("tenant_id")) for t in sources)))
        with self.lock:
            hit = self.cache.get(key)
        if hit and not refresh and _time.monotonic() - hit[0] < PUBLISHER_POOL_CACHE_SECONDS:
            return hit[1]

        def one(t):
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    rows, err = self.a.publisher_summary(t.get("tenant_id") or "", t.get("directory_id") or "", window)
            except Exception as e:
                log.exception("Publisher Summary failed for %s", t.get("label"))
                rows, err = None, f"Unexpected error: {e}"
            return t, rows, err

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            results = list(pool.map(one, sources))

        merged, errors = {}, []
        for t, rows, err in results:
            label = t.get("label") or t.get("tenant_id")
            if err:
                errors.append({"label": label, "error": err})
                continue
            for r in rows or []:
                name = str(r.get("Name") or "").strip()
                if not name or name == PUBLISHER_NOT_SIGNED:
                    continue
                os_type = r.get("OSType") or "Windows"
                k = publisher_key(name, os_type)
                try:
                    count = int(r.get("Count") or 0)
                except (TypeError, ValueError):
                    count = 0
                e = merged.setdefault(k, {"key": k, "name": name, "friendly": r.get("FriendlyName") or name, "os_type": os_type,
                                          "count": 0, "commonly_trusted": False, "tenants": []})
                e["count"] += count
                e["commonly_trusted"] = e["commonly_trusted"] or bool(r.get("CommonlyTrusted"))
                e["tenants"].append({"label": label, "count": count})
        out = {
            "window": window, "fetched_at": _now(), "sources": len(sources), "errors": errors,
            "publishers": sorted(merged.values(), key=lambda e: (-e["count"], e["name"].lower())),
        }
        if not errors:
            with self.lock:
                self.cache[key] = (_time.monotonic(), out)
        return out


class DashboardReader:
    """Reads the dashboard for several tenants in parallel (each worker
    enters the MSP connection itself), with a short cache."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.lock = threading.Lock()

    def read(self, conn, tenants, f, refresh=False):
        from concurrent.futures import ThreadPoolExecutor
        import time as _time
        fkey = json.dumps(f, sort_keys=True)

        def one(t):
            key = (t.get("tenant_id"), fkey)
            with self.lock:
                hit = self.cache.get(key)
            if hit and not refresh and _time.monotonic() - hit[0] < DASHBOARD_CACHE_SECONDS:
                return hit[1]
            out = {"id": t.get("id"), "label": t.get("label"), "error": None}
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    out.update(tenant_dashboard(self.a, t, f))
            except TenantReadError as e:
                out["error"] = str(e)
            except Exception as e:
                log.exception("MSP dashboard read failed for %s", t.get("label"))
                out["error"] = f"Unexpected error: {e}"
            if out["error"] and "Tenant Role(s) NOT Found" in out["error"]:
                out["error"] += " — the Cloud admin account has no role on this tenant yet (open it once in the Cloud console, or use \"Add Me to Tenant\")."
            if not out["error"]:
                with self.lock:
                    self.cache[key] = (_time.monotonic(), out)
            return out

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            return list(pool.map(one, tenants))


def clean_dashboard_filters(raw):
    raw = raw if isinstance(raw, dict) else {}
    iso = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$")
    start, end = str(raw.get("start_time") or ""), str(raw.get("end_time") or "")
    if not iso.match(start) or not iso.match(end):
        return None, "start_time and end_time must be UTC ISO timestamps, e.g. 2026-11-08T23:39:41.513Z."
    exec_type = str(raw.get("execution_type") if raw.get("execution_type") is not None else "All").strip() or "All"
    if exec_type != "All" and exec_type not in {str(i) for i, _ in DASHBOARD_EXECUTION_TYPES}:
        return None, "Unknown execution type."
    return {
        "start_time": start,
        "end_time": end,
        "policy_group": str(raw.get("policy_group") or "All").strip() or "All",
        "include_children": raw.get("include_children") is not False,
        "execution_type": exec_type,
    }, None


def summarize_steps(steps):
    counts = {}
    for s in steps:
        counts[s["outcome"]] = counts.get(s["outcome"], 0) + 1
    if counts.get("error"):
        status = "error"
    elif counts.get("planned"):
        status = "changes"
    elif counts.get("done"):
        status = "applied"
    elif counts.get("differs"):
        status = "differs"
    elif counts.get("skipped"):
        # Something was asked for but couldn't be done (e.g. an allowlist
        # that doesn't exist on the tenant and can't be created yet, or a
        # policy group the tenant doesn't have). Never report that as "in
        # sync" (Ryan, 2026-11-15).
        status = "blocked"
    else:
        status = "in_sync"
    return status, counts


# --------------------------------------------------------------------------
# Storage, runs, routes
# --------------------------------------------------------------------------

def _empty_config():
    # dashboard_include_reference: the reference tenant may be one of the
    # MSP's customers (real data to build policies on) or a lab that mirrors
    # their customers' environments (Ryan, 2026-11-08). On by default; an MSP
    # with a lab reference unticks it in Tenant Configuration.
    # discovery: optional hints for "Discover tenants" (the MSP admin's login
    # email and top-level directory ID), only needed if the Cloud won't list
    # tenants from the API key alone.
    return {"msp_name": "", "dashboard_include_reference": True, "discovery": {}, "connection": {}, "reference": None, "managed_tenants": [],
            "inventory": None, "runs": [], "baseline_name_map": {}}


class MspStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()

    def load(self):
        with self.lock:
            data = _empty_config()
            if os.path.exists(self.path):
                try:
                    with open(self.path, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                    if isinstance(loaded, dict):
                        data.update({k: v for k, v in loaded.items() if k in data})
                except (json.JSONDecodeError, OSError):
                    log.exception("Couldn't read %s", self.path)
            return data

    def save(self, data):
        with self.lock:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, self.path)

    def update(self, fn):
        with self.lock:
            data = self.load()
            result = fn(data)
            self.save(data)
            return result


def connection_error(conn):
    if not (conn or {}).get("base_domain"):
        return "Set the Cloud base domain under Connection first."
    if not (conn or {}).get("api_key"):
        return "Save a Cloud admin API key under Connection first."
    return None


class MspRunManager:
    def __init__(self, adapter, store, on_apply_done=None):
        self.a = adapter
        self.store = store
        self.lock = threading.Lock()
        self.active = None
        self.on_apply_done = on_apply_done  # e.g. clear the status cache so colors refresh

    def start(self, sel, reference, tenants, conn, dry_run):
        update_differing = sel["update_differing"]
        if sel.get("trust_on_reference") and sel["items"].get("publishers"):
            # The one write this tool makes to the reference: only the
            # ticked publishers, and only when asked for.
            tenants = [dict(reference, id="reference", is_reference=True,
                            label=f"{reference.get('label') or 'Reference'} (reference)")] + list(tenants)
        with self.lock:
            if self.active and self.active.get("status") == "running":
                return None, "Another run is still in progress — wait for it to finish."
            run = {
                "id": str(uuid.uuid4()),
                "mode": "preview" if dry_run else "apply",
                "update_differing": bool(update_differing),
                "label": selection_label(sel),
                "selection": copy.deepcopy(sel),
                "reference_label": reference.get("label"),
                "status": "running",
                "phase": "Reading the reference tenant…",
                "started_at": _now(),
                "finished_at": None,
                "notes": [],
                "resolved": None,
                "tenants": [
                    {"id": t.get("id"), "label": t.get("label") or t.get("tenant_id"), "tenant_id": t.get("tenant_id"),
                     "is_reference": bool(t.get("is_reference")), "status": "pending", "counts": {}, "steps": []}
                    for t in tenants
                ],
            }
            self.active = run
        self._persist(run)
        threading.Thread(target=self._run, args=(run, reference, tenants, conn, dry_run, update_differing), daemon=True).start()
        return run, None

    def _run(self, run, reference, tenants, conn, dry_run, update_differing):
        learned = dict(self.store.load().get("baseline_name_map") or {})
        try:
            with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                try:
                    spec, notes = ReferenceReader(self.a, reference, learned).resolve_selection(run["selection"])
                except ReferenceReadError as e:
                    run["notes"] = [str(e)]
                    for slot in run["tenants"]:
                        slot["status"] = "error"
                        slot["steps"] = [{"kind": "reference", "item": "Reference tenant", "outcome": "error",
                                          "detail": "Nothing was done: the reference tenant couldn't be read."}]
                    return
                run["notes"] = notes
                run["resolved"] = spec
                run["phase"] = ""
                self._persist(run)
                for slot, tenant in zip(run["tenants"], tenants):
                    slot["status"] = "running"
                    try:
                        tspec = {"publishers": spec.get("publishers") or []} if tenant.get("is_reference") else spec
                        steps = TenantRun(self.a, tenant, dry_run, update_differing, learned).run(tspec)
                    except Exception as e:
                        log.exception("MSP run crashed on tenant %s", slot["label"])
                        steps = [{"kind": "tenant", "item": slot["label"], "outcome": "error", "detail": f"Unexpected error: {e}"}]
                    slot["steps"] = steps
                    slot["status"], slot["counts"] = summarize_steps(steps)
                    self._persist(run, learned)
        except Exception as e:
            log.exception("MSP run crashed")
            run["notes"] = list(run.get("notes") or []) + [f"Run stopped by an unexpected error: {e}"]
        finally:
            run["status"] = "done"
            run["phase"] = ""
            run["finished_at"] = _now()
            self._persist(run, learned)
            if not dry_run and self.on_apply_done:
                self.on_apply_done()

    def _persist(self, run, learned=None):
        def fn(data):
            runs = [r for r in data.get("runs") or [] if r.get("id") != run["id"]]
            runs.insert(0, copy.deepcopy(run))
            data["runs"] = runs[:MAX_RUN_HISTORY]
            if learned:
                data["baseline_name_map"] = dict(data.get("baseline_name_map") or {}, **learned)
        self.store.update(fn)

    def get(self, run_id):
        if self.active and self.active.get("id") == run_id:
            return copy.deepcopy(self.active)
        return next((r for r in self.store.load().get("runs") or [] if r.get("id") == run_id), None)


def run_summary(run):
    totals = {}
    for t in run.get("tenants") or []:
        totals[t.get("status")] = totals.get(t.get("status"), 0) + 1
    summary = {k: run.get(k) for k in ("id", "mode", "label", "status", "started_at", "finished_at", "update_differing", "reference_label")}
    summary["tenant_count"] = len(run.get("tenants") or [])
    summary["tenant_status_counts"] = totals
    return summary


def _key_preview(value):
    value = str(value or "")
    return f"{value[:4]}…{value[-4:]}" if len(value) > 10 else ("•" * len(value))


def create_msp_blueprint(adapter, config_path):
    missing = [f for f in REQUIRED_ADAPTER_FUNCTIONS if not callable(getattr(adapter, f, None))]
    if missing:
        raise ValueError(f"MSP adapter is missing: {', '.join(missing)}")

    store = MspStore(config_path)
    status = StatusChecker(adapter)
    runs = MspRunManager(adapter, store, on_apply_done=status.clear)
    dashboard = DashboardReader(adapter)
    publisher_pool = PublisherPool(adapter)
    inventory_lock = threading.Lock()
    bp = Blueprint("msp", __name__, url_prefix="/msp")

    def fail(msg, code=400):
        return jsonify({"success": False, "error": msg}), code

    # -- connection -------------------------------------------------------------
    def connection_payload(conn):
        return {"base_domain": conn.get("base_domain") or "", "has_key": bool(conn.get("api_key")),
                "key_preview": _key_preview(conn.get("api_key")) if conn.get("api_key") else ""}

    @bp.route("/connection", methods=["GET"])
    def connection_get():
        return jsonify(connection_payload(store.load().get("connection") or {}))

    @bp.route("/connection", methods=["POST"])
    def connection_set():
        body = request.get_json(silent=True) or {}
        domain = re.sub(r"^https?://", "", str(body.get("base_domain") or "").strip()).strip("/")
        if not domain:
            return fail("Enter the Cloud base domain, e.g. am.appenforcement.com.")
        key = str(body.get("api_key") or "").strip()

        def fn(data):
            conn = data.get("connection") or {}
            conn["base_domain"] = domain
            if key:
                conn["api_key"] = key
            data["connection"] = conn
            return conn
        conn = store.update(fn)
        return jsonify(dict(connection_payload(conn), success=True))

    @bp.route("/connection/import-nfr", methods=["POST"])
    def connection_import():
        nfr = adapter.nfr_connection() or {}
        if not nfr.get("base_domain") or not nfr.get("api_key"):
            return fail("NFR Tracking doesn't have a saved Cloud connection to copy.")

        def fn(data):
            data["connection"] = {"base_domain": nfr["base_domain"], "api_key": nfr["api_key"]}
            return data["connection"]
        conn = store.update(fn)
        return jsonify(dict(connection_payload(conn), success=True))

    # -- tenants ------------------------------------------------------------------
    def tenants_payload(data):
        return {"reference": data.get("reference"), "managed": data.get("managed_tenants") or []}

    @bp.route("/tenants", methods=["GET"])
    def tenants_get():
        return jsonify(tenants_payload(store.load()))

    @bp.route("/reference", methods=["POST"])
    def reference_set():
        entry, err = clean_tenant_entry(request.get_json(silent=True) or {})
        if err:
            return fail(err)

        def fn(data):
            if any(t.get("tenant_id") == entry["tenant_id"] for t in data.get("managed_tenants") or []):
                return "That tenant is in the managed list — remove it there first. The reference tenant is never a push target."
            old = data.get("reference") or {}
            if old.get("tenant_id") != entry["tenant_id"]:
                data["inventory"] = None  # a different tenant: the cached inventory no longer applies
            data["reference"] = entry
            return None
        err = store.update(fn)
        if err:
            return fail(err)
        return jsonify(dict(tenants_payload(store.load()), success=True))

    @bp.route("/managed", methods=["POST"])
    def managed_add():
        entry, err = clean_tenant_entry(request.get_json(silent=True) or {})
        if err:
            return fail(err)
        entry["id"] = str(uuid.uuid4())

        def fn(data):
            if (data.get("reference") or {}).get("tenant_id") == entry["tenant_id"]:
                return "That's the reference tenant — it can't also be a managed tenant."
            if any(t.get("tenant_id") == entry["tenant_id"] for t in data.get("managed_tenants") or []):
                return "That tenant is already in the managed list."
            data.setdefault("managed_tenants", []).append(entry)
            return None
        err = store.update(fn)
        if err:
            return fail(err)
        return jsonify(dict(tenants_payload(store.load()), success=True))

    @bp.route("/managed/delete", methods=["POST"])
    def managed_delete():
        tid = str((request.get_json(silent=True) or {}).get("id") or "")

        def fn(data):
            before = len(data.get("managed_tenants") or [])
            data["managed_tenants"] = [t for t in data.get("managed_tenants") or [] if t.get("id") != tid]
            return len(data["managed_tenants"]) < before
        if not store.update(fn):
            return fail("Tenant not found.", 404)
        return jsonify(dict(tenants_payload(store.load()), success=True))

    # -- reference inventory ------------------------------------------------------
    @bp.route("/inventory", methods=["GET"])
    def inventory_get():
        return jsonify({"inventory": store.load().get("inventory")})

    @bp.route("/inventory/refresh", methods=["POST"])
    def inventory_refresh():
        data = store.load()
        reference = data.get("reference")
        if not reference:
            return fail("Set the reference tenant first.")
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        if not inventory_lock.acquire(blocking=False):
            return fail("The reference tenant is already being read — wait a moment.", 409)
        try:
            with adapter.connection(conn["base_domain"], conn["api_key"]):
                inv = ReferenceReader(adapter, reference, data.get("baseline_name_map")).inventory()
        except ReferenceReadError as e:
            return fail(str(e), 502)
        finally:
            inventory_lock.release()
        inv["reference_tenant_id"] = reference["tenant_id"]

        def fn(d):
            d["inventory"] = inv
        store.update(fn)
        return jsonify({"success": True, "inventory": inv})

    # -- replication sets ---------------------------------------------------------
    # -- the page -------------------------------------------------------------------
    @bp.route("/ui", methods=["GET"])
    def ui():
        return render_template("msp_manager.html")

    # -- MSP details ------------------------------------------------------------------
    def settings_payload(d):
        disc = d.get("discovery") or {}
        return {"msp_name": d.get("msp_name") or "",
                "dashboard_include_reference": d.get("dashboard_include_reference") is not False,
                "discovery_email": disc.get("email") or "", "discovery_directory_id": disc.get("directory_id") or ""}

    @bp.route("/settings", methods=["GET"])
    def settings_get():
        return jsonify(settings_payload(store.load()))

    @bp.route("/settings", methods=["POST"])
    def settings_set():
        """Partial update: {msp_name?, dashboard_include_reference?}."""
        body = request.get_json(silent=True) or {}
        changes = {}
        if "msp_name" in body:
            name = str(body.get("msp_name") or "").strip()
            if not name:
                return fail("Enter the MSP's name.")
            if len(name) > MAX_NAME_LENGTH:
                return fail(f"The name must be {MAX_NAME_LENGTH} characters or fewer.")
            changes["msp_name"] = name
        if "dashboard_include_reference" in body:
            changes["dashboard_include_reference"] = bool(body.get("dashboard_include_reference"))
        if not changes:
            return fail("Nothing to save.")

        def fn(d):
            d.update(changes)
        store.update(fn)
        return jsonify(dict(settings_payload(store.load()), success=True))

    @bp.route("/managed/update", methods=["POST"])
    def managed_update():
        body = request.get_json(silent=True) or {}
        tid = str(body.get("id") or "")
        entry, err = clean_tenant_entry(body)
        if err:
            return fail(err)

        def fn(data):
            tenants = data.get("managed_tenants") or []
            target = next((t for t in tenants if t.get("id") == tid), None)
            if not target:
                return "Tenant not found."
            if (data.get("reference") or {}).get("tenant_id") == entry["tenant_id"]:
                return "That's the reference tenant — it can't also be a managed tenant."
            if any(t.get("tenant_id") == entry["tenant_id"] and t.get("id") != tid for t in tenants):
                return "Another managed tenant already has that tenant ID."
            target.update(entry)
            return None
        err = store.update(fn)
        if err:
            return fail(err)
        status.clear()
        return jsonify(dict(tenants_payload(store.load()), success=True))

    # -- tenant discovery -------------------------------------------------------------
    @bp.route("/discover", methods=["POST"])
    def discover():
        """Lists every tenant the connection's API key can reach, marked
        reference / managed / available, for the Tenant Configuration pick
        list. Body: {email?, directory_id?} (optional hints, remembered)."""
        body = request.get_json(silent=True) or {}
        email = str(body.get("email") or "").strip()
        directory_id = str(body.get("directory_id") or "").strip()

        def remember(d):
            d["discovery"] = {"email": email, "directory_id": directory_id}
        store.update(remember)
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        with adapter.connection(conn["base_domain"], conn["api_key"]):
            found, method, err = adapter.discover_tenants(email, directory_id)
        if err:
            return fail(err, 502)
        ref_id = (data.get("reference") or {}).get("tenant_id")
        managed = {t.get("tenant_id") for t in data.get("managed_tenants") or []}
        out = []
        for t in found or []:
            roles = t.get("roles") or []
            out.append(dict(
                t,
                status="reference" if t["tenant_id"] == ref_id else "managed" if t["tenant_id"] in managed else "available",
                # Roles only come with the sign-in profile; [] = unknown.
                can_edit=None if not roles else any(r.startswith("edit_") for r in roles),
            ))
        out.sort(key=lambda t: (" / ".join(t["path"]).lower(), t["name"].lower()))
        return jsonify({"success": True, "method": method, "tenants": out, "discovered_at": _now()})

    @bp.route("/managed/bulk", methods=["POST"])
    def managed_bulk():
        """Adds several managed tenants at once (from the discovery list).
        Body: {tenants: [{label, tenant_id, directory_id}]}. Skips the
        reference tenant and ones already managed."""
        raw = (request.get_json(silent=True) or {}).get("tenants") or []
        entries, problems = [], []
        for r in raw if isinstance(raw, list) else []:
            entry, err = clean_tenant_entry(r)
            if err:
                problems.append(f"{(r or {}).get('label') or (r or {}).get('tenant_id') or '?'}: {err}")
            else:
                entries.append(entry)
        if not entries:
            return fail("; ".join(problems) or "Tick at least one tenant to add.")

        def fn(data):
            ref_id = (data.get("reference") or {}).get("tenant_id")
            have = {t.get("tenant_id") for t in data.get("managed_tenants") or []}
            added, skipped = [], []
            for e in entries:
                if e["tenant_id"] == ref_id:
                    skipped.append(f"{e['label']} (it's the reference tenant)")
                elif e["tenant_id"] in have:
                    skipped.append(f"{e['label']} (already managed)")
                else:
                    e["id"] = str(uuid.uuid4())
                    data.setdefault("managed_tenants", []).append(e)
                    have.add(e["tenant_id"])
                    added.append(e["label"])
            return added, skipped
        added, skipped = store.update(fn)
        return jsonify(dict(tenants_payload(store.load()), success=True, added=added, skipped=skipped + problems))

    # -- colors: per tenant x group x item state ------------------------------------------
    @bp.route("/status", methods=["POST"])
    def status_check():
        """Body: {tenant_ids, groups, message_from?, refresh?}. With no
        tenant_ids, reports the reference tenant itself (so browsing the
        library still looks like the console)."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        library = data.get("inventory")
        if not library:
            return fail("Read the reference tenant's library first.")
        groups = [str(g) for g in body.get("groups") or [] if str(g).strip()]
        if not groups:
            return jsonify({"tenants": [], "groups": []})
        wanted = {str(x) for x in body.get("tenant_ids") or []}
        if wanted:
            tenants = [t for t in data.get("managed_tenants") or [] if str(t.get("id")) in wanted]
        else:
            ref = data.get("reference")
            if not ref:
                return fail("Set the reference tenant first.")
            tenants = [dict(ref, id="reference", is_reference=True)]
        results = status.check(conn, tenants, library, groups, str(body.get("message_from") or "").strip(),
                               data.get("baseline_name_map") or {}, refresh=bool(body.get("refresh")))
        return jsonify({"tenants": results, "groups": groups, "checked_at": _now()})

    # -- Bulk Add (publisher pool) ---------------------------------------------------------
    @bp.route("/publishers/pool", methods=["GET"])
    def publishers_pool():
        """?window=1d|1w|2w|1mo&refresh=1 — the merged Publisher Summary of
        the reference and every managed tenant. Read-only."""
        window = request.args.get("window") or "1mo"
        if window not in dict(PUBLISHER_WINDOWS):
            return fail("Unknown time window.")
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        reference = data.get("reference")
        if not reference:
            return fail("Set the reference tenant first.")
        out = publisher_pool.read(conn, reference, data.get("managed_tenants") or [], window,
                                  refresh=request.args.get("refresh") in ("1", "true"))
        return jsonify(dict(out, windows=[{"key": k, "name": n} for k, n in PUBLISHER_WINDOWS]))

    # -- dashboard ------------------------------------------------------------------------
    @bp.route("/dashboard/options", methods=["GET"])
    def dashboard_options():
        return jsonify({
            "time": [{"key": k, "name": n} for k, n in DASHBOARD_TIME_OPTIONS],
            "execution_types": [{"index": i, "name": n} for i, n in DASHBOARD_EXECUTION_TYPES],
        })

    @bp.route("/dashboard", methods=["POST"])
    def dashboard_read():
        """Body: {tenant_id? (one tenant, or omitted for all managed tenants),
        start_time, end_time, policy_group, include_children, execution_type,
        refresh?}. Returns totals plus per-tenant numbers."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        f, err = clean_dashboard_filters(body)
        if err:
            return fail(err)
        reference = data.get("reference")
        ref_entry = dict(reference, id="reference", label=f"{reference.get('label')} (reference)") if reference else None
        one = str(body.get("tenant_id") or "")
        if one == "reference":
            if not ref_entry:
                return fail("No reference tenant is set.")
            tenants = [ref_entry]
        elif one:
            tenants = [t for t in data.get("managed_tenants") or [] if str(t.get("id")) == one]
            if not tenants:
                return fail("That tenant isn't in the managed list.")
        else:
            tenants = list(data.get("managed_tenants") or [])
            if ref_entry and data.get("dashboard_include_reference") is not False:
                tenants.insert(0, ref_entry)
        if not tenants:
            return jsonify({"tenants": [], "totals": aggregate_dashboard([]), "filters": f})
        per = dashboard.read(conn, tenants, f, refresh=bool(body.get("refresh")))
        return jsonify({"tenants": [{"id": t["id"], "label": t["label"], "error": t.get("error"), "group_missing": t.get("group_missing", False)} for t in per],
                        "totals": aggregate_dashboard(per), "filters": f, "read_at": _now()})

    # -- runs ---------------------------------------------------------------------------
    @bp.route("/runs", methods=["POST"])
    def runs_start():
        """Body: the page's selection + mode. "preview" = Apply Changes
        (stage, read-only); "apply" = Replicate Changes Now."""
        body = request.get_json(silent=True) or {}
        mode = body.get("mode")
        if mode not in ("preview", "apply"):
            return fail("mode must be 'preview' or 'apply'.")
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        reference = data.get("reference")
        if not reference:
            return fail("Set the reference tenant first.")
        sel, err = clean_selection(body)
        if err:
            return fail(err)
        wanted = set(sel["tenant_ids"])
        tenants = [t for t in data.get("managed_tenants") or [] if str(t.get("id")) in wanted]
        if not tenants:
            return fail("None of the ticked tenants are in the managed list any more.")
        run, err = runs.start(sel, reference, tenants, conn, dry_run=(mode == "preview"))
        if err:
            return fail(err, 409)
        return jsonify({"success": True, "run": run_summary(run)})

    @bp.route("/runs", methods=["GET"])
    def runs_list():
        return jsonify({"runs": [run_summary(r) for r in store.load().get("runs") or []]})

    @bp.route("/runs/<run_id>", methods=["GET"])
    def runs_get(run_id):
        run = runs.get(run_id)
        if not run:
            return jsonify({"error": "Run not found."}), 404
        return jsonify({"run": run})

    bp.msp_store = store
    bp.msp_runs = runs
    return bp
