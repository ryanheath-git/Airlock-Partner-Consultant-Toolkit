"""MSP Manager — engine and routes for the SE Toolkit's MSP Manager tab
(and, later, the standalone MSP tool).

(The file keeps its original name, msp_policy_packs.py, from the first
version of this feature, a widget built around hand-built packs; that became
a reference-tenant widget on 2026-11-03 and the MSP Manager tab on
2026-11-08. Keeping the name avoids leaving an orphan file behind.)

Built so it can be lifted out of the SE Toolkit unchanged: this module never
imports app.py. Every Cloud API call goes through an *adapter* (see
REQUIRED_ADAPTER_FUNCTIONS), the page is its own template
(templates/msp_manager.html, served at /msp/ui and embedded in the toolkit's
MSP Manager tab), and the data lives in its own config file
(msp_config.json): the MSP's name, its own Cloud connection, a reference
tenant and a managed-tenant list (entered from scratch, never shared with NFR
Tracking), the cached reference library, and run history. One MSP per
install.

The model (Ryan, 2026-11-08):
  - The MSP builds everything in the *reference tenant* in the Airlock
    console itself. This tool only ever READS the reference tenant: it's a
    *library* (not a blueprint) of blocklists, allowlists, baselines and
    group settings to pick from.
  - On the Policies Replication page the MSP ticks managed tenants (center),
    target policy groups (left, the reference's tree; matched by NAME on
    each tenant — the MSP keeps the same group structure everywhere) and
    library items (right). Every ticked item is applied to every ticked
    group on every ticked tenant.
  - Items are colored like the console, for the ticked tenants x groups:
    green = assigned, red = available but not assigned, blue = inherited
    from a parent group, purple = doesn't exist on the tenant yet, so
    replicating would create it. Several tenants/groups -> a mixed count.
  - "Apply Changes" stages the selection: a preview (read-only) per tenant.
    "Replicate Changes Now" pushes exactly the staged selection.

What a push does on each managed tenant:
  - creates what's missing (blocklist, its rules, baseline) and assigns to
    the ticked groups — assigning only when Airlock clearly reports "not
    applied"; an unrecognized status is left alone;
  - allowlists: created (in the same-named top-level category) if the
    tenant has none by that name, missing metadata rules added with their
    elevation setting, and assigned to the ticked groups — like blocklists
    (allowlist and blocklist hashes are copied add-only; a missing subcategory is created);
  - an existing blocklist or allowlist rule whose definition differs is
    reported and left alone, unless the run's "Also update items that
    differ" is ticked;
  - the notification message is set on the ticked groups wherever it
    differs;
  - nothing is ever deleted, and the reference tenant is never written to.
"""

import copy
import json
import logging
import os
import re
import threading
import uuid
from datetime import datetime, timedelta, timezone

from flask import Blueprint, jsonify, render_template, request

log = logging.getLogger("app.msp")

MAX_RUN_HISTORY = 25
MAX_NAME_LENGTH = 120

AIRLOCK_SYSTEM_POLICY_PARENT = "Airlock Policies"
POLICY_GLOBAL_SETTINGS_PARENT = "global-policy-settings"
OS_TYPES = ("Windows", "MacOS", "Linux")

# Criteria fields that only exist for Windows rules (from the captured
# tenant-blocklist-metarule-options-list). Used to infer a reference rule's
# OS when the rule list doesn't report it.
WINDOWS_ONLY_FIELDS = {"description", "thumbprint", "rootprint", "tbshash", "digest", "group", "csgroup"}

# Library item types the Policies Replication page can replicate. Trusted
# publishers are keyed "<OSType>::<Name>" and trusted per policy group with
# the Bulk Add page's call (captured 2026-11-15) — they come either from the
# reference's Publishers list or from the Bulk Add pool (the Publisher
# Summary of the reference + every managed tenant). Allowlists are matched
# by name: created in the same-named top-level category if missing, their
# metadata rules copied (elevation included), and assigned (all captured
# 2026-11-15). Hash (file) entries are copied add-only; a missing subcategory is created.
ITEM_TYPES = ("blocklists", "allowlists", "baselines", "publishers", "paths", "processes", "installers")

# Per-group entries (captured 2026-11-15): replicated by value onto each
# ticked group, matched by key. Paths by their text; processes as
# "<ProcType>::<Name>"; trusted installer processes as "<os>::<Name>" (0
# Windows, 1 macOS), plus the special key below for the group's three
# Configure Trusted Installer switches.
INSTALLER_SWITCHES_KEY = "switches"
INSTALLER_SWITCH_FIELDS = ("MicrosoftManagedInstallerTrust", "WindowsTrustedInstallerTrust", "MacOSManagedInstallerTrust")
INSTALLER_SWITCH_LABELS = {"MicrosoftManagedInstallerTrust": "Microsoft Managed Installer claims",
                           "WindowsTrustedInstallerTrust": "Airlock Trusted Installer (Windows)",
                           "MacOSManagedInstallerTrust": "macOS (Jamf)"}
SWITCH_VALUE_LABELS = {0: "Disabled", 1: "Enabled", 2: "Enabled with Trusted Logging"}
READ_ONLY_TYPES = ()

PUBLISHER_WINDOWS = (("1d", "1 Day"), ("1w", "1 Week"), ("2w", "2 Weeks"), ("1mo", "1 Month"))
PUBLISHER_POOL_CACHE_SECONDS = 300
# The Publisher Summary's bucket for unsigned files — not a publisher you can trust.
PUBLISHER_NOT_SIGNED = "Not Signed"

# Per (tenant, policy group, item) states — the console's colors.
STATE_ASSIGNED = "assigned"            # green
STATE_NOT_ASSIGNED = "not_assigned"    # red
STATE_INHERITED = "inherited"          # blue
STATE_CREATE = "create"                # purple: not on the tenant; replicating creates it
STATE_CANT_CREATE = "cant_create"      # not on the tenant and can't be created yet (allowlists)
STATE_GROUP_MISSING = "group_missing"  # the tenant has no policy group with this name
STATE_UNKNOWN = "unknown"              # Airlock returned a status this tool can't place

STATUS_CACHE_SECONDS = 120
STATUS_WORKERS = 6

REQUIRED_ADAPTER_FUNCTIONS = (
    "connection",                   # (base_domain, api_key) -> context manager: Cloud calls in it use these credentials
    "nfr_connection",               # () -> {base_domain, api_key} from NFR Tracking (for the optional copy button)
    "list_policies",                # (tid, did) -> ([{id, name, parent}], err)
    "list_blocklists",              # (tid, did) -> ([{ID, Name, ...}], err)
    "create_blocklist",             # (tid, did, name) -> (blocklist_id, err)
    "list_blocklist_rules",         # (tid, did, blocklist_id) -> ([{ID, Name, Criteria, Setting, ...}], err)
    "save_blocklist_rule",          # (tid, did, blocklist_id, spec) -> (ok, err)  creates, or updates a same-named rule
    "list_blocklist_hashes",        # (tid, did, blocklist_id) -> ([sha256], err)
    "add_blocklist_hashes",         # (tid, did, blocklist_id, [sha256]) -> (added_count, err)
    "blocklist_statuses",           # (tid, did, group_ref) -> ([{ID, Status}], err)
    "assign_blocklist",             # (tid, did, group_ref, blocklist_id, name) -> (ok, err)
    "list_reference_baselines",     # (tid, did) -> ([{FullName, ...}], err)
    "add_reference_baseline",       # (tid, did, reference_entry) -> (ok, err)
    "list_tenant_baselines",        # (tid, did) -> ([{ID, Name, Timestamp}], err)
    "baseline_statuses",            # (tid, did, group_ref) -> ([{ID, Name, Status, IsInherited, IsApproved}], err)
    "assign_baseline",              # (tid, did, group_ref, baseline_id, baseline_name) -> (ok, err)
    "get_policy_settings",          # (tid, did, group_ref) -> (settings_dict, err)
    "save_notification_message",    # (tid, did, group_ref, loaded_settings, message) -> (ok, err)
    "list_allowlists",              # (tid, did) -> ([{ID, Name, Category, Fcount, ...}], err)
    "list_allowlist_rules",         # (tid, did, allowlist_id) -> ([{ID, Name, OSType, IntegrityLevel, Criteria}], err)
    "create_allowlist_rule",
    "list_allowlist_hashes",        # (tid, did, allowlist_id) -> ([{sha256, name, path}], err)
    "add_allowlist_hashes",         # (tid, did, allowlist_id, [sha256]) -> (added_count, err)        # (tid, did, allowlist_id, spec) -> (ok, err)
    "list_group_publishers",        # (tid, did, group_ref) -> ([{ID, Name, FriendlyName, OSType, IsInherited}], err)
    "publisher_summary",            # (tid, did, window) -> ([{Name, FriendlyName, OSType, Count, CommonlyTrusted}], err)
    "trust_publishers",             # (tid, did, group_ref, [{name, os_type}]) -> (ok, err)
    "list_group_paths",             # (tid, did, group_ref) -> ([{name, inherited}], err)
    "add_group_paths",              # (tid, did, group_ref, [name]) -> (ok, err)
    "list_group_processes",         # (tid, did, group_ref) -> ([{name, proc_type, label, inherited}], err)
    "add_group_processes",          # (tid, did, group_ref, [{name, proc_type}]) -> (ok, err)
    "list_group_installers",        # (tid, did, group_ref) -> ([{name, os, mode, publisher, inherited}], err)
    "add_group_installers",         # (tid, did, group_ref, [{name, os, mode, publisher}]) -> (ok, err)
    "get_installer_switches",       # (tid, did, group_ref) -> ({field: 0|1|2}, err)
    "set_installer_switches",       # (tid, did, group_ref, {field: 0|1|2}) -> (ok, err)
    "list_webhooks",                # (tid, did) -> ([webhook], err)
    "webhook_options",              # (tid, did) -> ({templates: [...]}, err)
    "create_webhook",               # (tid, did, spec, secret) -> (ok, err)
    "update_webhook",               # (tid, did, webhook_id, spec, secret|None) -> (ok, err)
    "get_exception_email",          # (tid, did) -> (settings|None, err)
    "save_exception_email",         # (tid, did, existing_id|None, {enabled, recipients, subject}) -> (ok, err)
    "report_tenant_license",        # (tid, did) -> ({name, allocated, used, unmanaged, disabled_by_expiry}, err)
    "report_directory_license",     # (did) -> ({name, capacity, dates_enabled, start, end}, err)
    "report_agent_summary",         # (tid, did) -> (agent/v1/summary, err)
    "report_executive_section",     # (tid, did, days, section, chunk_date=None) -> (executive-overview, err)
    "report_enforcement_readiness", # (tid, did, days, threshold) -> (overview, err)
    "report_applications",          # (tid, did) -> (app-context applications, err)
    "allowlist_group_statuses",     # (tid, did, group_ref) -> ([{ID, Text, Status, Type}], err)
    "list_allowlist_categories",    # (tid, did) -> ([{ID, Name}], err)
    "create_allowlist",             # (tid, did, category_id, name) -> (allowlist_entry, err)
    "create_allowlist_subcategory", # (tid, did, category_id, name) -> ({ID, Name}, err)
    "assign_allowlist",             # (tid, did, group_ref, allowlist_entry) -> (ok, err)
    "update_allowlist_rule",        # (tid, did, allowlist_id, existing_rule, spec) -> (ok, err)
    "dashboard_get",                # (tid, did, path, params) -> (json, err)  reporting/v1/dashboard/<path>
    "server_activity",              # (tid, did, from, to, search, task, skip, take) -> ({count, rows}, err)
    "create_policy_group",          # (tid, did, parent_id, name) -> ({id, name, parent}, err)   tenant-policy-add-new-group
    "set_policy_group_mode",        # (tid, did, group_ref, audit: bool) -> (ok, err)
    "server_activity_tasks",        # (tid, did) -> ([task display name], err)
    "realtime_activity",            # (tid, did, from, max_rows, types{field: bool}) -> ([row], err)
    "discover_tenants",             # (email, directory_id) -> ([{tenant_id, directory_id, name, path, roles, source}], method, err)
)

# Dashboard filter values, as the console's filter-list calls return them
# (captured 2026-11-08). Execution types are sent by Index; only "All" has
# been seen on the wire, so a specific type is not yet live-confirmed.
DASHBOARD_TIME_OPTIONS = [("today", "Today"), ("15m", "15 Minutes"), ("1h", "1 Hour"), ("1d", "1 Day"),
                          ("3d", "3 Days"), ("1w", "1 Week"), ("2w", "2 Weeks"), ("1mo", "1 Month")]
DASHBOARD_EXECUTION_TYPES = [(-1, "All"), (1, "Blocked Execution"), (2, "Untrusted Execution [Audit]"),
                             (3, "Untrusted Execution [OTP]"), (-2, "Untrusted Execution"), (0, "Trusted Hash Execution"),
                             (4, "Trusted Path Execution"), (5, "Trusted Publisher Execution"), (8, "Trusted Process Execution"),
                             (10, "Trusted Metadata Execution"), (17, "Trusted Installer Execution"), (9, "Constrained Execution"),
                             (6, "Blocklist Execution"), (7, "Blocklist Execution [Audit]")]
# Extension Overview: the same reporting calls with browser_exec=true and its
# own type list (tenant-dashboard-filter-execution-type-list with
# {TenantDashboardBrowserExec:true}, captured 2026-11-16).
DASHBOARD_BROWSER_EXECUTION_TYPES = [(-1, "All"), (11, "Trusted Browser Execution"), (12, "Blocked Browser Execution"),
                                     (13, "Untrusted Browser Execution [Audit]"), (14, "Untrusted Browser Execution [OTP]"),
                                     (-3, "Untrusted Browser Execution"), (15, "Blocklist Browser Execution [Audit]"),
                                     (16, "Blocklist Browser Execution")]
# Server Activity History + Realtime Activity (captured 2026-11-16).
SERVER_ACTIVITY_MAX_DAYS = 31
SERVER_ACTIVITY_PER_TENANT = 500      # newest rows read per tenant; the count says how many exist
SERVER_ACTIVITY_CACHE_SECONDS = 30
REALTIME_TYPES = [("BlockedExecution", "Blocked Execution"), ("UntrustedExecutionAudit", "Untrusted Execution [Audit]"),
                  ("UntrustedExecutionOTP", "Untrusted Execution [OTP]"), ("BlocklistExecution", "Blocklist Execution"),
                  ("BlocklistExecutionAudit", "Blocklist Execution [Audit]")]
REALTIME_MAX_ROWS = 1000
DASHBOARD_COUNTS = [f"{kind}/{measure}" for kind in ("blocked", "untrusted") for measure in ("total", "unique", "unreviewed")]
DASHBOARD_CACHE_SECONDS = 60
DASHBOARD_TOP_N = 15


def _now():
    return datetime.now(timezone.utc).isoformat()


# --------------------------------------------------------------------------
# Pure helpers (no I/O)
# --------------------------------------------------------------------------

_NAME_UNSAFE = re.compile(r"[^A-Za-z0-9 ]+")


def airlock_safe_name(name):
    """The name with everything but letters, digits and spaces removed —
    some create calls (tenant-blocklist-create, seen 2026-11-15) reject
    anything else with "input must only contain alpha-numeric characters",
    even though the console shows names like "... (main)"."""
    return re.sub(r"\s+", " ", _NAME_UNSAFE.sub(" ", name or "")).strip()


def is_name_rejection(err):
    text = str(err or "").lower()
    return "alpha-numeric" in text or "alphanumeric" in text


def find_named(items, name, key="Name"):
    """Items whose name is the reference's name, or — when none is — its
    cleaned-up form (what replication creates when Airlock rejects the
    original), so a copy created under the cleaned name still matches."""
    exact = [i for i in items or [] if i.get(key) == name]
    if exact:
        return exact
    safe = airlock_safe_name(name)
    if not safe or safe == name:
        return []
    return [i for i in items or [] if i.get(key) == safe]


def normalize_baseline_name(value):
    """Reference catalog FullNames and tenant baseline Names are formatted
    differently ("Windows 11-25H2-x64-April 2026.tar.gz" vs "Windows 11 25H2
    x64 April 2026 (Reference)"). Maps both to one comparable form. Only the
    Windows shape is confirmed from a real capture; the learned
    baseline_name_map covers anything this gets wrong after the first add."""
    s = str(value or "").strip().lower()
    s = re.sub(r"\.tar\.gz$", "", s)
    s = s.replace("(reference)", "")
    s = re.sub(r"[-\s]+", " ", s)
    return s.strip()


def is_user_group(policy):
    return policy.get("parent") != AIRLOCK_SYSTEM_POLICY_PARENT and policy.get("id") != POLICY_GLOBAL_SETTINGS_PARENT


def build_policy_group_ref(policies, group_name):
    """Console-shaped ref (ID/Name/Parent/parentid/children) for a user-facing
    policy group, from an already-fetched policy list. None if not found."""
    group = next((p for p in policies if p.get("name") == group_name and is_user_group(p)), None)
    if not group:
        return None
    parent = group.get("parent") or POLICY_GLOBAL_SETTINGS_PARENT
    children = [p for p in policies if p.get("parent") == group["id"]]
    return {
        "ID": group["id"],
        "Name": group["name"],
        "Parent": parent,
        "parentid": parent,
        "children": [
            {"ID": c["id"], "Name": c["name"], "Parent": group["id"], "parentid": group["id"], "children": []}
            for c in children
        ],
    }


def blocklist_status_is_applied(status):
    """BlGreen = applied directly; BlInherited* = applied via the parent."""
    return status == "BlGreen" or str(status or "").startswith("BlInherited")


def baseline_assignment_state(entry):
    """"applied" / "not_applied" / "unknown" for one TenantBaselineStatusList
    entry. Status values aren't all confirmed, so anything unplaceable is
    "unknown" — and the engine never assigns on "unknown"."""
    if not entry:
        return "not_applied"
    status = str(entry.get("Status") or "")
    if entry.get("IsInherited") is True or entry.get("IsApproved") is True or "Green" in status or "Inherited" in status:
        return "applied"
    if "Red" in status or entry.get("IsApproved") is False:
        return "not_applied"
    return "unknown"


def baseline_directly_assigned(entry):
    """Applied on this group itself, not inherited from its parent (inherited
    assignments follow automatically once the parent's is copied)."""
    return (
        baseline_assignment_state(entry) == "applied"
        and entry.get("IsInherited") is not True
        and "Inherited" not in str(entry.get("Status") or "")
    )


def blocklist_state(status):
    if status == "BlGreen":
        return STATE_ASSIGNED
    if str(status or "").startswith("BlInherited"):
        return STATE_INHERITED
    if status == "BlRed" or not status:
        return STATE_NOT_ASSIGNED
    return STATE_UNKNOWN


def baseline_state(entry):
    if not entry:
        return STATE_NOT_ASSIGNED
    if entry.get("IsInherited") is True or "inherit" in str(entry.get("Status") or "").lower():
        return STATE_INHERITED
    return {"applied": STATE_ASSIGNED, "not_applied": STATE_NOT_ASSIGNED}.get(baseline_assignment_state(entry), STATE_UNKNOWN)


def allowlist_assignment_state(entry):
    """One tenant-policy-allowlist-list TenantCategoryInfoList entry (Type
    "capture", ID = the allowlist's ID). Only "red" is confirmed from a
    capture; green/inherited are matched the way the console colors them."""
    if not entry:
        return STATE_NOT_ASSIGNED
    status = str(entry.get("Status") or "").lower()
    if "inherit" in status or "blue" in status:
        return STATE_INHERITED
    if "green" in status:
        return STATE_ASSIGNED
    if "red" in status:
        return STATE_NOT_ASSIGNED
    return STATE_UNKNOWN


def reference_rule_os(rule):
    """Returns (os_type, how): how is "reported" (the API said), "inferred"
    (a Windows-only criteria field is used) or "assumed" (defaulted to
    Windows — flagged in the UI and run results)."""
    for key in ("MetadataRuleNameOS", "NameOS", "OS", "OSType", "OperatingSystem", "Os"):
        value = rule.get(key)
        for os_type in OS_TYPES:
            if isinstance(value, str) and value.strip().lower() == os_type.lower():
                return os_type, "reported"
    fields = {str(c.get("Field") or "").lower() for c in rule.get("Criteria") or [] if isinstance(c, dict)}
    if fields & WINDOWS_ONLY_FIELDS:
        return "Windows", "inferred"
    return "Windows", "assumed"


def rule_message(rule):
    notify = ((rule.get("Setting") or {}).get("CustomNotify")) or {}
    return str(notify.get("Text") or "") if notify.get("Enabled") else ""


def rule_spec_from_airlock(rule):
    """A reference tenant's rule -> the engine's rule spec."""
    os_type, how = reference_rule_os(rule)
    ordered = sorted([c for c in rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    return {
        "name": rule.get("Name") or "",
        "os_type": os_type,
        "os_source": how,
        "criteria": [{"field": c.get("Field") or "", "operation": c.get("Operation") or "", "value": c.get("Value") or ""} for c in ordered],
        "message": rule_message(rule),
    }


def rule_matches(airlock_rule, spec):
    ordered = sorted([c for c in airlock_rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    got = [(c.get("Field"), c.get("Operation"), c.get("Value")) for c in ordered]
    want = [(c["field"], c["operation"], c["value"]) for c in spec["criteria"]]
    return got == want and rule_message(airlock_rule) == (spec.get("message") or "")


def allowlist_rule_spec_from_airlock(rule):
    """A reference tenant's allowlist rule -> the engine's rule spec. The
    allowlist rule list reports OSType (captured), and FriendlyField /
    FriendlyOperation, which the create call also sends."""
    os_type, how = reference_rule_os(rule)
    ordered = sorted([c for c in rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    try:
        integrity = int(rule.get("IntegrityLevel") or 0)
    except (TypeError, ValueError):
        integrity = 1
    return {
        "name": rule.get("Name") or "",
        "os_type": os_type,
        "os_source": how,
        # Confirmed 2026-11-15: a rule created with elevate_process true
        # lists as IntegrityLevel 1, false as 0. Copied as elevate_process.
        "elevated": integrity != 0,
        "criteria": [
            {"field": c.get("Field") or "", "operation": c.get("Operation") or "", "value": c.get("Value") or "",
             "friendly_field": c.get("FriendlyField") or "", "friendly_operation": c.get("FriendlyOperation") or ""}
            for c in ordered
        ],
    }


def allowlist_rule_matches(airlock_rule, spec):
    ordered = sorted([c for c in airlock_rule.get("Criteria") or [] if isinstance(c, dict)], key=lambda c: c.get("Idx") or 0)
    got = [(c.get("Field"), c.get("Operation"), c.get("Value")) for c in ordered]
    try:
        elevated = int(airlock_rule.get("IntegrityLevel") or 0) != 0
    except (TypeError, ValueError):
        elevated = True
    return (got == [(c["field"], c["operation"], c["value"]) for c in spec["criteria"]]
            and elevated == bool(spec.get("elevated")))


def extract_named_items(data, skip=("Atro", "TenantDatabaseRegisterList")):
    """Pulls [{name, id, status}] out of a list response whose item key isn't
    confirmed (trusted publishers: the only capture had none). Takes every
    top-level list of dicts except known bookkeeping keys."""
    items = []
    if not isinstance(data, dict):
        return items
    for key, value in data.items():
        if key in skip or not isinstance(value, list):
            continue
        for entry in value:
            if not isinstance(entry, dict):
                continue
            name = next((entry.get(k) for k in ("Name", "Text", "Publisher", "PublisherName", "CommonName", "Subject") if entry.get(k)), None)
            if name:
                items.append({"name": str(name), "id": entry.get("ID") or "", "status": entry.get("Status") or ""})
    return items


def publisher_key(name, os_type):
    return f"{os_type or 'Windows'}::{name}"


def process_key(name, proc_type):
    return f"{proc_type or 'pprocess'}::{name}"


def installer_key(name, os_code):
    return f"{int(os_code or 0)}::{name}"


def parse_entry_key(kind, key):
    """Turns a selection key back into the entry to add, or None if malformed."""
    key = str(key or "")
    if kind == "paths":
        return {"name": key} if key.strip() else None
    if kind == "installers" and key == INSTALLER_SWITCHES_KEY:
        return {"switches": True}
    a, sep, name = key.partition("::")
    if not sep or not name.strip():
        return None
    if kind == "processes":
        return {"name": name, "proc_type": a}
    if kind == "installers" and a in ("0", "1"):
        return {"name": name, "os": int(a)}
    return None


# kind -> (adapter list fn, adapter add fn, key of a listed row, what's sent to add)
ENTRY_KINDS = {
    "paths": ("list_group_paths", "add_group_paths", lambda r: r["name"], lambda e: e["name"]),
    "processes": ("list_group_processes", "add_group_processes", lambda r: process_key(r["name"], r.get("proc_type")),
                  lambda e: {"name": e["name"], "proc_type": e.get("proc_type") or "pprocess"}),
    "installers": ("list_group_installers", "add_group_installers", lambda r: installer_key(r["name"], r.get("os")),
                   lambda e: {"name": e["name"], "os": e.get("os", 0), "mode": e.get("mode", 0), "publisher": e.get("publisher") or ""}),
}
ENTRY_LABELS = {"paths": "Path", "processes": "Process", "installers": "Trusted installer"}


def parse_publisher_key(key):
    """'Windows::Broadcom Inc' -> ('Broadcom Inc', 'Windows'); None if malformed."""
    os_type, sep, name = str(key or "").partition("::")
    if not sep or not name.strip() or os_type not in OS_TYPES:
        return None
    return name, os_type


def clean_tenant_entry(raw):
    raw = raw if isinstance(raw, dict) else {}
    entry = {
        "label": str(raw.get("label") or "").strip(),
        "tenant_id": str(raw.get("tenant_id") or "").strip(),
        "directory_id": str(raw.get("directory_id") or "").strip(),
    }
    if not entry["label"]:
        return None, "Give the tenant a label (e.g. the customer's name)."
    if not entry["tenant_id"]:
        return None, "Enter the tenant ID (it's in the tenant's console URL)."
    if not entry["directory_id"]:
        return None, "Enter the directory ID."
    return entry, None


def clean_selection(raw):
    """The Policies Replication page's selection -> {tenant_ids, groups,
    items: {blocklists, allowlists, baselines}, message_from, update_differing}.
    Returns (selection, None) or (None, error)."""
    raw = raw if isinstance(raw, dict) else {}

    def names(values):
        out, seen = [], set()
        for v in values or []:
            v = str(v or "").strip()
            if v and v not in seen:
                seen.add(v)
                out.append(v)
        return out

    items = raw.get("items") if isinstance(raw.get("items"), dict) else {}
    sel = {
        "tenant_ids": names(raw.get("tenant_ids")),
        "groups": names(raw.get("groups")),
        "items": {t: names(items.get(t)) for t in ITEM_TYPES},
        "message_from": str(raw.get("message_from") or "").strip(),
        "update_differing": bool(raw.get("update_differing")),
        "trust_on_reference": bool(raw.get("trust_on_reference")),
    }
    bad = [k for k in sel["items"]["publishers"] if not parse_publisher_key(k)]
    if bad:
        return None, f"Unrecognized publisher: {bad[0]}"
    for kind in ENTRY_KINDS:
        bad = [k for k in sel["items"][kind] if not parse_entry_key(kind, k)]
        if bad:
            return None, f"Unrecognized {kind[:-1]}: {bad[0]}"
    if not sel["items"]["publishers"]:
        sel["trust_on_reference"] = False
    if not sel["tenant_ids"]:
        return None, "Tick at least one managed tenant."
    if not sel["groups"]:
        return None, "Tick at least one policy group on the left."
    if not any(sel["items"].values()) and not sel["message_from"]:
        return None, "Tick at least one item on the right (a baseline, allowlist, blocklist, publisher or group setting)."
    return sel, None


def selection_label(sel):
    counts = [f"{len(v)} {k}" for k, v in sel["items"].items() if v]
    if sel.get("message_from"):
        counts.append("notification message")
    if sel.get("trust_on_reference"):
        counts.append("+ reference")
    groups = ", ".join(sel["groups"][:3]) + (f" +{len(sel['groups']) - 3}" if len(sel["groups"]) > 3 else "")
    return f"{', '.join(counts)} → {groups}"


# --------------------------------------------------------------------------
# Reading the reference tenant
# --------------------------------------------------------------------------

class ReferenceReader:
    """Reads the reference tenant. Used for the inventory (everything) and at
    run time (only the selected items)."""

    def __init__(self, adapter, ref_tenant, learned_names):
        self.a = adapter
        self.tid = ref_tenant["tenant_id"]
        self.did = ref_tenant["directory_id"]
        self.learned = learned_names or {}
        self.errors = []
        self._policies = None
        self._group_cache = {}

    def policies(self):
        if self._policies is None:
            policies, err = self.a.list_policies(self.tid, self.did)
            if err:
                raise ReferenceReadError(f"Couldn't list the reference tenant's policy groups: {err}")
            self._policies = policies
        return self._policies

    def user_groups(self):
        return [p for p in self.policies() if is_user_group(p) and p.get("parent")]

    def group_ref(self, name):
        return build_policy_group_ref(self.policies(), name)

    def _per_group(self, kind, fn):
        """{group_name: result} for every user-facing group, cached per kind.
        A failing group is recorded in self.errors and skipped."""
        if kind not in self._group_cache:
            out = {}
            for g in self.user_groups():
                ref = self.group_ref(g["name"])
                result, err = fn(self.tid, self.did, ref)
                if err:
                    self.errors.append(f"{kind} for '{g['name']}': {err}")
                    continue
                out[g["name"]] = result
            self._group_cache[kind] = out
        return self._group_cache[kind]

    def blocklist_assignments(self):
        """{blocklist_id: [group names where directly applied (BlGreen)]}"""
        result = {}
        for group, statuses in self._per_group("blocklist assignments", self.a.blocklist_statuses).items():
            for s in statuses or []:
                if s.get("Status") == "BlGreen":
                    result.setdefault(s.get("ID"), []).append(group)
        return result

    def baseline_assignments(self):
        result = {}
        for group, statuses in self._per_group("baseline assignments", self.a.baseline_statuses).items():
            for s in statuses or []:
                if baseline_directly_assigned(s):
                    result.setdefault(s.get("ID"), []).append(group)
        return result

    def blocklists(self):
        items, err = self.a.list_blocklists(self.tid, self.did)
        if err:
            raise ReferenceReadError(f"Couldn't list the reference tenant's blocklists: {err}")
        return items

    def blocklist_detail(self, bl):
        rules, err = self.a.list_blocklist_rules(self.tid, self.did, bl.get("ID"))
        if err:
            raise ReferenceReadError(f"Couldn't read the rules of blocklist '{bl.get('Name')}': {err}")
        if rules:
            log.info("MSP reference rule fields (for OS detection): %s", sorted(rules[0].keys()))
        specs = [rule_spec_from_airlock(r) for r in rules]
        hashes, err = self.a.list_blocklist_hashes(self.tid, self.did, bl.get("ID"))
        return specs, (None if err else hashes)

    def tenant_baselines(self):
        items, err = self.a.list_tenant_baselines(self.tid, self.did)
        if err:
            raise ReferenceReadError(f"Couldn't list the reference tenant's baselines: {err}")
        return items

    def allowlists(self):
        items, err = self.a.list_allowlists(self.tid, self.did)
        if err:
            raise ReferenceReadError(f"Couldn't list the reference tenant's allowlists: {err}")
        return items

    def allowlist_rules(self, al):
        rules, err = self.a.list_allowlist_rules(self.tid, self.did, al.get("ID"))
        if err:
            raise ReferenceReadError(f"Couldn't read the rules of allowlist '{al.get('Name')}': {err}")
        return [allowlist_rule_spec_from_airlock(r) for r in rules]

    def catalog(self):
        items, err = self.a.list_reference_baselines(self.tid, self.did)
        if err:
            self.errors.append(f"Airlock's reference baseline catalog: {err}")
            return []
        return items

    def full_name_for(self, baseline_name, catalog):
        """Maps a tenant baseline's Name back to the catalog FullName it was
        added from. None = a custom baseline (or one this can't place)."""
        for full, learned in self.learned.items():
            if learned == baseline_name:
                return full
        if "(reference)" not in str(baseline_name or "").lower():
            return None
        wanted = normalize_baseline_name(baseline_name)
        return next((c.get("FullName") for c in catalog if normalize_baseline_name(c.get("FullName")) == wanted), None)

    def notification_messages(self):
        out = {}
        for group, settings in self._per_group("policy settings", self.a.get_policy_settings).items():
            out[group] = {
                "message": str((settings or {}).get("NotificationMessage") or ""),
                "enabled": bool((settings or {}).get("ClientNotification")),
            }
        return out

    def group_entries(self, kind):
        """Paths / processes / trusted installers set on any user-facing group:
        [{key, name, ..., groups (set there), inherited_groups}]."""
        list_fn, _, key_of, _ = ENTRY_KINDS[kind]
        items = {}
        for group, rows in self._per_group(kind, getattr(self.a, list_fn)).items():
            for r in rows or []:
                k = key_of(r)
                e = items.setdefault(k, dict({x: r[x] for x in r if x != "inherited"}, key=k, groups=[], inherited_groups=[]))
                e["inherited_groups" if r.get("inherited") else "groups"].append(group)
        return sorted(items.values(), key=lambda x: str(x["name"]).lower())

    def trusted_publishers(self):
        """Every publisher trusted on any user-facing group: [{key, name,
        friendly, os_type, groups (direct), inherited_groups}]."""
        items = {}
        for group, rows in self._per_group("trusted publishers", self.a.list_group_publishers).items():
            for r in rows or []:
                key = publisher_key(r.get("Name"), r.get("OSType"))
                entry = items.setdefault(key, {"key": key, "name": r.get("Name"), "friendly": r.get("FriendlyName") or r.get("Name"),
                                               "os_type": r.get("OSType") or "Windows", "groups": [], "inherited_groups": []})
                entry["inherited_groups" if r.get("IsInherited") else "groups"].append(group)
        return sorted(items.values(), key=lambda x: (x["name"].lower(), x["os_type"]))

    # -- the library (what the Policies Replication page lists) -----------------
    def inventory(self):
        """The reference tenant's library: its policy group tree (the targets
        on the left), and the blocklists, allowlists, baselines and group
        notification messages to pick from (right). Assignments on the
        reference itself aren't read here — colors come from /msp/status."""
        inv = {"fetched_at": _now(), "groups": [], "tree": [], "blocklists": [], "baselines": [], "policy_settings": [],
               "allowlists": [], "publishers": [], "paths": [], "processes": [], "installers": [],
               "installer_switches": {}, "errors": []}
        users = self.user_groups()
        ids = {g["id"] for g in users}
        inv["groups"] = [g["name"] for g in users]
        inv["tree"] = [{"id": g["id"], "name": g["name"], "parent_id": g["parent"] if g["parent"] in ids else None} for g in users]

        for bl in self.blocklists():
            try:
                rules, hashes = self.blocklist_detail(bl)
                hash_count = None if hashes is None else len(hashes)
            except ReferenceReadError as e:
                self.errors.append(str(e))
                rules, hash_count = [], None
            inv["blocklists"].append({
                "name": bl.get("Name"),
                "rules": [{"name": r["name"], "os_type": r["os_type"], "os_source": r["os_source"], "criteria_count": len(r["criteria"])} for r in rules],
                "hash_count": hash_count,
            })

        allowlists = self.allowlists()
        name_counts = {}
        for al in allowlists:
            name_counts[al.get("Name")] = name_counts.get(al.get("Name"), 0) + 1
        for al in allowlists:
            try:
                rules = self.allowlist_rules(al)
            except ReferenceReadError as e:
                self.errors.append(str(e))
                rules = []
            inv["allowlists"].append({
                "name": al.get("Name"),
                "category": al.get("Category") or "",
                "top_category": al.get("TopCategory") or al.get("Category") or "",
                "in_subcategory": bool(al.get("InSubcategory")),
                "subcategory": al.get("Subcategory") or "",
                "rules": [{"name": r["name"], "os_type": r["os_type"], "criteria_count": len(r["criteria"]), "elevated": r["elevated"]} for r in rules],
                "file_count": al.get("Fcount") or 0,
                "duplicate_name": name_counts.get(al.get("Name"), 0) > 1,
            })

        catalog = self.catalog()
        catalog_os = {c.get("FullName"): c.get("OSType") for c in catalog}
        for b in self.tenant_baselines():
            full = self.full_name_for(b.get("Name"), catalog)
            inv["baselines"].append({
                "name": b.get("Name"),
                "full_name": full,
                "os_type": catalog_os.get(full) or b.get("OSType") or "",
                "replicable": bool(full),
                "reason": "" if full else "Custom baseline (not from Airlock's reference catalog) — can't be copied yet.",
            })

        for group, info in self.notification_messages().items():
            inv["policy_settings"].append({"group": group, "message": info["message"], "enabled": info["enabled"]})

        inv["publishers"] = self.trusted_publishers()
        for kind in ENTRY_KINDS:
            inv[kind] = self.group_entries(kind)
        inv["installer_switches"] = self._per_group("trusted installer switches", self.a.get_installer_switches)
        inv["errors"] = list(self.errors)
        return inv

    # -- run-time resolution of a selection ---------------------------------------
    def resolve_selection(self, sel):
        """Reads the ticked library items' *current* definitions from the
        reference tenant and targets them at the ticked groups. Returns (spec,
        notes): spec is what TenantRun applies; notes are warnings shown at
        the top of the run (e.g. an item no longer on the reference)."""
        notes = []
        groups = list(sel["groups"])
        items = sel["items"]
        spec = {"blocklists": [], "allowlists": [], "baselines": [], "policy_settings": [], "publishers": [],
                "paths": [], "processes": [], "installers": [], "installer_switches": []}
        for kind in ENTRY_KINDS:
            want = items.get(kind) or []
            if not want:
                continue
            known = {e["key"]: e for e in self.group_entries(kind)}
            for key in want:
                parsed = parse_entry_key(kind, key)
                if not parsed:
                    continue
                if parsed.get("switches"):
                    for g in groups:
                        sw, err = self.a.get_installer_switches(self.tid, self.did, self.group_ref(g))
                        if err:
                            notes.append(f"Couldn't read the Trusted Installer switches of '{g}' on the reference — skipped: {err}")
                        else:
                            spec["installer_switches"].append({"group": g, "switches": sw})
                    continue
                entry = dict(known.get(key) or {}, **parsed)
                if key not in known:
                    notes.append(f"{ENTRY_LABELS[kind]} '{parsed['name']}' is no longer on the reference tenant — skipped.")
                    continue
                spec[kind].append(dict(entry, key=key, assign_groups=groups))
        for key in items.get("publishers") or []:
            parsed = parse_publisher_key(key)
            if parsed:
                spec["publishers"].append({"key": key, "name": parsed[0], "os_type": parsed[1], "assign_groups": groups})

        if items.get("blocklists"):
            by_name = {b.get("Name"): b for b in self.blocklists()}
            for name in items["blocklists"]:
                bl = by_name.get(name)
                if not bl:
                    notes.append(f"Blocklist '{name}' is no longer on the reference tenant — skipped.")
                    continue
                rules, hashes = self.blocklist_detail(bl)
                for r in rules:
                    if r["os_source"] == "assumed":
                        notes.append(f"Blocklist '{name}', rule '{r['name']}': Airlock didn't report the rule's OS, so Windows is assumed.")
                if hashes is None:
                    notes.append(f"Couldn't read the hash entries of blocklist '{name}', so none are copied this run.")
                spec["blocklists"].append({"name": name, "rules": rules, "assign_groups": groups, "hashes": hashes})

        if items.get("allowlists"):
            all_lists = self.allowlists()
            for name in items["allowlists"]:
                matches = [a for a in all_lists if a.get("Name") == name]
                if not matches:
                    notes.append(f"Allowlist '{name}' is no longer on the reference tenant — skipped.")
                    continue
                if len(matches) > 1:
                    notes.append(f"The reference tenant has {len(matches)} allowlists named '{name}' — skipped; rename one so the name is unique.")
                    continue
                al = matches[0]
                rules = []
                for r in self.allowlist_rules(al):
                    if r["os_source"] == "assumed":
                        notes.append(f"Allowlist '{name}', rule '{r['name']}': Airlock didn't report the rule's OS, so Windows is assumed.")
                    rules.append(r)
                files, herr = self.a.list_allowlist_hashes(self.tid, self.did, al["ID"])
                if herr:
                    notes.append(f"Couldn't read the file (hash) entries of allowlist '{name}', so none are copied this run: {herr}")
                    files = None
                spec["allowlists"].append({"name": name, "rules": rules, "assign_groups": groups,
                                           "hashes": None if files is None else sorted({f["sha256"] for f in files}),
                                           "category": al.get("TopCategory") or al.get("Category") or "",
                                           "in_subcategory": bool(al.get("InSubcategory")),
                                           "subcategory": al.get("Subcategory") or ""})

        if items.get("baselines"):
            tenant_baselines = {b.get("Name"): b for b in self.tenant_baselines()}
            catalog = self.catalog()
            for name in items["baselines"]:
                if name not in tenant_baselines:
                    notes.append(f"Baseline '{name}' is no longer on the reference tenant — skipped.")
                    continue
                full = self.full_name_for(name, catalog)
                if not full:
                    notes.append(f"Baseline '{name}' is a custom baseline — can't be copied yet, skipped.")
                    continue
                spec["baselines"].append({"full_name": full, "label": name, "assign_groups": groups})

        if sel.get("message_from"):
            src = sel["message_from"]
            info = self.notification_messages().get(src)
            if info is None:
                notes.append(f"Policy group '{src}' is no longer on the reference tenant (or its settings couldn't be read) — notification message skipped.")
            elif not info["message"]:
                notes.append(f"Policy group '{src}' has no notification message on the reference tenant — skipped.")
            else:
                for g in groups:
                    spec["policy_settings"].append({"group": g, "block_notification_message": info["message"], "source_group": src})

        notes.extend(f"Reference read problem: {e}" for e in self.errors)
        return spec, notes


class ReferenceReadError(Exception):
    pass


# --------------------------------------------------------------------------
# Applying to one managed tenant
# --------------------------------------------------------------------------

class TenantRun:
    def __init__(self, adapter, tenant, dry_run, update_differing, learned_names):
        self.a = adapter
        self.tid = tenant.get("tenant_id") or ""
        self.did = tenant.get("directory_id") or ""
        self.dry_run = dry_run
        self.update_differing = update_differing
        self.learned = learned_names
        self.steps = []
        self._policies = None
        self._blocklists = None
        self._tenant_baselines = None
        self._reference = None
        self._allowlists = None

    def step(self, kind, item, outcome, detail=""):
        """outcome: planned | done | exists | differs | skipped | error"""
        if outcome == "error" and "Tenant Role(s) NOT Found" in str(detail):
            detail = (f"{detail} — the Cloud admin account doesn't have a role on this tenant yet. "
                      "Open the tenant once in the Cloud console (or use its \"Add Me to Tenant\" button), then run again.")
        self.steps.append({"kind": kind, "item": item, "outcome": outcome, "detail": detail})

    def act(self, kind, item, planned_detail, fn):
        if self.dry_run:
            self.step(kind, item, "planned", planned_detail)
            return True
        ok, err = fn()
        if ok:
            self.step(kind, item, "done", planned_detail)
            return True
        self.step(kind, item, "error", err or "Failed.")
        return False

    def named_act(self, kind, item, planned_detail, name, fn):
        """Like act(), but fn(name) -> (result, err) creates something
        named. If Airlock rejects the name for its punctuation, it's
        retried once with the cleaned-up name and the step says so.
        Returns (result, name actually used) — result None on failure."""
        safe = airlock_safe_name(name)
        if self.dry_run:
            hint = f" If Airlock rejects the symbols in the name, it'll be created as '{safe}'." if safe and safe != name else ""
            self.step(kind, item, "planned", planned_detail + hint)
            return True, name
        result, err = fn(name)
        used = name
        if not result and is_name_rejection(err) and safe and safe != name:
            result, err = fn(safe)
            used = safe
        if result:
            note = f" Created as '{used}' — Airlock only accepts letters, numbers and spaces in this name." if used != name else ""
            self.step(kind, item, "done", planned_detail + note)
            return result, used
        self.step(kind, item, "error", err or "Failed.")
        return None, used

    def policies(self):
        if self._policies is None:
            policies, err = self.a.list_policies(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's policy groups: {err}")
            self._policies = policies
        return self._policies

    def group_ref(self, name):
        return build_policy_group_ref(self.policies(), name)

    def blocklists(self):
        if self._blocklists is None:
            items, err = self.a.list_blocklists(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's blocklists: {err}")
            self._blocklists = items
        return self._blocklists

    def tenant_baselines(self, refresh=False):
        if self._tenant_baselines is None or refresh:
            items, err = self.a.list_tenant_baselines(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's baselines: {err}")
            self._tenant_baselines = items
        return self._tenant_baselines

    def run(self, spec):
        for bl in spec.get("blocklists") or []:
            self.guarded(self.do_blocklist, bl, "blocklist", f"Blocklist '{bl['name']}'")
        for al in spec.get("allowlists") or []:
            self.guarded(self.do_allowlist, al, "allowlist", f"Allowlist '{al['name']}'")
        for b in spec.get("baselines") or []:
            self.guarded(self.do_baseline, b, "baseline", f"Baseline '{b.get('label') or b['full_name']}'")
        for s in spec.get("policy_settings") or []:
            self.guarded(self.do_policy_setting, s, "policy_setting", f"Notification message on '{s['group']}'")
        if spec.get("publishers"):
            self.guarded(self.do_publishers, spec["publishers"], "publisher", "Trusted publishers")
        for kind in ENTRY_KINDS:
            if spec.get(kind):
                self.guarded(lambda entries, kind=kind: self.do_group_entries(kind, entries), spec[kind], kind[:-1], f"{ENTRY_LABELS[kind]}s")
        for sw in spec.get("installer_switches") or []:
            self.guarded(self.do_installer_switches, sw, "installer_switches", f"Trusted Installer switches on '{sw['group']}'")
        return self.steps

    def groups_parent_first(self, groups):
        by_id = {x.get("id"): x for x in self.policies()}

        def depth(name):
            node = next((x for x in self.policies() if x.get("name") == name), None)
            d = 0
            while node and node.get("parent") in by_id and d < 20:
                node, d = by_id[node.get("parent")], d + 1
            return d
        return sorted(groups, key=depth)

    def do_group_entries(self, kind, entries):
        """Adds paths / processes / trusted installers to each ticked group
        that doesn't have them yet (set there or inherited) — one call per
        group, parents first so children that inherit them are a no-op."""
        list_fn, add_fn, key_of, to_add = ENTRY_KINDS[kind]
        noun = ENTRY_LABELS[kind]
        groups = []
        for e in entries:
            for g in e.get("assign_groups") or []:
                if g not in groups:
                    groups.append(g)
        for g in self.groups_parent_first(groups):
            wanted = [e for e in entries if g in (e.get("assign_groups") or [])]
            label = lambda e: f"{noun} '{e['name']}' → '{g}'"
            ref = self.group_ref(g)
            if not ref:
                for e in wanted:
                    self.step(kind[:-1], label(e), "skipped", f"No policy group named '{g}' on this tenant.")
                continue
            rows, err = getattr(self.a, list_fn)(self.tid, self.did, ref)
            if err:
                for e in wanted:
                    self.step(kind[:-1], label(e), "error", f"Couldn't read the group's {kind}: {err}")
                continue
            have = {key_of(r): r for r in rows or []}
            missing = []
            for e in wanted:
                hit = have.get(e["key"])
                if hit:
                    self.step(kind[:-1], label(e), "exists",
                              "Already there (inherited from a parent group)." if hit.get("inherited") else "Already there.")
                else:
                    missing.append(e)
            if not missing:
                continue
            if self.dry_run:
                for e in missing:
                    self.step(kind[:-1], label(e), "planned", "Add to the policy group.")
                continue
            ok, err = getattr(self.a, add_fn)(self.tid, self.did, ref, [to_add(e) for e in missing])
            for e in missing:
                self.step(kind[:-1], label(e), "done" if ok else "error", "Added to the policy group." if ok else (err or "Failed."))

    def do_installer_switches(self, sw):
        g = sw["group"]
        label = f"Trusted Installer switches on '{g}'"
        ref = self.group_ref(g)
        if not ref:
            self.step("installer_switches", label, "skipped", f"No policy group named '{g}' on this tenant.")
            return
        current, err = self.a.get_installer_switches(self.tid, self.did, ref)
        if err:
            self.step("installer_switches", label, "error", f"Couldn't read the group's settings: {err}")
            return
        want = sw["switches"]
        diff = [f for f in INSTALLER_SWITCH_FIELDS if int(current.get(f) or 0) != int(want.get(f) or 0)]
        if not diff:
            self.step("installer_switches", label, "exists", "Already matches the reference.")
            return
        detail = "; ".join(f"{INSTALLER_SWITCH_LABELS[f]}: {SWITCH_VALUE_LABELS.get(int(current.get(f) or 0))} → "
                           f"{SWITCH_VALUE_LABELS.get(int(want.get(f) or 0))}" for f in diff)
        self.act("installer_switches", label, f"Set to match the reference ({detail}).",
                 lambda: self.a.set_installer_switches(self.tid, self.did, ref, {f: int(want.get(f) or 0) for f in INSTALLER_SWITCH_FIELDS}))

    def do_publishers(self, pubs):
        """Trusts the publishers on each ticked group that doesn't already
        trust them (directly or inherited) — one call per group. Parent
        groups go first, so a child that inherits the result is a no-op."""
        groups = []
        for p in pubs:
            for g in p.get("assign_groups") or []:
                if g not in groups:
                    groups.append(g)
        for g in self.groups_parent_first(groups):
            wanted = [p for p in pubs if g in (p.get("assign_groups") or [])]
            ref = self.group_ref(g)
            if not ref:
                for p in wanted:
                    self.step("publisher", f"Publisher '{p['name']}' ({p['os_type']}) → trust on '{g}'", "skipped",
                              f"No policy group named '{g}' on this tenant.")
                continue
            rows, err = self.a.list_group_publishers(self.tid, self.did, ref)
            if err:
                for p in wanted:
                    self.step("publisher", f"Publisher '{p['name']}' ({p['os_type']}) → trust on '{g}'", "error",
                              f"Couldn't read the group's trusted publishers: {err}")
                continue
            have = {publisher_key(r.get("Name"), r.get("OSType")): r for r in rows or []}
            missing = []
            for p in wanted:
                label = f"Publisher '{p['name']}' ({p['os_type']}) → trust on '{g}'"
                hit = have.get(p["key"])
                if hit:
                    self.step("publisher", label, "exists",
                              "Already trusted (inherited from a parent group)." if hit.get("IsInherited") else "Already trusted.")
                else:
                    missing.append((p, label))
            if not missing:
                continue
            if self.dry_run:
                for p, label in missing:
                    self.step("publisher", label, "planned", "Trust this publisher on the policy group.")
                continue
            ok, err = self.a.trust_publishers(self.tid, self.did, ref, [{"name": p["name"], "os_type": p["os_type"]} for p, _ in missing])
            for p, label in missing:
                if ok:
                    self.step("publisher", label, "done", "Trusted on the policy group.")
                else:
                    self.step("publisher", label, "error", err or "Failed.")

    def guarded(self, fn, item, kind, label):
        try:
            fn(item)
        except TenantReadError as e:
            self.step(kind, label, "error", str(e))
        except Exception as e:
            log.exception("MSP step failed (%s)", label)
            self.step(kind, label, "error", f"Unexpected error: {e}")

    def do_blocklist(self, bl):
        label = f"Blocklist '{bl['name']}'"
        existing = next(iter(find_named(self.blocklists(), bl["name"])), None)
        blocklist_id = existing.get("ID") if existing else None
        tenant_name = existing.get("Name") if existing else bl["name"]

        if existing:
            note = f" (as '{tenant_name}')" if tenant_name != bl["name"] else ""
            self.step("blocklist", label, "exists", f"Already on the tenant{note}.")
        else:
            created, tenant_name = self.named_act(
                "blocklist", label, "Create blocklist.", bl["name"],
                lambda n: self.a.create_blocklist(self.tid, self.did, n))
            if not created:
                return
            if not self.dry_run:
                blocklist_id = created

        existing_rules = []
        if blocklist_id:
            existing_rules, err = self.a.list_blocklist_rules(self.tid, self.did, blocklist_id)
            if err:
                self.step("blocklist_rule", f"{label} rules", "error", f"Couldn't list the blocklist's rules: {err}")
                existing_rules = None
        for rule in bl.get("rules") or []:
            rlabel = f"{label} → rule '{rule['name']}'"
            if existing_rules is None:
                self.step("blocklist_rule", rlabel, "skipped", "Rules couldn't be read, so nothing was changed.")
                continue
            spec = {"rule_name": rule["name"], "os_type": rule["os_type"], "criteria": rule["criteria"], "message": rule.get("message") or ""}
            crit = "; ".join(f"{c['field']} {c['operation']} '{c['value']}'" for c in rule["criteria"]) or "no criteria"
            os_note = " (OS assumed — Airlock didn't report it)" if rule.get("os_source") == "assumed" else ""
            match = next(iter(find_named(existing_rules, rule["name"])), None)
            if match and rule_matches(match, rule):
                self.step("blocklist_rule", rlabel, "exists", "Already matches the reference.")
                continue
            if match and not self.update_differing:
                self.step("blocklist_rule", rlabel, "differs",
                          "Exists with different criteria or message — left unchanged. Tick \"Also update items that differ\" to overwrite it.")
                continue
            if match:
                spec["rule_name"] = match.get("Name") or rule["name"]
                self.act("blocklist_rule", rlabel, f"Update to match the reference: {crit}{os_note}.",
                         lambda spec=spec: self.a.save_blocklist_rule(self.tid, self.did, blocklist_id, spec))
            else:
                self.named_act("blocklist_rule", rlabel, f"Create {rule['os_type']} rule: {crit}{os_note}.", rule["name"],
                               lambda n, spec=spec: self.a.save_blocklist_rule(self.tid, self.did, blocklist_id, dict(spec, rule_name=n)))

        self.do_hashes("blocklist_hashes", label, blocklist_id, bl.get("hashes"), created_now=not existing,
                       list_fn=self.a.list_blocklist_hashes, add_fn=self.a.add_blocklist_hashes)

        for group in bl.get("assign_groups") or []:
            alabel = f"{label} → assign to '{group}'"
            ref = self.group_ref(group)
            if not ref:
                self.step("blocklist_assign", alabel, "skipped", f"No policy group named '{group}' on this tenant.")
                continue
            if blocklist_id:
                statuses, err = self.a.blocklist_statuses(self.tid, self.did, ref)
                if err:
                    self.step("blocklist_assign", alabel, "error", f"Couldn't read the group's blocklists: {err}")
                    continue
                status = next((s.get("Status") for s in statuses or [] if s.get("ID") == blocklist_id), "")
                if blocklist_status_is_applied(status):
                    self.step("blocklist_assign", alabel, "exists", "Already applied (directly or inherited).")
                    continue
            self.act("blocklist_assign", alabel, "Assign blocklist to the policy group.",
                     lambda ref=ref: self.a.assign_blocklist(self.tid, self.did, ref, blocklist_id, tenant_name))

    def do_allowlist(self, al):
        """Creates the allowlist if the tenant doesn't have one with this
        name (in the same-named top-level category), adds missing rules,
        updates differing ones when the run allows it, and assigns it to the
        ticked groups — all calls captured 2026-11-15."""
        label = f"Allowlist '{al['name']}'"
        if self._allowlists is None:
            items, err = self.a.list_allowlists(self.tid, self.did)
            if err:
                raise TenantReadError(f"Couldn't list the tenant's allowlists: {err}")
            self._allowlists = items
        matches = find_named(self._allowlists, al["name"])
        if len(matches) > 1:
            self.step("allowlist", label, "skipped", f"The tenant has {len(matches)} allowlists with this name — rename one so it's unique.")
            return
        allowlist = matches[0] if matches else None

        if allowlist:
            self.step("allowlist", label, "exists", f"Already on the tenant (in {allowlist.get('Category') or 'its category'}).")
        else:
            cats, err = self.a.list_allowlist_categories(self.tid, self.did)
            if err:
                self.step("allowlist", label, "error", f"Couldn't list the tenant's allowlist categories: {err}")
                return
            cat = next((c for c in cats or [] if c.get("Name") == al.get("category")), None)
            if not cat:
                self.step("allowlist", label, "skipped",
                          f"Not on this tenant, and the tenant has no '{al.get('category')}' category to create it in. Create the category in the console, then run again.")
                return
            target_id, where = cat["ID"], cat["Name"]
            sub_name = al.get("subcategory") if al.get("in_subcategory") else ""
            if al.get("in_subcategory") and not sub_name:
                self.step("allowlist", label, "skipped", "It sits in a subcategory on the reference, but the subcategory's name couldn't be read.")
                return
            if sub_name:
                where = f"{cat['Name']} / {sub_name}"
                sub = next((sc for sc in cat.get("Subcategories") or [] if sc.get("Name") == sub_name), None)
                if sub:
                    target_id = sub["ID"]
                elif self.dry_run:
                    self.step("allowlist_subcategory", f"Subcategory '{where}'", "planned", "Create the subcategory.")
                    target_id = None
                else:
                    sub, err = self.a.create_allowlist_subcategory(self.tid, self.did, cat["ID"], sub_name)
                    if err:
                        self.step("allowlist_subcategory", f"Subcategory '{where}'", "error", err)
                        return
                    self.step("allowlist_subcategory", f"Subcategory '{where}'", "done", "Created.")
                    target_id = sub["ID"]
                    cat.setdefault("Subcategories", []).append(sub)
            created, _ = self.named_act(
                "allowlist", label, f"Create allowlist in '{where}'.", al["name"],
                lambda n: self.a.create_allowlist(self.tid, self.did, target_id, n))
            if not created:
                return
            if not self.dry_run:
                allowlist = created
                self._allowlists.append(created)

        # Rules
        existing = []
        if allowlist:
            existing, err = self.a.list_allowlist_rules(self.tid, self.did, allowlist["ID"])
            if err:
                self.step("allowlist", f"{label} rules", "error", f"Couldn't list the allowlist's rules: {err}")
                existing = None
        for rule in al.get("rules") or []:
            rlabel = f"{label} → rule '{rule['name']}'"
            if existing is None:
                self.step("allowlist_rule", rlabel, "skipped", "Rules couldn't be read, so nothing was changed.")
                continue
            crit = "; ".join(f"{c['field']} {c['operation']} '{c['value']}'" for c in rule["criteria"]) or "no criteria"
            elev = ", runs elevated" if rule.get("elevated") else ""
            match = next(iter(find_named(existing, rule["name"])), None)
            if match and allowlist_rule_matches(match, rule):
                self.step("allowlist_rule", rlabel, "exists", "Already matches the reference.")
                continue
            if match and not self.update_differing:
                self.step("allowlist_rule", rlabel, "differs",
                          "Exists with different criteria or elevation — left unchanged. Tick \"Also update items that differ\" to overwrite it.")
                continue
            if match:
                self.act("allowlist_rule", rlabel, f"Update to match the reference: {crit}{elev}.",
                         lambda rule=rule, match=match: self.a.update_allowlist_rule(self.tid, self.did, allowlist["ID"], match, rule))
            else:
                self.named_act("allowlist_rule", rlabel, f"Create {rule['os_type']} rule: {crit}{elev}.", rule["name"],
                               lambda n, rule=rule: self.a.create_allowlist_rule(self.tid, self.did, allowlist["ID"], dict(rule, name=n)))

        # File (hash) entries — added before assigning, so a group that
        # then shows an update for this allowlist gets it approved below.
        self.do_hashes("allowlist_hashes", label, allowlist and allowlist["ID"], al.get("hashes"), created_now=not matches,
                       list_fn=lambda t, d, i: (lambda r: (None if r[1] else [f["sha256"] for f in r[0] or []], r[1]))(self.a.list_allowlist_hashes(t, d, i)),
                       add_fn=self.a.add_allowlist_hashes)

        # Assignments
        for group in al.get("assign_groups") or []:
            alabel = f"{label} → assign to '{group}'"
            ref = self.group_ref(group)
            if not ref:
                self.step("allowlist_assign", alabel, "skipped", f"No policy group named '{group}' on this tenant.")
                continue
            if allowlist:
                statuses, err = self.a.allowlist_group_statuses(self.tid, self.did, ref)
                if err:
                    self.step("allowlist_assign", alabel, "error", f"Couldn't read the group's allowlists: {err}")
                    continue
                state = allowlist_assignment_state(next((x for x in statuses or [] if x.get("ID") == allowlist["ID"]), None))
                if state in (STATE_ASSIGNED, STATE_INHERITED):
                    self.step("allowlist_assign", alabel, "exists", "Already assigned (directly or inherited).")
                    continue
                if state == STATE_UNKNOWN:
                    self.step("allowlist_assign", alabel, "skipped", "Couldn't tell whether it's assigned — left alone.")
                    continue
            self.act("allowlist_assign", alabel, "Assign allowlist to the policy group.",
                     lambda ref=ref: self.a.assign_allowlist(self.tid, self.did, ref, allowlist))

    def do_hashes(self, kind, label, list_id, ref_hashes, created_now, list_fn, add_fn):
        """Adds the reference's hashes the tenant's list (allowlist or
        blocklist) doesn't have. Add-only: hashes only on the tenant are left
        alone. One summary step, not one per hash — lists can hold thousands.
        Airlock re-publishes the list to its groups by itself afterwards."""
        if not ref_hashes:
            return
        hlabel = f"{label} → hashes"
        have = set()
        if list_id and not created_now:
            found, err = list_fn(self.tid, self.did, list_id)
            if err:
                self.step(kind, hlabel, "error", f"Couldn't read the hash entries: {err}")
                return
            have = set(found or [])
        missing = [h for h in ref_hashes if h not in have]
        already = len(ref_hashes) - len(missing)
        there = f" ({already} already there)" if already else ""
        if not missing:
            self.step(kind, hlabel, "exists", f"All {len(ref_hashes)} hash{'' if len(ref_hashes) == 1 else 'es'} already there.")
            return
        plural = "" if len(missing) == 1 else "es"
        if self.dry_run or not list_id:
            self.step(kind, hlabel, "planned", f"Add {len(missing)} hash{plural}{there}.")
            return
        added, err = add_fn(self.tid, self.did, list_id, missing)
        if err:
            self.step(kind, hlabel, "error", f"Added {added} of {len(missing)}: {err}")
        else:
            self.step(kind, hlabel, "done", f"Added {added} hash{plural}{there}.")

    def find_tenant_baseline(self, full_name):
        wanted = {normalize_baseline_name(full_name)}
        if self.learned.get(full_name):
            wanted.add(normalize_baseline_name(self.learned[full_name]))
        return next((b for b in self.tenant_baselines() if normalize_baseline_name(b.get("Name")) in wanted), None)

    def do_baseline(self, b):
        label = f"Baseline '{b.get('label') or b['full_name']}'"
        baseline = self.find_tenant_baseline(b["full_name"])
        if baseline:
            self.step("baseline", label, "exists", f"Already on the tenant as '{baseline.get('Name')}'.")
        else:
            if self._reference is None:
                catalog, err = self.a.list_reference_baselines(self.tid, self.did)
                if err:
                    self.step("baseline", label, "error", f"Couldn't read Airlock's reference baseline catalog: {err}")
                    return
                self._reference = catalog
            entry = next((r for r in self._reference if r.get("FullName") == b["full_name"]), None)
            if not entry:
                self.step("baseline", label, "error",
                          f"'{b['full_name']}' isn't in Airlock's current reference catalog — it may have been retired for a newer monthly build.")
                return
            if self.dry_run:
                self.step("baseline", label, "planned", "Add from Airlock's reference catalog.")
            else:
                before = {x.get("ID") for x in self.tenant_baselines()}
                ok, err = self.a.add_reference_baseline(self.tid, self.did, entry)
                if not ok:
                    self.step("baseline", label, "error", err or "Failed to add.")
                    return
                new = [x for x in self.tenant_baselines(refresh=True) if x.get("ID") not in before]
                baseline = new[0] if len(new) == 1 else self.find_tenant_baseline(b["full_name"])
                if not baseline:
                    self.step("baseline", label, "error", "Add reported success, but the new baseline couldn't be found on the tenant afterwards.")
                    return
                self.learned[b["full_name"]] = baseline.get("Name") or ""
                self.step("baseline", label, "done", f"Added as '{baseline.get('Name')}'.")

        for group in b.get("assign_groups") or []:
            alabel = f"{label} → assign to '{group}'"
            ref = self.group_ref(group)
            if not ref:
                self.step("baseline_assign", alabel, "skipped", f"No policy group named '{group}' on this tenant.")
                continue
            if baseline:
                statuses, err = self.a.baseline_statuses(self.tid, self.did, ref)
                if err:
                    self.step("baseline_assign", alabel, "error", f"Couldn't read the group's baselines: {err}")
                    continue
                entry = next((s for s in statuses or [] if s.get("ID") == baseline.get("ID")), None)
                state = baseline_assignment_state(entry)
                if state == "applied":
                    self.step("baseline_assign", alabel, "exists", "Already assigned (directly or inherited).")
                    continue
                if state == "unknown":
                    self.step("baseline_assign", alabel, "skipped",
                              f"Couldn't tell whether it's assigned (Airlock status '{entry.get('Status')}') — left alone.")
                    continue
            self.act("baseline_assign", alabel, "Assign baseline to the policy group.",
                     lambda ref=ref: self.a.assign_baseline(self.tid, self.did, ref, baseline["ID"], baseline.get("Name") or ""))

    def do_policy_setting(self, s):
        label = f"Notification message on '{s['group']}'"
        ref = self.group_ref(s["group"])
        if not ref:
            self.step("policy_setting", label, "skipped", f"No policy group named '{s['group']}' on this tenant.")
            return
        loaded, err = self.a.get_policy_settings(self.tid, self.did, ref)
        if err:
            self.step("policy_setting", label, "error", f"Couldn't load the group's settings: {err}")
            return
        message = s["block_notification_message"]
        if loaded.get("NotificationMessage") == message and loaded.get("ClientNotification"):
            self.step("policy_setting", label, "exists", "Already matches the reference.")
            return
        current = str(loaded.get("NotificationMessage") or "").strip()
        preview = (current[:80] + "…") if len(current) > 80 else current
        self.act("policy_setting", label, f"Set to the reference's message (currently: '{preview or 'blank'}').",
                 lambda: self.a.save_notification_message(self.tid, self.did, ref, loaded, message))


class TenantReadError(Exception):
    pass


def tenant_item_states(adapter, tenant, library, groups, message_from, learned, kinds=None):
    """Colors for one tenant: for every library item and every ticked policy
    group, one of the STATE_* values. Read-only. Returns
      {"groups_missing": [...],
       "items": {"blocklists": {name: {group: state}}, "allowlists": {...}, "baselines": {...}},
       "message": {group: state}}            (only when message_from is set)
    kinds: only work out these item types (default all).
    Raises TenantReadError if the tenant can't be read at all."""
    tid, did = tenant.get("tenant_id") or "", tenant.get("directory_id") or ""
    wants = lambda k: kinds is None or k in kinds

    policies, err = adapter.list_policies(tid, did)
    if err:
        raise TenantReadError(f"Couldn't list policy groups: {err}")
    refs = {g: build_policy_group_ref(policies, g) for g in groups}
    present = [g for g in groups if refs[g]]
    result = {"groups_missing": [g for g in groups if not refs[g]],
              "items": {t: {} for t in ITEM_TYPES}, "message": {}}

    def fill(kind, name, per_group):
        """per_group: function(group) -> state for groups that exist."""
        result["items"][kind][name] = {g: (per_group(g) if refs[g] else STATE_GROUP_MISSING) for g in groups}

    # Blocklists
    lib_bl = [b["name"] for b in library.get("blocklists") or []] if wants("blocklists") else []
    if lib_bl:
        tenant_bl, err = adapter.list_blocklists(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list blocklists: {err}")
        ids = {b.get("Name"): b.get("ID") for b in tenant_bl}
        statuses = {}
        if any(n in ids or airlock_safe_name(n) in ids for n in lib_bl):
            for g in present:
                rows, err = adapter.blocklist_statuses(tid, did, refs[g])
                if err:
                    raise TenantReadError(f"Couldn't read blocklist assignments on '{g}': {err}")
                statuses[g] = {r.get("ID"): r.get("Status") for r in rows or []}
        for name in lib_bl:
            bid = ids.get(name) or ids.get(airlock_safe_name(name))
            if not bid:
                fill("blocklists", name, lambda g: STATE_CREATE)
            else:
                fill("blocklists", name, lambda g, bid=bid: blocklist_state(statuses.get(g, {}).get(bid)))

    # Allowlists
    lib_al = [a["name"] for a in library.get("allowlists") or []] if wants("allowlists") else []
    if lib_al:
        tenant_al, err = adapter.list_allowlists(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list allowlists: {err}")
        by_name = {}
        for a in tenant_al:
            by_name.setdefault(a.get("Name"), []).append(a.get("ID"))
        statuses = {}
        def found_for(n):
            return by_name.get(n) or by_name.get(airlock_safe_name(n)) or []
        if any(len(found_for(n)) == 1 for n in lib_al):
            for g in present:
                rows, err = adapter.allowlist_group_statuses(tid, did, refs[g])
                if err:
                    raise TenantReadError(f"Couldn't read allowlist assignments on '{g}': {err}")
                statuses[g] = {r.get("ID"): r for r in rows or [] if isinstance(r, dict)}
        lib_by_name = {a["name"]: a for a in library.get("allowlists") or []}
        cat_names = None
        for name in lib_al:
            found = found_for(name)
            if len(found) == 0:
                info = lib_by_name.get(name) or {}
                if cat_names is None:
                    cats, err = adapter.list_allowlist_categories(tid, did)
                    if err:
                        raise TenantReadError(f"Couldn't list allowlist categories: {err}")
                    cat_names = {c.get("Name") for c in cats or []}
                creatable = (info.get("top_category") or info.get("category")) in cat_names
                fill("allowlists", name, lambda g, ok=creatable: STATE_CREATE if ok else STATE_CANT_CREATE)
            elif len(found) > 1:
                fill("allowlists", name, lambda g: STATE_UNKNOWN)
            else:
                fill("allowlists", name, lambda g, aid=found[0]: allowlist_assignment_state(statuses.get(g, {}).get(aid)))

    # Trusted publishers: what each ticked group trusts (green / blue). A
    # publisher not listed is "not trusted" (red) — the page treats any key
    # missing here (e.g. a Bulk Add publisher) the same way.
    pub_states, pub_names = {}, {}
    for g in (present if wants("publishers") else []):
        rows, err = adapter.list_group_publishers(tid, did, refs[g])
        if err:
            raise TenantReadError(f"Couldn't read trusted publishers on '{g}': {err}")
        for r in rows or []:
            key = publisher_key(r.get("Name"), r.get("OSType"))
            pub_states.setdefault(key, {})[g] = STATE_INHERITED if r.get("IsInherited") else STATE_ASSIGNED
            pub_names[key] = r.get("FriendlyName") or r.get("Name")
    for p in (library.get("publishers") or []) if wants("publishers") else []:
        if p.get("key"):
            pub_states.setdefault(p["key"], {})
    for key, per in pub_states.items():
        for g in groups:
            per.setdefault(g, STATE_NOT_ASSIGNED if refs[g] else STATE_GROUP_MISSING)
    result["items"]["publishers"] = pub_states
    result["publisher_names"] = pub_names  # friendly names, e.g. "<GUID> [Mozilla]"

    # Paths / processes / trusted installers: set on the group (green),
    # inherited (blue); anything missing is red. The installer list lives on a
    # different service, so a failure there marks those entries unknown
    # rather than failing the whole tenant.
    for kind, (list_fn, _, key_of, _) in ENTRY_KINDS.items():
        if not wants(kind):
            continue
        states = {}
        for g in present:
            rows, err = getattr(adapter, list_fn)(tid, did, refs[g])
            if err:
                if kind == "installers":
                    for e in library.get(kind) or []:
                        states.setdefault(e.get("key"), {})[g] = STATE_UNKNOWN
                    continue
                raise TenantReadError(f"Couldn't read {kind} on '{g}': {err}")
            for r in rows or []:
                states.setdefault(key_of(r), {})[g] = STATE_INHERITED if r.get("inherited") else STATE_ASSIGNED
        for e in library.get(kind) or []:
            states.setdefault(e.get("key"), {})
        for per in states.values():
            for g in groups:
                per.setdefault(g, STATE_NOT_ASSIGNED if refs[g] else STATE_GROUP_MISSING)
        result["items"][kind] = states
    ref_sw = library.get("installer_switches") or {}
    sw_states = {}
    for g in (groups if wants("installers") else []):
        if not refs[g]:
            sw_states[g] = STATE_GROUP_MISSING
            continue
        cur, err = adapter.get_installer_switches(tid, did, refs[g])
        want = ref_sw.get(g)
        if err or want is None:
            sw_states[g] = STATE_UNKNOWN
        else:
            sw_states[g] = STATE_ASSIGNED if all(int(cur.get(f) or 0) == int(want.get(f) or 0) for f in INSTALLER_SWITCH_FIELDS) else STATE_NOT_ASSIGNED
    if wants("installers"):
        result["items"]["installers"][INSTALLER_SWITCHES_KEY] = sw_states

    # Baselines (matched by catalog FullName, like replication does)
    lib_bs = (library.get("baselines") or []) if wants("baselines") else []
    if lib_bs:
        tenant_bs, err = adapter.list_tenant_baselines(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list baselines: {err}")

        def find(b):
            wanted = {normalize_baseline_name(b["name"])}
            if b.get("full_name"):
                wanted.add(normalize_baseline_name(b["full_name"]))
                if learned.get(b["full_name"]):
                    wanted.add(normalize_baseline_name(learned[b["full_name"]]))
            return next((x for x in tenant_bs if normalize_baseline_name(x.get("Name")) in wanted), None)

        matches = {b["name"]: find(b) for b in lib_bs}
        statuses = {}
        if any(matches.values()):
            for g in present:
                rows, err = adapter.baseline_statuses(tid, did, refs[g])
                if err:
                    raise TenantReadError(f"Couldn't read baseline assignments on '{g}': {err}")
                statuses[g] = {r.get("ID"): r for r in rows or [] if isinstance(r, dict)}
        for b in lib_bs:
            m = matches[b["name"]]
            if not m:
                fill("baselines", b["name"], lambda g, ok=b.get("replicable"): STATE_CREATE if ok else STATE_CANT_CREATE)
            else:
                fill("baselines", b["name"], lambda g, bid=m.get("ID"): baseline_state(statuses.get(g, {}).get(bid)))

    # Group setting: the notification message copied from one reference group
    if message_from:
        msg = next((p["message"] for p in library.get("policy_settings") or [] if p.get("group") == message_from), None)
        for g in groups:
            if not refs[g]:
                result["message"][g] = STATE_GROUP_MISSING
                continue
            loaded, err = adapter.get_policy_settings(tid, did, refs[g])
            if err:
                raise TenantReadError(f"Couldn't read settings on '{g}': {err}")
            same = loaded.get("NotificationMessage") == msg and loaded.get("ClientNotification")
            result["message"][g] = STATE_ASSIGNED if same else STATE_NOT_ASSIGNED
    return result


class StatusChecker:
    """Runs tenant_item_states for several tenants in parallel (each worker
    enters the MSP connection itself — the credential override is per
    thread), with a short cache so ticking boxes doesn't re-read everything."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.lock = threading.Lock()

    def clear(self):
        with self.lock:
            self.cache.clear()

    def check(self, conn, tenants, library, groups, message_from, learned, refresh=False):
        from concurrent.futures import ThreadPoolExecutor
        import time as _time

        def one(t):
            key = (t.get("tenant_id"), tuple(groups), message_from, library.get("fetched_at"))
            with self.lock:
                hit = self.cache.get(key)
            if hit and not refresh and _time.monotonic() - hit[0] < STATUS_CACHE_SECONDS:
                return hit[1]
            out = {"id": t.get("id"), "label": t.get("label"), "is_reference": bool(t.get("is_reference")), "error": None}
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    out.update(tenant_item_states(self.a, t, library, groups, message_from, learned))
            except TenantReadError as e:
                out["error"] = str(e)
            except Exception as e:
                log.exception("MSP status check failed for %s", t.get("label"))
                out["error"] = f"Unexpected error: {e}"
            if out["error"] and "Tenant Role(s) NOT Found" in out["error"]:
                out["error"] += " — the Cloud admin account has no role on this tenant yet (open it once in the Cloud console, or use \"Add Me to Tenant\")."
            if not out["error"]:
                with self.lock:
                    self.cache[key] = (_time.monotonic(), out)
            return out

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            return list(pool.map(one, tenants))


def tenant_dashboard(adapter, tenant, f):
    """Every dashboard panel for one tenant. f = {start_time, end_time,
    policy_group ("All" or a name), include_children, execution_type
    ("All" or an Index)}. Raises TenantReadError on the first failing call."""
    tid, did = tenant.get("tenant_id") or "", tenant.get("directory_id") or ""
    out = {"group_missing": False}
    policy_id = "All"
    if f["policy_group"] != "All":
        policies, err = adapter.list_policies(tid, did)
        if err:
            raise TenantReadError(f"Couldn't list policy groups: {err}")
        group = next((p for p in policies if p.get("name") == f["policy_group"] and is_user_group(p)), None)
        if not group:
            out["group_missing"] = True
            return out
        policy_id = group["id"]
    base = {"start_time": f["start_time"], "end_time": f["end_time"]}
    scoped = dict(base, policy_id=policy_id, include_children="true" if f["include_children"] else "false")
    typed = dict(scoped, execution_type=f["execution_type"])

    def get(path, params):
        flag = "true" if f.get("browser") else "false"
        data, err = adapter.dashboard_get(tid, did, path, dict(params, browser_exec=flag) if params is not None else None)
        if err:
            raise TenantReadError(f"{path}: {err}")
        return data if isinstance(data, dict) else {}

    et = get("execution-types", typed)
    out["execution_types"] = {k: int(v or 0) for k, v in (et.get("counts") or {}).items()}
    vd = et.get("volumeDelta") or {}
    out["volume"] = {"current": int(vd.get("current") or 0), "previous": int(vd.get("previous") or 0)}
    out["counts"] = {k: int(get(f"execution-counts/{k}", scoped).get("count") or 0) for k in DASHBOARD_COUNTS}
    out["new_files"] = [r for r in get("new-files", base).get("data") or [] if isinstance(r, dict)]
    if f.get("browser"):   # New Extensions Seen: the console shows only the extension rows
        out["new_files"] = [r for r in out["new_files"] if r.get("extension") is not False]
    for key, path in (("top_users", "top-users"), ("top_hostnames", "top-hostnames"), ("top_policy_groups", "top-policy-groups")):
        out[key] = {k: int(v or 0) for k, v in (get(path, typed).get("counts") or {}).items()}
    cov = get("audit-enforcement-coverage", None)
    out["coverage"] = {"audit": int(cov.get("auditAgents") or 0), "enforcement": int(cov.get("enforcementAgents") or 0)}
    return out


def aggregate_dashboard(per_tenant):
    """per_tenant: [{id, label, error, group_missing, ...panels}] -> totals
    plus the per-tenant numbers the tiles' breakdowns show."""
    ok = [t for t in per_tenant if not t.get("error") and not t.get("group_missing")]
    agg = {
        "counts": {k: sum(t["counts"].get(k, 0) for t in ok) for k in DASHBOARD_COUNTS},
        "execution_types": {},
        "volume": {"current": sum(t["volume"]["current"] for t in ok), "previous": sum(t["volume"]["previous"] for t in ok)},
        "coverage": {"audit": sum(t["coverage"]["audit"] for t in ok), "enforcement": sum(t["coverage"]["enforcement"] for t in ok)},
        "new_files": [],
        "breakdown": [{"id": t["id"], "label": t["label"], "counts": t.get("counts"), "error": t.get("error"),
                       "group_missing": t.get("group_missing", False)} for t in per_tenant],
        "tenants_ok": len(ok),
        "tenants_total": len(per_tenant),
    }
    for t in ok:
        for k, v in t["execution_types"].items():
            agg["execution_types"][k] = agg["execution_types"].get(k, 0) + v
        for row in t["new_files"]:
            agg["new_files"].append(dict(row, _tenant=t["label"]))
    for key in ("top_users", "top_hostnames", "top_policy_groups"):
        rows = [{"name": name, "tenant": t["label"], "count": n} for t in ok for name, n in t[key].items()]
        agg[key] = sorted(rows, key=lambda r: (-r["count"], r["name"].lower()))[:DASHBOARD_TOP_N]
    return agg


class PublisherPool:
    """The Bulk Add list: the Publisher Summary (publishers seen in untrusted
    executions) of the reference and every managed tenant, merged by
    publisher + OS. Read in parallel, cached per time window."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.lock = threading.Lock()

    def read(self, conn, reference, tenants, window, refresh=False):
        from concurrent.futures import ThreadPoolExecutor
        import time as _time

        sources = ([dict(reference, label=f"{reference.get('label') or 'Reference'} (reference)")] if reference else []) + list(tenants)
        key = (window, tuple(sorted(str(t.get("tenant_id")) for t in sources)))
        with self.lock:
            hit = self.cache.get(key)
        if hit and not refresh and _time.monotonic() - hit[0] < PUBLISHER_POOL_CACHE_SECONDS:
            return hit[1]

        def one(t):
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    rows, err = self.a.publisher_summary(t.get("tenant_id") or "", t.get("directory_id") or "", window)
            except Exception as e:
                log.exception("Publisher Summary failed for %s", t.get("label"))
                rows, err = None, f"Unexpected error: {e}"
            return t, rows, err

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            results = list(pool.map(one, sources))

        merged, errors = {}, []
        for t, rows, err in results:
            label = t.get("label") or t.get("tenant_id")
            if err:
                errors.append({"label": label, "error": err})
                continue
            for r in rows or []:
                name = str(r.get("Name") or "").strip()
                if not name or name == PUBLISHER_NOT_SIGNED:
                    continue
                os_type = r.get("OSType") or "Windows"
                k = publisher_key(name, os_type)
                try:
                    count = int(r.get("Count") or 0)
                except (TypeError, ValueError):
                    count = 0
                e = merged.setdefault(k, {"key": k, "name": name, "friendly": r.get("FriendlyName") or name, "os_type": os_type,
                                          "count": 0, "commonly_trusted": False, "tenants": []})
                e["count"] += count
                e["commonly_trusted"] = e["commonly_trusted"] or bool(r.get("CommonlyTrusted"))
                e["tenants"].append({"label": label, "count": count})
        out = {
            "window": window, "fetched_at": _now(), "sources": len(sources), "errors": errors,
            "publishers": sorted(merged.values(), key=lambda e: (-e["count"], e["name"].lower())),
        }
        if not errors:
            with self.lock:
                self.cache[key] = (_time.monotonic(), out)
        return out


# ---- Exception integrations (Exceptions page) -------------------------------
# Webhooks and the exception-request notification email, copied from the
# reference tenant to the ticked tenants. Tenant-wide, not per policy group.
WEBHOOK_FIELDS = ("name", "enabled", "template", "url", "secret_header", "verify_tls", "event_types", "activity_keywords", "custom_payloads")
EVENT_TITLES = {"exception_request": "Exception Request", "exception_action": "Exception Action", "server_activity": "Server Activity"}


def json_text(value):
    """value escaped for use inside a JSON string."""
    return json.dumps(str(value), ensure_ascii=False)[1:-1]


def customize_payload(text, reference_name, customer, event):
    """Puts the customer's name into one event's payload template, so one
    shared helpdesk channel can tell the customers apart (Airlock has no
    tenant placeholder). In order:
      1. Wherever the template mentions the reference tenant's name, that
         becomes the customer's name — write your reference's name where you
         want the customer's to appear.
      2. Otherwise the first heading — "Exception Request" etc., which every
         built-in template has (Slack/Teams header, Zendesk subject...) —
         gets " — <customer>" appended.
      3. Otherwise, for a JSON object payload, a top-level "customer" field."""
    text = str(text or "")
    if reference_name and reference_name in text:
        return text.replace(json_text(reference_name), json_text(customer))
    title = EVENT_TITLES.get(event)
    if title and title in text:
        return text.replace(title, f"{title} — {json_text(customer)}", 1)
    try:
        obj = json.loads(text)
    except ValueError:
        return text
    if isinstance(obj, dict):
        return json.dumps(dict({"customer": customer}, **obj), indent=2, ensure_ascii=False)
    return text


def default_payloads(options, template_id):
    """{event: template text} of a built-in template, as the console shows it."""
    tpl = next((t for t in (options or {}).get("templates") or [] if t.get("id") == template_id), None) or {}
    out = {}
    for event, body in (tpl.get("event_payloads") or {}).items():
        payload = body.get("payload") if isinstance(body, dict) else body
        out[event] = payload if isinstance(payload, str) else json.dumps(payload, indent=2, ensure_ascii=False)
    return out


def webhook_spec_for(ref_webhook, options, reference_name, customer):
    """What the target tenant's copy of a reference webhook should be."""
    spec = {f: copy.deepcopy(ref_webhook.get(f)) for f in WEBHOOK_FIELDS}
    spec["event_types"] = list(spec.get("event_types") or [])
    spec["activity_keywords"] = list(spec.get("activity_keywords") or [])
    spec["secret_header"] = spec.get("secret_header") or ""
    spec["verify_tls"] = bool(spec.get("verify_tls", True))
    base = dict(default_payloads(options, spec.get("template")))
    base.update(ref_webhook.get("custom_payloads") or {})
    spec["custom_payloads"] = {e: customize_payload(base.get(e, ""), reference_name, customer, e)
                               for e in spec["event_types"] if base.get(e)}
    return spec


def webhook_differences(existing, spec):
    """Fields where the tenant's webhook differs from the wanted one."""
    diffs = []
    for f in WEBHOOK_FIELDS:
        a, b = existing.get(f), spec.get(f)
        if f in ("event_types", "activity_keywords"):
            a, b = sorted(a or []), sorted(b or [])
        if f == "custom_payloads":
            norm = lambda d: {k: re.sub(r"\s+", "", v or "") for k, v in (d or {}).items() if v}
            a, b = norm(a), norm(b)
        if f == "secret_header":
            a, b = a or "", b or ""
        if a != b:
            diffs.append(f)
    return diffs


def email_settings(raw):
    raw = raw or {}
    return {"enabled": bool(raw.get("emailrequest")), "recipients": str(raw.get("emailrecipient") or ""),
            "subject": str(raw.get("emailsubject") or "")}


class IntegrationSync:
    """Reads the reference's exception integrations and compares / copies
    them to managed tenants. Secrets (webhook auth header values) arrive with
    a request, are sent to Airlock and are never stored or logged."""

    def __init__(self, adapter):
        self.a = adapter

    def reference_items(self, conn, reference):
        with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
            tid, did = reference.get("tenant_id"), reference.get("directory_id")
            hooks, err = self.a.list_webhooks(tid, did)
            if err:
                return None, f"Couldn't read the reference's webhooks: {err}"
            options, err = self.a.webhook_options(tid, did)
            if err:
                options = {}
            email, err = self.a.get_exception_email(tid, did)
            if err:
                return None, f"Couldn't read the reference's exception email settings: {err}"
        labels = {t.get("id"): t.get("label") for t in (options or {}).get("templates") or []}
        return {
            "webhooks": [{"name": w.get("name"), "template": w.get("template"), "template_label": labels.get(w.get("template"), w.get("template")),
                          "enabled": bool(w.get("enabled")), "event_types": w.get("event_types") or [],
                          "url_host": re.sub(r"^https?://([^/]+).*$", r"\1", str(w.get("url") or "")),
                          "needs_secret": bool(w.get("secret_header")), "secret_header": w.get("secret_header") or "",
                          "verify_tls": bool(w.get("verify_tls", True)), "custom": bool(w.get("custom_payloads"))}
                         for w in hooks or []],
            "email": email_settings(email),
            "email_saved": email is not None,
            "_raw_hooks": hooks or [], "_options": options or {},
        }, None

    def tenant_plan(self, tenant, ref, reference_name, wanted_hooks, want_email, update_differing, secrets):
        """[(kind, label, status, detail, action|None)] for one tenant —
        status: exists / planned / differs / skipped / error."""
        tid, did, customer = tenant.get("tenant_id"), tenant.get("directory_id"), tenant.get("label") or tenant.get("tenant_id")
        out = []
        if wanted_hooks:
            hooks, err = self.a.list_webhooks(tid, did)
            if err:
                out += [("webhook", f"Webhook '{n}'", "error", f"Couldn't read the tenant's webhooks: {err}", None) for n in wanted_hooks]
                wanted_hooks, hooks = [], []
            by_name = {}
            for h in hooks or []:
                by_name.setdefault(h.get("name"), []).append(h)
            for name in wanted_hooks:
                label = f"Webhook '{name}'"
                rw = next((w for w in ref["_raw_hooks"] if w.get("name") == name), None)
                if not rw:
                    out.append(("webhook", label, "skipped", "No longer on the reference tenant.", None))
                    continue
                spec = webhook_spec_for(rw, ref["_options"], reference_name, customer)
                secret = (secrets or {}).get(name)
                found = by_name.get(name) or []
                if len(found) > 1:
                    out.append(("webhook", label, "skipped", f"The tenant has {len(found)} webhooks with this name — rename one.", None))
                    continue
                if not found:
                    if spec["secret_header"] and not secret:
                        out.append(("webhook", label, "skipped",
                                    f"Needs the value for its '{spec['secret_header']}' auth header — Airlock never returns it, so enter it on this page.", None))
                        continue
                    out.append(("webhook", label, "planned", f"Create ({'enabled' if spec['enabled'] else 'disabled'}), sending to {spec['url']} as {customer}.",
                                lambda spec=spec, secret=secret: self.a.create_webhook(tid, did, spec, secret or "")))
                    continue
                diffs = webhook_differences(found[0], spec)
                if not diffs and not secret:
                    out.append(("webhook", label, "exists", "Already matches the reference.", None))
                    continue
                if diffs and not update_differing:
                    out.append(("webhook", label, "differs", f"Exists but differs ({', '.join(diffs)}) — left unchanged. Tick \"Also update items that differ\" to overwrite it.", None))
                    continue
                what = f"Update ({', '.join(diffs)})" if diffs else "Update the auth header value"
                out.append(("webhook", label, "planned", what + (" and its auth header value." if diffs and secret else "."),
                            lambda wid=found[0].get("id"), spec=spec, secret=secret: self.a.update_webhook(tid, did, wid, spec, secret)))
        if want_email:
            label = "Exception request email"
            cur, err = self.a.get_exception_email(tid, did)
            if err:
                out.append(("exception_email", label, "error", f"Couldn't read the tenant's settings: {err}", None))
            else:
                want = dict(ref["email"])
                want["subject"] = want["subject"].replace(reference_name, customer) if reference_name else want["subject"]
                have = email_settings(cur)
                if have == want:
                    out.append(("exception_email", label, "exists", "Already matches the reference.", None))
                else:
                    state = "on" if want["enabled"] else "off"
                    out.append(("exception_email", label, "planned",
                                f"Set to the reference's: {state}, to {want['recipients'] or 'nobody'}" + (f", subject '{want['subject']}'." if want["subject"] else "."),
                                lambda cid=(cur or {}).get("id"), want=want: self.a.save_exception_email(tid, did, cid, want)))
        return out

    def run(self, conn, reference, tenants, wanted_hooks, want_email, update_differing, secrets, dry_run, ref=None):
        from concurrent.futures import ThreadPoolExecutor
        if ref is None:
            ref, err = self.reference_items(conn, reference)
            if err:
                return None, err
        reference_name = reference.get("label") or ""

        def one(t):
            steps = []
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    for kind, label, status, detail, action in self.tenant_plan(t, ref, reference_name, wanted_hooks, want_email, update_differing, secrets):
                        if status == "planned" and not dry_run:
                            ok, aerr = action()
                            status, detail = ("done", detail) if ok else ("error", aerr or "Failed.")
                        steps.append({"kind": kind, "item": label, "status": status, "detail": detail})
            except Exception as e:
                log.exception("Exception integration sync failed for %s", t.get("label"))
                steps.append({"kind": "integration", "item": "Exception integrations", "status": "error", "detail": f"Unexpected error: {e}"})
            status, counts = summarize_steps([{"outcome": st["status"]} for st in steps])
            return {"id": t.get("id"), "label": t.get("label"), "steps": steps, "counts": counts, "status": status}

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            results = list(pool.map(one, tenants))
        return {"mode": "preview" if dry_run else "apply", "finished_at": _now(), "tenants": results}, None

    def status(self, conn, reference, tenants):
        """Read-only: for each tenant, each reference webhook + the email,
        one of in_sync / differs / missing / error."""
        ref, err = self.reference_items(conn, reference)
        if err:
            return None, err
        res, err = self.run(conn, reference, tenants, [w["name"] for w in ref["webhooks"]],
                            True, update_differing=False, secrets={}, dry_run=True, ref=ref)
        if err:
            return None, err
        out = {}
        for t in res["tenants"]:
            cells = {}
            for st in t["steps"]:
                key = "email" if st["kind"] == "exception_email" else st["item"][len("Webhook '"):-1] if st["item"].startswith("Webhook '") else st["item"]
                cells[key] = {"exists": "in_sync", "planned": "missing" if "Create" in st["detail"] else "differs",
                              "differs": "differs"}.get(st["status"], "needs_secret" if "auth header" in st["detail"] and st["status"] == "skipped" else st["status"])
            out[t["id"]] = cells
        return out, None


# ---- Reports page ----------------------------------------------------------
# The console's Reporting tabs (Agents, Executive Report, Enforcement
# Readiness, Application Context) plus licence tracking, read per tenant and
# combined across the chosen tenants. Read-only.
REPORT_KINDS = ("licenses", "agents", "executive", "readiness", "apps")
REPORT_DAYS = (1, 7, 14, 30)
REPORT_CACHE_SECONDS = 120
LICENSE_WARN_DAYS = 60
EXEC_COUNT_FIELDS = ("total_executions", "trusted_executions", "blocked_executions", "audit_executions", "exception_executions",
                     "otp_executions", "exception_requests", "self_service_executions", "blocklist_executions",
                     "blocklist_block_executions", "blocklist_audit_executions")


def _version_key(v):
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", str(v or "")))


def _merge_named(lists, key="name", count="count", extra=None):
    """Sums counts of [{name, count}] lists by name, biggest first."""
    out = {}
    for lst in lists:
        for item in lst or []:
            if not isinstance(item, dict):
                continue
            k = item.get(key)
            e = out.setdefault(k, {key: k, count: 0})
            e[count] += int(item.get(count) or 0)
            for x in extra or ():
                if item.get(x) is not None and x not in e:
                    e[x] = item.get(x)
    return sorted(out.values(), key=lambda e: -e[count])


def tenant_report(adapter, tenant, kind, params):
    """One tenant's raw data for a report. Raises TenantReadError."""
    tid, did = tenant.get("tenant_id") or "", tenant.get("directory_id") or ""

    def need(res, what):
        data, err = res
        if err:
            raise TenantReadError(f"Couldn't read {what}: {err}")
        return data

    if kind == "licenses":
        lic = need(adapter.report_tenant_license(tid, did), "the licence numbers")
        return {"license": lic}
    if kind == "agents":
        return {"agents": need(adapter.report_agent_summary(tid, did), "the agent summary")}
    if kind == "readiness":
        return {"readiness": need(adapter.report_enforcement_readiness(tid, did, params["days"], params["threshold"]), "enforcement readiness")}
    if kind == "apps":
        return {"apps": need(adapter.report_applications(tid, did), "the application context")}
    if kind == "executive":
        days = params["days"]
        out = {}
        for section in ("endpoint_coverage", "policy_governance", "exception_management", "system_health", "execution_activity_top_blocked"):
            out[section] = need(adapter.report_executive_section(tid, did, days, section), f"the executive report ({section})")
        start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        chunks = []
        for i in range(days - 1, -1, -1):
            day = start - timedelta(days=i)
            chunks.append(need(adapter.report_executive_section(tid, did, days, "execution_activity",
                                                               day.strftime("%Y-%m-%dT00:00:00.000Z")), "the execution activity"))
        out["execution_days"] = chunks
        return out
    raise ValueError(kind)


def aggregate_report(kind, rows, directories=None):
    """Combines per-tenant rows ({id, label, error, ...raw}) into one report:
    {totals..., tenants: [per-tenant summary row]}."""
    ok = [r for r in rows if not r.get("error")]
    errors = [{"label": r["label"], "error": r["error"]} for r in rows if r.get("error")]
    out = {"kind": kind, "errors": errors, "tenant_count": len(ok)}

    if kind == "licenses":
        today = datetime.now(timezone.utc)
        tenants = []
        for r in ok:
            lic, d = r["license"], (directories or {}).get(r.get("directory_id")) or {}
            end = d.get("end") or ""
            days_left = None
            if end and d.get("dates_enabled", True):
                try:
                    days_left = (datetime.fromisoformat(end.replace("Z", "+00:00")) - today).days
                except ValueError:
                    days_left = None
            tenants.append({"id": r["id"], "label": r["label"], "allocated": lic["allocated"], "used": lic["used"],
                            "unmanaged": lic["unmanaged"], "free": lic["allocated"] - lic["used"],
                            "pct": round(100 * lic["used"] / lic["allocated"], 1) if lic["allocated"] else None,
                            "directory": d.get("name") or "", "expires": end, "days_left": days_left,
                            "disabled_by_expiry": lic.get("disabled_by_expiry"),
                            "flag": "over" if lic["used"] > lic["allocated"] else "expiring" if days_left is not None and days_left <= LICENSE_WARN_DAYS
                            else "high" if lic["allocated"] and lic["used"] / lic["allocated"] >= 0.9 else ""})
        out["tenants"] = sorted(tenants, key=lambda t: t["label"].lower())
        out["totals"] = {k: sum(t[k] for t in tenants) for k in ("allocated", "used", "unmanaged", "free")}
        out["totals"]["pct"] = round(100 * out["totals"]["used"] / out["totals"]["allocated"], 1) if out["totals"]["allocated"] else None
        out["directories"] = [dict(v, id=k, allocated=sum(t["allocated"] for t, r in zip(tenants, ok) if r.get("directory_id") == k))
                              for k, v in (directories or {}).items() if v]
        return out

    if kind == "agents":
        platforms, oses, health, status, policies, tenants = {}, {}, {}, {"Online": 0, "Offline": 0, "Stale": 0}, [], []
        for r in ok:
            a = r["agents"] or {}
            st = {c.get("label"): int(c.get("agents") or 0) for c in (a.get("status") or {}).get("counts") or []}
            for k in status:
                status[k] += st.get(k, 0)
            total = int((a.get("version") or {}).get("total_agents") or (a.get("status") or {}).get("total_agents") or 0)
            latest = {}
            for p in (a.get("version") or {}).get("platforms") or []:
                e = platforms.setdefault(p.get("platform"), {"platform": p.get("platform"), "agents": 0, "versions": {}})
                e["agents"] += int(p.get("agents") or 0)
                for v in p.get("versions") or []:
                    e["versions"][v.get("version")] = e["versions"].get(v.get("version"), 0) + int(v.get("agents") or 0)
                latest[p.get("platform")] = p.get("latest_version")
            for h in (a.get("status") or {}).get("check_in_health") or []:
                health[h.get("since_minutes")] = health.get(h.get("since_minutes"), 0) + int(h.get("agents") or 0)
            for o in (a.get("os_distribution") or {}).get("operating_systems") or []:
                for c in o.get("children") or [o]:
                    e = oses.setdefault(c.get("os"), {"os": c.get("os"), "family": o.get("os"), "agents": 0, "agents_online": 0})
                    e["agents"] += int(c.get("agents") or 0)
                    e["agents_online"] += int(c.get("agents_online") or 0)
            for p in (a.get("top_policies") or {}).get("policies") or []:
                policies.append({"tenant": r["label"], "policy_group": p.get("policy_group"), "mode": p.get("mode"),
                                 "agents": int(p.get("total_agents") or 0), "online": int(p.get("agents_online") or 0)})
            tenants.append({"id": r["id"], "label": r["label"], "total": total, "online": st.get("Online", 0), "offline": st.get("Offline", 0),
                            "stale": st.get("Stale", 0), "versions": latest})
        plat = []
        for e in platforms.values():
            vs = sorted(({"version": v, "agents": n} for v, n in e["versions"].items()), key=lambda x: _version_key(x["version"]), reverse=True)
            plat.append({"platform": e["platform"], "agents": e["agents"], "latest_version": vs[0]["version"] if vs else "N/A", "versions": vs})
        out.update({"total_agents": sum(t["total"] for t in tenants), "status": status, "platforms": plat,
                    "check_in_health": [{"since_minutes": k, "agents": v} for k, v in health.items()],
                    "os": sorted(oses.values(), key=lambda e: -e["agents"]), "policies": sorted(policies, key=lambda p: -p["agents"]),
                    "tenants": tenants})
        return out

    if kind == "readiness":
        groups, tenants = [], []
        for r in ok:
            d = r["readiness"] or {}
            for g in d.get("groups") or []:
                groups.append(dict({k: g.get(k) for k in ("policy_name", "total_clients", "ready_clients", "not_ready_clients",
                                                          "online_clients", "ready_percentage", "recommendation")}, tenant=r["label"]))
            tot = int(d.get("total_clients") or 0)
            not_ready = int(d.get("total_not_ready") or 0)
            tenants.append({"id": r["id"], "label": r["label"], "audit_groups": int(d.get("total_policies") or 0), "total": tot,
                            "ready": tot - not_ready, "not_ready": not_ready, "pct": round(100 * (tot - not_ready) / tot, 1) if tot else None})
        tot = sum(t["total"] for t in tenants)
        ready = sum(t["ready"] for t in tenants)
        out.update({"total_clients": tot, "ready": ready, "not_ready": tot - ready, "pct": round(100 * ready / tot, 1) if tot else None,
                    "groups": sorted(groups, key=lambda g: (-(g.get("ready_percentage") or 0), g["tenant"])), "tenants": tenants})
        return out

    if kind == "apps":
        apps, tenants, labels = {}, [], {}
        for r in ok:
            d = r["apps"] or {}
            for c in d.get("categories") or []:
                if isinstance(c, dict) and c.get("key"):
                    labels.setdefault(c["key"], c.get("label") or c["key"])
            tcats = {}
            for g in d.get("groups") or []:
                key = (str(g.get("name") or "").strip().lower(), str(g.get("publisher") or "").strip().lower())
                cats = [k for k in (g.get("category_keys") or []) if k] or [g.get("primary_category_key") or "unknown"]
                primary = g.get("primary_category_key") or cats[0]
                e = apps.setdefault(key, {"name": g.get("name"), "publisher": g.get("publisher"), "path": g.get("canonical_path"),
                                          "tenants": [], "hash_count": 0, "versions": set(), "category": primary, "categories": [],
                                          "confidence": g.get("confidence_level") or ""})
                for k in dict.fromkeys([primary] + cats):
                    if k not in e["categories"]:
                        e["categories"].append(k)
                    tcats[k] = tcats.get(k, 0) + (1 if r["label"] not in e["tenants"] else 0)
                if r["label"] not in e["tenants"]:
                    e["tenants"].append(r["label"])
                e["hash_count"] += int(g.get("hash_count") or 0)
                e["versions"].update(v for v in g.get("versions") or [] if v)
            tenants.append({"id": r["id"], "label": r["label"], "applications": int(d.get("total_count") or len(d.get("groups") or [])),
                            "files": int(d.get("total_files") or 0), "built_at": d.get("built_at"), "status": d.get("status"),
                            "categories": tcats})
        label = lambda k: labels.get(k) or str(k).replace("_", " ").title()
        rows_ = [dict(e, versions=sorted(e["versions"])[:5], tenant_count=len(e["tenants"]), category_label=label(e["category"]),
                      category_labels=[label(k) for k in e["categories"]]) for e in apps.values()]
        cats = {}
        for e in rows_:
            for k in e["categories"]:
                c = cats.setdefault(k, {"key": k, "label": label(k), "applications": 0, "tenants": set()})
                c["applications"] += 1
                c["tenants"].update(e["tenants"])
        for k, lab in labels.items():           # list every category Airlock knows, even if empty here
            cats.setdefault(k, {"key": k, "label": lab, "applications": 0, "tenants": set()})
        categories = sorted(({**c, "tenants": sorted(c["tenants"]), "tenant_count": len(c["tenants"])} for c in cats.values()),
                            key=lambda c: (-c["applications"], c["label"].lower()))
        out.update({"applications": sorted(rows_, key=lambda e: (-e["tenant_count"], str(e["name"]).lower())), "tenants": tenants,
                    "categories": categories})
        return out

    if kind == "executive":
        cov = {k: 0 for k in ("total_clients", "online_count", "offline_count", "stale_count", "enforcement_clients", "audit_clients",
                              "readiness_ready", "readiness_not_ready", "safemode_count")}
        gov = {k: 0 for k in ("total_policies", "audit_mode_policies", "enforcement_mode_policies", "policy_changes", "policy_rule_modifications")}
        exc = {k: 0 for k in ("exception_sessions", "otp_sessions", "exception_requests", "self_service_sessions")}
        act = {k: 0 for k in EXEC_COUNT_FIELDS}
        trend, exc_trend, cov_trend = {}, {}, {}
        lists = {"type_breakdown": [], "policy_breakdown": [], "top_publishers": [], "top_parent_processes": [],
                 "top_files": [], "maintainers": [], "rule_categories": []}
        health = {"last_activity_at": "", "unmanaged_agent_count": 0, "execution_history_record_count": 0}
        tenants = []
        for r in ok:
            c = (r["endpoint_coverage"] or {}).get("endpoint_coverage") or {}
            for k in cov:
                cov[k] += int(c.get(k) or 0)
            for p in c.get("trend") or []:
                e = cov_trend.setdefault(p.get("timestamp"), {"timestamp": p.get("timestamp"), "total_clients": 0, "enforcing_clients": 0})
                e["total_clients"] += int(p.get("total_clients") or 0)
                e["enforcing_clients"] += int(p.get("enforcing_clients") or 0)
            g = (r["policy_governance"] or {}).get("policy_governance") or {}
            for k in gov:
                gov[k] += int(g.get(k) or 0)
            lists["maintainers"].append(g.get("top_policy_maintainers"))
            lists["rule_categories"].append(g.get("rules_modified_by_category"))
            x = (r["exception_management"] or {}).get("exception_management") or {}
            for k in exc:
                exc[k] += int(x.get(k) or 0)
            for p in x.get("exception_trend") or []:
                e = exc_trend.setdefault(p.get("date"), {"date": p.get("date"), "otp": 0, "requests": 0, "self_service": 0})
                for k in ("otp", "requests", "self_service"):
                    e[k] += int(p.get(k) or 0)
            h = (r["system_health"] or {}).get("system_health") or {}
            health["last_activity_at"] = max(health["last_activity_at"], h.get("last_activity_at") or "")
            health["unmanaged_agent_count"] += int(h.get("unmanaged_agent_count") or 0)
            health["execution_history_record_count"] += int(h.get("execution_history_record_count") or 0)
            tb = ((r["execution_activity_top_blocked"] or {}).get("execution_activity") or {}).get("top_files") or []
            lists["top_files"].append([dict(f, tenant=r["label"]) for f in tb])
            t_act = {k: 0 for k in EXEC_COUNT_FIELDS}
            for day in r["execution_days"]:
                a = day.get("execution_activity") or {}
                for k in EXEC_COUNT_FIELDS:
                    t_act[k] += int(a.get(k) or 0)
                for p in a.get("trend") or []:
                    e = trend.setdefault(p.get("timestamp"), {"timestamp": p.get("timestamp"), "blocked": 0, "audit": 0, "trusted": 0})
                    for k in ("blocked", "audit", "trusted"):
                        e[k] += int(p.get(k) or 0)
                for name in ("type_breakdown", "policy_breakdown", "top_publishers", "top_parent_processes"):
                    lists[name].append(a.get(name))
            for k in EXEC_COUNT_FIELDS:
                act[k] += t_act[k]
            total = int(c.get("total_clients") or 0)
            tenants.append({"id": r["id"], "label": r["label"], "endpoints": total, "online": int(c.get("online_count") or 0),
                            "enforcement_pct": round(100 * int(c.get("enforcement_clients") or 0) / total, 1) if total else None,
                            "ready_for_enforcement": int(c.get("readiness_ready") or 0), "executions": t_act["total_executions"],
                            "blocked": t_act["blocked_executions"], "exception_requests": int(x.get("exception_requests") or 0),
                            "policy_changes": int(g.get("policy_changes") or 0), "last_activity": h.get("last_activity_at") or ""})
        tot = cov["total_clients"]
        files = {}
        for lst in lists["top_files"]:
            for f in lst:
                e = files.setdefault(f.get("hash"), {"name": f.get("name"), "hash": f.get("hash"), "count": 0, "unique_hosts": 0, "tenants": []})
                e["count"] += int(f.get("count") or 0)
                e["unique_hosts"] += int(f.get("unique_hosts") or 0)
                if f["tenant"] not in e["tenants"]:
                    e["tenants"].append(f["tenant"])
        out.update({
            "coverage": dict(cov, online_pct=round(100 * cov["online_count"] / tot, 1) if tot else None,
                             enforcement_pct=round(100 * cov["enforcement_clients"] / tot, 1) if tot else None,
                             trend=sorted(cov_trend.values(), key=lambda e: e["timestamp"] or "")),
            "activity": dict(act, trend=sorted(trend.values(), key=lambda e: e["timestamp"] or ""),
                             type_breakdown=_merge_named(lists["type_breakdown"], key="label"),
                             policy_breakdown=_merge_named(lists["policy_breakdown"])[:10],
                             top_publishers=_merge_named(lists["top_publishers"])[:10],
                             top_parent_processes=_merge_named(lists["top_parent_processes"])[:10],
                             top_files=sorted(files.values(), key=lambda e: -e["count"])[:10]),
            "governance": dict(gov, maintainers=_merge_named(lists["maintainers"])[:10], rule_categories=_merge_named(lists["rule_categories"])),
            "exceptions": dict(exc, trend=sorted(exc_trend.values(), key=lambda e: e["date"] or "")),
            "health": health, "tenants": tenants})
        return out
    raise ValueError(kind)


class ReportReader:
    """Reads a report for several tenants in parallel, cached briefly."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.lock = threading.Lock()

    def read(self, conn, tenants, kind, params, refresh=False):
        from concurrent.futures import ThreadPoolExecutor
        import time as _time
        pkey = json.dumps(params, sort_keys=True)

        def one(t):
            key = (kind, t.get("tenant_id"), pkey)
            with self.lock:
                hit = self.cache.get(key)
            if hit and not refresh and _time.monotonic() - hit[0] < REPORT_CACHE_SECONDS:
                return hit[1]
            out = {"id": t.get("id"), "label": t.get("label"), "directory_id": t.get("directory_id"), "error": None}
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    out.update(tenant_report(self.a, t, kind, params))
            except TenantReadError as e:
                out["error"] = str(e)
            except Exception as e:
                log.exception("MSP report %s failed for %s", kind, t.get("label"))
                out["error"] = f"Unexpected error: {e}"
            if not out["error"]:
                with self.lock:
                    self.cache[key] = (_time.monotonic(), out)
            return out

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            rows = list(pool.map(one, tenants))
        directories = {}
        if kind == "licenses":
            with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                for did in sorted({t.get("directory_id") for t in tenants if t.get("directory_id")}):
                    d, err = self.a.report_directory_license(did)
                    directories[did] = d if not err else {"name": "", "error": err}
        return dict(aggregate_report(kind, rows, directories), read_at=_now(), params=params)


# ---- Creating policy groups across tenants -------------------------------------------
# Airlock creates new groups in enforcement mode, so the mode is always set
# explicitly (Audit by default in the page). Groups are matched by name, like
# everywhere else; existing groups are never renamed, moved or deleted.
GROUP_NAME_MAX = 100


def clean_group_specs(raw):
    """[{name, parent ("" = top level), mode: "audit"|"enforce"}] in an order
    where every parent named in the batch comes before its children."""
    if not isinstance(raw, list) or not raw:
        return None, "Add at least one group."
    specs, seen = [], set()
    for r in raw:
        r = r if isinstance(r, dict) else {}
        name = " ".join(str(r.get("name") or "").split())
        parent = " ".join(str(r.get("parent") or "").split())
        mode = r.get("mode")
        if not name:
            return None, "Every group needs a name."
        if len(name) > GROUP_NAME_MAX:
            return None, f"'{name[:30]}…' is longer than {GROUP_NAME_MAX} characters."
        if name.lower() in seen:
            return None, f"'{name}' is listed twice."
        if parent.lower() == name.lower():
            return None, f"'{name}' can't be its own parent."
        if mode not in ("audit", "enforce"):
            return None, f"Pick Audit or Enforcement for '{name}'."
        seen.add(name.lower())
        specs.append({"name": name, "parent": parent, "mode": mode})
    ordered, placed = [], set()
    pending = list(specs)
    while pending:
        ready = [s for s in pending if not s["parent"] or s["parent"].lower() not in seen or s["parent"].lower() in placed]
        if not ready:
            return None, "The parents in this list loop back on each other."
        for s in ready:
            ordered.append(s)
            placed.add(s["name"].lower())
            pending.remove(s)
    return ordered, None


def create_groups_on_tenant(adapter, tenant, specs, dry_run):
    """Creates the missing groups on one tenant. Steps per group: exists /
    planned / done / skipped / error (+ a mode step when created)."""
    tid, did = tenant.get("tenant_id") or "", tenant.get("directory_id") or ""
    steps = []
    policies, err = adapter.list_policies(tid, did)
    if err:
        return [{"kind": "group", "item": "(policy groups)", "outcome": "error", "detail": f"Couldn't list policy groups: {err}"}]
    users = [p for p in policies if is_user_group(p)]
    by_name = {p.get("name", "").lower(): p for p in users}
    planned = set()
    for s in specs:
        label = s["name"] if not s["parent"] else f"{s['parent']} › {s['name']}"
        mode_word = "Audit" if s["mode"] == "audit" else "Enforcement"
        have = by_name.get(s["name"].lower())
        if have:
            parent_now = next((p.get("name") for p in users if p.get("id") == have.get("parent")), "")
            note = "" if parent_now.lower() == s["parent"].lower() else f" (under {parent_now or 'the top level'}, not {s['parent'] or 'the top level'} — left as is)"
            steps.append({"kind": "group", "item": label, "outcome": "exists", "detail": f"Already on this tenant{note}."})
            continue
        if s["parent"]:
            parent = by_name.get(s["parent"].lower())
            if not parent and s["parent"].lower() not in planned:
                steps.append({"kind": "group", "item": label, "outcome": "skipped", "detail": f"No policy group named '{s['parent']}' to put it under."})
                continue
        else:
            parent = None
        if dry_run:
            planned.add(s["name"].lower())
            steps.append({"kind": "group", "item": label, "outcome": "planned", "detail": f"Will be created in {mode_word} mode."})
            continue
        parent_id = parent.get("id") if parent else POLICY_GLOBAL_SETTINGS_PARENT
        made, err = adapter.create_policy_group(tid, did, parent_id, s["name"])
        if err:
            steps.append({"kind": "group", "item": label, "outcome": "error", "detail": err})
            continue
        policies, err = adapter.list_policies(tid, did)
        if err:
            steps.append({"kind": "group", "item": label, "outcome": "error", "detail": f"Created, but couldn't re-read the groups to set the mode — it's in Enforcement mode: {err}"})
            continue
        users = [p for p in policies if is_user_group(p)]
        by_name = {p.get("name", "").lower(): p for p in users}
        ref = build_policy_group_ref(policies, made["name"])
        ok, err = adapter.set_policy_group_mode(tid, did, ref, s["mode"] == "audit") if ref else (False, "the new group isn't in the list yet")
        if ok:
            steps.append({"kind": "group", "item": label, "outcome": "done", "detail": f"Created in {mode_word} mode."})
        else:
            steps.append({"kind": "group", "item": label, "outcome": "error",
                          "detail": f"Created, but setting {mode_word} mode failed — it's in Airlock's default Enforcement mode until you change it: {err}"})
    return steps


def reference_group_plan(adapter, conn, reference, tenants):
    """The reference's policy groups (parent-first, with mode) and which of
    them each tenant lacks — for "Copy groups from the reference"."""
    def read(t):
        p, err = adapter.list_policies(t.get("tenant_id") or "", t.get("directory_id") or "")
        return p, err
    results = _parallel(adapter, conn, [reference] + list(tenants), read)
    ref_pol, err = results[0][1], results[0][2]
    if err:
        raise TenantReadError(f"Couldn't list the reference's policy groups: {err}")
    users = [p for p in ref_pol if is_user_group(p)]
    ids = {p["id"]: p for p in users}
    def depth(p):
        d, seen = 0, set()
        while p.get("parent") in ids and p["id"] not in seen:
            seen.add(p["id"]); p = ids[p["parent"]]; d += 1
        return d
    groups = [{"name": p["name"], "parent": ids[p["parent"]]["name"] if p.get("parent") in ids else "", "depth": depth(p),
               "mode": "audit" if str(p.get("auditmode")) == "1" else "enforce"} for p in users]
    order = {p["name"]: i for i, p in enumerate(users)}
    groups.sort(key=lambda g: (g["depth"], order[g["name"]]))
    out = []
    for t, pol, err in results[1:]:
        have = {p.get("name", "").lower() for p in pol or [] if is_user_group(p)}
        out.append({"id": t.get("id"), "label": t.get("label"), "error": err,
                    "missing": [] if err else [g["name"] for g in groups if g["name"].lower() not in have]})
    return {"groups": groups, "tenants": out}


# ---- Policy difference report -------------------------------------------------------
# Every tenant compared with a base tenant (the reference by default, or any
# tenant), group by group (matched by name). Read-only. Per item and group:
#   match    applied (or inherited) on both
#   differs  applied on both, but the content differs (rules, hash/file counts,
#            installer switch values, settings)
#   missing  applied on the base, not on the tenant
#   extra    applied on the tenant, not on the base ("only on tenant"; not scored)
# Publishers are not scored against the base (Ryan, 2026-11-16): they're shown
# as who-trusts-what across every tenant, like the Publishers list.
DRIFT_TYPES = ("blocklists", "allowlists", "baselines", "paths", "processes", "installers", "settings")
DRIFT_LIST_TYPES = ("blocklists", "allowlists", "baselines")
DRIFT_CACHE_SECONDS = 300
_APPLIED = (STATE_ASSIGNED, STATE_INHERITED)


def _drift_content(kind, item):
    """What 'differs' compares for an item present on both tenants."""
    if kind == "blocklists":
        return {"rules": sorted((r["name"], r.get("os_type") or "", r.get("criteria_count") or 0) for r in item.get("rules") or []),
                "hashes": item.get("hash_count")}
    if kind == "allowlists":
        return {"rules": sorted((r["name"], r.get("os_type") or "", r.get("criteria_count") or 0, bool(r.get("elevated"))) for r in item.get("rules") or []),
                "files": item.get("file_count") or 0}
    return None


def _content_notes(kind, a, b):
    """Human differences between base content a and tenant content b."""
    notes = []
    if a is None or b is None:
        return notes
    if a.get("hashes") is not None and b.get("hashes") is not None and a["hashes"] != b["hashes"]:
        notes.append(f"hashes {a['hashes']} vs {b['hashes']}")
    if "files" in a and a["files"] != b.get("files"):
        notes.append(f"files {a['files']} vs {b.get('files')}")
    ra, rb = {r[0]: r for r in a["rules"]}, {r[0]: r for r in b["rules"]}
    only_a, only_b = sorted(set(ra) - set(rb)), sorted(set(rb) - set(ra))
    changed = sorted(n for n in set(ra) & set(rb) if ra[n] != rb[n])
    if only_a:
        notes.append("rules missing: " + ", ".join(only_a))
    if only_b:
        notes.append("extra rules: " + ", ".join(only_b))
    if changed:
        notes.append("rules changed: " + ", ".join(changed))
    return notes


def tenant_policy_snapshot(adapter, tenant, learned):
    """Phase 1 for one tenant: its own library (ReferenceReader works on any
    tenant) and its policy groups' modes."""
    tid, did = tenant.get("tenant_id") or "", tenant.get("directory_id") or ""
    try:
        inv = ReferenceReader(adapter, tenant, learned).inventory()
    except ReferenceReadError as e:
        raise TenantReadError(str(e).replace("the reference tenant's ", "the ").replace("the reference tenant", "the tenant"))
    policies, err = adapter.list_policies(tid, did)
    if err:
        raise TenantReadError(f"Couldn't list policy groups: {err}")
    modes = {p.get("name"): ("Audit" if str(p.get("auditmode")) == "1" else "Enforcement" if str(p.get("auditmode")) == "0" else "")
             for p in policies if is_user_group(p)}
    return {"inventory": inv, "modes": modes}


def drift_union_library(snaps):
    """Every blocklist / allowlist / baseline on any compared tenant, so each
    tenant's assignments are read for the same names."""
    lib = {k: [] for k in DRIFT_LIST_TYPES}
    seen = {k: set() for k in DRIFT_LIST_TYPES}
    for snap in snaps:
        for k in DRIFT_LIST_TYPES:
            for item in snap["inventory"].get(k) or []:
                if item.get("name") not in seen[k]:
                    seen[k].add(item.get("name"))
                    lib[k].append(item)
    return lib


def tenant_policy_view(adapter, tenant, snap, union, groups, learned):
    """Phase 2 for one tenant: {type: {key: {"name", "groups": {g: state},
    "content"}}} for every compared type, plus settings, switches and
    publishers, for the compared groups."""
    inv = snap["inventory"]
    st = tenant_item_states(adapter, tenant, union, groups, None, learned, kinds=set(DRIFT_LIST_TYPES))
    missing_groups = set(st["groups_missing"])
    gstate = lambda g, direct, inherited: (STATE_GROUP_MISSING if g in missing_groups else STATE_ASSIGNED if g in direct
                                           else STATE_INHERITED if g in inherited else STATE_NOT_ASSIGNED)
    own = {k: {i.get("name"): i for i in inv.get(k) or []} for k in DRIFT_LIST_TYPES}
    view = {"groups_missing": sorted(missing_groups), "items": {}}
    for k in DRIFT_LIST_TYPES:
        view["items"][k] = {name: {"name": name, "groups": per, "content": _drift_content(k, own[k].get(name) or {}) if name in own[k] else None}
                            for name, per in (st["items"].get(k) or {}).items()}
    for k in ENTRY_KINDS:
        view["items"][k] = {e["key"]: {"name": e.get("name") or e["key"], "groups": {g: gstate(g, e.get("groups") or [], e.get("inherited_groups") or []) for g in groups},
                                       "content": None} for e in inv.get(k) or []}
    sw = inv.get("installer_switches") or {}
    view["switches"] = {g: (None if g in missing_groups else sw.get(g)) for g in groups}
    msgs = {p["group"]: p for p in inv.get("policy_settings") or []}
    view["settings"] = {g: (None if g in missing_groups else {"mode": snap["modes"].get(g) or "",
                                                              "message": (msgs.get(g) or {}).get("message", ""),
                                                              "notify": bool((msgs.get(g) or {}).get("enabled"))}) for g in groups}
    view["publishers"] = {p["key"]: {"name": p.get("friendly") or p.get("name"), "os_type": p.get("os_type"),
                                     "groups": {g: gstate(g, p.get("groups") or [], p.get("inherited_groups") or []) for g in groups}}
                          for p in inv.get("publishers") or []}
    return view


def _cell(kind, base_item, item, groups, groups_missing=()):
    """Compare one item on one tenant with the base, group by group."""
    per, notes = {}, []
    for g in groups:
        b = (base_item or {}).get("groups", {}).get(g, STATE_NOT_ASSIGNED)
        t = STATE_GROUP_MISSING if g in groups_missing else (item or {}).get("groups", {}).get(g, STATE_NOT_ASSIGNED)
        if t == STATE_GROUP_MISSING:
            r = "group_missing" if b in _APPLIED else None
        elif b in _APPLIED and t in _APPLIED:
            r = "match"
        elif b in _APPLIED:
            r = "missing"
        elif t in _APPLIED:
            r = "extra"
        else:
            r = None
        if r:
            per[g] = {"result": r, "base": b, "tenant": t}
    if not per:
        return None
    if any(c["result"] == "match" for c in per.values()):
        notes = _content_notes(kind, (base_item or {}).get("content"), (item or {}).get("content"))
        if notes:
            for c in per.values():
                if c["result"] == "match":
                    c["result"] = "differs"
    order = ("missing", "group_missing", "differs", "extra", "match")
    result = next(r for r in order if any(c["result"] == r for c in per.values()))
    inherited = result == "match" and all(c["tenant"] == STATE_INHERITED for c in per.values() if c["result"] == "match")
    return {"result": result, "inherited": inherited, "groups": per, "notes": notes}


def compare_policies(base_t, base_view, targets, groups):
    """targets: [(tenant, view or None, error)]. Returns the report."""
    rows = {k: {} for k in DRIFT_TYPES}
    tenants = []
    for t, view, err in targets:
        entry = {"id": t.get("id"), "label": t.get("label"), "error": err, "groups_missing": [],
                 "categories": {k: {"match": 0, "differs": 0, "missing": 0, "extra": 0} for k in DRIFT_TYPES}, "fix": {}, "score": None}
        tenants.append(entry)
        if err:
            continue
        entry["groups_missing"] = [g for g in view["groups_missing"] if g in groups]
        for k in DRIFT_TYPES:
            if k == "settings":
                continue
            keys = set(base_view["items"].get(k, {})) | set(view["items"].get(k, {}))
            for key in keys:
                c = _cell(k, base_view["items"][k].get(key), view["items"][k].get(key), groups, set(view["groups_missing"]))
                if not c:
                    continue
                name = (base_view["items"][k].get(key) or view["items"][k].get(key))["name"]
                row = rows[k].setdefault(key, {"type": k, "key": key, "name": name, "cells": {},
                                               "on_base": key in base_view["items"][k] and any(s in _APPLIED for s in base_view["items"][k][key]["groups"].values())})
                row["cells"][t.get("id")] = c
                if c["result"] in entry["categories"][k]:
                    entry["categories"][k][c["result"]] += 1
                if c["result"] == "missing":
                    # Fix targets the groups where the base sets the item itself;
                    # its children then inherit it, as on the base.
                    miss = [g for g, x in c["groups"].items() if x["result"] == "missing"]
                    direct = [g for g in miss if c["groups"][g]["base"] == STATE_ASSIGNED]
                    entry["fix"].setdefault(k, []).append({"key": key, "groups": direct or miss})
        # installer switches: one row per group
        for g in groups:
            want, have = base_view["switches"].get(g), view["switches"].get(g)
            if want is None:
                continue
            key = f"{INSTALLER_SWITCHES_KEY}::{g}"
            if have is None:
                c = {"result": "group_missing", "inherited": False, "groups": {}, "notes": []}
            else:
                diff = [f"{INSTALLER_SWITCH_LABELS.get(f, f)}: {SWITCH_VALUE_LABELS.get(int(want.get(f) or 0))} vs {SWITCH_VALUE_LABELS.get(int(have.get(f) or 0))}"
                        for f in INSTALLER_SWITCH_FIELDS if int(want.get(f) or 0) != int(have.get(f) or 0)]
                c = {"result": "differs" if diff else "match", "inherited": False, "groups": {}, "notes": diff}
            row = rows["installers"].setdefault(key, {"type": "installers", "key": key, "name": f"Trusted installer switches — {g}", "cells": {}, "on_base": True, "group": g})
            row["cells"][t.get("id")] = c
            if c["result"] in ("match", "differs"):
                entry["categories"]["installers"][c["result"]] += 1
            if c["result"] == "differs":
                entry["fix"].setdefault("installers", []).append({"key": INSTALLER_SWITCHES_KEY, "groups": [g]})
        # settings: mode, notification message per group
        for g in groups:
            want, have = base_view["settings"].get(g), view["settings"].get(g)
            if want is None:
                continue
            for setting, label in (("mode", "Mode"), ("notify", "Notification on"), ("message", "Notification message")):
                key = f"{setting}::{g}"
                if have is None:
                    c = {"result": "group_missing", "notes": [], "base": want[setting], "tenant": None}
                else:
                    same = want[setting] == have[setting]
                    c = {"result": "match" if same else "differs", "notes": [], "base": want[setting], "tenant": have[setting]}
                row = rows["settings"].setdefault(key, {"type": "settings", "key": key, "name": f"{label} — {g}", "cells": {}, "on_base": True,
                                                        "group": g, "setting": setting, "base_value": want[setting]})
                row["cells"][t.get("id")] = c
                if c["result"] in ("match", "differs"):
                    entry["categories"]["settings"][c["result"]] += 1
        cats = entry["categories"]
        scored = sum(c["match"] + c["differs"] + c["missing"] for c in cats.values())
        entry["score"] = round(100 * sum(c["match"] for c in cats.values()) / scored) if scored else None
    for k in DRIFT_TYPES:
        rows[k] = sorted(rows[k].values(), key=lambda r: (not r["on_base"], str(r["name"]).lower()))
    return {"tenants": tenants, "rows": rows}


def publisher_matrix(entries, groups):
    """entries: [(tenant, view)] incl. the base. Who trusts each publisher on
    the compared groups. Never scored, never 'missing'."""
    pubs = {}
    for t, view in entries:
        for key, p in (view or {}).get("publishers", {}).items():
            states = {g: s for g, s in p["groups"].items() if s in _APPLIED}
            if not states:
                continue
            row = pubs.setdefault(key, {"key": key, "name": p["name"], "os_type": p["os_type"], "cells": {}})
            row["cells"][t.get("id")] = {"inherited": all(s == STATE_INHERITED for s in states.values()), "groups": states}
    return sorted(pubs.values(), key=lambda r: (-len(r["cells"]), str(r["name"]).lower()))


class DriftReader:
    """Reads every compared tenant in parallel (phase 1: libraries; phase 2:
    assignments for the combined library) and compares them with the base.
    Snapshots are cached for a few minutes."""

    def __init__(self, adapter):
        self.a = adapter
        self.snaps = {}
        self.lock = threading.Lock()

    def read(self, conn, base, targets, groups, learned, refresh=False):
        import time as _time
        everyone = [base] + [t for t in targets if t is not base]

        def snap(t):
            key = str(t.get("tenant_id"))
            with self.lock:
                hit = self.snaps.get(key)
            if hit and not refresh and _time.monotonic() - hit[0] < DRIFT_CACHE_SECONDS:
                return hit[1], None
            try:
                s = tenant_policy_snapshot(self.a, t, learned)
            except TenantReadError as e:
                return None, str(e)
            with self.lock:
                self.snaps[key] = (_time.monotonic(), s)
            return s, None

        phase1 = _parallel(self.a, conn, everyone, snap)
        snaps = {id(t): (s, e) for t, s, e in phase1}
        base_snap, base_err = snaps[id(base)]
        if base_err:
            raise TenantReadError(f"Couldn't read {base.get('label')}: {base_err}")
        groups = [g for g in (groups or base_snap["inventory"].get("groups") or []) if g in (base_snap["inventory"].get("groups") or [])]
        union = drift_union_library([s for s, e in snaps.values() if s])

        def view(t):
            s, e = snaps[id(t)]
            if e:
                return None, e
            try:
                return tenant_policy_view(self.a, t, s, union, groups, learned), None
            except TenantReadError as err:
                return None, str(err)

        phase2 = _parallel(self.a, conn, everyone, view)
        views = {id(t): (v, e) for t, v, e in phase2}
        base_view, err = views[id(base)]
        if err:
            raise TenantReadError(f"Couldn't read {base.get('label')}: {err}")
        out = compare_policies(base, base_view, [(t, *views[id(t)]) for t in targets], groups)
        out.update({"base": {"id": base.get("id"), "label": base.get("label")}, "groups": groups,
                    "all_groups": base_snap["inventory"].get("groups") or [], "tree": base_snap["inventory"].get("tree") or [],
                    "publishers": publisher_matrix([(t, views[id(t)][0]) for t in everyone], groups),
                    "read_at": _now(), "base_errors": base_snap["inventory"].get("errors") or []})
        return out


_ISO = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?Z$")


def _iso_dt(s):
    s = str(s or "")
    if not _ISO.match(s):
        return None
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def _parallel(adapter, conn, tenants, fn):
    """Run fn(tenant) for each tenant in its own worker inside the MSP
    connection. Returns [(tenant, result, error)]."""
    from concurrent.futures import ThreadPoolExecutor

    def one(t):
        try:
            with adapter.connection(conn.get("base_domain"), conn.get("api_key")):
                res, err = fn(t)
        except Exception as e:
            log.exception("MSP read failed for %s", t.get("label"))
            res, err = None, f"Unexpected error: {e}"
        if err and "Tenant Role(s) NOT Found" in str(err) and "Add Me to Tenant" not in str(err):
            err = f"{err} — the Cloud admin account has no role on this tenant yet (open it once in the Cloud console, or use \"Add Me to Tenant\")."
        return t, res, err

    with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
        return list(pool.map(one, tenants))


class ActivityReader:
    """Server Activity History and Realtime Activity across tenants: each
    tenant is read in parallel, rows are tagged with the tenant and merged
    newest first. Server activity is cached briefly; realtime never is."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.tasks = {}
        self.lock = threading.Lock()

    def server(self, conn, tenants, f, refresh=False):
        import time as _time
        key = (json.dumps(f, sort_keys=True), tuple(str(t.get("tenant_id")) for t in tenants))
        with self.lock:
            hit = self.cache.get(key)
        if hit and not refresh and _time.monotonic() - hit[0] < SERVER_ACTIVITY_CACHE_SECONDS:
            return hit[1]
        results = _parallel(self.a, conn, tenants, lambda t: self.a.server_activity(
            t.get("tenant_id") or "", t.get("directory_id") or "", f["from"], f["to"], f["search"], f["task"], 0, SERVER_ACTIVITY_PER_TENANT))
        rows, per, errors = [], [], []
        for t, res, err in results:
            if err:
                errors.append({"label": t.get("label"), "error": err})
                per.append({"id": t.get("id"), "label": t.get("label"), "count": None, "shown": 0, "error": err})
                continue
            for r in res["rows"]:
                rows.append({"tenant": t.get("label"), "tenant_id": t.get("id"), "datetime": r.get("Datetime"), "task": r.get("Task") or "",
                             "user": r.get("User") or "", "description": r.get("Description") or "", "level": r.get("Loglevel")})
            per.append({"id": t.get("id"), "label": t.get("label"), "count": res["count"], "shown": len(res["rows"]), "error": None})
        rows.sort(key=lambda r: str(r["datetime"] or ""), reverse=True)
        tasks = {}
        for r in rows:
            tasks[r["task"]] = tasks.get(r["task"], 0) + 1
        out = {"rows": rows, "tenants": per, "errors": errors, "filters": f, "read_at": _now(), "tenant_count": len(tenants),
               "total": sum(p["count"] or 0 for p in per), "truncated": any((p["count"] or 0) > p["shown"] for p in per),
               "by_task": sorted(({"task": k, "count": v} for k, v in tasks.items()), key=lambda x: (-x["count"], x["task"]))}
        if not errors:
            with self.lock:
                self.cache[key] = (_time.monotonic(), out)
        return out

    def task_names(self, conn, tenant):
        """The task filter list (same on every tenant); read once and kept."""
        with self.lock:
            if self.tasks.get("names"):
                return self.tasks["names"]
        res = _parallel(self.a, conn, [tenant], lambda t: self.a.server_activity_tasks(t.get("tenant_id") or "", t.get("directory_id") or ""))
        _, names, err = res[0]
        if err or not names:
            return []
        with self.lock:
            self.tasks["names"] = names
        return names

    def realtime(self, conn, tenants, f):
        results = _parallel(self.a, conn, tenants, lambda t: self.a.realtime_activity(
            t.get("tenant_id") or "", t.get("directory_id") or "", f["from"], f["max_rows"], f["types"]))
        rows, per, errors = [], [], []
        for t, res, err in results:
            if err:
                errors.append({"label": t.get("label"), "error": err})
                per.append({"id": t.get("id"), "label": t.get("label"), "count": None, "error": err})
                continue
            for r in res:
                rows.append({"tenant": t.get("label"), "tenant_id": t.get("id"), "id": r.get("ID"),
                             "received": r.get("ReceivedDate"), "event": r.get("EventDate"), "hostname": r.get("HostName") or "",
                             "user": r.get("User") or "", "path": r.get("Path") or "", "executable": r.get("Executable") or "",
                             "hash": r.get("Hash") or "", "type": r.get("FileExecuted") or "", "parent_group": r.get("ParentGroup") or "",
                             "group": r.get("Group") or "", "policy_version": r.get("PolicyVersion") or "",
                             "hashdb_version": r.get("HashBDVersion") or r.get("HashDBVersion") or "", "version_color": r.get("VerColor") or ""})
            per.append({"id": t.get("id"), "label": t.get("label"), "count": len(res), "error": None})
        rows.sort(key=lambda r: str(r["received"] or ""), reverse=True)
        types = {}
        for r in rows:
            types[r["type"]] = types.get(r["type"], 0) + 1
        return {"rows": rows[:f["max_rows"] * max(1, len(tenants))], "tenants": per, "errors": errors, "filters": f, "read_at": _now(),
                "tenant_count": len(tenants), "by_type": sorted(({"type": k, "count": v} for k, v in types.items()), key=lambda x: -x["count"])}


def clean_server_activity_filters(raw):
    raw = raw if isinstance(raw, dict) else {}
    a, b = _iso_dt(raw.get("from")), _iso_dt(raw.get("to"))
    if not a or not b:
        return None, "from and to must be UTC ISO timestamps."
    if b < a:
        return None, "The To date is before the From date."
    if (b - a).days > SERVER_ACTIVITY_MAX_DAYS:
        return None, f"Pick a range of {SERVER_ACTIVITY_MAX_DAYS} days or less."
    return {"from": raw["from"], "to": raw["to"], "search": str(raw.get("search") or "").strip()[:200],
            "task": str(raw.get("task") or "").strip()[:80]}, None


def clean_realtime_filters(raw):
    raw = raw if isinstance(raw, dict) else {}
    a = _iso_dt(raw.get("from"))
    if not a:
        return None, "from must be a UTC ISO timestamp."
    try:
        max_rows = int(raw.get("max_rows") or 400)
    except (TypeError, ValueError):
        max_rows = 400
    types = raw.get("types") if isinstance(raw.get("types"), dict) else {}
    types = {k: types.get(k, True) is not False for k, _ in REALTIME_TYPES}
    if not any(types.values()):
        return None, "Tick at least one execution type."
    return {"from": raw["from"], "max_rows": max(1, min(REALTIME_MAX_ROWS, max_rows)), "types": types}, None


class DashboardReader:
    """Reads the dashboard for several tenants in parallel (each worker
    enters the MSP connection itself), with a short cache."""

    def __init__(self, adapter):
        self.a = adapter
        self.cache = {}
        self.lock = threading.Lock()

    def read(self, conn, tenants, f, refresh=False):
        from concurrent.futures import ThreadPoolExecutor
        import time as _time
        fkey = json.dumps(f, sort_keys=True)

        def one(t):
            key = (t.get("tenant_id"), fkey)
            with self.lock:
                hit = self.cache.get(key)
            if hit and not refresh and _time.monotonic() - hit[0] < DASHBOARD_CACHE_SECONDS:
                return hit[1]
            out = {"id": t.get("id"), "label": t.get("label"), "error": None}
            try:
                with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                    out.update(tenant_dashboard(self.a, t, f))
            except TenantReadError as e:
                out["error"] = str(e)
            except Exception as e:
                log.exception("MSP dashboard read failed for %s", t.get("label"))
                out["error"] = f"Unexpected error: {e}"
            if out["error"] and "Tenant Role(s) NOT Found" in out["error"]:
                out["error"] += " — the Cloud admin account has no role on this tenant yet (open it once in the Cloud console, or use \"Add Me to Tenant\")."
            if not out["error"]:
                with self.lock:
                    self.cache[key] = (_time.monotonic(), out)
            return out

        with ThreadPoolExecutor(max_workers=STATUS_WORKERS) as pool:
            return list(pool.map(one, tenants))


def clean_dashboard_filters(raw):
    raw = raw if isinstance(raw, dict) else {}
    iso = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$")
    start, end = str(raw.get("start_time") or ""), str(raw.get("end_time") or "")
    if not iso.match(start) or not iso.match(end):
        return None, "start_time and end_time must be UTC ISO timestamps, e.g. 2026-11-08T23:39:41.513Z."
    exec_type = str(raw.get("execution_type") if raw.get("execution_type") is not None else "All").strip() or "All"
    browser = raw.get("browser") is True
    types = DASHBOARD_BROWSER_EXECUTION_TYPES if browser else DASHBOARD_EXECUTION_TYPES
    if exec_type != "All" and exec_type not in {str(i) for i, _ in types}:
        return None, "Unknown execution type."
    return {
        "browser": browser,
        "start_time": start,
        "end_time": end,
        "policy_group": str(raw.get("policy_group") or "All").strip() or "All",
        "include_children": raw.get("include_children") is not False,
        "execution_type": exec_type,
    }, None


def summarize_steps(steps):
    counts = {}
    for s in steps:
        counts[s["outcome"]] = counts.get(s["outcome"], 0) + 1
    if counts.get("error"):
        status = "error"
    elif counts.get("planned"):
        status = "changes"
    elif counts.get("done"):
        status = "applied"
    elif counts.get("differs"):
        status = "differs"
    elif counts.get("skipped"):
        # Something was asked for but couldn't be done (e.g. an allowlist
        # that doesn't exist on the tenant and can't be created yet, or a
        # policy group the tenant doesn't have). Never report that as "in
        # sync" (Ryan, 2026-11-15).
        status = "blocked"
    else:
        status = "in_sync"
    return status, counts


# --------------------------------------------------------------------------
# Storage, runs, routes
# --------------------------------------------------------------------------

def _empty_config():
    # dashboard_include_reference: the reference tenant may be one of the
    # MSP's customers (real data to build policies on) or a lab that mirrors
    # their customers' environments (Ryan, 2026-11-08). On by default; an MSP
    # with a lab reference unticks it in Tenant Configuration.
    # discovery: optional hints for "Discover tenants" (the MSP admin's login
    # email and top-level directory ID), only needed if the Cloud won't list
    # tenants from the API key alone.
    return {"msp_name": "", "dashboard_include_reference": True, "discovery": {}, "connection": {}, "reference": None, "managed_tenants": [],
            "inventory": None, "runs": [], "baseline_name_map": {}}


class MspStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()

    def load(self):
        with self.lock:
            data = _empty_config()
            if os.path.exists(self.path):
                try:
                    with open(self.path, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                    if isinstance(loaded, dict):
                        data.update({k: v for k, v in loaded.items() if k in data})
                except (json.JSONDecodeError, OSError):
                    log.exception("Couldn't read %s", self.path)
            return data

    def save(self, data):
        with self.lock:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, self.path)

    def update(self, fn):
        with self.lock:
            data = self.load()
            result = fn(data)
            self.save(data)
            return result


def connection_error(conn):
    if not (conn or {}).get("base_domain"):
        return "Set the Cloud base domain under Connection first."
    if not (conn or {}).get("api_key"):
        return "Save a Cloud admin API key under Connection first."
    return None


class MspRunManager:
    def __init__(self, adapter, store, on_apply_done=None):
        self.a = adapter
        self.store = store
        self.lock = threading.Lock()
        self.active = None
        self.on_apply_done = on_apply_done  # e.g. clear the status cache so colors refresh

    def start(self, sel, reference, tenants, conn, dry_run):
        update_differing = sel["update_differing"]
        if sel.get("trust_on_reference") and sel["items"].get("publishers"):
            # The one write this tool makes to the reference: only the
            # ticked publishers, and only when asked for.
            tenants = [dict(reference, id="reference", is_reference=True,
                            label=f"{reference.get('label') or 'Reference'} (reference)")] + list(tenants)
        with self.lock:
            if self.active and self.active.get("status") == "running":
                return None, "Another run is still in progress — wait for it to finish."
            run = {
                "id": str(uuid.uuid4()),
                "mode": "preview" if dry_run else "apply",
                "update_differing": bool(update_differing),
                "label": selection_label(sel),
                "selection": copy.deepcopy(sel),
                "reference_label": reference.get("label"),
                "status": "running",
                "phase": "Reading the reference tenant…",
                "started_at": _now(),
                "finished_at": None,
                "notes": [],
                "resolved": None,
                "tenants": [
                    {"id": t.get("id"), "label": t.get("label") or t.get("tenant_id"), "tenant_id": t.get("tenant_id"),
                     "is_reference": bool(t.get("is_reference")), "status": "pending", "counts": {}, "steps": []}
                    for t in tenants
                ],
            }
            self.active = run
        self._persist(run)
        threading.Thread(target=self._run, args=(run, reference, tenants, conn, dry_run, update_differing), daemon=True).start()
        return run, None

    def _run(self, run, reference, tenants, conn, dry_run, update_differing):
        learned = dict(self.store.load().get("baseline_name_map") or {})
        try:
            with self.a.connection(conn.get("base_domain"), conn.get("api_key")):
                try:
                    spec, notes = ReferenceReader(self.a, reference, learned).resolve_selection(run["selection"])
                except ReferenceReadError as e:
                    run["notes"] = [str(e)]
                    for slot in run["tenants"]:
                        slot["status"] = "error"
                        slot["steps"] = [{"kind": "reference", "item": "Reference tenant", "outcome": "error",
                                          "detail": "Nothing was done: the reference tenant couldn't be read."}]
                    return
                run["notes"] = notes
                run["resolved"] = spec
                run["phase"] = ""
                self._persist(run)
                for slot, tenant in zip(run["tenants"], tenants):
                    slot["status"] = "running"
                    try:
                        tspec = {"publishers": spec.get("publishers") or []} if tenant.get("is_reference") else spec
                        steps = TenantRun(self.a, tenant, dry_run, update_differing, learned).run(tspec)
                    except Exception as e:
                        log.exception("MSP run crashed on tenant %s", slot["label"])
                        steps = [{"kind": "tenant", "item": slot["label"], "outcome": "error", "detail": f"Unexpected error: {e}"}]
                    slot["steps"] = steps
                    slot["status"], slot["counts"] = summarize_steps(steps)
                    self._persist(run, learned)
        except Exception as e:
            log.exception("MSP run crashed")
            run["notes"] = list(run.get("notes") or []) + [f"Run stopped by an unexpected error: {e}"]
        finally:
            run["status"] = "done"
            run["phase"] = ""
            run["finished_at"] = _now()
            self._persist(run, learned)
            if not dry_run and self.on_apply_done:
                self.on_apply_done()

    def _persist(self, run, learned=None):
        def fn(data):
            runs = [r for r in data.get("runs") or [] if r.get("id") != run["id"]]
            runs.insert(0, copy.deepcopy(run))
            data["runs"] = runs[:MAX_RUN_HISTORY]
            if learned:
                data["baseline_name_map"] = dict(data.get("baseline_name_map") or {}, **learned)
        self.store.update(fn)

    def get(self, run_id):
        if self.active and self.active.get("id") == run_id:
            return copy.deepcopy(self.active)
        return next((r for r in self.store.load().get("runs") or [] if r.get("id") == run_id), None)


def run_summary(run):
    totals = {}
    for t in run.get("tenants") or []:
        totals[t.get("status")] = totals.get(t.get("status"), 0) + 1
    summary = {k: run.get(k) for k in ("id", "mode", "label", "status", "started_at", "finished_at", "update_differing", "reference_label")}
    summary["tenant_count"] = len(run.get("tenants") or [])
    summary["tenant_status_counts"] = totals
    return summary


def _key_preview(value):
    value = str(value or "")
    return f"{value[:4]}…{value[-4:]}" if len(value) > 10 else ("•" * len(value))


def create_msp_blueprint(adapter, config_path):
    missing = [f for f in REQUIRED_ADAPTER_FUNCTIONS if not callable(getattr(adapter, f, None))]
    if missing:
        raise ValueError(f"MSP adapter is missing: {', '.join(missing)}")

    store = MspStore(config_path)
    status = StatusChecker(adapter)
    runs = MspRunManager(adapter, store, on_apply_done=status.clear)
    dashboard = DashboardReader(adapter)
    activity = ActivityReader(adapter)
    drift = DriftReader(adapter)
    integrations = IntegrationSync(adapter)
    reports = ReportReader(adapter)
    publisher_pool = PublisherPool(adapter)
    inventory_lock = threading.Lock()
    bp = Blueprint("msp", __name__, url_prefix="/msp")

    def fail(msg, code=400):
        return jsonify({"success": False, "error": msg}), code

    # -- connection -------------------------------------------------------------
    def connection_payload(conn):
        return {"base_domain": conn.get("base_domain") or "", "has_key": bool(conn.get("api_key")),
                "key_preview": _key_preview(conn.get("api_key")) if conn.get("api_key") else ""}

    @bp.route("/connection", methods=["GET"])
    def connection_get():
        return jsonify(connection_payload(store.load().get("connection") or {}))

    @bp.route("/connection", methods=["POST"])
    def connection_set():
        body = request.get_json(silent=True) or {}
        domain = re.sub(r"^https?://", "", str(body.get("base_domain") or "").strip()).strip("/")
        if not domain:
            return fail("Enter the Cloud base domain, e.g. am.appenforcement.com.")
        key = str(body.get("api_key") or "").strip()

        def fn(data):
            conn = data.get("connection") or {}
            conn["base_domain"] = domain
            if key:
                conn["api_key"] = key
            data["connection"] = conn
            return conn
        conn = store.update(fn)
        return jsonify(dict(connection_payload(conn), success=True))

    @bp.route("/connection/import-nfr", methods=["POST"])
    def connection_import():
        nfr = adapter.nfr_connection() or {}
        if not nfr.get("base_domain") or not nfr.get("api_key"):
            return fail("NFR Tracking doesn't have a saved Cloud connection to copy.")

        def fn(data):
            data["connection"] = {"base_domain": nfr["base_domain"], "api_key": nfr["api_key"]}
            return data["connection"]
        conn = store.update(fn)
        return jsonify(dict(connection_payload(conn), success=True))

    # -- tenants ------------------------------------------------------------------
    def tenants_payload(data):
        return {"reference": data.get("reference"), "managed": data.get("managed_tenants") or []}

    @bp.route("/tenants", methods=["GET"])
    def tenants_get():
        return jsonify(tenants_payload(store.load()))

    @bp.route("/reference", methods=["POST"])
    def reference_set():
        entry, err = clean_tenant_entry(request.get_json(silent=True) or {})
        if err:
            return fail(err)

        def fn(data):
            if any(t.get("tenant_id") == entry["tenant_id"] for t in data.get("managed_tenants") or []):
                return "That tenant is in the managed list — remove it there first. The reference tenant is never a push target."
            old = data.get("reference") or {}
            if old.get("tenant_id") != entry["tenant_id"]:
                data["inventory"] = None  # a different tenant: the cached inventory no longer applies
            data["reference"] = entry
            return None
        err = store.update(fn)
        if err:
            return fail(err)
        return jsonify(dict(tenants_payload(store.load()), success=True))

    @bp.route("/managed", methods=["POST"])
    def managed_add():
        entry, err = clean_tenant_entry(request.get_json(silent=True) or {})
        if err:
            return fail(err)
        entry["id"] = str(uuid.uuid4())

        def fn(data):
            if (data.get("reference") or {}).get("tenant_id") == entry["tenant_id"]:
                return "That's the reference tenant — it can't also be a managed tenant."
            if any(t.get("tenant_id") == entry["tenant_id"] for t in data.get("managed_tenants") or []):
                return "That tenant is already in the managed list."
            data.setdefault("managed_tenants", []).append(entry)
            return None
        err = store.update(fn)
        if err:
            return fail(err)
        return jsonify(dict(tenants_payload(store.load()), success=True))

    @bp.route("/managed/delete", methods=["POST"])
    def managed_delete():
        tid = str((request.get_json(silent=True) or {}).get("id") or "")

        def fn(data):
            before = len(data.get("managed_tenants") or [])
            data["managed_tenants"] = [t for t in data.get("managed_tenants") or [] if t.get("id") != tid]
            return len(data["managed_tenants"]) < before
        if not store.update(fn):
            return fail("Tenant not found.", 404)
        return jsonify(dict(tenants_payload(store.load()), success=True))

    # -- reference inventory ------------------------------------------------------
    @bp.route("/inventory", methods=["GET"])
    def inventory_get():
        return jsonify({"inventory": store.load().get("inventory")})

    @bp.route("/inventory/refresh", methods=["POST"])
    def inventory_refresh():
        data = store.load()
        reference = data.get("reference")
        if not reference:
            return fail("Set the reference tenant first.")
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        if not inventory_lock.acquire(blocking=False):
            return fail("The reference tenant is already being read — wait a moment.", 409)
        try:
            with adapter.connection(conn["base_domain"], conn["api_key"]):
                inv = ReferenceReader(adapter, reference, data.get("baseline_name_map")).inventory()
        except ReferenceReadError as e:
            return fail(str(e), 502)
        finally:
            inventory_lock.release()
        inv["reference_tenant_id"] = reference["tenant_id"]

        def fn(d):
            d["inventory"] = inv
        store.update(fn)
        return jsonify({"success": True, "inventory": inv})

    # -- replication sets ---------------------------------------------------------
    # -- the page -------------------------------------------------------------------
    @bp.route("/ui", methods=["GET"])
    def ui():
        return render_template("msp_manager.html")

    # -- MSP details ------------------------------------------------------------------
    def settings_payload(d):
        disc = d.get("discovery") or {}
        return {"msp_name": d.get("msp_name") or "",
                "dashboard_include_reference": d.get("dashboard_include_reference") is not False,
                "discovery_email": disc.get("email") or "", "discovery_directory_id": disc.get("directory_id") or ""}

    @bp.route("/settings", methods=["GET"])
    def settings_get():
        return jsonify(settings_payload(store.load()))

    @bp.route("/settings", methods=["POST"])
    def settings_set():
        """Partial update: {msp_name?, dashboard_include_reference?}."""
        body = request.get_json(silent=True) or {}
        changes = {}
        if "msp_name" in body:
            name = str(body.get("msp_name") or "").strip()
            if not name:
                return fail("Enter the MSP's name.")
            if len(name) > MAX_NAME_LENGTH:
                return fail(f"The name must be {MAX_NAME_LENGTH} characters or fewer.")
            changes["msp_name"] = name
        if "dashboard_include_reference" in body:
            changes["dashboard_include_reference"] = bool(body.get("dashboard_include_reference"))
        if not changes:
            return fail("Nothing to save.")

        def fn(d):
            d.update(changes)
        store.update(fn)
        return jsonify(dict(settings_payload(store.load()), success=True))

    @bp.route("/managed/update", methods=["POST"])
    def managed_update():
        body = request.get_json(silent=True) or {}
        tid = str(body.get("id") or "")
        entry, err = clean_tenant_entry(body)
        if err:
            return fail(err)

        def fn(data):
            tenants = data.get("managed_tenants") or []
            target = next((t for t in tenants if t.get("id") == tid), None)
            if not target:
                return "Tenant not found."
            if (data.get("reference") or {}).get("tenant_id") == entry["tenant_id"]:
                return "That's the reference tenant — it can't also be a managed tenant."
            if any(t.get("tenant_id") == entry["tenant_id"] and t.get("id") != tid for t in tenants):
                return "Another managed tenant already has that tenant ID."
            target.update(entry)
            return None
        err = store.update(fn)
        if err:
            return fail(err)
        status.clear()
        return jsonify(dict(tenants_payload(store.load()), success=True))

    # -- tenant discovery -------------------------------------------------------------
    @bp.route("/discover", methods=["POST"])
    def discover():
        """Lists every tenant the connection's API key can reach, marked
        reference / managed / available, for the Tenant Configuration pick
        list. Body: {email?, directory_id?} (optional hints, remembered)."""
        body = request.get_json(silent=True) or {}
        email = str(body.get("email") or "").strip()
        directory_id = str(body.get("directory_id") or "").strip()

        def remember(d):
            d["discovery"] = {"email": email, "directory_id": directory_id}
        store.update(remember)
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        with adapter.connection(conn["base_domain"], conn["api_key"]):
            found, method, err = adapter.discover_tenants(email, directory_id)
        if err:
            return fail(err, 502)
        ref_id = (data.get("reference") or {}).get("tenant_id")
        managed = {t.get("tenant_id") for t in data.get("managed_tenants") or []}
        out = []
        for t in found or []:
            roles = t.get("roles") or []
            out.append(dict(
                t,
                status="reference" if t["tenant_id"] == ref_id else "managed" if t["tenant_id"] in managed else "available",
                # Roles only come with the sign-in profile; [] = unknown.
                can_edit=None if not roles else any(r.startswith("edit_") for r in roles),
            ))
        out.sort(key=lambda t: (" / ".join(t["path"]).lower(), t["name"].lower()))
        return jsonify({"success": True, "method": method, "tenants": out, "discovered_at": _now()})

    @bp.route("/managed/bulk", methods=["POST"])
    def managed_bulk():
        """Adds several managed tenants at once (from the discovery list).
        Body: {tenants: [{label, tenant_id, directory_id}]}. Skips the
        reference tenant and ones already managed."""
        raw = (request.get_json(silent=True) or {}).get("tenants") or []
        entries, problems = [], []
        for r in raw if isinstance(raw, list) else []:
            entry, err = clean_tenant_entry(r)
            if err:
                problems.append(f"{(r or {}).get('label') or (r or {}).get('tenant_id') or '?'}: {err}")
            else:
                entries.append(entry)
        if not entries:
            return fail("; ".join(problems) or "Tick at least one tenant to add.")

        def fn(data):
            ref_id = (data.get("reference") or {}).get("tenant_id")
            have = {t.get("tenant_id") for t in data.get("managed_tenants") or []}
            added, skipped = [], []
            for e in entries:
                if e["tenant_id"] == ref_id:
                    skipped.append(f"{e['label']} (it's the reference tenant)")
                elif e["tenant_id"] in have:
                    skipped.append(f"{e['label']} (already managed)")
                else:
                    e["id"] = str(uuid.uuid4())
                    data.setdefault("managed_tenants", []).append(e)
                    have.add(e["tenant_id"])
                    added.append(e["label"])
            return added, skipped
        added, skipped = store.update(fn)
        return jsonify(dict(tenants_payload(store.load()), success=True, added=added, skipped=skipped + problems))

    # -- colors: per tenant x group x item state ------------------------------------------
    @bp.route("/status", methods=["POST"])
    def status_check():
        """Body: {tenant_ids, groups, message_from?, refresh?}. With no
        tenant_ids, reports the reference tenant itself (so browsing the
        library still looks like the console)."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        library = data.get("inventory")
        if not library:
            return fail("Read the reference tenant's library first.")
        groups = [str(g) for g in body.get("groups") or [] if str(g).strip()]
        if not groups:
            return jsonify({"tenants": [], "groups": []})
        wanted = {str(x) for x in body.get("tenant_ids") or []}
        if wanted:
            tenants = [t for t in data.get("managed_tenants") or [] if str(t.get("id")) in wanted]
        else:
            ref = data.get("reference")
            if not ref:
                return fail("Set the reference tenant first.")
            tenants = [dict(ref, id="reference", is_reference=True)]
        results = status.check(conn, tenants, library, groups, str(body.get("message_from") or "").strip(),
                               data.get("baseline_name_map") or {}, refresh=bool(body.get("refresh")))
        return jsonify({"tenants": results, "groups": groups, "checked_at": _now()})

    # -- Reports page ------------------------------------------------------------------------
    @bp.route("/reports", methods=["POST"])
    def reports_read():
        """Body: {kind: licenses|agents|executive|readiness|apps, tenant_id:
        "all"|"reference"|<managed id>, include_reference, days, threshold,
        refresh}. Read-only."""
        body = request.get_json(silent=True) or {}
        kind = body.get("kind")
        if kind not in REPORT_KINDS:
            return fail("Unknown report.")
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        reference = data.get("reference")
        managed = data.get("managed_tenants") or []
        ref_entry = dict(reference, id="reference", label=f"{reference.get('label') or 'Reference'} (reference)") if reference else None
        which = str(body.get("tenant_id") or "all")
        if which == "all":
            chosen = list(managed) + ([ref_entry] if ref_entry and body.get("include_reference", True) else [])
        elif which == "reference":
            chosen = [ref_entry] if ref_entry else []
        else:
            chosen = [t for t in managed if str(t.get("id")) == which]
        if not chosen:
            return fail("No tenants to report on — add managed tenants in Tenant Configuration.")
        try:
            days = int(body.get("days") or 7)
        except (TypeError, ValueError):
            days = 7
        if days not in REPORT_DAYS:
            return fail("Unknown time period.")
        try:
            threshold = max(0, int(body.get("threshold") or 0))
        except (TypeError, ValueError):
            threshold = 0
        params = {"days": days, "threshold": threshold} if kind in ("executive", "readiness") else {}
        return jsonify(reports.read(conn, chosen, kind, params, refresh=bool(body.get("refresh"))))

    # -- Exceptions page: exception integrations ------------------------------------------
    def integration_context():
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return None, None, None, err
        reference = data.get("reference")
        if not reference:
            return None, None, None, "Set the reference tenant first."
        return conn, reference, data.get("managed_tenants") or [], None

    @bp.route("/integrations", methods=["GET"])
    def integrations_read():
        """The reference's webhooks + exception email, and each managed
        tenant's state for them. Read-only; secrets are never returned
        (Airlock masks them anyway)."""
        conn, reference, tenants, err = integration_context()
        if err:
            return fail(err)
        ref, err = integrations.reference_items(conn, reference)
        if err:
            return fail(err)
        states, err = integrations.status(conn, reference, tenants)
        if err:
            return fail(err)
        return jsonify({"reference": reference.get("label"), "webhooks": ref["webhooks"], "email": ref["email"],
                        "email_saved": ref["email_saved"], "states": states, "read_at": _now()})

    @bp.route("/integrations/run", methods=["POST"])
    def integrations_run():
        """Body: {mode: preview|apply, tenant_ids, webhooks: [names], email: bool,
        update_differing, secrets: {webhook name: auth header value}}. The
        secrets go straight to Airlock: not stored, not logged, not echoed."""
        body = request.get_json(silent=True) or {}
        mode = body.get("mode")
        if mode not in ("preview", "apply"):
            return fail("mode must be 'preview' or 'apply'.")
        conn, reference, tenants, err = integration_context()
        if err:
            return fail(err)
        wanted = {str(x) for x in body.get("tenant_ids") or []}
        chosen = [t for t in tenants if str(t.get("id")) in wanted]
        if not chosen:
            return fail("Tick at least one managed tenant.")
        hooks = [str(x) for x in body.get("webhooks") or [] if str(x).strip()]
        want_email = bool(body.get("email"))
        if not hooks and not want_email:
            return fail("Tick at least one webhook or the exception email.")
        secrets = {str(k): str(v) for k, v in (body.get("secrets") or {}).items() if str(v)}
        result, err = integrations.run(conn, reference, chosen, hooks, want_email, bool(body.get("update_differing")),
                                       secrets, dry_run=(mode == "preview"))
        if err:
            return fail(err)
        return jsonify(dict(result, success=True))

    # -- Bulk Add (publisher pool) ---------------------------------------------------------
    @bp.route("/publishers/pool", methods=["GET"])
    def publishers_pool():
        """?window=1d|1w|2w|1mo&refresh=1 — the merged Publisher Summary of
        the reference and every managed tenant. Read-only."""
        window = request.args.get("window") or "1mo"
        if window not in dict(PUBLISHER_WINDOWS):
            return fail("Unknown time window.")
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        reference = data.get("reference")
        if not reference:
            return fail("Set the reference tenant first.")
        out = publisher_pool.read(conn, reference, data.get("managed_tenants") or [], window,
                                  refresh=request.args.get("refresh") in ("1", "true"))
        return jsonify(dict(out, windows=[{"key": k, "name": n} for k, n in PUBLISHER_WINDOWS]))

    # -- dashboard ------------------------------------------------------------------------
    @bp.route("/dashboard/options", methods=["GET"])
    def dashboard_options():
        return jsonify({
            "time": [{"key": k, "name": n} for k, n in DASHBOARD_TIME_OPTIONS],
            "execution_types": [{"index": i, "name": n} for i, n in DASHBOARD_EXECUTION_TYPES],
            "browser_execution_types": [{"index": i, "name": n} for i, n in DASHBOARD_BROWSER_EXECUTION_TYPES],
            "realtime_types": [{"key": k, "name": n} for k, n in REALTIME_TYPES],
        })

    def activity_tenants(body, data):
        """tenant_id: omitted/"all" (managed + reference if the Dashboard
        setting includes it), "reference", or one managed id."""
        reference = data.get("reference")
        ref_entry = dict(reference, id="reference", label=f"{reference.get('label')} (reference)") if reference else None
        one = str(body.get("tenant_id") or "all")
        if one == "reference":
            return ([ref_entry] if ref_entry else []), (None if ref_entry else "No reference tenant is set.")
        if one != "all":
            t = [t for t in data.get("managed_tenants") or [] if str(t.get("id")) == one]
            return t, (None if t else "That tenant isn't in the managed list.")
        tenants = list(data.get("managed_tenants") or [])
        if ref_entry and data.get("dashboard_include_reference") is not False:
            tenants.insert(0, ref_entry)
        return tenants, (None if tenants else "No tenants yet — add them in Tenant Configuration.")

    @bp.route("/groups/reference-plan", methods=["GET"])
    def groups_reference_plan():
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        reference = data.get("reference")
        if not reference:
            return fail("Set the reference tenant first.")
        try:
            return jsonify(reference_group_plan(adapter, conn, dict(reference, id="reference"), data.get("managed_tenants") or []))
        except TenantReadError as e:
            return fail(str(e))

    @bp.route("/groups/create", methods=["POST"])
    def groups_create():
        """Body: {groups: [{name, parent, mode}], tenant_ids: [managed ids,
        and/or "reference"], dry_run}. Creates only what's missing; never
        renames, moves or deletes."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        specs, err = clean_group_specs(body.get("groups"))
        if err:
            return fail(err)
        reference = data.get("reference")
        everyone = ([dict(reference, id="reference", label=f"{reference.get('label') or 'Reference'} (reference)")] if reference else []) + list(data.get("managed_tenants") or [])
        wanted = {str(x) for x in body.get("tenant_ids") or []}
        tenants = [t for t in everyone if str(t.get("id")) in wanted]
        if not tenants:
            return fail("Tick at least one tenant.")
        dry = body.get("dry_run") is not False
        results = _parallel(adapter, conn, tenants, lambda t: (create_groups_on_tenant(adapter, t, specs, dry), None))
        out = []
        for t, steps, e in results:
            steps = steps or [{"kind": "group", "item": "(tenant)", "outcome": "error", "detail": e}]
            st, counts = summarize_steps(steps)
            out.append({"id": t.get("id"), "label": t.get("label"), "status": st, "counts": counts, "steps": steps})
        if not dry:
            status.clear()
            drift.snaps.clear()
            log.info("MSP policy groups created: %s on %d tenant(s)", [s["name"] for s in specs], len(tenants))
        return jsonify({"dry_run": dry, "groups": specs, "tenants": out,
                        "reference_changed": (not dry) and any(t["id"] == "reference" and t["counts"].get("done") for t in out)})

    @bp.route("/drift", methods=["POST"])
    def drift_read():
        """Policy difference report. Body: {base: "reference"|<managed id>,
        compare: "all"|"reference"|<managed id>, groups?: [names], refresh?}.
        Read-only."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        reference = data.get("reference")
        managed = data.get("managed_tenants") or []
        ref_entry = dict(reference, id="reference", label=f"{reference.get('label') or 'Reference'} (reference)") if reference else None
        everyone = ([ref_entry] if ref_entry else []) + list(managed)
        by_id = {str(t.get("id")): t for t in everyone}
        base = by_id.get(str(body.get("base") or "reference"))
        if not base:
            return fail("Pick the tenant to compare against (set a reference tenant in Tenant Configuration).")
        which = str(body.get("compare") or "all")
        if which == "all":
            targets = [t for t in everyone if t is not base]
        else:
            targets = [by_id[which]] if which in by_id and by_id[which] is not base else []
        if not targets:
            return fail("Pick a different tenant to compare with.")
        groups = [str(g) for g in body.get("groups") or [] if isinstance(g, str)]
        try:
            out = drift.read(conn, base, targets, groups, data.get("baseline_name_map") or {}, refresh=bool(body.get("refresh")))
        except TenantReadError as e:
            return fail(str(e))
        out["fixable"] = base.get("id") == "reference"
        return jsonify(out)

    @bp.route("/dashboard/server-activity", methods=["POST"])
    def dashboard_server_activity():
        """Body: {tenant_id?, from, to, search?, task?, refresh?}. Read-only."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        f, err = clean_server_activity_filters(body)
        if err:
            return fail(err)
        tenants, err = activity_tenants(body, data)
        if err:
            return fail(err)
        out = activity.server(conn, tenants, f, refresh=bool(body.get("refresh")))
        return jsonify(dict(out, task_names=activity.task_names(conn, tenants[0])))

    @bp.route("/dashboard/realtime", methods=["POST"])
    def dashboard_realtime():
        """Body: {tenant_id?, from, max_rows, types{BlockedExecution: bool, ...}}. Read-only, never cached."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        f, err = clean_realtime_filters(body)
        if err:
            return fail(err)
        tenants, err = activity_tenants(body, data)
        if err:
            return fail(err)
        return jsonify(activity.realtime(conn, tenants, f))

    @bp.route("/dashboard", methods=["POST"])
    def dashboard_read():
        """Body: {tenant_id? (one tenant, or omitted for all managed tenants),
        start_time, end_time, policy_group, include_children, execution_type,
        refresh?}. Returns totals plus per-tenant numbers."""
        body = request.get_json(silent=True) or {}
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        f, err = clean_dashboard_filters(body)
        if err:
            return fail(err)
        reference = data.get("reference")
        ref_entry = dict(reference, id="reference", label=f"{reference.get('label')} (reference)") if reference else None
        one = str(body.get("tenant_id") or "")
        if one == "reference":
            if not ref_entry:
                return fail("No reference tenant is set.")
            tenants = [ref_entry]
        elif one:
            tenants = [t for t in data.get("managed_tenants") or [] if str(t.get("id")) == one]
            if not tenants:
                return fail("That tenant isn't in the managed list.")
        else:
            tenants = list(data.get("managed_tenants") or [])
            if ref_entry and data.get("dashboard_include_reference") is not False:
                tenants.insert(0, ref_entry)
        if not tenants:
            return jsonify({"tenants": [], "totals": aggregate_dashboard([]), "filters": f})
        per = dashboard.read(conn, tenants, f, refresh=bool(body.get("refresh")))
        return jsonify({"tenants": [{"id": t["id"], "label": t["label"], "error": t.get("error"), "group_missing": t.get("group_missing", False)} for t in per],
                        "totals": aggregate_dashboard(per), "filters": f, "read_at": _now()})

    # -- runs ---------------------------------------------------------------------------
    @bp.route("/runs", methods=["POST"])
    def runs_start():
        """Body: the page's selection + mode. "preview" = Apply Changes
        (stage, read-only); "apply" = Replicate Changes Now."""
        body = request.get_json(silent=True) or {}
        mode = body.get("mode")
        if mode not in ("preview", "apply"):
            return fail("mode must be 'preview' or 'apply'.")
        data = store.load()
        conn = data.get("connection") or {}
        err = connection_error(conn)
        if err:
            return fail(err)
        reference = data.get("reference")
        if not reference:
            return fail("Set the reference tenant first.")
        sel, err = clean_selection(body)
        if err:
            return fail(err)
        wanted = set(sel["tenant_ids"])
        tenants = [t for t in data.get("managed_tenants") or [] if str(t.get("id")) in wanted]
        if not tenants:
            return fail("None of the ticked tenants are in the managed list any more.")
        run, err = runs.start(sel, reference, tenants, conn, dry_run=(mode == "preview"))
        if err:
            return fail(err, 409)
        return jsonify({"success": True, "run": run_summary(run)})

    @bp.route("/runs", methods=["GET"])
    def runs_list():
        return jsonify({"runs": [run_summary(r) for r in store.load().get("runs") or []]})

    @bp.route("/runs/<run_id>", methods=["GET"])
    def runs_get(run_id):
        run = runs.get(run_id)
        if not run:
            return jsonify({"error": "Run not found."}), 404
        return jsonify({"run": run})

    bp.msp_store = store
    bp.msp_runs = runs
    return bp
