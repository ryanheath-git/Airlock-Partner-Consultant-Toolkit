# SE Toolkit — Project Summary

Read this first in a new conversation to get up to speed quickly. It covers what's
built, why it's built the way it is, and mistakes already made once — no need to
repeat them.

## What this is

A local Flask app (`app.py` + `templates/index.html`, single-page frontend) for an
Airlock Digital partner/consultant. Runs on `127.0.0.1:5000` only, single user,
plaintext local config files (deliberate — this is a personal tool, not multi-user
or internet-facing).

Lives at `Documents\airlock-partner-consulting-toolkit` (moved up one level from an
old `airlock-partner-consulting-toolkit_Migrate\airlock-partner-consulting-toolkit`
nesting on 2026-09-04 — just a folder rename/move, no code changes involved).

Renamed from "Airlock Partner Consulting Toolkit" to **SE Toolkit** on 2026-11-03:
page title/header, run.bat, README, API reference page, and the publish zip name
(now `se-toolkit_v<version>.zip`; older `airlock-partner-consulting-toolkit_v*.zip`
files already in the GitHub repo are left as-is). The folder name and the GitHub
repo URL in `config.json` were not changed.

## Tabs / features, in the order they were built

1. **Editor** — run/compile Python snippets, upload compiled .exe to VirusTotal.
2. **Scripts** — run local Airlock Digital scripts with env vars
   (`AIRLOCK_API_KEY`/`TENANT`/`PORT`, `VT_API_KEY`) injected from the active
   connection. Auto-detects an output file from a script's own stdout
   (`HTML report:`, `Saved:`, etc.) and offers to open it.
3. **Custom Widgets** tab, tile-list-and-detail-panel UI (click a tile on the left,
   its content opens on the right):
   - **Timed Audit Mode** — move Airlock agents to an audit group temporarily,
     auto-revert on a timer (persists across app restarts).
   - **ISO 27001 Compliance** — evaluates policy groups against a small,
     *editable* set of ISO 27001 controls (`iso_mapping.json`), some with real
     automated rules, others explicitly marked `manual` (honest placeholders,
     not guessed logic). Produces a live dashboard plus a downloadable,
     self-contained HTML report with an endpoint-weighted SVG donut chart
     (weighted by agent count, not just group count).
   - **NFR Tracking** (originally "Partner Engagement Report") — pulls user
     activity, agent counts, audit/enforce split, and license utilization
     across partner tenants in Airlock's **Cloud multi-tenant API** — a
     completely different, undocumented API surface from the on-prem REST API
     the rest of the app uses. See "Cloud API reverse-engineering" below.
     The partner tenant list is collapsible (`<details>`, collapsed by
     default) with a live summary line (e.g. "12 tenants — 8 selected") so you
     don't have to scroll a long tenant list just to generate a report;
     Select all/none and the add-tenant form stay outside it. The generated
     report uses the app's own dark color palette (`--bg`/`--panel`/`--accent`
     etc., same values as `templates/index.html`) instead of plain white/black,
     with a light-theme override for `@media print` so it doesn't waste ink.
     Alongside "Generate report" (opens the HTML report in a new tab), two
     export buttons pull the same data as **Excel** (`.xlsx` — a Summary sheet
     across all tenants plus one sheet per tenant listing its users) or
     **XML** (`.xml` — a `<PartnerEngagementReport>` document with per-tenant
     `<Users>` and explicit `<Errors>` elements, so a failed data pull for one
     tenant is called out rather than silently dropped). All three formats are
     built from `run_cloud_partner_report()` in `app.py`, so they can never
     drift out of sync with each other.
   - **Training Instances** — creates a brand-new Airlock tenant per student
     for a class (Phase 2 design; replaced a Phase 1 design that
     pre-provisioned a fixed instance list and assigned users onto it — see
     "Where things stand" below). Ported from a working, standalone bash
     toolkit (`Airlock_Training_Tenant_Automation_v1`) already used against
     real Airlock AU/AM production. Reuses the same Cloud admin API key as
     NFR Tracking, but tenant creation authenticates with a different header
     pair (`X-ApiKey`/`DirectoryID`, not `UserApiKey`/`tenantID`). Creating a
     class queues one tenant-creation job per roster row
     (`directory/v1/tenant-create-schedule`); a background thread polls each
     job (`quevider/v1/job/{JobID}/status`) every 15 seconds to a terminal
     state, so the UI never has to block on however long provisioning takes.
     Tenant deletion (Phase 3, `directory/v1/tenant-delete`) is now wired up
     too — per student ("Delete tenant") or for a whole class at once
     ("Delete N tenants") once a tenant's creation reached a terminal state.
     It's permanent, always confirmed first, and sends exactly one tenant
     per call even though the payload accepts an array (see "Cloud API
     reverse-engineering" below for why). "Remove from list" stays a
     separate, non-destructive action that never touches Airlock.
     Baseline provisioning (Phase 4) is also wired up: the moment a
     tenant reaches `Completed`, the app automatically adds a configured
     reference baseline to it (`webfe/v1/tenant-baseline-reference-list`
     to fetch the catalog, `webfe/v1/tenant-baseline-reference-create` to
     add the match) — these two calls use the *same* `UserApiKey`
     auth style as NFR Tracking, unlike tenant create/delete/poll, which
     was confirmed (not assumed) from a real capture's `AccessLog`. The
     target baseline is a `FullName` string configurable under Tenant
     creation settings, since Airlock's catalog gets a new monthly-patch
     build periodically. A baseline failure is tracked independently of
     the tenant itself and can be retried per student without touching
     the tenant. Policy assignment (Phase 5) chains right after: once a
     baseline is added, the app resolves it to its tenant-scoped ID
     (`webfe/v1/tenant-baseline-list`), finds the target policy group's
     ID and Audit/Enforced children via the already-shipped
     `policy/v1/policy?limit=10000` call, then assigns it
     (`webfe/v1/tenant-policy-update-changes`) — same auth style again,
     this time confirmed straight from real request headers. The target
     policy group name is also configurable under Tenant creation
     settings (default `Workstations`, which Airlock auto-provisions on
     every new tenant). A policy-assign failure is tracked independently
     of both the baseline and the tenant, retriable on its own.
     Instructor access provisioning (Phase 6) runs first, before both of
     the above: a real-world test showed the automatic chain 403ing on
     every brand-new tenant, because Airlock only grants the calling
     account tenant-level roles the first time someone personally opens
     that tenant in the console. This step replicates that first-visit
     action automatically (`webfe/v1/tenant-user-group-list` to find the
     tenant's "LocalAdmin" group by name, `webfe/v1/tenant-user-create`
     to add the configured instructor to it — the same call the
     console's own "Add Me to Tenant" button fires), using a configurable
     **Instructor full name**/**Instructor email** under Tenant creation
     settings (blank skips the step rather than erroring). A real live
     test then showed the granted role doesn't take effect instantly —
     an automatic baseline-add right after a successful grant still
     403'd, but a manual retry moments later succeeded — so both the
     automatic chain and the manual retry routes now wrap the baseline-
     add and policy-assign calls in a small retry-with-delay helper
     (`retry_on_role_propagation_delay`) that only retries this specific,
     confirmed "Tenant Role(s) NOT Found" error shape, up to 3 times, 3
     seconds apart. See "Where things stand" below for the full story of
     how both of these were found. The "New class" form now only asks for a
     class name and a roster (per-class licence override, auto-expiry, and
     description were removed as unnecessary); "Tenant creation settings"
     shows a live "Licenses allocated: N of M available" descriptor above
     the (renamed) **Tenant license allocation** field — the "N" reuses the
     same Cloud API call NFR Tracking already used, and the "M" comes from
     a second, independent, genuinely read-only call (`directory-search`),
     each able to fail without blocking the other. The **Reference
     baseline (FullName)** field now has a "Suggested baselines" quick-pick
     row above it — the single most recently patched entry per OS, curated
     client-side from the full ~180-entry catalog this app already
     fetches, so browsing doesn't mean scrolling hundreds of entries; the
     field itself stays free-text for anything not in the curated list.
4. **Settings** tab — same tile-list-and-detail-panel UI as Custom Widgets
   (deliberately restructured to match it). Cards: VirusTotal API, Airlock API
   Settings (multi-connection manager), Script folder & execution, GitHub sync,
   **Publish to GitHub**, Logging.
   - **Publish to GitHub** is the opposite direction from GitHub sync — it
     pushes this app's own source *out* to a repo of your choice (same repo
     as sync, or a different one) instead of pulling scripts in. Packages a
     fixed, hand-maintained file list (`GITHUB_PUBLISH_FILES` in `app.py`:
     `app.py`, `templates/index.html`, `iso_mapping.json`, `README.md`,
     `PROJECT_SUMMARY.md`, `requirements.txt`, `run.bat`, `.gitignore`)
     into a single versioned zip (`se-toolkit_v<version>.zip`,
     pushed to the repo root) rather than committing files individually —
     `config.json`, `cloud_config.json`, `training_config.json`, `venv/`,
     `builds/`, `api_scripts/`, and `audit_sessions.json` are structurally
     excluded, not just skipped by convention. The version number
     auto-increments from the last push but stays editable, and every past
     version is kept — a push never overwrites or deletes an older zip.
     Builds one commit via GitHub's Git Data API (blob → tree → commit →
     ref), and handles both an existing branch (fast-forward) and a
     brand-new repo/branch (no parent commit) the first time you publish
     into one. Needs a token with **write** access (classic `repo` scope,
     or fine-grained `Contents: Read and write`, on a repo actually
     included under that token's "Repository access") — a stricter
     requirement than GitHub sync's read-only, optional-for-public-repos
     token.

## Key design decisions

- **Multiple Airlock connections, not one.** Each saved connection bundles
  label + tenant + port + API key as one unit, so a key can never get paired
  with the wrong tenant. One is "active" at a time; switching it takes effect
  immediately across every widget, no restart. Switching from *either*
  Settings or the Scripts tab keeps both in sync, and notifies any
  already-opened widget (Timed Audit Mode, ISO) to refresh stale
  connection-dependent data rather than silently showing data from the
  previous connection.
- **Per-feature config files, not one shared blob.** `config.json` (core
  settings + Airlock connections), `cloud_config.json` (NFR Tracking's admin
  credential + tenant list — deliberately separated after a real persistence
  issue, see Pitfalls), `training_config.json` (Training Instances' own
  tenant-creation settings + class/student tracking), `iso_mapping.json` (ISO
  control rules, git-tracked, meant to be hand-edited), `audit_sessions.json`
  (Timed Audit Mode runtime state). All the *.json config files are
  pretty-printed (`indent=2`) so they're actually readable if someone opens
  them by hand.
- **Rule engine for ISO controls, not hardcoded logic.** `iso_mapping.json`
  defines controls declaratively (`field_equals`, `list_any_match`, `all_of`,
  `manual`); a control with no confirmed field mapping is `manual`, and shows
  as "unknown" rather than a fabricated pass/fail. Manual controls are
  excluded from the compliance-category rollup so an unscored control can't
  silently drag a group into "non-compliant."
- **Reports are self-contained HTML**, not PDF/Word — open in any browser,
  print-to-PDF if needed, no extra dependencies. ISO report downloads; NFR
  Tracking report opens directly in a new tab once data is ready (see
  Pitfalls — this was originally wrong). NFR Tracking additionally offers
  Excel and XML export of the same underlying data, for people who want to
  pivot/filter it or feed it into something else rather than just read it.
- **Logging is toggleable and dual-destination** — Settings → Logging turns
  terminal + rotating `app.log` (5MB, 3 backups) on/off together, live, no
  restart. On by default.

## Cloud API reverse-engineering (NFR Tracking widget)

This was the hardest part of the project — Airlock's Cloud multi-tenant
management API has essentially no public documentation. Found by manually
capturing browser Network tab traffic (Thunder Client for testing, HAR
export for bulk documentation) while using the actual web console.

**What was learned, for reference:**
- Auth: `UserApiKey` header (not `X-ApiKey`, that's the on-prem API), plus
  per-call `tenantID` and `Directoryid` headers. Directory ID is **not fixed**
  — it genuinely varies per partner tenant, confirmed on two different real
  tenants.
- URL shape: `https://<base_domain>/<module>/v1/<endpoint>`. At least four
  modules exist (`willard`, `webfe`, `policy`, `directory`), each hosting
  different endpoints — **the module isn't guessable from the endpoint name**.
  `directory-licence-allocation-list`'s module (`directory`) was wrongly
  assumed to be `webfe` initially and caused a real 404 bug in production use.
- **HTTP method is not consistent across endpoints** — some need GET, some
  need POST (even ones with no meaningful request body). Wrong-method calls
  return 405, which is easy to conflate with an auth problem if you're not
  looking closely.
- Sending more than one item in a batch-shaped request
  (`tenant-policy-clients-in-scope-list` with multiple `TenantPolicyGroupList`
  entries) triggered a `500 Internal Server Error` — the backend doesn't
  handle it, despite the payload accepting an array. Stick to one item per
  call unless multi-item support is explicitly confirmed working.
- A tool (`document_api_from_har.py`, delivered separately from the toolkit
  zip — meant to live in the user's Script Folder) turns a HAR capture into
  an interactive, Swagger-style HTML reference: sidebar grouped by module,
  sample curl command per endpoint, secrets redacted to placeholders. Runs
  incrementally — merges new captures into the same file, filling gaps
  without erasing or duplicating what's already documented.

## Pitfalls hit and already fixed — avoid repeating these

1. **`dict.get(key, default)` doesn't catch an explicit `null`.** Bit us
   twice with real Airlock/Cloud API responses that returned `"agents": null`
   instead of omitting the key or using `[]`. Fix: `(data.get(x) or [])`, not
   `data.get(x, [])`, for any field sourced from a third-party API.
2. **Folder/process mixups look exactly like data-loss bugs.** More than
   once, what looked like a persistence bug was actually the running
   `app.py` and the config file being inspected living in different folders,
   or an old server process still running on port 5000. Fix applied: the app
   now prints its exact working directory and config file paths at startup —
   check that first before assuming a save is broken.
3. **Don't guess API method/module from a sibling endpoint.** Every wrong
   guess in the Cloud API integration came from assuming a new endpoint would
   behave like one already confirmed. Test each one for real.
4. **A report that opens a browser tab before the data is ready is a bug,
   not a nice-to-have fix.** Originally opened the tab immediately then
   filled it in async — user stared at a blank page for minutes on a slow
   multi-tenant pull. Fixed: fetch first, open the tab (via blob URL) only
   once the response is actually in hand; falls back to a clickable link if
   the browser's popup blocker catches the delayed `window.open()`. The
   Excel/XML export buttons follow the same pattern — data is fetched fully
   before a download is triggered.
5. **When two tabs share the same CSS classes for visual consistency, scope
   their JS event handlers independently.** Settings and Custom Widgets both
   use `.widget-tile`/`.widget-detail-panel` for identical styling — their
   click handlers are scoped to `#tab-settings` / `#tab-widgets`
   respectively so opening one never collapses the other.
6. **Terminal log output is the single most effective debugging tool in this
   project.** Every real bug (the null-vs-missing crash, the wrong HTTP
   method, the wrong module) was found by adding a log line and asking for
   the terminal output — not by guessing from symptoms alone.
7. **Flask's dev server doesn't hot-reload.** After any `app.py` or
   `templates/index.html` edit, fully stop the running server and restart it
   (`run.bat` again, or `python app.py`) — otherwise you'll be staring at old
   behavior and wondering why a fix "didn't work."

## Where things stand

Fully working, tested against real Airlock environments (not just synthetic
data) at every step. No known open bugs as of this summary.

Session 2026-09-04 added to NFR Tracking: a collapsible partner tenant list
with a live selected-count summary, a report re-themed to match the app's own
dark palette (with a light print override), and Excel/XML export alongside
the existing HTML report — all three built from the same
`run_cloud_partner_report()` data so they stay in sync. Also moved the
project folder up a level, from `Documents\airlock-partner-consulting-toolkit_Migrate\airlock-partner-consulting-toolkit`
to just `Documents\airlock-partner-consulting-toolkit` (folder move only, no
code changes).

Session 2026-09-08 added the **Publish to GitHub** Settings card — pushes
this app's own source files to a GitHub repo as a single commit via the Git
Data API, using a fixed file list so secrets/runtime files can't end up in
it by accident. See the Settings tab bullet above for details. Verified with
the Flask test client and mocked GitHub API responses covering: pushing to
an existing branch, publishing into a brand-new repo/branch with no prior
commits, a missing-token error, and a malformed repo string — plus a full
template render to confirm the new card doesn't break page load.

Session 2026-09-18 replaced Training Instances' Phase 1 design (a fixed list
of pre-provisioned instances, hand-added with their own Tenant/Group ID, with
roster rows assigned onto them one admin account at a time) with Phase 2:
creating a brand-new Airlock tenant per student on demand, ported from a
working bash toolkit (`Airlock_Training_Tenant_Automation_v1`) already
verified against real Airlock AU/AM production. This confirmed a *third*
Cloud API auth style beyond the two already known — `X-ApiKey` +
`DirectoryID` headers for `directory/v1/tenant-create-schedule` (queues a
job) and a new `quevider` module for `job/{JobID}/status` polling — distinct
from NFR Tracking's `UserApiKey` + `tenantID`/`Directoryid` style. A
background thread (`training_scheduler_loop`, same pattern as the existing
Timed Audit Mode scheduler) polls every in-flight job every 15 seconds so
the widget never blocks on however long provisioning takes; the frontend
polls the class list every 15 seconds too, to reflect live status. Phase 1's
old `training_config.json` data is preserved, not deleted, under a
`legacy_instances` key on first startup after the upgrade. Verified with a
Flask test client and mocked Cloud API responses (26 tests) covering: both
Cloud auth header shapes side by side (to guard against ever conflating
them), successful and failed tenant creation, every Quevider status
(`COMPLETED`, `DEAD`, `WAITING`, an unrecognized value, a transport error
that must NOT be treated as job failure), one student failing to queue
without blocking the rest of the class, duplicate-email and bad-auto-expiry
validation, and removal guards that block deleting a class/student while
still mid-creation. Deleting a tenant is explicitly NOT implemented — the
source toolkit doesn't have that call either — flagged as a Phase 3
follow-up once that endpoint is captured the same way NFR Tracking's and
Phase 1's calls were (a real browser Network capture).

This session also caught two other docs that had drifted out of date from
undocumented prior-session work: Publish to GitHub had already been reworked
from one-commit-per-file to a single versioned zip with full version
history, and Training Instances' Phase 1 had shipped without ever being
written up here. Both are now reflected above and in `README.md`.

Later the same session (2026-09-18), Ryan ran Phase 2 end to end against
real Airlock production — created a test class with two real tenants,
watched both reach `Completed`, then captured a real browser Network
request for deleting a test tenant in the Cloud console and shared it back.
That confirmed Phase 3: `POST directory/v1/tenant-delete`, body
`{"TenantList":[{"ID","DirectoryID"}],"atcp":null}`, same module and
`X-ApiKey`/`DirectoryID` auth as tenant creation, synchronous (no
JobID/polling — `Atro.ErrorOccured == false` means it already happened).
Built `cloud_delete_tenant()` and two new routes — per-student
(`/training/classes/student/delete-tenant`) and per-class bulk
(`/training/classes/delete-tenants`) — both gated to tenants whose creation
reached a terminal state (`completed`/`dead`/`cancelled`/`partial`) and
always sending exactly one tenant per call, since a sibling batch-shaped
Cloud API endpoint (`tenant-policy-clients-in-scope-list`, see "Cloud API
reverse-engineering" above) was previously confirmed to 500 with more than
one item despite accepting an array. The UI now shows a "Delete tenant" /
"Retry delete" button per student and a "Delete N tenants" button per
class, both with an irreversible-action confirm dialog, plus a separate
`delete_status`/`delete_error`/`deleted_at` per student so a failed delete
never overwrites the original creation status. "Remove from list" (local
tracking only) now warns when the tenant it's removing was never actually
deleted in Airlock, rather than staying silent about it. Verified with 12
more tests (38 total for this widget) built directly against Ryan's real
captured response shape, covering: the exact request/response shape,
Atro-level and HTTP-level delete failures, blocked deletes for a tenant
still creating or that never got created, idempotent re-delete rejection,
bulk delete skipping already-deleted tenants without an extra API call, and
that removing a deleted tenant's tracking row still works afterward.

Session 2026-09-19 added Training Instances' Phase 4: automatic baseline
provisioning. Ryan wanted every new training tenant to get a Windows
Workstation baseline as part of provisioning, starting with "Add Baseline
from Reference" in the console's Baselines tab. Two real browser Network
captures confirmed the calls: `POST webfe/v1/tenant-baseline-reference-list`
(payload just `{"atcp":null}` — always returns Airlock's full ~180-entry
reference catalog, not filtered per-request) to find the target baseline by
`FullName`, then `POST webfe/v1/tenant-baseline-reference-create` (payload
`{"TenantReferenceBaselineList":[<the matched entry, echoed back
whole>],"atcp":null}`) to add it. The captured create-call's cURL headers
settled an open question from this project's "Cloud API reverse-engineering"
history: this pair uses the *same* `UserApiKey` + `tenantID`/`Directoryid`
auth style as NFR Tracking (confirmed from the real headers, not inferred
from the AccessLog shape alone as first suspected) — genuinely different
from tenant create/poll/delete's `X-ApiKey`/`DirectoryID` style, so
`cloud_api_request()` is reused here, not `cloud_tenant_api_request()`.
There was also a naming snag: Ryan's stated target, "Windows 11 24H2 x64
April 2026", doesn't exist in the real catalog — the only x64/April 2026
Windows 11 entry is `ServicePack: "25H2"`, and the only true 24H2 entries
are ARM64/older patch levels. Confirmed with Ryan before building: he meant
25H2. Built `cloud_list_reference_baselines()`, `cloud_find_reference_baseline()`
(exact, case-sensitive `FullName` match), `cloud_create_baseline_from_reference()`
(passes the matched catalog entry through unmodified rather than guessing
which of its fields — including a few UI-bookkeeping ones the real capture
showed, like `_id_internal`/`originalSortOrder` — actually matter server-side),
and `cloud_add_baseline_to_tenant()` orchestrating all three. Per Ryan's
choice: baseline creation is automatic the moment
`process_pending_training_jobs()` sees a tenant reach `Completed` (not a
separate manual step), and the target `FullName` is a Settings field
(`baseline_full_name`, default `Windows 11-25H2-x64-April 2026.tar.gz`)
rather than fixed in code, since Airlock publishes a new monthly-patch
baseline periodically. A baseline failure never affects the tenant's own
status — it's tracked independently via `baseline_status`/`baseline_error`/
`baseline_created_at` per student, with "Add baseline"/"Retry baseline"
available per student (new route:
`/training/classes/student/retry-baseline`) once a baseline hasn't already
succeeded. Only ever sends one baseline per create call, same caution as
tenant deletion. Verified with 20 more tests (58 total for this widget)
built against Ryan's real captured request/response shapes, covering the
plain functions in isolation, the automatic on-completion trigger (success
and failure paths, confirming a baseline failure doesn't touch tenant
status), the manual retry route and its guards (already-added, tenant not
yet completed, no Directory ID), and that existing students/classes with no
baseline data at all still render and behave correctly (backward
compatibility with pre-Phase-4 `training_config.json` data).

Later the same session (2026-09-19), Ryan captured the follow-up step he'd
flagged: assigning the newly-added baseline to a policy group — completing
his original ask ("add baselines to the windows Workstation Policy
groups"). This took several rounds of real captures to pin down, since two
different `webfe` endpoints turned out to be UI-state-sync/telemetry calls
rather than data sources (`tenant-policy-table-list`'s response carried no
policy data at all — just the generic Atro ack shape — despite its request
payload looking like it should). Chrome DevTools' body-search (Ctrl+Shift+F
across all captured responses) is what actually found the real source:
`policy?limit=10000`, an endpoint this app already calls
(`cloud_get_policies()`, shipped for Partner Engagement Report), turned out
to already return every policy including the target group by name — no new
endpoint needed for that part. The real write call, `POST
webfe/v1/tenant-policy-update-changes`, was confirmed via a full cURL
capture: its `Policy` field echoes the entire tree (group + children) back
including console-only cosmetic UI fields (icon/expanded/isChecked/etc.)
this app can't derive real values for, so `cloud_build_policy_group_tree()`
sends only the real structural fields (ID/Name/Parent/children) and skips
guessing at the rest — if a live run ever proves the API needs one of
those, that'll be a clear error to fix from, not a guess made now. A
second capture (`GET webfe/v1/tenant-baseline-list`) resolves the just-
added baseline to the UUID-form `BaselineID` the assign call needs — a
genuinely different identifier than the numeric value seen in the
baseline-create response's `TenantBAdded` field (that numeric value turned
out to be the same as `tenant-baseline-list`'s `Timestamp` field, not a
separate ID scheme). Rather than reconstruct the baseline's display name
from the reference catalog's differently-formatted `FullName`, the app
just picks the most-recently-created entry on the tenant, since exactly
one baseline is ever added immediately before this lookup runs. Built
`cloud_list_tenant_baselines()`, `cloud_find_newest_tenant_baseline()`,
`cloud_build_policy_group_tree()`, `cloud_apply_baseline_to_policy_group()`,
and `cloud_assign_baseline_to_policy()` orchestrating all three; chained
automatically right after a successful baseline add in
`process_pending_training_jobs()`, with a matching manual retry route
(`/training/classes/student/retry-policy-assign`) for when only this step
needs another attempt. The target policy group name is a new
`policy_group_name` Settings field (default `Workstations`, confirmed via
a real capture — including its `tenant-baseline-server-activity-list`
activity log — to be what Airlock auto-provisions, alongside
`Workstations Audit`/`Workstations Enforced` children, for every newly
created tenant). Assigning to the parent group cascades a database-
regeneration job to both children automatically — confirmed via the real
capture's `QueviderQueue`, which showed three jobs (group + both children)
from one API call, not three separate assignments. Fixed a latent crash
class while building this: `cloud_get_policies()` and the new
`cloud_list_tenant_baselines()` both used `(data or {}).get(...)`, which
raises `AttributeError` if `data` is a truthy non-dict (e.g. the bare
status string the quevider job-status endpoint returns) — now both check
`isinstance(data, dict)` first. Verified with 20 more tests (78 total for
this widget) built against Ryan's real captured shapes, covering the plain
functions in isolation (including the non-dict-response crash guard), the
full chained automatic flow (baseline succeeds → policy assign attempts →
both tracked independently), the manual retry route and its guards
(already-assigned, baseline not yet added, no Directory ID), and that a
policy-assign failure never touches the baseline's or tenant's own status.

Still the same session (2026-09-19), Ryan ran the freshly-built Phase 4/5
chain against a genuinely brand-new tenant for the first time and hit a
403 on `tenant-baseline-reference-list`: `TenantRoleCheckMessage: "Tenant
Role(s) NOT Found: view_baselines"`, for Ryan's own `UserID`. This was a
real architectural gap, not a code bug — every prior capture in this
feature had been taken from tenants Ryan had already personally opened in
the console, which masked the fact that Airlock doesn't grant the calling
account's tenant-level roles automatically at tenant-creation time via the
API. Two diagnostic theories were proposed (plain retry vs. open the
tenant in console once, then retry); Ryan confirmed the second: "When you
launch a tenant for the first time, it not only launches it, but it
autopopulates myself as a new user admin account. After that, it works."
Rather than guess at a fix, Ryan captured the console's own "Add Yourself
to This Tenant" modal — the exact thing that fires on that first visit —
by opening a genuinely never-before-visited tenant with the Network tab
open. The modal itself ("You don't have access to this tenant. To get
access, add yourself...") confirmed this is a deliberate, distinct action,
not a passive side effect: clicking "Add Me to Tenant" fires `POST
webfe/v1/tenant-user-create`, payload
`{"TenantUserCreate":{"TenantUser":{"FullName","Email","FirstName",
"LastName","UserGroups":[<group id>]}}}`. The captured response's
`AccessLog` is what made this safe to automate on a tenant nobody has
opened: every `TenantRoleCheckMessage` said "NOT Found", but
`AccessGranted` was `true` anyway because of `"Directory Role(s) Found,
Inherited: true"` — this endpoint accepts either a tenant-level role or an
inherited directory-level one, and the account this app authenticates as
already has adequate directory-level admin roles. One wrong turn along the
way: the modal's "Local User Group" dropdown was first assumed to come
from `security/v1/directory-group-list` (already visible in the page-load
capture), but that endpoint's real response had no "LocalAdmin" entry at
all and completely different IDs — it turned out to return the calling
user's own *directory-wide* admin role groups, unrelated to the tenant-
scoped dropdown. The real source, `webfe/v1/tenant-user-group-list`, was
found by checking the very first page-load capture again for a
similarly-named call that had been overlooked; a second real capture of it
confirmed the field shape (`TenantUserGroupList[].{ID,Name,Roles,
Policies}`) and, interestingly, the same `LocalAdmin` UUID on two
completely different tenants — suggesting it may be a stable, platform-
wide default, though the app still looks it up by name every time rather
than trusting that. Ryan also proposed the fix's shape himself: rather
than a one-off manual step, add a configurable **Instructor full
name**/**Instructor email** to Settings and auto-grant that account access
to every new tenant automatically — explicitly so this becomes portable to
other instructors later ("I eventually want to share this tool with other
instructors"), where sharing just means pointing those two fields (and the
Cloud admin API key) at someone else's identity. Built
`cloud_list_tenant_user_groups()`, `cloud_find_user_group_by_name()`,
`cloud_add_user_to_tenant()`, and `cloud_provision_instructor_access()`
orchestrating all three; chained as the very first automatic step in
`process_pending_training_jobs()` — before baseline-add and policy-assign,
since those are exactly the steps this unblocks — with its own
`instructor_access_status`/`instructor_access_error`/
`instructor_access_created_at` per student (a `"skipped"` status, not an
error, when the Settings fields are left blank) and a matching manual
retry route (`/training/classes/student/retry-instructor-access`). A
failure here never blocks baseline/policy from being attempted anyway,
since they may still succeed some other way. Verified with 21 more tests
(99 total for this widget) built against Ryan's real captured request and
response shapes for both endpoints, covering the plain functions in
isolation, the full automatic chain (instructor access → baseline →
policy, in that order, including the "skipped" and failure-doesn't-block
paths), the manual retry route and its guards, and config validation
(malformed instructor email rejected, blank fields accepted as an
intentional opt-out).

Immediately after shipping Phase 6, Ryan ran it live against a genuinely
brand-new tenant (never opened in the console) and hit almost the finish
line: instructor access was granted successfully, but the automatic
baseline-add attempted right after it still 403'd with the exact same
`Tenant Role(s) NOT Found: view_baselines` error as before Phase 6
existed. This was a real, distinct problem from the one Phase 6 solved —
not a sign the fix didn't work, but that Airlock's tenant-level role grant
isn't visible to the very next API call. To isolate which, Ryan was asked
to just click "Retry baseline" on that same student with no other change —
it succeeded immediately. That confirmed a real propagation delay between
granting a tenant-level role and it taking effect elsewhere in Airlock's
backend, not a fundamentally broken grant. (One live capture had hinted at
a possible mechanism for this — the console's own post-grant flow calls
`security/v1/user-spa-profile-load` with a field literally named
`RapidSecurityProfileRefresh`, suggesting a cached permission profile that
needs an explicit refresh — but since only the *request* shape for that
call had been captured, not its response, and the plain-retry test alone
was enough to confirm and fix the actual symptom, that specific call was
left uninvestigated rather than bolted on unconfirmed.) Fixed with a small,
narrowly-scoped retry helper, `retry_on_role_propagation_delay()`: it
retries a call up to 3 times, 3 seconds apart, but ONLY when the failure
matches this exact confirmed error text ("Tenant Role(s) NOT Found") —
any other kind of failure (wrong group name, real permissions problem,
network error) still surfaces immediately on the first attempt, unretried,
same as before. Wrapped around both the baseline-add and policy-assign
calls, in both the automatic chain and their manual retry routes, since
either could plausibly hit the same propagation window. Verified with 7
more tests (106 total for this widget): the retry helper in isolation
(succeeds first try, retries and recovers, gives up after max attempts,
never retries a different error), the automatic chain absorbing one
transient 403 transparently, the automatic chain still failing cleanly
(and remaining manually retriable) when every attempt 403s, and the manual
retry route itself absorbing one transient 403. `time.sleep` is mocked in
every test so none of this actually pauses the test suite.

With the confirmed hands-off provisioning chain complete ("OK, that worked
perfectly."), Ryan asked for a UI cleanup pass on Training Instances' "New
class" form and "Tenant creation settings" section. Removed three fields
from "New class" — **Licence allocation per tenant** (`training-class-
licence`), **Auto-expiry** (`training-class-expiry`, which Ryan confirmed
never actually worked), and **Description** (`training-class-description`)
— on the reasoning that a class name is sufficient; every class now just
uses the configured tenant licence allocation, with no per-class override,
expiry, or description sent to Airlock. `training_classes_create()` was
simplified to match — it no longer reads or validates `licence_allocation`/
`auto_expiry`/`description` from the request body at all (a stale client
still sending them is silently ignored, not rejected). Renamed **Default
licence allocation** to **Tenant license allocation** (UI label only — the
backend key stays `default_licence_allocation`). Added a live descriptor
above that field showing how many licenses are currently allocated to the
configured directory, sourced from a real capture Ryan supplied: `POST
directory/v1/directory-licence-allocation-list` (module `directory`,
payload `{"DirectoryLicenceAllocationList":{"DirectoryID":"<id>"},
"atcp":null}`, response `DirectoryLicenceAllocationList.
DirectoryLicenceAllocated`) — this exact call was already implemented as
`cloud_get_license_allocation()` for the Partner Engagement Report widget's
NFR tracking, confirmed byte-for-byte against Ryan's fresh capture, so no
new Cloud API reverse-engineering was needed. Only a new route,
`GET /training/directory-licence`, was added to expose it to this widget
(using the configured `creation_directory_id`, directory-scoped so
`tenant_id=""`), plus the frontend fetch/render wired to run on Settings
load and again right after a successful config save (in case the Directory
ID just changed). Verified with 3 new tests covering the route (missing-
directory error, success against the real captured response shape, Cloud
API error passthrough) and one updated test replacing the now-obsolete
bad-auto-expiry rejection test with one confirming legacy
licence/description/auto-expiry fields are silently ignored rather than
erroring (109 total for this widget).

Ryan then asked to extend the descriptor to "N of M available" rather than
just the allocated count, and supplied a real capture for the "M" (total
capacity) half: `POST directory/v1/directory-update`, response containing
`DirectoryUpdate.Directory.LicenceCapacity: 101`. Before wiring it up, a
safety check on that specific capture caught that it was actually the
console's directory-Settings *Save* flow, not a page load — confirmed by
the very next captured call being `hermes/v1/message-create` with
`"Content":"Directory was successfully updated"`, a toast that only fires
after a successful write. Reading `LicenceCapacity` from `directory-update`
would have meant POSTing the *entire* Directory object back — including
both invite-email HTML templates and the licence date range — just to read
one field, a real risk of corrupting live directory/billing settings for
what should be a harmless display value, so this was flagged to Ryan rather
than built as asked. Ryan then captured the directory Settings page's
plain load (screenshot: "CTF Events (6 allocated | 101 capacity)" header),
which pointed at `tenant-search`, still not the right source; the technique
that actually found it was the same Chrome DevTools Ctrl+Shift+F
across-all-responses body search used earlier this project to find
`tenant-user-group-list` for instructor access — searching a fresh page
load for `LicenceCapacity` surfaced `POST directory/v1/directory-search`
(payload `{"DirectorySearch":{"DirectoryID":"<id>"},"atcp":null}`, response
`DirectorySearch.DirectoryList[0].LicenceCapacity`), a genuinely read-only
call fired alongside `directory-licence-allocation-list` on that same page
load, with no update-toast side effect. Built
`cloud_get_directory_licence_capacity()` (same auth style, `tenant_id=""`,
directory-scoped) and wired it into `/training/directory-licence`
alongside the existing allocated-count call, as two independent lookups —
a capacity failure returns the allocated count on its own (`capacity:
null`, `capacity_error` set) rather than failing the whole descriptor,
matching the "each data point is independent" convention
`cloud_collect_tenant_data` already established for NFR Tracking. The
frontend descriptor now reads "Licenses allocated: *N* of *M* available"
when both succeed, falling back to just "Licenses allocated: *N*" if the
capacity half fails. Verified with 2 more tests (111 total for this
widget): the combined success case (confirming both real payload shapes in
one request), and capacity failing independently without blocking the
allocated count.

With both license descriptors done, Ryan raised a separate ask: the
**Reference baseline (FullName)** field is a free-text box, but the real
catalog is ~180 entries — he didn't want to list them all, just "the most
recent baseline for each OS" as a quick-pick. Rather than build blind,
this was scoped with two quick questions first: whether the picker should
replace the text field or sit above it as quick-pick buttons that just
fill the field in (Ryan chose the latter — keeps the field free-text as an
escape hatch for the other ~170+ entries), and whether "per OS" should
mean full OS+version (Windows 11 and Windows 10 as separate picks) or just
high-level family (one "Windows" pick) — Ryan chose full OS+version, matching
how the console's own catalog lists them. Built `_parse_baseline_patch_level()`
(parses the confirmed real `PatchLevel` shape, e.g. `"April 2026"`, into a
sortable year/month tuple, tolerantly returning `None` for anything that
doesn't match rather than crashing, since only Windows entries are
confirmed to use this format) and `cloud_pick_recent_baselines_by_os()`
(groups the full catalog by `OperatingSystem`, keeps the newest `PatchLevel`
per group, prefers x64 on an exact tie, and still surfaces an unparseable
entry rather than dropping it) — both operate on data
`cloud_list_reference_baselines()` already fetches, so no new Cloud API
reverse-engineering was needed for the curation logic itself.

The one open question was auth: `tenant-baseline-reference-list` uses the
same per-tenant `UserApiKey`/`tenantID` role-check as the baseline-add call
it backs, but the Settings page needing this list has no specific tenant in
mind — Ryan hasn't necessarily created one recently, or ever, on a fresh
install. Rather than guess, the route (`GET /training/reference-baselines`)
tries with a blank tenant_id first (on the chance it behaves like
`tenant-user-create`, which accepts an inherited directory-level role in
place of a tenant-level one), and only if that's refused falls back to
`_find_known_training_tenant_id()` — any tenant this app has already
created, preferring one whose status is `completed`. If neither works
(most likely: no training tenant exists yet at all), the real Cloud API
error is surfaced with an explicit note to create a class first, rather
than silently failing — consistent with this project's practice of
surfacing genuine errors instead of masking assumptions that might be
wrong. This is the one piece of this feature not yet confirmed against a
live response; if it turns out blank tenant_id 403s and the fallback tenant
doesn't have `view_baselines` either, Ryan's next live-test report will
show exactly which branch needs adjusting, same as every other gap this
project has closed. The frontend shows a small button per suggested
baseline (e.g. "Windows 11 25H2 x64 — April 2026") in a row above the
FullName field, plus a manual "⟳ Refresh" button; clicking a suggestion
just sets the text field's value, so nothing about baseline validation,
matching, or the create call itself changed. Verified with 18 new tests
(129 total for this widget): patch-level parsing (full and abbreviated
month names, unparseable, blank/missing), the grouping/picking logic (one
pick per OS, correct newest-patch-level selection, x64 tie-break,
unparseable entries still surfacing, non-dict entries ignored, empty
catalog), the known-tenant-id fallback helper in isolation, and the
route's three paths (blank tenant_id succeeds first try, blank fails and
falls back to a known tenant successfully, both fail with no known tenant
and the error explicitly mentions needing a training tenant first).

Ryan then reported a real bug in that quick-pick row via screenshot: "LOL,
I think we may tried to make this too friendly" — grouping by
`OperatingSystem` had produced 70+ ungrouped buttons, not a short "most
popular" list. The root cause was the grouping assumption itself: it held
for Windows (`OperatingSystem` stays constant across minor versions, e.g.
`"Windows 11"`, with the minor build in `ServicePack`) but not for Linux,
where every distro embeds its own minor version *inside*
`OperatingSystem` (`"CentOS 7.0.1406"` and `"CentOS 7.1.1503"` are two
distinct `OperatingSystem` strings), so nothing collapsed for
CentOS/RHEL/Rocky/AlmaLinux/Ubuntu. Ryan's own suggestion — an OS dropdown
followed by a second dropdown of just that OS's baselines — matched the
fix. Rather than guess a new grouping heuristic from the button labels
alone, this was rebuilt from real data: Ryan supplied real captured
catalog entries across every family (Windows client, Windows Server,
macOS, AlmaLinux, CentOS, RHEL, Rocky), confirming `OSType` is exactly one
of `"Windows"`/`"Linux"`/`"MacOS"` (that capitalization, not `"macOS"`),
that `Architecture`'s x64 spelling varies by vendor (`"x64"` for Windows,
`"x86_64"` for RHEL/CentOS, `"x86_x64"` for Rocky/AlmaLinux), and that
`ServicePack` can legitimately be the literal string `"None"`. From that,
`cloud_pick_recent_baselines_by_os()` was replaced with
`_baseline_family()` (macOS's `OSType` collapses to one `"macOS"` family;
Windows's `OSType` splits into `"Windows"` vs. `"Windows Server"` by
whether `OperatingSystem` starts with `"Windows Server"`, since both
share the same `OSType`; Linux's `OSType` uses the leading letters of
`OperatingSystem` via regex to get one family per distro; anything else
surfaces under its own `OSType` rather than being dropped),
`cloud_group_baselines_by_family()`, and
`cloud_recommend_baseline_per_family()` (same newest-`PatchLevel`-wins,
x64-tiebreak logic as before, just applied per family instead of per
`OperatingSystem`). `/training/reference-baselines` now returns
`families`, `baselines_by_family`, and `recommended_by_family`; the
frontend replaced the single button row with two `<select>` elements —
family, then specific baseline within it, with the recommended entry
marked "(recommended)" and pre-selected, auto-filling the FullName field
the moment a family is chosen. The auth logic (blank tenant_id first,
falling back to a known training tenant) carried over unchanged. Verified
with 9 new/replaced tests (138 total for this widget, using the real
multi-family sample data Ryan provided verbatim rather than synthetic
fixtures): family derivation for every confirmed `OSType`/`OperatingSystem`
combination including the Windows/Windows Server split, grouping entries
into families, and per-family recommendation picking.

Ryan then live-tested the two-dropdown picker end to end and hit a real
bug: no matter which baseline he picked, new tenants kept getting the
default Windows 11 one instead. Rather than guess, this was traced from
his own `cmd` window logging (turned on specifically to debug this) —
the log line `Training Instances: added baseline 'Windows
11-25H2-x64-April 2026.tar.gz' to tenant for ...` on a run where he'd
picked something else proved the *saved config* still held the default,
not a bug in the add/assign logic itself. Root cause: picking from the
two dropdowns only fills the (free-text) FullName field — like every
other field in the "Tenant creation settings" panel, it isn't applied
until the single shared "Save settings" button is clicked, and Ryan
hadn't realized that was a separate step. A second live test, after
actually clicking Save, added `macOS Tahoe-26.x-M-April 2026.tar.gz` and
assigned it to Workstations successfully — confirming the add/assign
chain itself was correct all along, and also incidentally confirming the
one previously-open question from the paragraph above:
`/training/reference-baselines`'s blank-tenant_id-first auth attempt
*does* 403 in practice (`TenantID: "000000000000000000000000"`,
`ErrorMessage: "Incorrect permissions for accessing
/webfe/v1/tenant-baseline-reference-list"`), and the fallback to a known
training tenant picks it up cleanly right after — exactly the untested
branch this project flagged and never guessed at.

Since a missed Save silently falls back to stale settings for every
subsequent tenant, and tenant creation immediately emails the student's
account, a passive hint felt too weak. Added a settings-wide dirty
tracker (`trainingCaptureConfigSnapshot()` / `trainingConfigIsDirty()`
in the frontend) that snapshots all six "Tenant creation settings" field
values on load and after a successful save, shows a persistent "⚠
Unsaved changes" warning near the Save button whenever any of them
drifts from that snapshot (the baseline dropdowns update it manually
after their programmatic `.value` assignment, since that doesn't fire a
DOM "input" event), and — the actual guard — makes "Create tenants"
refuse outright with a clear message if anything is unsaved, rather than
silently using whatever was last actually saved. Frontend-only change;
all 138 tests unaffected (verified by re-running the full suite).

Natural next steps, if picked up again: if a live run ever
shows the `Policy` tree's omitted cosmetic UI fields are actually
required, add them back informed by that specific error; extend
`iso_mapping.json` with more automated controls (several are still
`manual` pending confirmed field mappings); possibly extend NFR Tracking
with more Cloud API data points now that the auth/module/method pattern
is understood; and if this toolkit is ever actually handed to a second
instructor, confirm in practice that just changing the Cloud admin API
key plus the Instructor full name/email fields is really sufficient,
since that's been designed for but not yet tested against a second real
Airlock user account.

Session 2026-09-24 (v5.2) added Training Instances' Phase 8: a custom
**blocked-file notification message** (the popup an agent shows when it
blocks a file) pushed to every new tenant. Built from a real HAR capture
of Ryan editing it on "Workstations Enforced" in the console. No new
endpoint was needed for the save — it's the same `webfe/v1/tenant-policy-update-changes`
call Phase 5 uses, with a different change handler
(`"Handler": "TenantPolicySettingUpdate"`, `Data: {ID, Parent,
TenantPolicySettingList: [<settings>]}`); the load is `POST
webfe/v1/tenant-policy-setting-list` (one policy group per call), both
`UserApiKey`/`tenantID` auth (`edit_policies` role). One false lead first:
`tenant-policy-blocklist-list` only lists blocklist entries, not the
message. The important catch: the save carries the policy group's
**entire** settings object (audit mode, script control, OTP durations,
proxy, cache, …), not a diff, so a naive save could silently reset other
policy settings. `cloud_set_block_notification_message()` therefore loads
the group's current settings, changes only `NotificationMessage` (and
forces `ClientNotification: true`, by Ryan's choice, since otherwise the
message is never shown), saves, then re-reads to confirm the message
stuck. Diffing the console's save against its load showed it omits a
handful of fields (`ID`, `AgentDownloadList`, `CacheExpiryTime`,
`ClientToServerProxy`, `CmdlineEnabled`, `CommunicationList`,
`PowerShellLanguageMode`, `ScriptCustom`, and `TargetVer.PolicyID`) —
mirrored exactly in `POLICY_SETTING_FIELDS_OMITTED_ON_SAVE` /
`build_policy_settings_for_save()` rather than guessing. Settings are per
policy group; by Ryan's choice only `"<Policy group> Enforced"` is
updated (where blocks actually happen). Applies to Training Instances
only, not NFR Provisioning. New Settings field **Blocked-file
notification message** (`block_notification_message`; blank = step
"skipped"; 1000-char sanity cap), part of the unsaved-changes guard. Runs
as step 4 of the automatic chain, independent of baseline success, wrapped
in `retry_on_role_propagation_delay`; tracked via
`block_notification_status`/`_error`/`_created_at`, with a "Block message
set" checklist badge and a per-student Set/Retry/Re-apply button (new
route `/training/classes/student/retry-block-notification`; re-apply is
allowed after success so an edited message can be re-pushed). Verified
with 22 tests built on the real HAR shapes, including a byte-for-byte
match between the app's built payload and the console's own save.

Note: this summary predates some work visible in the folder (NFR
Provisioning incl. Phase 7 sub-directory creation, `har_to_catalog.py`,
`api_catalog.json`, `QUICKSTART.md`) — those aren't written up here yet.

Session 2026-10-02 added Training Instances' Phase 9: **Add students to an
existing class**, plus a **per-class settings snapshot**. Each class card
now has a "+ Add students" button that opens an inline roster box (same
`Full Name, email` format). Each new student gets their own tenant named
`<Class> — <Name>` via the new route `POST /training/classes/add-students`
(`{class_id, roster}`), and the normal automatic chain then runs (instructor
access → baseline → policy → block message). Duplicate emails are rejected
both within the new rows and against the class's existing students. A
student whose tenant was deleted doesn't count, so they can be re-added.
The same unsaved-settings guard as "Create tenants" applies. The open form
and its typed text survive the class list's 15-second re-render
(`trainingAddStudentsState`).

By Ryan's choice ("option 2"), every class now freezes the settings it was
created with under `cls["settings"]`: `licence_allocation`,
`baseline_full_name`, `policy_group_name`, `block_notification_message`.
A blank message is a real frozen choice, meaning "skip". Everything for that
class uses the snapshot instead of the live Settings, so a late joiner
always matches their classmates even if Settings were changed in between:
- the automatic chain in `process_pending_training_jobs()`
- all three manual retry routes
- added students

Helpers: `current_training_class_settings()`,
`training_class_settings()` (effective values),
`freeze_training_class_settings()`, plus `clean_training_roster()`,
`new_training_student()` and `queue_training_students()`, shared by class
creation and Add students. Classes created before Phase 9 have no snapshot.
They keep following the current Settings (the card says "follows current
settings") until students are first added, at which point the then-current
values are frozen onto the class.

Escape hatches, since a frozen value can go stale:
- Retry baseline / Retry assignment accept `use_current_settings: true`.
  The UI offers this (with a confirm) only when the error says the class's
  baseline "was not found in Airlock's current catalog" or its policy group
  "was not found on this tenant", and Settings holds a different value. It
  moves the whole class onto the current value.
- The block message button shows "Apply current message" when Settings
  holds a different message than the class. That pushes it to that student
  and makes it the class's message for future additions. Other students
  keep theirs until it's applied to them too.

Class cards now show the class's baseline, policy group and block-message
status instead of the old auto-expiry text. Verified with 10 new tests,
including Ryan's real `training_config.json` as the pre-Phase-9 case
(existing students and `legacy_instances` untouched). The earlier 22
block-message tests still pass, and a headless-browser run against the real
class data checked add, re-render persistence and the duplicate rejection.

Session 2026-10-06 (v5.3) added Training Instances' Phase 10: an optional
**Custom blocklist**. It sits under Tenant creation settings as a checkbox;
ticking it reveals:
- Blocklist name
- Blocklist rule name
- OS
- up to five criteria rows (Field / Operator / Value)
- a custom blocklist message

Each new tenant gets that blocklist, with one Blocklist Metadata Rule in it,
assigned to "<Policy group> Enforced". It runs as step 5 of the automatic
chain, after the block message and independent of the baseline.

Built from one real HAR (Ryan creating "Test Blocklist" plus a Wireshark
Publisher + Path rule, setting its message, and assigning it to Workstations
Enforced). Every call uses `UserApiKey`/`tenantID` auth:
- `tenant-blocklist-create` (`{"TenantBlocklistParamsList":[{"Name"}]}`).
  Its response does **not** include the new ID, so the app re-lists with
  `tenant-blocklist-list` and finds it by name.
- `tenant-blocklist-metarule-create`. The rule ID and every criterion ID
  are UUIDs the console generates itself, so the app does too.
- `tenant-blocklist-metarule-update`. The custom message is
  `Setting.CustomNotify {Enabled, Text}` **on the rule**. It has nothing to
  do with Phase 8's policy-wide message. The console creates the rule with
  an empty message, then sets it with an update; the app does the same.
- `tenant-blocklist-metarule-list` re-reads the rule to confirm its criteria
  and message.
- `tenant-policy-update-changes` with Handler
  `TenantPolicyBlocklistApproveUpdate`, `Data {ID, Name, Parent,
  BlocklistID, AuditMode: 0}`.
- `tenant-policy-blocklist-list` confirms the result. `BlRed` = not applied,
  `BlGreen` = applied, `BlInheritedEnforced` = applied via the parent.

Field/Operator choices come from `tenant-blocklist-metarule-options-list`:
- They are per OS.
- A rule's **first** criterion gets a smaller operator set
  (`CriteriaAlreadyExists:false`) than later ones.
- Some fields (Username, Command Line, Hostname, Product Version, Parent
  Process, …) are only offered as later criteria.

The UI and the save validation both enforce this. That call needs a tenant to
authenticate against (same limitation as the baseline catalog), so
`/training/blocklist-options` tries live first. Otherwise it serves
`BUILTIN_BLOCKLIST_CRITERIA_OPTIONS`, the captured response normalized by
`normalize_blocklist_criteria_options()`.

Every step is find-or-create by name, so retries never duplicate anything:
- An existing blocklist is reused.
- An existing rule with the same name is updated to match, reusing its
  criterion IDs by position.
- If the group already shows the blocklist as applied, the assign call is
  skipped.

Phase 9 snapshot: `custom_blocklist` is a new snapshot key (the spec, or
`null` when off). A class frozen before Phase 10 counts as "no blocklist"; it
deliberately does not fall back to the current setting, so late joiners match
their classmates. Classes from before Phase 9 still follow current settings.
Unticking the checkbox keeps the typed values. An older client that omits
`custom_blocklist` leaves the saved one untouched.

Tracking and UI:
- Per-student fields `blocklist_status`/`_error`/`_created_at`.
- A "Blocklist added" checklist badge. Students from before Phase 10 show
  "skipped" when their class has no blocklist.
- Per-student button "Add blocklist" / "Retry blocklist" / "Apply current
  blocklist". The last one appears when Settings holds a different
  blocklist; it applies that blocklist and makes it the class's.
- Route `/training/classes/student/retry-blocklist`.

Verified with 37 new tests against a fake tenant built from the HAR's real
response shapes:
- the app's create, rule-create and rule-update request bodies are
  **byte-identical** to the console's; the assign change matches
- full flow, idempotent retry, blank message, inherited status, criteria
  update
- error surfacing and the role-propagation 403
- validation, including the first-criterion rules
- snapshot behaviour, using Ryan's real `training_config.json` (one
  pre-Phase-9 class and one Phase-9 class, both untouched)
- options fallback

A headless-browser run covered the checkbox reveal, the per-row dropdowns,
the unsaved-changes guard, save/reload persistence and the class cards.

Not yet confirmed live:
- Updating an existing rule's **criteria** (the capture only changed its
  message). This only happens on retry or "Apply current blocklist" with
  edited criteria.
- Whether a brand-new tenant needs the role-propagation retry for
  `create_blocklists`, as the other steps do. It's wrapped anyway.

Follow-up the same session: Ryan live-tested Phase 10 end to end ("works
like a charm"), then asked that the blocklist **not** be assigned to
Workstations Enforced. Attaching it is now part of the student exercise.
`cloud_provision_custom_blocklist()` stops after the rule and message are
confirmed. The assign/confirm functions (`cloud_apply_blocklist_to_policy_group`,
`cloud_get_policy_group_blocklist_status`) stay in the code, confirmed from
the capture, but are no longer called. Anything above about Phase 10
assigning or confirming the blocklist on the Enforced group describes the
first version only.

Then Ryan asked for assignment back as an **option**. Inside the Custom
blocklist section, an **Assign to a policy group** checkbox reveals a group
dropdown; it is off by default.
- Settings store `assign_enabled` + `assign_policy_group` (default
  "Workstations Enforced", remembered while unticked).
- The frozen class spec carries `assign_policy_group`, or `null` = don't
  assign. Specs frozen before this option existed have no key, which also
  means unassigned.
- The group is stored **by name**, since group IDs differ per tenant, and
  resolved per tenant by `cloud_find_policy_group_ref()`. It accepts any
  user-facing group: Airlock's system groups (parent "Airlock Policies")
  are excluded. `cloud_get_policies()` now also returns each group's
  `parent`.
- Ref shape: Parent is the parent group's ID for a child group (matches the
  capture) or `global-policy-settings` for a top-level group. A top-level
  group's ref includes its children so the change cascades, as Phase 5's
  baseline assign does.
- The step is skipped if the blocklist is already applied (`BlGreen` or any
  `BlInherited*`), and re-read afterwards to confirm.
- The dropdown is filled by `GET /training/policy-groups`: live from a known
  training tenant, else `BUILTIN_POLICY_GROUP_NAMES` (Workstations/Servers ±
  Audit/Enforced, the groups every new tenant gets, confirmed from the
  capture's policy list).
- The class card shows "blocklist X → Group" or "(unassigned)".

Assigning to Workstations Enforced is confirmed byte-for-byte against the
capture. Assigning to a top-level group or an Audit group follows the same
shape but hasn't been seen live yet. The `AuditMode: 0` in the change data is
always sent: in the GENERATE_DB job it maps to `enforced_blocklists` (block
mode), not to the target group's own audit/enforce mode. 45 tests pass.

Later the same day: the **API Reference widget** (`templates/api_reference.html`)
was brought up to date with every call mapped today:
- the seven blocklist endpoints
- `tenant-policy-update-changes`, now listing all three handlers (baseline,
  settings, blocklist)
- the `parent` field on `policy/v1/policy`
- Phase 8's `tenant-policy-setting-list`, which had never been added

The Blocklist HAR was merged into `api_catalog.json` (now 48 endpoints).
`har_to_catalog.py`'s `KNOWN_DOCUMENTED` gained the same entries. It also got
a small fix: the "documented" flag is now re-checked on every run instead of
only when an endpoint is first seen, so older catalog entries stop being
reported as undocumented once they're added to the widget.

Session 2026-10-23 (v5.4), Cloud Tenant Provisioning (NFR) changes:

**Own baseline.** NFR's baseline is now its own setting with its own
**Baseline Picker**, independent of Provision Training Instances. Before this,
`get_nfr_provisioning_settings()` read Training's `baseline_full_name` live.
- `nfr_provisioning_config.json` gains `baseline_full_name`.
- A config without it falls back to Training's value.
  `migrate_nfr_baseline_setting()` pins that value once at startup, so
  nothing changes for existing setups, and from then on changing Training's
  baseline never changes NFR's.
- `/nfr-provisioning/config` POST accepts `baseline_full_name`. If it's
  absent the saved value is kept; blank means the built-in default.
- **The policy group is still shared with Training.**

**Catalog route.** The catalog fetch/fallback logic was pulled out of
`/training/reference-baselines` into `fetch_reference_baseline_catalog()` and
`reference_baseline_picker_payload()`. A new `GET
/nfr-provisioning/reference-baselines` uses them, authenticating against NFR
tenants (completed first), each with its **own** directory ID. Both routes
share the `baselines.json` cache, since the catalog isn't tenant-specific.

**Shared picker component.** The frontend picker is now one component,
`createBaselinePicker()`, used by both widgets in place of Training's
hand-wired code. Each picker has a bold "Baseline Picker" title.

**Collapsible tenant list.** The NFR tenant list is now newest-first and
shows only:
- the newest tenant
- any tenant that still needs attention: still creating, creation failed, a
  failed step, or a failed delete

The rest sit behind "Show N older tenants" / "Hide older tenants". The
choice survives the 15-second refresh and is remembered in `localStorage`
where available.

Verified with 7 new backend tests against Ryan's real
`nfr_provisioning_config.json` and `training_config.json`:
- fallback, migration and independence
- save and older-client behaviour
- the NFR chain using NFR's baseline
- the catalog auth order (tenant's own directory) and cache fallback
- the Training route unchanged

The 45 Phase 10 tests still pass. A headless-browser run covered both
pickers, saving NFR's baseline without touching Training's, and the collapse
toggle with the real 5 tenants (only "WWT" shown collapsed).

Session 2026-11-03 renamed the project to **SE Toolkit** (see top) and
added an MSP widget for applying standard policy across customer tenants.
Ryan plans to ship it later as a standalone management tool for MSPs.
It went through two designs the same evening:

1. **MSP Policy Packs** (replaced). Packs were hand-built in the app,
   targets were NFR Tracking's tenants, and pushes were add-missing-only.
2. **MSP Policy Replication** (current, Ryan's idea). A **reference
   tenant** is the single source of truth. Ryan's decisions:
   - Packs are replaced entirely.
   - Reference and managed tenants are defined from scratch, never
     pre-filled from NFR Tracking.
   - Items are picked from per-type dropdowns (allowlists, blocklists,
     trusted publishers, baselines).
   - Differences use the recommended per-run toggle, "Also update items
     that differ", which is off by default.

How it's built:
- **Standalone-ready.** `msp_policy_packs.py` (blueprint at `/msp/*`;
  file name kept from v1 so no orphan file) never imports `app.py`.
  Every Cloud call goes through `MspCloudAdapter` in `app.py`, a class of
  staticmethods checked against `REQUIRED_ADAPTER_FUNCTIONS` at startup.
  `msp_config.json` holds:
  - `connection`: its own base domain + admin key
  - `reference`, `managed_tenants`, `sets`
  - `inventory`: the cached reference read
  - `runs`: the last 25
  - `baseline_name_map`
- **Its own connection** without touching the ~40 cloud_* helpers: the
  adapter's `connection()` is `cloud_credentials()`, a context manager
  that overrides `get_cloud_admin_config()` for the current thread only
  (thread-local). Every other widget keeps using NFR Tracking's
  connection, and a test asserts that.
- **Reference inventory** (`ReferenceReader.inventory()`, read-only).
  For each user-facing policy group it reads:
  - blocklist statuses: direct = `BlGreen`
  - baseline statuses: direct = applied and not inherited
  - settings: the notification message
  - allowlist list and publisher list

  Plus blocklists, their rules and hash counts, and tenant baselines. A
  tenant baseline maps back to its catalog FullName via
  `normalize_baseline_name()` and the learned map. Anything that doesn't
  map, or has no "(Reference)" suffix, is custom and not copyable.
- **Rule OS:** it's unknown whether the rule list returns the OS. The
  `reference_rule_os()` order is:
  1. a reported field
  2. inferred from a Windows-only criteria field
  3. assumed Windows, flagged in the inventory, run notes and steps

  The first live inventory logs the rule's real field names ("MSP
  reference rule fields") to `app.log`. Check that line to settle it.
- **Publishers:** the only capture had no publishers, so the response
  key is unknown. `extract_named_items()` reads any named list from the
  raw response.
- **Allowlists:** `TenantCategoryInfoList` (captured). Listed only.
  Allowlist/publisher create calls and blocklist **hash** entries still
  need captures.
- **Runs:** each run resolves the set live from the reference
  (`ReferenceReader.resolve()`). Items gone from the reference become run
  notes, not failures. The run then applies per tenant with `TenantRun`:
  - preview = `dry_run`
  - a same-named rule that differs is `differs` (left alone) unless the
    toggle is on
  - with the toggle on, `cloud_ensure_blocklist_rule` takes its update
    path, keeping the rule's and criteria's IDs
  - assignments are made only on a clear "not applied"; nothing is ever
    deleted
  - the reference tenant is never written to

  New baselines are identified by diffing tenant baseline IDs before and
  after the add, which feeds `baseline_name_map`. A "Tenant Role(s) NOT
  Found" error gets an "Add Me to Tenant" hint.
- **New read helpers in `app.py`:**
  - `cloud_get_policy_group_baseline_statuses`
  - `cloud_list_policy_group_blocklist_statuses`
  - `cloud_list_policy_group_allowlists`
  - `cloud_list_policy_group_publishers` (both of these send just `{ID}`,
    as captured)
  - `cloud_list_blocklist_hashes`
- **One shared change:** `cloud_apply_baseline_to_policy_group()` sends
  the tree's own `Parent`. That's identical for top-level groups (all
  Training/NFR uses) and needed for child groups. **Not live-tested for a
  child group yet.**

Verified with 49 checks against a fake, stateful Cloud (a prebuilt
reference tenant plus empty managed ones) mocked at `requests.get/post`,
so every real payload builder ran. The checks covered:
- own connection only, with NFR's left untouched
- tenants starting empty; the reference can't be a managed tenant
- inventory: assignments, hash count, OS reported/inferred, custom
  baseline flagged, read-only allowlists
- preview making zero writes
- the 403 hint
- full apply with correct OS, criteria, message and assignments
- re-apply as a no-op
- a changed reference rule: `differs` by default, updated in place (same
  rule ID) with the toggle
- an item deleted from the reference noted and skipped
- the reference never written to

A headless-browser walkthrough covered: reading the reference, building a
set from the dropdowns (the custom baseline disabled), save, preview,
notes and per-tenant results, with no page errors. **Not yet run
against real tenants.** First live test, in order:
1. Read the reference tenant and check the OS log line.
2. Preview to one managed tenant.
3. Apply.
4. Preview again; it should be all "Already there".

Session 2026-11-04 (Training Instances): **retry failed tenant creation**.
In a real class ("Boston QBR") the internet dropped while tenants were being
queued. Two students ended `create_failed` with a `NameResolutionError`:
the request never reached Airlock, so they have no tenant ID and no job.
Until now there was no way to retry them or clear them.

- **`POST /training/classes/retry-create`** `{class_id, student_id?}` re-queues
  creation for one student, or (no `student_id`) every never-created student
  in the class. It keeps the same row and uses the class's frozen licence via
  `queue_training_students()`, so there's no unsaved-settings guard. It's only
  allowed for `create_failed` with no tenant ID and no job, which means
  nothing exists in Airlock to duplicate. `dead`/`cancelled`/`partial` (the
  job ran and failed inside Airlock, and a tenant ID was assigned) are
  refused: delete that tenant and re-add the student.
- **`POST /training/classes/student/remove-failed`** drops a never-created
  row, and the class too if it was the last student. It's the one exception
  to "a row only leaves through an actual tenant deletion", and it's safe
  because there's nothing in Airlock to orphan.
- **Roster email check** (`TRAINING_EMAIL_RE`): one "@", a dot in the domain,
  and no spaces, commas or semicolons. It's applied in
  `clean_training_roster()`, so it covers both class creation and Add
  students. It caught a real typo, `erin,byrne@airlockdigital.com`: the
  comma got into the email and Airlock failed that job as DEAD. Retry also
  refuses a bad email and points to Remove + re-add.
- **UI:** per student, "Retry create" + "Remove" on never-created rows.
  Per class, "Retry N failed" when 2 or more. DEAD/CANCELLED/PARTIAL rows
  show a hint: check the email, delete the tenant, add the student again.

Verified with 9 new tests against Ryan's real `training_config.json`, which
has two classes named "Boston QBR" and these exact rows:
- retry one (same row, class licence, other rows untouched)
- retry all (dead row and the other class untouched)
- still offline (stays failed with the new error)
- dead/completed refused, bad email refused
- remove, including dropping an emptied class
- roster validation; every real roster email still passes

The 45 Phase 10 and 7 v5.4 tests still pass. A headless-browser run against
the real class list showed the buttons, the "Retry 2 failed" class button
and the DEAD hint, plus a retry (with no Cloud configured) staying failed
with an explanatory alert, and Remove.

**2026-11-04: allowlist rules added to MSP Policy Replication.** These
came from Ryan's second allowlist HAR.

His first HAR was from a tenant's own console (`*.managedwhitelisting.com:3128`,
`/allowlists/addmetarule` + `/blocklists/savecriteria`). That's
multipart forms with a session cookie and CSRF token, and HTML
responses, so it can't be automated with an API key and was **not
used**.

The second HAR was from the Cloud portal (`am.appenforcement.com/webfe/v1`,
same auth as the blocklist calls). It gave three calls:
- **`tenant-repository-allowlist-list`** `{"atcp":null}` ->
  `TenantCategoriesList[{ID, Name, SubCategories, Captures[{ID, Name,
  Version, Fcount, IsApproved, ...}]}]`. Allowlists are "captures" grouped
  in categories. A new tenant has "Workstations Bulk Add" and "Servers
  Bulk Add".
- **`tenant-allowlist-metarule-list`**
  `{"TenantAllowlistMetadataRuleList":{"AllowlistID"}}` ->
  `TenantAlMetaList[{ID, OSType, Name, IntegrityLevel, Criteria[{Field,
  FriendlyField, Operation, FriendlyOperation, Value, RealValue, Idx}]}]`.
  `Idx` is 1-based here. **OSType is reported**, so the blocklist rule
  list probably reports it too; `reference_rule_os()` already reads
  `OSType`.
- **`tenant-allowlist-metarule-create`**
  `{"TenantAllowlistMetadataRuleCreate":{AllowlistID, MetadataRuleName,
  MetadataRuleNameOS, MetadataRuleUpload:false, elevate_process:false,
  MetadataRuleCriteriaList:[{Field, Operation, Value, FriendlyField,
  FriendlyOperation, Idx (0-based)}]}}`. One call with the criteria
  included. The response queues a GENERATE_DB job.

New `app.py` helpers: `cloud_list_allowlists()`,
`cloud_list_allowlist_rules()`, and `cloud_create_allowlist_rule()`
(creates, then re-reads to confirm). They replace the per-group
`cloud_list_policy_group_allowlists`.

Engine behavior: `allowlists` is now a set item type, matched by allowlist
Name on the managed tenant.
- A missing allowlist is skipped, with a "create it once in the console"
  note.
- Duplicate names are skipped.
- Rules with a non-zero `IntegrityLevel` are treated as elevated and not
  copied.
- Allowlist file entries (`Fcount`) aren't copied; the run notes say so.
- A same-named rule that differs is always `differs`, even with the
  update toggle, since there's no edit call.

`har_to_catalog.py` was run on the HAR, adding 5 endpoints to
`api_catalog.json` (redacted shapes only). 58 fake-Cloud checks pass,
including the exact create payload shape.

**Still needs captures:**
- creating a new allowlist (and category)
- assigning an allowlist to a policy group (probably a
  `tenant-policy-update-changes` handler like the blocklist one)
- editing an allowlist rule
- adding a trusted publisher
- blocklist hash entries

**Not live-tested yet.**

**Session 2026-11-08: MSP Manager pilot.** The MSP widget became its own
top-level **MSP Manager** tab, in the Airlock console's look. Ryan's design
decisions:
- **Scope:** one MSP per install, Windows + Mac, and it'll later ship
  standalone, maybe compiled to `.exe` / `.dmg`.
- **Sidebar:** Dashboard, Policies Replication, Exceptions (placeholder),
  Tenant Configuration. Reporting and Settings were dropped for the pilot.
  The SE Tools widget was removed.
- **The reference tenant is a library, not a blueprint.** The MSP builds
  in the Airlock console, and the tool only reads the reference.
- **Policies Replication:** tick tenants (center), groups (left, the
  reference's tree, matched by name) and items (right). Every item goes to
  every ticked group on every ticked tenant.
- **Console colors:** red, green and blue are the console's. **Purple** =
  will be created (grey was avoided, since Airlock already uses it).
- **Apply Changes** stages (preview); **Replicate Changes Now** pushes.
- **Dashboard:** totals across tenants, with a Tenant filter for a
  single-customer view and per-tenant breakdowns behind the tiles.
- **Security:** the pilot keeps plain config. Before it's shared outside
  the lab, config is encrypted with a key in Windows Credential Manager /
  macOS Keychain (`keyring`), plus a per-launch access token for the local
  server and no secrets in logs. That's for the standalone tool only.
- **Packaging:** one codebase, with per-platform `packaging/` folders
  (PyInstaller specs, icons, a DMG script). Config goes in the per-user
  app-data folder. Signed builds matter, since MSPs run Airlock.

How it's built:
- **The page:** `templates/msp_manager.html`, fully self-contained (own
  CSS/JS, Manrope font with system fallback), served by the blueprint at
  `/msp/ui`. The toolkit's MSP Manager tab is an iframe that loads it on
  first open.
- **The engine:** `msp_policy_packs.py` (name kept, so there's no orphan
  file).
  - **Replication sets removed.** The selection is the request (`tenant_ids,
    groups, items{blocklists, allowlists, baselines}, message_from,
    update_differing`).
  - **`ReferenceReader.inventory()`** = the library, plus `tree` (policy
    groups with `parent_id`) and the baseline `os_type`.
  - **`resolve_selection()`** targets the ticked groups.
  - **`tenant_item_states()` / `StatusChecker`** = the colors per tenant ×
    group × item: `assigned` / `not_assigned` / `inherited` / `create` /
    `cant_create` / `group_missing` / `unknown`. Tenants are read in
    parallel (each worker enters the thread-local Cloud credential
    override), with a 120s cache that's cleared after every replicate.
    With no tenants ticked, it shows the reference's own state.
  - **Allowlist assignment:** read via the new
    `cloud_list_policy_group_allowlist_statuses()`
    (`tenant-policy-allowlist-list`, `TenantCategoryInfoList` Type
    "capture"). Only "red" is confirmed; green and inherited are matched
    by name. Allowlist assign steps report exists/skipped (no capture).
  - **New routes:** `/ui`, `/settings` (MSP name), `/managed/update`,
    `/status`. `/runs` takes a selection. History is labelled "items →
    groups".
- **Verified:** 54 fake-Cloud checks, including:
  - colors: red/green/blue on the reference; purple/can't-create on a
    managed tenant
  - a tenant missing a group
  - status never writing, and caching
  - staging writing nothing
  - assigning to the *ticked* groups only, not the reference's
  - the status cache cleared after replicating
  - re-replicating as a no-op
  - the update toggle
  - the old widget removed

  A browser walkthrough covered all four pages, staging and replicating,
  and the tab at 1366px wide, with no page errors.

**Not live-tested.** First live test, in order:
1. Tenant Configuration: enter the connection, reference and managed
   tenants.
2. Read the library.
3. Policies Replication: tick one tenant, one group and one blocklist.
4. Apply Changes, then Replicate.
5. Check the colors turn green.

**Captures needed next:**
- the Airlock dashboard, each sub-tab
- creating an allowlist and assigning it
- adding a trusted publisher and assigning it
- paths, processes and trusted installers (if wanted)

**2026-11-08 (later): live MSP Manager dashboard.** This came from Ryan's
dashboard HAR. The console's numbers come from a separate **reporting**
service: `GET reporting/v1/dashboard/<path>?start_time&end_time&...&browser_exec=false`,
which returns plain JSON with no Atro wrapper. The paths:
- `execution-types` → `{counts, volumeDelta{current, previous, ...}}`
- `execution-counts/{blocked|untrusted}/{total|unique|unreviewed}` →
  `{count}`
- `new-files` → `{data: []}`. It was empty in the capture, so the row
  fields are unknown, and the UI picks common names.
- `top-users`, `top-hostnames`, `top-policy-groups` →
  `{counts: {name: n}}`
- `audit-enforcement-coverage` → `{auditAgents, enforcementAgents, ...}`

Parameters: `policy_id` is "All" or the **tenant's own** policy group
ID, so MSP Manager looks the name up on each tenant, and a tenant without
the group is left out and flagged. `include_children` is true/false.
`execution_type` is "All" or the type's Index; only "All" has been seen on
the wire.

The filter lists (time keys `today/15m/1h/1d/3d/1w/2w/1mo/customRange`,
and the 14 execution types with their Index) are hard-coded from the
capture's `tenant-dashboard-filter-*-list` calls.

How it's built:
- **`app.py`:** `CLOUD_MODULE_REPORTING`, plus `cloud_dashboard_get()`
  on the adapter as `dashboard_get`. **UserApiKey on the reporting
  service isn't live-confirmed yet;** the console used a browser session.
- **Engine:** `tenant_dashboard()` makes 12 GETs per tenant.
  `DashboardReader` reads tenants in parallel with a 60s cache.
  `aggregate_dashboard()` sums the counts, execution types, volume and
  coverage, keeps the tenant label on the top lists and new files, and
  builds the per-tenant `breakdown` the tiles use.
- **Routes:** `/msp/dashboard/options` and `POST /msp/dashboard`.
- **UI:** a summary row (events vs the previous period, tenants, agents
  in audit vs enforced) and live panels. Tiles open the per-tenant
  breakdown, including unreviewed counts. A "Not included" notice lists
  unreadable tenants and those missing the group.
- **Catalog:** `har_to_catalog.py` added 30 endpoints to
  `api_catalog.json` (71 total). It keeps **dict keys**, so the real
  user/host names in the `top-users`/`top-hostnames` shapes were scrubbed
  by hand. Watch for this with future captures.

70 fake-Cloud checks pass (16 new for the dashboard). A browser check
covered the live panels, the breakdown modal and the single-tenant view.

**First live test:** open the Dashboard with All tenants on 1 Week, and
compare one tenant against its own console dashboard. If the reporting
calls return 401/403 with the API key, they need a different auth style.

**2026-11-08: the reference tenant may be a real customer.** Ryan:
building policies needs real data, so an MSP may pick one of its clients
as the reference tenant. Others keep a full lab that mirrors their
customers' environments, so it depends. The dashboard therefore includes
the reference in "All tenants" totals by default
(`dashboard_include_reference` in `msp_config.json`, default true). The
switch is a checkbox in Tenant Configuration's Reference tenant panel,
since the pilot has no Settings page.

The Tenant filter always lists the reference as "<label> (reference)"
(`tenant_id: "reference"` in `POST /msp/dashboard`), even when it's
switched out of the totals. `/msp/settings` now does partial updates
(`msp_name` and/or `dashboard_include_reference`). Replication is
unchanged: the reference is still only read, never a target.

76 checks pass.

**2026-11-15: tenant discovery in MSP Manager.** Ryan's idea: an MSP
admin only has access to their own customers' tenants, so the tool can
list them from the API key and offer a pick list in Tenant Configuration.
His HAR of the directory/tenant page showed the data comes from the
console's sign-in profile, `security/v1/user-spa-profile-load`.
`UserSpaProfileLoad.RapidSecurityProfile.TenantUserSecurityProfileList`
has, per accessible tenant:
- `TenantID` and `Name`
- `DirectoryID` and `DirectoryName`
- `DirectoryBreadcrumbs [{ID, Name}]`
- `Roles` (e.g. `edit_blocklists`, `view_policies`) and `Groups`

The request body is `{"UserList":[{"OktaUserID","Email"}], "Uncategorised":
{"RapidSecurityProfileRefresh":true,"DirectoryCacheRefresh":true}}`.
**That response also contains the user's API key (`UserApiKey`) and the
browser sent an Okta bearer token, so HARs of this page are sensitive.**

`cloud_discover_tenants(email, directory_id)` in `app.py` tries two
sources, in order:
1. **The profile call**, with the API key and an optional email. Its body
   is never logged: `_cloud_send`/`cloud_api_request` got a
   `log_body=False` option. Only the tenant list is kept.
2. **`directory/v1/tenant-search` `{"TenantSearch":{"ID":""}}`**, scoped
   to a top-level directory ID. It drops deleted and `UserHasAccess:false`
   tenants, and directory names come from `directory-search`.

If both fail without a directory ID, it asks for one. **Live-confirmed
2026-11-15:** the profile call works with the Cloud admin API key
(`UserApiKey` header) and no email or directory ID. Ryan's first click
listed his tenants straight away, so the `tenant-search` fallback is a
safety net that hasn't been exercised live.

Engine and routes:
- `POST /msp/discover`: marks each tenant reference / managed /
  available, sets `can_edit` from roles (any `edit_*`), and remembers the
  email and directory ID hints in `msp_config.json` `discovery`.
- `POST /msp/managed/bulk`: adds tenants, skipping the reference and ones
  already managed.

UI: a "Discover tenants" panel with a search box, "hide tenants already
added", select all, "Add N selected as managed tenants", and per-row "Set
as reference" (which re-reads the library).

89 fake-Cloud checks pass, including that the profile's API key never
reaches the log or the browser.

**2026-11-15: full allowlist replication.** This came from Ryan's
allowlist HAR, taken in the Cloud portal with the same auth as before. Ryan
first hit a misleading screen: an allowlist that only existed on the
reference showed "In sync" and Replicate stayed disabled. That was fixed
the same day:
- `summarize_steps` now returns **`blocked`** when there are skipped steps
  and nothing else. The UI shows "Can't replicate yet", expanded with the
  reason.
- The tenant table counts `cant_create`/`unknown` items as "N can't
  replicate yet".
- The legend explains the dashed badge.

Calls captured 2026-11-15 (all `webfe/v1`):
- **`tenant-allowlist-create`**
  `{"TenantCaptureParamsList":[{"CategoryID","Name","Version":"1"}]}`.
  The response has no ID, so the helper re-lists. The default
  "Workstations"/"Servers" categories had identical IDs in both
  captures, but they're matched by name anyway.
- **Assign:** `tenant-policy-update-changes`, handler
  **`TenantPolicyApplicationsApproveUpdate`**, Data
  `{ID: group, Parent: group's parent, ApplicationTimestamp: <the
  allowlist's Timestamp>, AllowlistName: "<Name> - <Version>"}`. The same
  envelope as blocklists. The allowlist then lists as Status **`green`** on
  that group (confirmed; it was `red` before).
- **`tenant-allowlist-metarule-update`** = the create body plus
  `MetadataRuleID`, and the existing criteria's `ID`s (new criteria have no
  ID; the full list is sent). Reused by position.
- **Elevation:** `elevate_process: true` on create/update shows as
  `IntegrityLevel: 1` in the list. Elevated rules are now copied, where
  before they were skipped.
- `tenant-allowlist-metarule-criteria-list` and `tenant-publisher-list`
  (all of a tenant's publishers, with `PolicyID`) were captured but aren't
  used yet. Publishers belong to policy groups, and adding one is still
  uncaptured.

New `app.py` helpers: `cloud_create_allowlist`,
`cloud_apply_allowlist_to_policy_group`, `cloud_update_allowlist_rule`
and `cloud_list_allowlist_categories`. `cloud_list_allowlists` now also
returns `Timestamp`, `CategoryID`, `TopCategory` and `InSubcategory`.
`cloud_create_allowlist_rule` passes `elevate_process`.

Engine behavior:
- `TenantRun.do_allowlist` creates a missing allowlist in the same-named
  top-level category. It skips one that sits in a subcategory, or whose
  category is missing, with a reason.
- Rules are added, or updated with the toggle. A rule matches only if both
  its criteria and its elevation match.
- The allowlist is assigned on a clear red. Status coloring shows a missing
  allowlist as `create` (purple) when its category exists, `cant_create`
  otherwise.

`api_catalog.json` gained 6 endpoints (scanned: no emails, names, tokens
or keys). 99 fake-Cloud checks pass. **Not live-tested yet:** stage and
replicate "CMD Custom Allow List" to one tenant.

**Fix (2026-11-15, same evening):** an allowlist directly in a category
has `SubcategoryID` = `"000000000000000000000000"`, not empty. The first
build treated that as "in a subcategory" and skipped every allowlist
creation. `InSubcategory` now ignores all-zero IDs, and the fake data
uses the real zeros value. Real subcategories (a non-empty `SubCategories`
list) are still not created; no capture has had one yet.

**Live-confirmed 2026-11-15:** Ryan replicated "CMD Custom Allow List"
from his reference tenant to two managed tenants on Workstations. The
allowlist was created in the right category, its rules (including
elevated ones) were copied, and it was assigned. These are the first
real-tenant writes made by MSP Manager.

**Fix (2026-11-15, late):** replicating the blocklist "Microsoft
recommended block rules (main)" failed on every tenant with HTTP 400
from `tenant-blocklist-create`: "input must only contain alpha-numeric
characters". The console happily shows such names (likely imported), but
the create call rejects the brackets. New helpers in
`msp_policy_packs.py`:
- `airlock_safe_name(name)` keeps only letters, digits and spaces.
- `is_name_rejection(err)` spots that error.
- `find_named(items, name)` matches the exact name first, then the
  cleaned-up form.
- `TenantRun.named_act(...)` tries the exact name, and on that rejection
  only, retries once with the cleaned name and notes "Created as '...'" in
  the step. Previews warn about it.

Used for blocklist, allowlist and both kinds of rule creation. Status
coloring (`tenant_item_states`) matches the cleaned name too, and assigning
a blocklist passes the tenant's own name. 104 fake-Cloud checks pass (the
fake now rejects punctuation the same way). Whether *rule* names have the
same restriction is unknown; the retry covers it either way.

## MSP Manager to-do

Done and live-confirmed 2026-11-15: publisher replication + Bulk Add,
blocklist hash replication. Allowlist hash replication is built (same
pattern); Ryan accepts it on the strength of the blocklist result.

Still open:
- **Encrypted credential storage** before the tool leaves the lab (Ryan's
  requirement: no API keys or directory IDs in plain-text JSON).
- **Standalone packaging:** Windows .exe and Mac .dmg.
- **Reports page** built 2026-11-16 (Licenses, Agents, Executive,
  Enforcement Readiness, Application Context, Policy Differences). Not
  copied: the Search tab and the Resultant Policy PDF.
- **Custom baselines: dropped (Ryan, 2026-11-16).** Nobody builds them in
  practice; MSPs always use imported baselines, which already replicate.
  No replication gaps remain.
- **Exceptions page:** integrations replication built 2026-11-15. Still
  open: a cross-tenant list of pending exception requests with
  approve/deny.
- Dashboard sub-tabs: all four built 2026-11-16.
- **Unconfirmed live:** UserApiKey on the reporting service, New Files Seen
  field names, some execution_type values, the allowlist inherited status
  strings, baseline assignment to child groups.

**Publisher replication + Bulk Add (2026-11-15, night),** from Ryan's
`trustedpublisher.har`. The calls:
- **Publisher Summary:** POST `activity/v1/bulk-add-search/publisher-counts`
  (a new service for this app, `CLOUD_MODULE_ACTIVITY`). Same filter body
  as the console. It returns `publisherCounts[{Name, FriendlyName, OSType,
  Count, CommonlyTrusted}]`, and `null` when no executionType is set, so we
  send "Untrusted Execution". `timeSelector` keys come from
  `tenant-dashboard-filter-time-list`; we use 1d/1w/2w/1mo.
- **Trust:** POST `webfe/v1/tenant-dashboard-bulk-add-policy-publisher-update`
  with `{TenantPublisherList:[{Name, OSType}], TenantPolicyList:[<group
  tree node with children>]}`. Role `edit_policies`.
- **Per-group list:** `tenant-policy-publisher-list` turned out to return
  `TenantPublisherInfoList[{ID, Name, FriendlyName, OSType, IsInherited,
  LoggingType, ...}]`. Child groups list the parent's publishers with
  IsInherited true.
- After trusting, Broadcom vanished from the console's list only because
  the console adds it to `excludedPublishers` itself. The server doesn't
  filter, so we work out "not trusted" from the group lists.

app.py: `cloud_publisher_summary`, `cloud_trust_publishers`, and
`cloud_list_policy_group_publishers` now parsed. Adapter gained
`publisher_summary` and `trust_publishers`.

Engine:
- `publishers` is now an ITEM_TYPE, keyed `"<OSType>::<Name>"`
  (`publisher_key` / `parse_publisher_key`).
- `ReferenceReader.trusted_publishers()` returns `{key, name, os_type,
  groups, inherited_groups}`.
- `TenantRun.do_publishers` sorts the groups parents-first. Per group it
  reads the list, marks present publishers as exists (noting inherited),
  and trusts the missing ones in one call.
- `tenant_item_states` returns `items.publishers[key][group]`:
  assigned/inherited, `not_assigned` (red) when absent.
- `PublisherPool` merges the reference + managed tenants in parallel
  (cached 5 min per window), drops "Not Signed", and reports unreadable
  tenants. Route: GET `/msp/publishers/pool?window=`.
- `clean_selection` takes `trust_on_reference`, which is only kept when
  publishers are ticked. `MspRunManager.start` then puts the reference
  first as an extra slot (`is_reference`) that runs only the publisher
  part of the spec. Without the tick, the reference is never written
  (tested).

Page:
- The Publishers accordion is now tickable.
- New "Bulk Add (Publishers)" accordion: a window select, an in-place
  filter, and Load/Refresh. It loads lazily on first open and hides
  publishers the reference trusts on the ticked groups.
- "Also trust publishers on the reference tenant" tick box sits in the
  replicate bar.
- After a run that trusted something on the reference, the library is
  re-read so those publishers move to Publishers.

122 fake-Cloud checks pass, and a Playwright run of the full flow showed
no page errors. Not yet confirmed live:
- UserApiKey on the `activity` service
- whether the trust call needs the whole tree node or just the ID (we send
  the node, as the console does)
- the MacOS OSType string in the summary

**Live-confirmed 2026-11-15:** Ryan replicated a publisher to real
tenants: "worked like a champ". Follow-up at his request: the Publishers
accordion is **view only** again, scoped to the ticked policy groups
(`publishersSection`: green = trusted directly on a ticked group, blue =
inherited). Trusting is done only from Bulk Add. After the library is
re-read, publishers the reference now trusts on the ticked groups are
unticked in Bulk Add.

**Follow-up (2026-11-15, 20:30):** Ryan wants the Publishers list to show
the *ticked tenants'* trusted publishers, not the reference's, so it
matches the console for that tenant and group. It's now built client-side
from the `/msp/status` read (`trustedRows()`), keeping only assigned or
inherited states and aggregating across tenants as "Tenant › Group".
`tenant_item_states` also returns `publisher_names` (FriendlyName, e.g.
"<GUID> [Mozilla]"). With no tenant ticked, status covers the reference,
so the list shows the reference.

Bulk Add follows the same logic (`trustedEverywhere`): it hides a
publisher once it's trusted on every ticked tenant × group, and falls back
to the reference library before any status is read. 123 checks pass.
Also added `TEMPLATES_AUTO_RELOAD`, so page changes show without a
restart (debug is off, so Flask had been caching templates).



**Allowlist hash replication (2026-11-15, late night).** Captured live in
the desktop app's built-in browser. Ryan signed in, and an in-page
XHR/fetch recorder logged URL, request and response, never headers, since
the pane's network reader doesn't show the cross-origin API calls. Calls:
- **Browse:** `tenant-capture-fdrive-list` `{TenantCapturesList:[{ID}]}`
  returns the top-level `TenantFileList` (Type "drive").
  `tenant-capture-fchildren-list` `{TenantFileList:[<node>],
  TenantCapturesList:[{ID}]}` returns its children (Type "folder"/"file";
  files have SHA256, and their Name is the filename or, for imported ones,
  the hash).
- **Add:** `tenant-allowlist-bulk-add-hash-create`
  `{TenantAllowlistBulkAddHashCreate:{AllowlistID, Hashes:[...]}}`, role
  `edit_captures`. Hashes land under an "Imported Hashes" drive.
- **Also seen, not used:** `tenant-allowlist-multiple-hashes-extract-list`
  (validates pasted hashes) and `tenant-bulk-add-hashes` (reputation lookup
  for the Bulk Add page).
- **Allowlist `Fcount` is unreliable:** it was 0 on an allowlist with entries.
  The library no longer shows it.
- **Propagation:** ~10 s after the add, SYSTEM logged "User UPDATED
  Application CMD Custom Allow List on <group>" for every group using it,
  and regenerated definitions. The group status stayed blue. No approval
  step needed.

Test hash `e3b0c442…b855` (SHA-256 of an empty file) was added to Yellow
Dog's "CMD Custom Allow List" for the capture (removed later, see below).

Code:
- app.py: `cloud_list_allowlist_hashes` walks the tree breadth-first
  (max 5000 folders, sequential, because the credential override is
  thread-local). `cloud_add_allowlist_hashes` sends batches of 200.
- Engine: `resolve_selection` reads the reference hashes per ticked
  allowlist. If it can't, it notes it and skips the hashes, never guesses.
  `TenantRun.do_allowlist_hashes` runs before assignments, makes one
  summary step, is add-only, and doesn't re-read a just-created allowlist.
- Fake Cloud models the tree plus Imported Hashes. 130 checks pass.

**Blocklist hash replication (2026-11-15, 22:30)**, captured live the same
way. The test hash went into Yellow Dog's "CMD Customer Blocklist" with
Ryan's OK.
- **Add:** `tenant-blocklist-bulk-add-hash-create` `{TenantBlocklistParamsList:
  [{ID, Hashes:[...]}]}`, role `edit_blocklists`. The response is a
  `QueviderQueue` GENERATE_DB job, so policy groups rebuild automatically.
  The job args include `policy_db_pass`: never logged (`log_body=False`)
  and not in the catalog.
- **List:** `tenant-blocklist-hash-list` returns
  `TenantBlhashSummaryList[{ID, SHA256, FullName, Seen}]`.
- **Code:** `cloud_list_blocklist_hashes` now returns `[sha256]`.
  `cloud_add_blocklist_hashes` sends batches of 200. Allowlists and
  blocklists share `TenantRun.do_hashes(kind, ...)`, so the old "N hash
  entries can't be copied" note is gone. Step labels end in "→ hashes".
- 132 checks pass.

The test hash `e3b0c442…b855` was removed again from "CMD Custom Allow
List" and "CMD Customer Blocklist" (22:35, at Ryan's request), so Yellow
Dog is back to its original state. Removal in the console is per entry:
Delete in the blocklist's right-click menu; Remove Selected in the
allowlist file browser. The tool never deletes.

**Live-confirmed 2026-11-15, 22:36:** Ryan replicated "Microsoft
recommended block rules (main)" to all three test tenants. Each reported
"Added 259 hashes", and ryan airlock's console shows 259 hash entries
(13 pages) in "Microsoft recommended block rules main" (the cleaned name
from the earlier fix). The 51 rules matched. Allowlist hash replication
hasn't been tried live yet: the reference's allowlists currently have no
hash entries.

**Paths / processes / trusted installers / allowlist subcategories
(2026-11-15, 22:45–23:00).** Captured live on Yellow Dog's "Dev Audit"
group with sample entries, at Ryan's request.

The console's Policies page stages edits locally. "Apply Changes" sends
one `tenant-policy-update-changes` with the handlers below; Ryan then gets
an optional "policy change reason" toast.

- **Paths:**
  - List: `tenant-policy-expath-list` returns
    `TenantExclusionInfoList[{ID, Name, Status ("blue" = inherited, "" =
    set here), LoggingType}]`.
  - Add: handler `TenantPolicySaveExCreate`, Data `{ID, Exclusions:[{ID:
    group, ExclusionName, ExclusionOldName:""}]}`.
- **Processes:**
  - List: `tenant-policy-process-list` takes `{TenantPolicyGroup: <node>}`
    (singular!) and returns `TenantProcessInfoList[{Name, ProcType
    ("pprocess"), ProcTypeLabel, Inherited}]`.
  - Add: `TenantPolicyProcessAddExUpdate`, Data `{ID, Parent,
    TenantPProcessList:[{Name, ProcType}]}`.
- **Trusted installer processes:**
  - List: GET `policy/v1/policy/<group id>/trusted-installer-processes`
    (a new service, `CLOUD_MODULE_POLICY`) returns `{data:[{id, name,
    mode, os, comment, inherited, ...}]}`. Its XHR wasn't visible until the
    recorder watched every am.appenforcement.com call.
  - Add: `TrustedInstallerProcessAddUpdate`, Data `{ID, Parent,
    TenantTrustedInstallerProcessList:[{Comment, Mode, Name, OS,
    Publisher}]}`. Mode 0 = "Direct", OS 0 = Windows.
- **Installer switches:** `MicrosoftManagedInstallerTrust`,
  `WindowsTrustedInstallerTrust`, `MacOSManagedInstallerTrust` (0/1/2) in
  the group settings, saved with `TenantPolicySettingUpdate`.
- **Allowlist subcategories:**
  - Create: `tenant-capture-sub-category-create`
    `{TenantCaptureParamsList:[{Name, CategoryID}]}`, role `edit_captures`.
  - An allowlist in a subcategory is the normal `tenant-allowlist-create`
    with CategoryID = the subcategory's ID (the console sent Version "").
  - Wired in the same night. `cloud_list_allowlists` now reports
    `Subcategory`/`SubcategoryID` (by nesting, or looked up by
    SubcategoryID). `cloud_list_allowlist_categories` returns
    `Subcategories`. New `cloud_create_allowlist_subcategory` re-lists to
    get the ID. `TenantRun.do_allowlist` creates the subcategory if missing
    (a separate "Subcategory '<cat> / <sub>'" step), then the allowlist in
    it. Status shows purple (can create) instead of dashed. 149 checks
    pass.
- **Custom baselines:** the Baselines page offers only "Add Baseline from
  Import/Reference", Export XML/CSV, Delete, Rename. Not replicable for now.
- **Watch:** when the console saved the installer switch, the activity log
  said "disabled Client Auto Update on policy Dev Audit". The setting was
  false afterwards. Unknown whether it was on before, so asked Ryan.

Code:
- app.py: `cloud_list/add_policy_group_paths|processes|installers`,
  `cloud_get/set_installer_switches` (load-modify-save, then confirm), and
  `_msp_policy_changes`.
- Engine:
  - `ENTRY_KINDS` + `parse_entry_key`.
  - `ReferenceReader.group_entries(kind)`.
  - `TenantRun.do_group_entries` (batched per group, parents first, via
    the new `groups_parent_first`, also used by publishers now) and
    `do_installer_switches`.
  - `tenant_item_states` covers the three kinds. Installer read errors
    turn into "unknown" rather than failing the tenant.
- Page: Paths / Processes / Trusted Installers accordions are live, with
  the "switches" item first.
- 144 checks pass.

Not yet confirmed live: UserApiKey on the `policy` service.

All sample entries were removed again at Ryan's request (23:00):
- Dev Audit's path, process and trusted installer
- "Airlock Trusted Installer for Windows" back to Disabled
- the "MSP Toolkit Test" subcategory and its allowlist

Removing them in the console: Delete in each entry's right-click menu,
then Apply Changes on the Policies page. Allowlists and categories are
deleted immediately. Yellow Dog is back to its original state, except
possibly Dev Audit's Client Auto Update; Ryan is checking that.

**Exception integrations (2026-11-15, 23:10–23:40).** Ryan wants exception
requests routed to helpdesk apps (Teams, Zendesk...) on techs' phones,
configured once on the reference and replicated. His choice: one shared
destination, with the customer's name added to the message.

Captured live on Yellow Dog (Settings → Integrations) with a disabled
sample webhook (example.com) and a dummy email recipient. Both were
removed afterwards; the email settings now exist as an empty, disabled
record instead of null.

Service `tenant/v2/setting/integration/` (`CLOUD_MODULE_TENANT`, version
"v2"; `cloud_api_request` gained `version=`, and `_cloud_send` now handles
PUT/PATCH/DELETE and 204 empty bodies):
- **Webhooks:**
  - GET `webhooks` returns `[{id, name, enabled, template, url,
    secret_header, secret_value ("••••••••"), verify_tls, event_types
    [exception_request|exception_action|server_activity],
    activity_keywords, custom_payloads {event: text}}]`.
  - POST `webhooks` creates one (body as above, with the real
    secret_value).
  - PUT `webhooks/<id>` updates one (adds `id`, `secret_value_changed`;
    false keeps the secret).
  - DELETE `webhooks/<id>` deletes one (204).
  - GET `webhooks/options` returns the 9 built-in templates with
    `event_payloads[event].payload`. Placeholders: hostname, username,
    filename, sha256, publisher, product_name, parent_process,
    policy_name, reputation, justification, approval_id, review_url,
    timestamp. No tenant placeholder.
- **Email:**
  - GET `exception-notifications` returns null or `{id, emailrequest,
    emailrecipient, emailsubject}`.
  - POST creates it (emailrequest 0/1); PATCH `exception-notifications/<id>`
    updates it (emailrequest bool, 204).
- The Exceptions page in the console lists requests from
  `exception/v1/request` (GET). Not used yet.

Code:
- app.py: `cloud_list_webhooks`, `cloud_webhook_options`,
  `cloud_create_webhook`, `cloud_update_webhook`,
  `cloud_get_exception_email`, `cloud_save_exception_email`. All use
  `log_body=False`.
- Engine:
  - `customize_payload`: reference-name swap, else heading suffix, else a
    `customer` field.
  - `webhook_spec_for` / `webhook_differences`.
  - `IntegrationSync` with `run` (preview/apply, parallel per tenant) and
    `status`.
  - Routes GET `/msp/integrations` and POST `/msp/integrations/run`.
    Secrets come in the body and go straight to the adapter; they're not
    in the run record and not in history.
- Page: the Exceptions page is now "Exception integrations". Item list
  with password inputs for webhooks that need a secret, a tenant ×
  item state table, an update toggle, and Preview / Replicate Now.
- 163 checks pass, including that the secret never appears in responses,
  msp_config.json or the server log.

Not confirmed live yet: UserApiKey on the `tenant/v2` service.


**Reports page (2026-11-16),** captured live from the console's Reporting
tabs and Directory/Tenant settings:
- Licences: `directory/v1/tenant-search` with `{"TenantSearch":{"ID":tid}}`
  gives `LicenceAllocation`; `webfe/v1/tenant-client-count` with
  `{"TenantClientCount":{"TenantIDList":[tid]}}` gives ClientCount and
  UnmanagedCount; `directory-search` gives LicenceCapacity and the term
  dates.
- Agents: GET `agent/v1/summary?include_child_policies=true` (new service
  `CLOUD_MODULE_AGENT`).
- Executive: GET `activity/v1/executive-overview?days&section&include_children=true`,
  five sections; execution_activity is also read per day
  (`chunk_date`, `chunk_hours=24`) for the trend.
- Readiness: POST `activity/v1/enforcement-readiness` `{type:"overview",
  days, threshold}`.
- Applications: GET `app-context/v1/applications?limit=500...` (new
  service `CLOUD_MODULE_APP_CONTEXT`).

app.py: `report_tenant_license`, `report_directory_license`,
`report_agent_summary`, `report_executive_section`,
`report_enforcement_readiness`, `report_applications` (all on the adapter).
Engine: `REPORT_KINDS`, `tenant_report`, `aggregate_report`,
`ReportReader` (parallel per tenant, 2-minute cache, per-tenant errors
listed and the rest still shown). Route POST `/msp/reports`
`{kind, tenant_id: all|reference|<id>, include_reference, days, threshold,
refresh}`. UI: sidebar Reports, five sub-tabs, CSV export. Tests: 179
checks pass. Unconfirmed live: UserApiKey on the agent and app-context
services.

**Application Context categories (2026-11-16, afternoon).** Captured live:
each `groups[]` entry has `category_keys[]` and `primary_category_key`; the
response carries `categories[{key,label}]` (28 of them) and the console's
filter just adds `&category=<key>`. We read once (paged by offset,
`APP_CONTEXT_PAGE` 500, up to 6 pages) and group locally: the apps
aggregation now returns `categories[{key,label,applications,tenants,
tenant_count}]` (every known category, empty ones included), per-app
`category`/`categories`/`category_label(s)`, and per-tenant category counts.
Filter matches any of an app's categories. UI: Category select, clickable
category bars, per-tenant breakdown for the chosen category, Category
column and CSV. Not copied: the console's Time Selector (recent_days) and
Show Low Confidence. Tests: 184 checks.

**Dashboard sub-tabs captured (2026-11-16, afternoon) — not built yet.**
- *Extension Overview* is File Overview with `browser_exec=true` on every
  `reporting/v1/dashboard/*` call (execution-counts, execution-types,
  execution-trend, execution-type-trend, top-users/hostnames/policy-groups,
  new-files; audit-enforcement-coverage is the same). The execution-type
  filter list comes from `tenant-dashboard-filter-execution-type-list`
  with `{TenantDashboardBrowserExec:true}` (Trusted/Blocked/Untrusted
  [Audit]/[OTP]/Blocklist Browser Execution). New Extensions Seen = new-files
  rows with `extension:true`. Our existing dashboard code already sends
  `browser_exec=false`, so this is mostly a flag.
- *Server Activity History:* POST `webfe/v1/tenant-baseline-server-activity-pagination-list`
  `{TenantBaselineServerActivityList:{FromDatetime, ToDatetime, MaxItems:null,
  SearchText, TaskFilter}, Pagination:{skip, take}}` → `{count, result[{ID,
  Datetime, Task, User, Description, Loglevel}]}`. TaskFilter takes the
  display name ("Policy Modify"); options from `webfe/v1/server-activity-task-list`
  (`SeverActivityTaskListStruct`, 33 tasks). The small panel on the Overview
  tabs uses the unpaged `tenant-baseline-server-activity-list` (last 24 h,
  MaxItems 100). Role `view_server_activity_history`. Descriptions contain
  user emails and login IPs.
- *Realtime Activity:* POST `webfe/v1/tenant-dashboard-realtime-activity-list`
  `{TenantRealtimeActivityParamList:[{MaxRows:400, DateTimeFrom(UTC),
  BlockedExecution, UntrustedExecutionAudit, UntrustedExecutionOTP,
  BlocklistExecution, BlocklistExecutionAudit, startTime(local)}]}` →
  `TenantDashboardRealtimeActivityList[{ID, ReceivedDate, EventDate,
  HostName, User, Path, Executable, Hash, FileExecuted, ParentGroup, Group,
  PolicyVersion, HashBDVersion, VerColor}]` (the list key is missing when
  empty). Console polls every 30 s from now − 10 min.
- Seen too: GET `webfe/v1/tenant-svr-setting-list` on Realtime (backup,
  retention, 2FA, CrowdStrike settings) — not needed.

**Dashboard sub-tabs built (2026-11-16).** app.py: `cloud_server_activity`,
`cloud_server_activity_tasks`, `cloud_realtime_activity` (bodies never
logged), on the adapter as `server_activity`, `server_activity_tasks`,
`realtime_activity`. Engine: dashboard filters gained `browser` (sends
`browser_exec=true`, validates against `DASHBOARD_BROWSER_EXECUTION_TYPES`,
keeps only `extension` rows in New Extensions Seen); `ActivityReader`
(parallel per tenant via `_parallel`, server activity cached 30 s, realtime
never cached; rows tagged with the tenant and sorted newest first);
`clean_server_activity_filters` (≤ 31 days) and `clean_realtime_filters`
(max rows ≤ 1000, at least one type). Routes POST
`/msp/dashboard/server-activity` and `/msp/dashboard/realtime`
(tenant_id all|reference|<id>). UI: per-sub-tab filter fields (`fx-file`,
`fx-server`, `fx-rt`), task bars that filter, events-by-tenant, paging (50),
CSV, realtime countdown/pause that only runs while the tab is visible, new
rows highlighted. Tests: 200 checks. Unconfirmed live: UserApiKey on these
webfe calls (the webfe service has worked with it elsewhere).

**Policy Differences report (2026-11-16, evening).** Ryan's decisions: compare
against the reference by default, with an option to compare any two
tenants; publishers are the exception (not scored, shown as who-trusts-what
like the Publishers list); "Fix with replication" wanted. I chose: extras
("only on tenant") shown but not scored.
- No new API calls: `tenant_policy_snapshot` = `ReferenceReader(tenant).inventory()`
  (works on any tenant) + policy modes from `list_policies` (auditmode
  "1" = Audit). `drift_union_library` merges every tenant's blocklists /
  allowlists / baselines so `tenant_item_states(..., kinds=DRIFT_LIST_TYPES)`
  (new `kinds` filter) reads each tenant's assignments for the same names.
  Paths / processes / installers / publishers per group come straight from
  the inventory's groups / inherited_groups.
- `_cell` per item × tenant × group: match / differs / missing / extra /
  group_missing. Differs = both applied but `_drift_content` differs
  (blocklist rules + hash count, allowlist rules + file count) with notes
  from `_content_notes`. Installer switches and settings (mode, notify,
  message) are per-group rows with values.
- Score = match / (match + differs + missing); extras and missing groups
  not counted. `fix` per tenant: {type: [{key, groups}]} where groups =
  the groups the base sets the item on directly (children inherit), never
  a group the tenant lacks. Switch differences fix via the "switches" key.
- `DriftReader` caches snapshots per tenant for 5 min; two parallel phases
  (snapshots, then views with the union library). Route POST `/msp/drift`
  `{base, compare, groups, refresh}`; `fixable` only when base = reference.
- UI: Reports → Policy Differences (controls Compare against / Compare /
  Policy groups picker / item search), stat tiles, scorecard (worst first,
  clickable cells), detail tabs incl. Publishers, Only show differences,
  CSV. `rdFix` batches fixes by exact group set and pre-fills Policies
  Replication (biggest batch first, `#rep-fix` banner says how many remain).
- Tests: 216 checks.

**New policy groups across tenants (2026-11-16, evening).** Captured on Yellow
Dog with a throwaway "MSP Toolkit Test Group" (created under Workstations,
switched to audit, deleted — Ryan approved):
- Create: POST `webfe/v1/tenant-policy-add-new-group`
  `{TenantPolicyGroupList:[{Parent:<parent ID>, Name}]}` → `TenantPolicyList[0]`
  with the new ID. **New groups start in Enforcement** (AuditMode "0") with
  default settings. Top level = Parent "global-policy-settings" (not yet
  live-tested).
- Mode: the console's Audit Mode dropdown + Apply Changes sends
  `tenant-policy-update-changes` / TenantPolicySettingUpdate with the full
  settings and `AuditMode: true` — `cloud_set_policy_group_mode` does
  load-modify-save-confirm.
- Delete: DELETE `policy/v1/policy/{id}` → 204 (catalogued, not used).
- `auditmode` in the policy list matched the settings for every group (some
  group names don't match their mode, e.g. "MacOS Enforce" is in audit).
- Engine: `clean_group_specs` (names ≤ 100, no duplicates, mode required,
  parents ordered first, loop check), `create_groups_on_tenant` (exists /
  planned / done / skipped (parent missing) / error; mode set after create;
  a failed mode set is reported as an error that says the group is in
  Enforcement), `reference_group_plan` (reference groups parent-first with
  parent + mode, and what each tenant lacks). Routes GET
  `/msp/groups/reference-plan`, POST `/msp/groups/create` `{groups,
  tenant_ids, dry_run}` (dry_run defaults to true). Clears the status and
  drift caches after creating. Adapter: `create_policy_group`,
  `set_policy_group_mode`.
- UI: "+ New" on the Policy Groups panel → dialog with New group / Copy
  from the reference tabs, Preview then Create (confirm), per-tenant
  results; re-reads the library if the reference got a new group.
- Tests: 226 checks.
