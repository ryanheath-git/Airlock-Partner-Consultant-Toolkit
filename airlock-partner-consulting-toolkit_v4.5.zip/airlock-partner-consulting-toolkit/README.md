# Airlock Partner Consulting Tool Kit

A local, browser-based Python code runner. Write or paste Python in a
browser tab, run it, compile it into a standalone Windows `.exe`, scan
the result on VirusTotal, or run your own Airlock Digital scripts —
all served from a small Flask app running on your own machine.

**This app is designed to run only on localhost, for a single local user.
It is not meant to be exposed to a network or the internet — see
[Security](#security) below.**

## Features

- **Editor tab** — paste Python code, run it, see stdout/stderr/exit
  code in the Output panel.
- **Compile to .exe** — bundles the code with PyInstaller into a
  timestamped standalone executable (`script_YYYYMMDD_HHMMSS.exe`),
  downloadable from the browser.
- **VirusTotal upload** — after a successful compile, upload the `.exe`
  for scanning with one button, then open the results in a new tab
  with a second button once the upload completes.
- **Status panel** — a permanently visible panel at the bottom of the
  Editor and Scripts tabs showing compile/run progress, results, and
  errors, with larger, easier-to-read text than a slim status line.
- **Scripts tab** — run your own local Python scripts with
  command-line arguments (e.g. `report.py --user jdoe --verbose`),
  with autocomplete over the scripts in your configured folder, and a
  configurable execution timeout (default 120s) for longer-running
  scripts.
- **GitHub sync** — optionally sync `.py` files from a GitHub repo into
  your local script folder, automatically on startup or on demand.
- **Custom Widgets tab** — purpose-built tools beyond the code runner,
  shown as tiles that expand into a right-hand detail panel when
  clicked. Two widgets so far:
  - **Timed Audit Mode** moves selected Airlock Digital agents from
    one policy group into another (e.g. enforcement → audit) for a
    set duration, then automatically moves them back — even across an
    app restart, since sessions are persisted to disk and any overdue
    revert is caught up on the next launch. Failed reverts are
    retried automatically rather than silently dropped. Sessions can
    also be reverted early from the widget.
  - **ISO 27001 Compliance** assesses every Airlock policy group
    against a set of ISO/IEC 27001:2022 Annex A controls that Airlock's
    policy configuration can provide direct evidence for (currently
    A.8.7, A.8.8, A.8.9, A.8.12, A.8.15, A.8.19 — see `iso_mapping.json`
    for which ones have a real automated rule versus a manual
    placeholder). Shows a live dashboard per group plus an
    endpoint-weighted donut chart (Fully Compliant / Partially
    Compliant / Non-Compliant / Not Assessed, by percentage of managed
    endpoints, not just group count), and can generate a downloadable,
    self-contained HTML report with the same chart for client
    engagements — open it in any browser, and print to PDF from there
    if needed. The control mapping is intentionally editable, not
    hardcoded — see below.
  - **Partner Engagement Report** (also referred to as NFR Tracking)
    pulls user activity, agent counts (audit vs. enforcement), and
    license utilization across your partner tenants in Airlock
    Digital's Cloud multi-tenant environment — a separate API layer
    from the regular Airlock connections used elsewhere in the app,
    with its own admin credential and per-tenant Tenant ID / Directory
    ID pairs (each partner has a distinct Directory ID, so both are
    stored together per tenant rather than assuming one fixed value).
    The partner tenant list is collapsible with a live selected-count
    summary. Generates a self-contained HTML report — themed to match
    this app's own dark palette, with a light print override — plus
    Excel and XML export of the same data, all built from one function
    so the three formats can't drift out of sync.
  - **Training Instances** creates a brand-new Airlock tenant for each
    student in a class (not a shared pre-provisioned instance), using
    the same Cloud admin API key as Partner Engagement Report above but
    a genuinely different authentication header. Queues every tenant's
    creation job, then polls each one in the background to completion,
    showing live status per student, then automatically adds a
    configured reference baseline to each completed tenant and assigns
    it to a configured policy group. Deleting a tenant (per student or
    per class) is also built in. See "Training Instances (tenant
    creation)" below for the config it needs and its current
    limitations.
- **Settings tab** — a card-based layout (VirusTotal, Airlock Digital,
  Script folder & execution, GitHub sync, Publish to GitHub) so more
  options are visible at once. Store your VirusTotal API key, save
  multiple Airlock Digital connections (each its own tenant + port +
  key, switchable without re-entering anything), copy any saved key to
  the clipboard for use as a script argument, set the script folder
  path and timeout, configure GitHub sync, and push this app's own
  source files to a GitHub repo of your choice — all stored locally.

## Requirements

- Python 3.9+
- Windows (for the `.exe` compile feature — PyInstaller builds for
  whatever OS it runs on, so compiling only produces a real `.exe` if
  run on Windows)

## Setup

### Windows quick start — `run.bat`

The included `run.bat` sets everything up and launches the app in one
step, using an isolated Python virtual environment so this project's
dependencies never conflict with anything else on your machine:

1. Changes into the folder the batch file itself lives in (so it works
   no matter where you clone or move the project — no path to edit).
2. Creates a `venv\` virtual environment folder the first time it's
   run; skips this step on later runs since it already exists.
3. Activates that virtual environment.
4. Installs everything in `requirements.txt` into it via `pip install`.
5. Launches `python app.py` and keeps the window open (`pause`) so you
   can see the server log and any errors.

Just double-click `run.bat` (or run it from a terminal) each time you
want to start the app — steps 2–4 are safe to repeat and only do real
work the first time or after `requirements.txt` changes.

### Manual / cross-platform

```bash
git clone <your-repo-url>
cd <repo-folder>
pip install -r requirements.txt
python app.py
```

Then open **http://localhost:5000** in your browser.

**After pulling changes or replacing files, fully stop the running
server (Ctrl+C, or close the `run.bat` window) and start it again** —
Flask's dev server does not hot-reload, so edits won't take effect
until it's restarted. If a server seems "stuck" on old behavior, check
for a leftover process still bound to port 5000 (e.g.
`netstat -ano | findstr :5000` on Windows) and kill it before
restarting.

## ISO 27001 control mapping (`iso_mapping.json`)

This file defines which controls the ISO 27001 Compliance widget
assesses and how. It's a plain, git-tracked JSON file (not runtime
state) meant to be hand-edited per client engagement — add or remove
controls, change descriptions, or tune rule thresholds without
touching `app.py`.

Each control has an `id`, `title`/`name`, `description`, and a `rule`.
Supported rule types:

| Type | Purpose |
|---|---|
| `field_equals` | Compares one field in the policy response to a pass/partial value (e.g. `auditmode`) |
| `list_any_match` | Checks whether at least N items in a list field match a condition (e.g. an actively-enforced entry in `blocklists`) |
| `all_of` / `any_of` | Combines sub-rules (AND / OR) — used for controls needing more than one signal |
| `manual` | Marks a control as requiring manual attestation rather than automated scoring |

A control's status is always one of `meets`, `partial`, `unmet`, or
`unknown` (the field the rule depends on wasn't present in the API
response — treated distinctly from `unmet` so the report never
silently claims a control failed when the data just wasn't there to
check).

Overall compliance categorization per group (used for the endpoint-
weighted chart) is based only on controls with a real automated rule —
`manual` placeholders are excluded from that roll-up so an unconfirmed
control can't silently drag a group into "non-compliant."

Current scope: A.8.7, A.8.9, and A.8.19 have real automated rules,
confirmed against actual Airlock API responses. A.8.8, A.8.12, and
A.8.15 are `manual` placeholders pending a confirmed field mapping —
extending them, or adding more controls, is expected as this widget
matures.

## Configuration

All settings are managed from the **Settings** tab in the app itself
and stored in a local `config.json` file created next to `app.py` on
first save. This file is git-ignored — it never gets committed.

| Setting | Purpose |
|---|---|
| VirusTotal API key | Enables the "Upload to VirusTotal" button after compiling; available to scripts as `VT_API_KEY` |
| Airlock Digital connections | Multiple saved tenant+port+key combinations — see below; the active one is used by every Airlock-related widget, and is available to scripts as `AIRLOCK_API_KEY`, `AIRLOCK_TENANT`, `AIRLOCK_PORT` |
| Script folder | Local folder the Scripts tab lists/runs scripts from |
| Script execution timeout | How long (seconds) a script may run before it's stopped; default 120 |
| GitHub sync | Optionally pulls `.py` files from a repo into the script folder |
| Publish to GitHub | Pushes this app's own source files (never your config/secrets) to a repo of your choice, as one commit |

### Airlock Digital connections (multiple tenants)

The Settings tab lets you save more than one Airlock Digital connection
— useful if you work across multiple client tenants. Each connection
bundles a label, tenant, port, and API key together as one saved unit,
so an API key can never accidentally get paired with the wrong
tenant's URL. Only one connection is **active** at a time; every
Airlock-related feature (Timed Audit Mode, ISO 27001 Compliance, the
Scripts tab's env vars) always uses whichever connection is currently
active. Switching the active connection takes effect immediately, with
no restart needed.

If you're upgrading from an older version of this app that only
supported a single tenant/key, that setup is automatically migrated
into your first saved connection (labeled "Default") the next time you
start `app.py` — nothing is lost.

### Partner Engagement Report (Cloud multi-tenant API)

This widget talks to a completely different API surface than the rest
of the app — Airlock Digital's Cloud/MSP multi-tenant management
layer, not a single on-prem server. It has its own separate connection
config (Cloud base domain + admin API key, set inside the widget
itself, not the Settings tab) plus a list of partner tenants you
maintain, each with its own Tenant ID **and** Directory ID — both vary
per partner, so both are stored together per entry rather than
assuming one fixed value.

A few things worth knowing if you're extending this widget:

- Auth uses a `UserApiKey` header (not `X-ApiKey` like the on-prem
  API), plus per-call `tenantID` and `Directoryid` headers.
- Endpoints are split across at least four modules
  (`https://<base_domain>/<module>/v1/<endpoint>`) — `willard`,
  `webfe`, `policy`, and `directory` were all needed for the four data
  points this widget pulls today. There's no reliable rule for which
  module or HTTP method (GET vs. POST) a given endpoint needs — each
  one was confirmed individually against real API responses, and a
  couple of assumptions from before actual field-testing turned out
  wrong. If you add a new call, test it directly rather than pattern-
  matching from a similar-looking endpoint.
- `cloud_api_request()` in `app.py` logs every call (URL, method,
  status, response body) to the terminal — the fastest way to diagnose
  a new integration issue is to reproduce it and read that log.
- Each of the four data points (users, agent counts, audit/enforce
  split, license allocation) is collected independently — a failure in
  one shows as "Unavailable" for that piece specifically rather than
  blanking out the whole tenant's report.

### Training Instances (tenant creation)

Creates a brand-new Airlock tenant per student for a class you teach,
rather than pre-provisioning a fixed set of instances and assigning
users onto them. Ported from a standalone bash toolkit
(`Airlock_Training_Tenant_Automation_v1`) already used against real
Airlock AU/AM production, so every endpoint/field/header below is
confirmed, not guessed.

- Reuses the same Cloud admin API key and base domain already
  configured in Partner Engagement Report above, but authenticates
  with a genuinely different header pair: `X-ApiKey` + `DirectoryID`
  (not `UserApiKey` + `tenantID`/`Directoryid`). The key needs
  `TenantCreate`/`Titan`/Rapid Admin authorization on the target
  directory — a plain per-tenant admin key is not enough.
- Two settings specific to this widget, saved in `training_config.json`:
  a **Directory ID** (the *parent* directory new tenants are created
  under — not any individual partner tenant's own Directory ID from
  the Partner Engagement Report widget) and a **Tenant license
  allocation** applied to every tenant this widget creates. A class
  itself only needs a name and a roster — per-class licence overrides,
  auto-expiry, and a free-text description were all removed from the
  UI (auto-expiry never actually worked, and a class name proved to be
  all the app needed) to keep the "New class" form to what's actually
  used day to day.
  - Above the **Tenant license allocation** field, the app shows
    "Licenses allocated: *N* of *M* available" for the configured
    directory, combining two independent, confirmed-real-capture Cloud
    API calls:
    - **Allocated** (`POST directory/v1/directory-licence-allocation-list`,
      module `directory`, payload `{"DirectoryLicenceAllocationList":
      {"DirectoryID": "<directory id>"}, "atcp": null}`, response
      `DirectoryLicenceAllocationList.DirectoryLicenceAllocated`) —
      already implemented as-is for the Partner Engagement Report
      widget's NFR tracking, so no new endpoint was needed for this half.
    - **Available** (`POST directory/v1/directory-search`, module
      `directory`, payload `{"DirectorySearch": {"DirectoryID":
      "<directory id>"}, "atcp": null}`, response
      `DirectorySearch.DirectoryList[0].LicenceCapacity`) — deliberately
      *not* `directory/v1/directory-update`, which looked like the
      obvious source (the console's directory Settings page shows the
      same number in an editable field) but turned out from a real
      capture to be a write call: getting the capacity from it would mean
      POSTing the *entire* Directory object back, including its two
      invite-email HTML templates and licence date range, just to read
      one field — a real risk of corrupting live directory/billing
      settings for a simple display value. `directory-search` is the
      genuinely read-only call the same Settings page also fires on
      load, confirmed via a live capture with Chrome DevTools' Ctrl+Shift+F
      body-search across all requests on that page (the same technique
      that found `tenant-user-group-list` for instructor access
      earlier). If the capacity half fails for any reason, the allocated
      count still displays on its own rather than the whole descriptor
      failing.
- Creating a class queues one tenant-creation job per roster row
  (`POST directory/v1/tenant-create-schedule`) — each student is that
  tenant's sole administrator and receives a real "you've been
  invited" email from Airlock. A background thread then polls every
  in-flight job (`GET quevider/v1/job/{JobID}/status`) every 15
  seconds until it reaches a terminal state (`COMPLETED`, or a failure
  state: `DEAD` / `CANCELLED` / `PARTIAL`), so the page doesn't have to
  stay open or block on however long provisioning takes.
- **Deleting a tenant** (`POST directory/v1/tenant-delete`, confirmed via
  a real browser Network capture) is available per student ("Delete
  tenant") or for a whole class at once ("Delete N tenants"), once a
  tenant's creation has reached a terminal state (`Completed`, `Dead`,
  `Cancelled`, or `Partial`) — there's nothing to delete while a tenant
  is still being created. This is permanent and irreversible, and always
  confirmed before it runs. It sends exactly one tenant per API call
  even though the endpoint's payload shape is an array, since a sibling
  batch-shaped Cloud API endpoint elsewhere in this app was confirmed to
  500 with more than one item — see "Cloud API reverse-engineering"
  below. **"Remove from list" is separate and does NOT delete anything
  in Airlock** — it only removes tracking here, and stays available (with
  a warning) even for a tenant that was never deleted, e.g. if you'd
  rather leave it running or let auto-expiry handle it later.
- **Baseline provisioning**: the moment a tenant's creation reaches
  `Completed`, the app automatically adds a reference baseline to it —
  the same "Add Baseline from Reference" action available in the
  console's Baselines tab, confirmed via real browser Network captures
  (`POST webfe/v1/tenant-baseline-reference-list` to fetch Airlock's
  full ~180-entry reference catalog, then `POST
  webfe/v1/tenant-baseline-reference-create` to add the matched one).
  Unlike tenant creation/deletion, these two calls use the *same*
  `UserApiKey` + `tenantID`/`Directoryid` auth style as NFR Tracking
  above, not the `X-ApiKey` style — confirmed from a real capture's
  `AccessLog`, which showed both a `TenantID` and `DirectoryID` in the
  authorization context.
  - Which baseline gets added is set under **Tenant creation
    settings** as a **Reference baseline (FullName)** — must exactly
    match a `FullName` from Airlock's current catalog (e.g.
    `Windows 11-25H2-x64-April 2026.tar.gz`). Airlock publishes a new
    monthly-patch build periodically, so update this field when you
    want new tenants on a newer one; tenants already provisioned are
    unaffected either way.
  - Since the real catalog runs to roughly 180 entries — too many to
    list in the widget — a **Browse catalog** control above the field
    breaks it down into two dropdowns instead of one flat list, sourced
    from a new `GET /training/reference-baselines` route. It reuses the
    exact same `tenant-baseline-reference-list` call above (no new Cloud
    API endpoint), just curated into two levels:
    - **OS family** (first dropdown) — one entry per distinct operating
      system family. This started as a straight group-by-`OperatingSystem`,
      but real catalog data Ryan captured across every family showed that
      only works for Windows (`OperatingSystem` stays constant across
      minor versions there, e.g. `"Windows 11"`, with the minor build
      living in `ServicePack` instead, e.g. `"25H2"`). Every Linux distro
      instead embeds its own minor version *inside* `OperatingSystem`
      (`"CentOS 7.0.1406"` and `"CentOS 7.1.1503"` are two different
      `OperatingSystem` strings, not one `"CentOS"` with varying
      `ServicePack`), so grouping by `OperatingSystem` alone produced 70+
      ungrouped buttons for CentOS/RHEL/Rocky/AlmaLinux/Ubuntu. The family
      is now derived instead: macOS's `OSType` collapses to a single
      `"macOS"` family; Windows's `OSType` splits into `"Windows"` vs.
      `"Windows Server"` (by whether `OperatingSystem` starts with
      `"Windows Server"`, since both share the same `OSType`); Linux's
      `OSType` uses the leading letters of `OperatingSystem` (via regex)
      to get one family per distro (`"CentOS"`, `"RHEL"`, `"Rocky"`,
      `"AlmaLinux"`, `"Ubuntu"`, etc.); anything else surfaces under its
      own `OSType` rather than being silently dropped.
    - **Specific baseline** (second dropdown, enabled after picking a
      family) — every catalog entry in that family, labeled with its
      `OperatingSystem`/`ServicePack`/`Architecture`/`PatchLevel`. The
      newest one by `PatchLevel` is pre-selected and marked
      "(recommended)" (parsed from confirmed real examples like
      `"April 2026"`; entries whose `PatchLevel` doesn't parse that way —
      true of virtually every Linux entry, which use `"RTM"`/`"Patched"`
      instead of a real date — still get a pick rather than being
      dropped), with x64 preferred on an exact tie (`"x64"`, `"x86_64"`,
      and `"x86_x64"` are all treated as equivalent for this purpose only,
      never normalized in the data sent to Airlock).

    Picking a family auto-fills the text field with its recommended
    baseline's exact `FullName`; picking a specific baseline afterwards
    overrides that. The field stays free-text either way, so any of the
    ~180 catalog entries can still be typed by hand. Because this list
    call needs a real tenant to authenticate against (the same
    per-tenant role-check as the baseline-add call itself), it tries
    with no tenant context first (some `webfe` calls here, like
    `tenant-user-create`, accept an inherited directory-level role
    instead) and falls back to any tenant this app has already created
    if that's refused; if you haven't created any training tenant yet,
    the browser can't authenticate and shows a clear message asking you
    to create one first.
  - The create call's captured payload echoes the *entire* matched
    catalog entry back (including a few UI bookkeeping fields
    alongside the real `OSType`/`FullName`/`ServicePack`/etc. data), so
    the app looks the entry up fresh from a live
    `tenant-baseline-reference-list` call and passes it straight
    through unmodified rather than reconstructing a guessed subset of
    fields.
  - A baseline failure (e.g. the configured name no longer matches
    anything in the catalog) never affects the tenant itself — the
    tenant was still created successfully either way. It's tracked
    separately per student ("Baseline added" / "Baseline failed"
    badges) and can be retried on its own with "Add baseline" / "Retry
    baseline", without re-creating or touching the tenant.
  - Only ever sends one baseline per API call, for the same reason
    tenant deletion does — see "Cloud API reverse-engineering" below.
- **Policy assignment**: immediately after a baseline is added, the app
  assigns it to a policy group — the console's own "assign this policy"
  action, confirmed via real browser Network captures
  (`GET webfe/v1/tenant-baseline-list` to resolve the just-added
  baseline's own ID/name on the tenant, `GET policy/v1/policy?limit=10000`
  — already used elsewhere in this app — to find the target policy
  group's ID and its Audit/Enforced children, then
  `POST webfe/v1/tenant-policy-update-changes` to actually assign it).
  Same `UserApiKey` auth style as baseline provisioning above, confirmed
  from real request headers this time, not just inferred from the
  `AccessLog` shape.
  - Which policy group gets the baseline is set under **Tenant creation
    settings** as **Policy group** — must exactly match a policy group's
    name on the tenant. Defaults to `Workstations`, which a real capture
    confirmed Airlock auto-provisions (along with `Workstations Audit`/
    `Workstations Enforced` children) on every newly created tenant, so
    this works unmodified for training tenants this app creates.
  - Assigning to the group cascades to both its Audit and Enforced
    children automatically (confirmed via a real capture — one API call
    queued a database-regeneration job for the group and both children),
    so there's no need to target a specific mode separately.
  - The baseline lookup identifies "the one just added" as the *most
    recently created* baseline on the tenant (by an internal
    epoch-like `Timestamp` field) rather than trying to reconstruct its
    display name from the reference catalog's differently-formatted
    `FullName` — safe here since exactly one baseline gets added per
    tenant, immediately before this lookup runs.
  - The assignment payload's `Policy` object is built from data this app
    already has (via the same `policy?limit=10000` call used elsewhere)
    using only the real structural fields (ID/Name/Parent/children) —
    it deliberately omits console-only cosmetic UI fields (icon,
    expanded/checked state, etc.) that a real capture showed but that
    nothing available to this app can derive real values for. If a live
    run ever shows the API actually requires one of those, that'll
    surface as a clear API error to fix from, not a guess made now.
  - A failure here (e.g. the configured policy group name doesn't match
    anything on the tenant) never affects the baseline or tenant
    themselves — tracked separately per student ("Policy assigned" /
    "Policy assign failed" badges), retriable on its own with "Assign to
    policy" / "Retry assignment" once a baseline exists to assign.
  - Only ever sends one policy group's changes per API call, for the
    same reason tenant deletion and baseline creation do — see "Cloud
    API reverse-engineering" below.
- **Instructor access provisioning**: runs first, before baseline
  provisioning and policy assignment — closing a gap discovered from a
  real-world test where the fully-automatic chain above 403'd on every
  brand-new tenant (`Tenant Role(s) NOT Found: view_baselines`/
  `view_policies`). It turns out Airlock only grants the calling
  account those tenant-level roles the first time someone personally
  opens that tenant in the console — this step replicates exactly what
  that first console visit does, confirmed via a real capture of the
  console's own "Add Yourself to This Tenant" modal (`GET
  webfe/v1/tenant-user-group-list` to find the tenant's "LocalAdmin"
  user group by name, then `POST webfe/v1/tenant-user-create` to add
  the configured instructor to it — the same call the console's own
  "Add Me to Tenant" button fires). Same `UserApiKey` auth style as
  every other `webfe` call above.
  - This works on a tenant nobody has ever opened because of a detail
    in the captured response's `AccessLog`: every
    `TenantRoleCheckMessage` says "NOT Found", but `AccessGranted` is
    still `true` because of `"Directory Role(s) Found, Inherited:
    true"` — this endpoint accepts *either* a tenant-level role *or* an
    inherited directory-level one, and whichever account this app
    authenticates as already has adequate directory-level admin roles
    (the same account used for every other Cloud API call here).
  - Who gets added is set under **Tenant creation settings** as
    **Instructor full name** / **Instructor email** — unlike the
    baseline/policy fields above, there's no sensible generic default
    here, so leaving both blank simply skips this step (tracked as an
    "Instructor access skipped" badge, not an error) and falls back to
    the old behavior of needing someone to open the tenant in the
    console by hand first. Set these to whichever instructor's Cloud
    API key this app is configured with; sharing this toolkit with a
    different instructor is just a matter of updating these two fields
    (and the Cloud admin API key) to theirs.
  - The "LocalAdmin" user group's ID is looked up by name from a live
    `tenant-user-group-list` call every time rather than hardcoded —
    even though a real capture showed the same ID on two different
    tenants (suggesting it may be a stable, platform-wide default), the
    same look-up-by-name caution applies here as it does for baselines
    and policy groups elsewhere in this app. Note this is a *different*
    endpoint than `security/v1/directory-group-list`, which was tried
    first and confirmed wrong — that one returns the calling user's own
    directory-wide admin role groups (`TenantAdmin`/`ReadOnly`/
    `BillingAdmin`/etc.), not the tenant-scoped groups the console's
    "Local User Group" dropdown actually shows.
  - A failure here (e.g. no "LocalAdmin" group found) never blocks
    baseline provisioning or policy assignment from being attempted —
    they may still succeed on their own if the account already had
    access some other way. Tracked separately per student ("Instructor
    added" / "Instructor access failed" / "Instructor access skipped"
    badges), retriable on its own with "Grant instructor access" /
    "Retry instructor access".
  - **Confirmed via a real live test**: granting this access doesn't take
    effect instantly — an automatic baseline-add attempted immediately
    after a successful grant on a brand-new tenant 403'd with `Tenant
    Role(s) NOT Found: view_baselines`, but a manual retry moments later
    (no other change) succeeded. Both the automatic chain and the manual
    "Retry baseline"/"Retry assignment" buttons now absorb this specific,
    confirmed error shape automatically — retrying up to 3 times, 3
    seconds apart — so a brand-new tenant should now provision fully
    hands-off in the common case. Any *other* kind of failure (a real
    permissions problem, a wrong baseline/policy group name, a network
    error) still surfaces immediately, unretried.

### Publish to GitHub

The opposite direction from GitHub sync above: instead of pulling
scripts *into* this app, this card pushes the app's *own* source files
*out* to a GitHub repo — a quick way to back up or share your changes
without a separate git setup. It can point at the same repo as GitHub
sync or a completely different one.

- Pushes a single versioned zip file (`GITHUB_PUBLISH_FILES` in
  `app.py` lists exactly what goes into it: `app.py`,
  `templates/index.html`, `iso_mapping.json`, `README.md`,
  `PROJECT_SUMMARY.md`, `requirements.txt`, `run.bat`, `.gitignore`) —
  `config.json`, `cloud_config.json`, `training_config.json`, `venv/`,
  `builds/`, `api_scripts/`, and `audit_sessions.json` are never
  touched, by design — this is a fixed list, not a `.gitignore` parser,
  specifically so a secret or runtime file can never end up on it by
  accident.
- The zip is named `airlock-partner-consulting-toolkit_v<version>.zip`
  and pushed to the repo root. The version number auto-increments from
  your last push but is editable before each one, and **every past
  version is kept** — a new push never overwrites or deletes an older
  zip, so the repo accumulates a full version history.
- Requires a personal access token with **write** access to the target
  repo — a classic token needs the `repo` scope, a fine-grained token
  needs `Contents: Read and write` on that repo (and the repo itself
  must be included under "Repository access" for a fine-grained
  token). This is a different requirement than GitHub sync's token,
  which only needs read access (and isn't needed at all for a public
  repo).
- Builds the commit via GitHub's Git Data API (blob → tree → commit →
  branch ref) — the branch either fast-forwards to the new commit, or
  gets created fresh if it doesn't exist yet (e.g. publishing into a
  brand-new, empty repo).
- Optional commit message per push; defaults to a message naming the
  version if left blank.
- The status panel links straight to the commit on GitHub once a push
  succeeds.

## Security

This app executes arbitrary Python code and, once compiled,
arbitrary executables — with your full local user permissions. Keep
this in mind:

- Runs bound to `127.0.0.1` only — do **not** change this to `0.0.0.0`
  or expose port 5000 to your network/internet. Anyone who could reach
  it could run arbitrary code on your machine.
- `config.json` stores API keys in **plaintext**. It's git-ignored by
  default; don't commit it, screenshot it, or share it.
- The Cloud admin API key used by the Partner Engagement Report widget
  can see across **every** partner tenant it has access to — treat it
  with at least as much care as your other credentials, since it's not
  scoped to a single client the way your regular Airlock connections
  are.
- The Settings tab lets you copy a saved key to the clipboard — the
  real key value is sent to your own browser on request for that
  purpose, never anywhere else.
- Files uploaded to VirusTotal become visible to other VirusTotal
  users/vendors once scanned — don't upload anything containing
  secrets or proprietary code you don't want potentially exposed.
- Scripts run from the Scripts tab (local or synced from GitHub) run
  with your full user permissions — only point the script folder /
  GitHub sync at sources you trust.
- The Publish to GitHub token needs **write** access to whatever repo
  you point it at — a classic PAT with the `repo` scope can push to
  every repo that token can see, not just this one, so a fine-grained
  token scoped to a single repo is safer if your GitHub plan supports
  it. Either way, treat it like any other credential in this file.
- Timed Audit Mode moves real endpoints between real Airlock Digital
  policy groups — double-check the source/destination groups and agent
  selection before starting a session. `audit_sessions.json` tracks
  in-progress sessions locally so scheduled reverts survive an app
  restart; it's git-ignored since it's runtime state, not app source.

## Project structure

```
.
├── app.py                 # Flask app — all backend routes
├── run.bat                 # Windows one-step setup + launch script
├── requirements.txt
├── iso_mapping.json         # editable ISO 27001 <-> Airlock control mapping
├── templates/
│   └── index.html         # Single-page frontend (editor, scripts, widgets, settings)
├── .gitignore
├── venv/                   # created by run.bat — git-ignored
├── config.json             # created at runtime — git-ignored
├── cloud_config.json        # Partner Engagement Report's admin key + tenant list — git-ignored
├── training_config.json     # Training Instances' settings + class/tenant tracking — git-ignored
├── builds/                 # compiled .exe output — git-ignored
├── api_scripts/            # local/synced scripts folder — git-ignored
└── audit_sessions.json     # Timed Audit Mode session state — git-ignored
```
