#!/usr/bin/env python3
"""har_to_catalog.py — turn one or more exported HAR files into a growing,
de-duplicated JSON catalog of Airlock API endpoints.

WHY THIS EXISTS
----------------
api-reference.html (the API Reference widget) only documents the ~32
endpoints this app's own code happens to call. That's a narrow slice of
Airlock's real Cloud/tenant API surface — everything else in the console
you haven't automated yet is invisible to it. This script is how the
guide grows past that: export a HAR from the browser's Network tab after
clicking through some part of the console, run it through here, and any
endpoint not already known gets added to api_catalog.json with its
method, path, auth style, and a redacted request/response shape.

USAGE
-----
    python3 har_to_catalog.py capture1.har [capture2.har ...]
    python3 har_to_catalog.py capture1.har --catalog api_catalog.json

Run it again later with new captures — it merges into the same catalog
file rather than starting over, and prints a summary of what's new.

SECURITY — READ THIS BEFORE SHARING A HAR OR THE CATALOG
----------------------------------------------------------
A raw HAR export can contain live secrets in plaintext: API keys,
session cookies, bearer tokens. This script:
  1. Never writes the value of any header or JSON field whose name looks
     like a credential (api key, token, password, secret, authorization,
     cookie, session) — those become the literal string "<redacted>".
  2. Never writes literal request/response VALUES at all (no real names,
     emails, tenant IDs, or other customer data) — only the *shape*
     (key names + value types), so the catalog is safe to keep in the
     repo even though the source HARs are not.
The source .har files themselves are NOT sanitized by this script and
should never be committed or published — keep them local, and delete
them once you've run them through here if you don't need them for
anything else.
"""

import argparse
import base64
import json
import re
import sys
from collections import OrderedDict
from datetime import datetime, timezone
from urllib.parse import urlparse

# ---------------------------------------------------------------------
# Endpoints already hand-documented in the API Reference widget
# (templates/api_reference.html) — used only to flag NEW vs KNOWN in the
# summary printed at the end of a run. Keep this in sync by eye; it's a
# convenience flag, not a source of truth.
# ---------------------------------------------------------------------
KNOWN_DOCUMENTED = {
    ("POST", "/v1/group"), ("POST", "/v1/agent/find"), ("POST", "/v1/agent/move"),
    ("POST", "/v1/group/policies"),
    ("GET", "/webfe/v1/tenant-user-list"), ("POST", "/webfe/v1/tenant-policy-managed-count-list"),
    ("GET", "/policy/v1/policy"), ("POST", "/webfe/v1/tenant-policy-clients-in-scope-list"),
    ("POST", "/directory/v1/directory-licence-allocation-list"), ("POST", "/directory/v1/directory-search"),
    ("GET", "/webfe/v1/tenant-user-group-list"), ("POST", "/webfe/v1/tenant-user-create"),
    ("POST", "/webfe/v1/tenant-baseline-reference-list"), ("POST", "/webfe/v1/tenant-baseline-reference-create"),
    ("GET", "/webfe/v1/tenant-baseline-list"), ("POST", "/webfe/v1/tenant-policy-update-changes"),
    ("POST", "/directory/v1/directory-create"), ("POST", "/directory/v1/directory-list"),
    ("POST", "/directory/v1/tenant-create-schedule"), ("GET", "/quevider/v1/job/{id}/status"),
    ("POST", "/directory/v1/tenant-delete"),
}

# Hosts that are never part of Airlock's own API, however busy they are
# in a real capture — matched as a substring of the request host.
NOISE_HOSTS = (
    "sentry.io", "google-analytics.com", "googletagmanager.com", "doubleclick.net",
    "intercom.io", "segment.io", "segment.com", "hotjar.com", "fullstory.com",
    "mixpanel.com", "cloudflareinsights.com", "newrelic.com", "datadoghq.com",
    "gstatic.com", "googleapis.com/css", "fonts.googleapis.com",
)

# Path suffixes that mean "static asset", not an API call.
ASSET_EXTENSIONS = (".svg", ".png", ".jpg", ".jpeg", ".gif", ".ico", ".css", ".js",
                     ".woff", ".woff2", ".ttf", ".map")

# Header / JSON-key name fragments that mean "never write the real value".
SENSITIVE_KEY_PATTERN = re.compile(
    r"api[-_]?key|token|password|secret|authorization|cookie|session", re.IGNORECASE
)

# Path segments that are really an ID, not a fixed route component —
# generalized to {id} so e.g. two different job IDs collapse to one
# catalog entry instead of two.
ID_SEGMENT_PATTERN = re.compile(
    r"^[0-9a-fA-F]{24}$"                                  # Mongo ObjectId
    r"|^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"  # UUID
    r"|^\d{3,}$"                                           # long-ish plain numeric id
)


def is_noise_host(host):
    host = (host or "").lower()
    return any(n in host for n in NOISE_HOSTS)


def is_asset_path(path):
    return path.lower().endswith(ASSET_EXTENSIONS)


def normalize_path(path):
    """Collapses ID-shaped path segments to {id} so different calls to the
    same endpoint (different job/tenant/directory IDs) merge into one
    catalog entry. Query string is dropped entirely — captured separately
    if needed, not part of the endpoint's identity here."""
    parts = path.split("/")
    normalized = [ID_SEGMENT_PATTERN.sub("{id}", p) if p else p for p in parts]
    return "/".join(normalized)


def shape_of(value, depth=0):
    """Converts a real JSON value into a redacted structural description:
    key names and value TYPES only, never literal data. Recurses into
    dicts/lists with a depth cap so a deeply nested real payload can't
    blow this up. Any key that looks like a credential is always
    '<redacted>' regardless of its actual value or type."""
    if depth > 6:
        return "<truncated: too deep>"
    if isinstance(value, dict):
        out = OrderedDict()
        for k, v in value.items():
            if SENSITIVE_KEY_PATTERN.search(str(k)):
                out[k] = "<redacted>"
            else:
                out[k] = shape_of(v, depth + 1)
        return out
    if isinstance(value, list):
        if not value:
            return "array<empty>"
        return [shape_of(value[0], depth + 1)]
    if isinstance(value, bool):
        return "<boolean>"
    if isinstance(value, (int, float)):
        return "<number>"
    if value is None:
        return "<null>"
    return "<string>"


def parse_json_body(text, encoding=None):
    if not text:
        return None
    try:
        if encoding == "base64":
            text = base64.b64decode(text).decode("utf-8", errors="replace")
        return json.loads(text)
    except (ValueError, UnicodeDecodeError):
        return None


def detect_auth_style(header_names_lower):
    has = lambda n: n in header_names_lower
    if has("userapikey") and has("tenantid"):
        return "cloud-api-per-tenant (UserApiKey + tenantID/Directoryid)"
    if has("x-apikey") and has("directoryid") and not has("tenantid"):
        return "cloud-api-tenant-lifecycle (X-ApiKey + DirectoryID)"
    if has("x-apikey"):
        return "tenant-server (X-ApiKey)"
    if has("directoryid") or has("tenantid"):
        return "console-session (browser cookie/JWT auth — DirectoryID/TenantID present but no API-key header captured; not reproducible with this app's own credentials)"
    return "unknown — no scoping headers captured"


def entries_from_har(path):
    with open(path, "r", encoding="utf-8") as f:
        har = json.load(f)
    return har.get("log", {}).get("entries", [])


def process_har(path, catalog_endpoints, source_label, stats):
    for entry in entries_from_har(path):
        req = entry.get("request", {})
        resp = entry.get("response", {})
        url = req.get("url", "")
        parsed = urlparse(url)
        host = parsed.netloc
        raw_path = parsed.path

        stats["seen"] += 1

        if is_noise_host(host):
            stats["skipped_noise_host"] += 1
            continue
        if is_asset_path(raw_path):
            stats["skipped_asset"] += 1
            continue
        method = req.get("method", "GET").upper()
        if method not in ("GET", "POST", "PUT", "PATCH", "DELETE"):
            stats["skipped_method"] += 1
            continue

        norm_path = normalize_path(raw_path)
        key = (method, host, norm_path)

        header_names_lower = {h.get("name", "").lower() for h in req.get("headers", [])}
        auth_style = detect_auth_style(header_names_lower)

        post_data = req.get("postData", {})
        req_body = parse_json_body(post_data.get("text"))
        req_schema = shape_of(req_body) if req_body is not None else None

        content = resp.get("content", {})
        resp_mime = (content.get("mimeType") or "").split(";")[0].strip()
        resp_body = None
        if "json" in resp_mime:
            resp_body = parse_json_body(content.get("text"), content.get("encoding"))
        resp_schema = shape_of(resp_body) if resp_body is not None else (
            f"(non-JSON response: {resp_mime})" if resp_mime and "json" not in resp_mime else None
        )

        if key not in catalog_endpoints:
            catalog_endpoints[key] = {
                "method": method,
                "host": host,
                "path": norm_path,
                "auth_style": auth_style,
                "sample_status": resp.get("status"),
                "occurrences": 0,
                "sources": [],
                "request_body_schema": req_schema,
                "response_body_schema": resp_schema,
                "known_documented": (method, norm_path) in KNOWN_DOCUMENTED,
            }
            stats["new_endpoint"] += 1

        rec = catalog_endpoints[key]
        rec["occurrences"] += 1
        if source_label not in rec["sources"]:
            rec["sources"].append(source_label)
        # Fill in a schema if this occurrence has one and an earlier
        # occurrence didn't (e.g. first capture was an empty-body error).
        if rec["request_body_schema"] is None and req_schema is not None:
            rec["request_body_schema"] = req_schema
        if rec["response_body_schema"] is None and resp_schema is not None:
            rec["response_body_schema"] = resp_schema

        stats["cataloged"] += 1


def load_catalog(catalog_path):
    if not catalog_path.exists():
        return OrderedDict()
    with open(catalog_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    endpoints = OrderedDict()
    for e in data.get("endpoints", []):
        key = (e["method"], e["host"], e["path"])
        endpoints[key] = e
    return endpoints


def save_catalog(catalog_path, catalog_endpoints, all_sources):
    ordered = sorted(catalog_endpoints.values(), key=lambda e: (e["host"], e["path"], e["method"]))
    out = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "sources": sorted(all_sources),
        "endpoint_count": len(ordered),
        "endpoints": ordered,
    }
    with open(catalog_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)


def main():
    ap = argparse.ArgumentParser(description="Extract a redacted API endpoint catalog from exported HAR files.")
    ap.add_argument("har_files", nargs="+", help="One or more .har (or .har.txt) files to process.")
    ap.add_argument("--catalog", default="api_catalog.json", help="Catalog JSON to merge into (default: api_catalog.json in the current directory).")
    args = ap.parse_args()

    from pathlib import Path
    catalog_path = Path(args.catalog)
    catalog_endpoints = load_catalog(catalog_path)
    existing_sources = set()
    for e in catalog_endpoints.values():
        existing_sources.update(e.get("sources", []))

    all_new_by_file = {}
    for har_file in args.har_files:
        stats = {"seen": 0, "skipped_noise_host": 0, "skipped_asset": 0, "skipped_method": 0,
                  "new_endpoint": 0, "cataloged": 0}
        source_label = Path(har_file).name
        process_har(har_file, catalog_endpoints, source_label, stats)
        existing_sources.add(source_label)
        all_new_by_file[source_label] = stats

    save_catalog(catalog_path, catalog_endpoints, existing_sources)

    # ---- summary ----
    print(f"\nWrote {catalog_path} ({len(catalog_endpoints)} total endpoints known)\n")
    for source_label, stats in all_new_by_file.items():
        print(f"  {source_label}:")
        print(f"    {stats['seen']} requests seen, {stats['cataloged']} kept "
              f"({stats['skipped_noise_host']} skipped as noise hosts, "
              f"{stats['skipped_asset']} skipped as static assets, "
              f"{stats['skipped_method']} skipped by method)")
        print(f"    {stats['new_endpoint']} new endpoint(s) discovered")

    new_undocumented = [
        e for e in catalog_endpoints.values()
        if not e.get("known_documented") and any(s in all_new_by_file for s in e["sources"])
    ]
    if new_undocumented:
        print(f"\n{len(new_undocumented)} endpoint(s) found that AREN'T in the API Reference widget yet:")
        for e in sorted(new_undocumented, key=lambda e: (e["host"], e["path"])):
            print(f"    {e['method']:6s} {e['path']:55s} [{e['auth_style'].split(' ')[0]}]  x{e['occurrences']}")
        print("\nThese are captured with redacted request/response shapes in "
              f"{catalog_path.name} — review them and fold any worth documenting into "
              "templates/api_reference.html by hand (the 'used by' / purpose text can't "
              "be inferred from traffic alone).")


if __name__ == "__main__":
    main()
