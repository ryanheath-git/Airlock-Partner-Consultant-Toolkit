"""
Local browser-based Python code runner.

Run with:
    python app.py

Then open http://localhost:5000 in your browser.

SECURITY NOTE:
This runs whatever Python code is submitted, on your own machine,
with your own user permissions. It is intended for LOCAL, PERSONAL
use only (e.g. testing snippets on your own laptop). Do NOT expose
this server to the network or the internet — anyone who can reach
it can run arbitrary code on your computer.
"""

import subprocess
import sys
import tempfile
import os
import uuid
import json
import shlex
import time
import threading
import logging
import logging.handlers
import re
import html
import math
import base64
import zipfile
from io import BytesIO
from datetime import datetime, timezone, timedelta
import xml.etree.ElementTree as ET
from xml.dom import minidom

import requests
from flask import Flask, request, jsonify, render_template, send_from_directory, send_file
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

app = Flask(__name__)

# Where compiled executables, config, and logs are saved. Everything
# lives next to this file.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BUILDS_DIR = os.path.join(BASE_DIR, "builds")
os.makedirs(BUILDS_DIR, exist_ok=True)

# Log file path — only written to while logging is enabled (see
# configure_logging below). Rotated so it can't grow unbounded over a
# long-running session.
LOG_FILE_PATH = os.path.join(BASE_DIR, "app.log")

log = logging.getLogger("app")


def configure_logging(enabled):
    """Turns logging to the terminal and to app.log on or off. Affects
    the root logger, so it covers both our own log.info() calls (e.g.
    diagnosing third-party API calls to Airlock Digital, VirusTotal,
    the Cloud multi-tenant API) and Flask/Werkzeug's own request
    logging — a single toggle for everything currently visible in the
    terminal. Safe to call again at runtime to flip the setting
    without restarting the app."""
    root_logger = logging.getLogger()
    for handler in list(root_logger.handlers):
        root_logger.removeHandler(handler)

    if not enabled:
        # A NullHandler avoids Python's "no handlers found" warning;
        # setting the level above CRITICAL means log calls are cheap
        # no-ops rather than doing real work that goes nowhere.
        root_logger.addHandler(logging.NullHandler())
        root_logger.setLevel(logging.CRITICAL + 1)
        return

    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE_PATH, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    root_logger.setLevel(logging.INFO)


# On by default (matches this app's behavior before the toggle existed)
# so logging works immediately for any use of this module, including
# being imported directly for testing. __main__ below re-applies the
# actual saved preference once config.json can be read.
configure_logging(True)

# Max time (seconds) a submitted script is allowed to run before being killed.
EXECUTION_TIMEOUT = 10

# Max time (seconds) a compile job is allowed to run before being killed.
# PyInstaller can be slow, especially on the first run.
COMPILE_TIMEOUT = 180

# Local config file storing the VirusTotal API key.
# NOTE: stored in plaintext. Fine for a single-user local tool, but
# don't commit this file or share it — it grants access to your
# VirusTotal account/quota.
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")

# Persisted Timed Audit Mode sessions, so scheduled reverts survive an
# app restart. Local file next to app.py; not sensitive on its own
# (agent IDs and group IDs only, no secrets) but still git-ignored.
AUDIT_SESSIONS_PATH = os.path.join(BASE_DIR, "audit_sessions.json")

# Editable ISO 27001 <-> Airlock policy control mapping. This is
# reference content, not a secret or runtime state — it's meant to be
# committed to git and hand-tuned per client engagement.
ISO_MAPPING_PATH = os.path.join(BASE_DIR, "iso_mapping.json")

# NFR Tracking widget's own storage — deliberately separate from
# config.json so its data can never collide with anything else the app
# writes. Contains the Cloud admin credential and saved partner
# tenants.
CLOUD_CONFIG_PATH = os.path.join(BASE_DIR, "cloud_config.json")

# Training Instances widget's own storage — separate from cloud_config.json
# even though it reuses the same Cloud admin credential, since it tracks
# its own thing (saved Student instances and which admin account, if any,
# the widget currently has provisioned on each one).
TRAINING_CONFIG_PATH = os.path.join(BASE_DIR, "training_config.json")

# NFR Provisioning widget's own storage — separate again, even though it
# reuses the same Cloud admin credential AND (by Ryan's choice) the same
# baseline/policy group settings as Training Instances. Kept in its own
# file because its directory_id and tracked tenants are genuinely
# different data, not just a different view of training_config.json.
NFR_PROVISIONING_CONFIG_PATH = os.path.join(BASE_DIR, "nfr_provisioning_config.json")

# Reference baseline catalog cache — its own file, separate from
# training_config.json, so it survives independently of tenants/classes.
# The catalog itself barely changes (Airlock publishes a new monthly-patch
# build periodically) and Ryan's normal workflow is to delete every
# training tenant after a class and start the next one from scratch, so
# once this has been populated by one successful live fetch it should just
# keep serving the picker from disk rather than needing a tenant to exist
# to re-authenticate the lookup every time.
BASELINES_CACHE_PATH = os.path.join(BASE_DIR, "baselines.json")

VT_FILES_URL = "https://www.virustotal.com/api/v3/files"
VT_UPLOAD_URL_ENDPOINT = "https://www.virustotal.com/api/v3/files/upload_url"
VT_LARGE_FILE_THRESHOLD = 32 * 1024 * 1024  # VT requires the special upload URL above 32MB

# Max time (seconds) an API-calls script is allowed to run before being killed.
DEFAULT_API_SCRIPT_TIMEOUT = 120

# Default folder for your Airlock Digital script repository, used when
# api_scripts_dir isn't set in config.json. You can point this at your
# existing repo instead via the Settings tab. Scripts always run from
# this local folder — GitHub, when enabled, is a sync source that copies
# .py files into this folder, not a separate execution location.
DEFAULT_API_SCRIPTS_DIR = os.path.join(BASE_DIR, "api_scripts")

# File types the app will offer to open after an API-calls script runs.
OUTPUT_FILE_EXTENSIONS = (".xlsx", ".xml", ".html", ".htm")

# Labels scripts commonly use to announce where they wrote their output,
# most specific first. Matched case-insensitively against each line of
# stdout/stderr, e.g. "HTML report: report\policy_report.html".
OUTPUT_LABEL_PATTERNS = [
    re.compile(r"html report\s*:\s*(.+)", re.IGNORECASE),
    re.compile(r"report file\s*:\s*(.+)", re.IGNORECASE),
    re.compile(r"output file\s*:\s*(.+)", re.IGNORECASE),
    re.compile(r"\bsaved\s*:\s*(.+)", re.IGNORECASE),
    re.compile(r"\breport\s*:\s*(.+)", re.IGNORECASE),
    re.compile(r"\boutput\s*:\s*(.+)", re.IGNORECASE),
]


def extract_output_path_from_text(text, exec_dir):
    """Looks for a line like 'HTML report: some\\path\\file.html' in a
    script's console output and resolves it to a real file under
    exec_dir. Returns the absolute path, or None if nothing matched or
    the resulting file doesn't actually exist.

    Checks label patterns in priority order (most specific label first)
    across the *entire* output before falling back to a less-specific
    label — so a specific "HTML report:" line always wins over a generic
    "Saved:" line from an earlier step (e.g. an intermediate XML export),
    even though that generic line appears first in the text.
    """
    if not text:
        return None

    real_exec_dir = os.path.realpath(exec_dir)
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]

    def resolve(candidate):
        candidate = candidate.strip().strip('"').strip("'")
        if not candidate.lower().endswith(OUTPUT_FILE_EXTENSIONS):
            return None

        # Scripts run on Windows commonly print backslash paths.
        normalized = candidate.replace("\\", os.sep).replace("/", os.sep)
        full_path = normalized if os.path.isabs(normalized) else os.path.join(exec_dir, normalized)
        full_path = os.path.normpath(full_path)

        # Security: only accept paths that stay inside the scripts folder.
        real_full = os.path.realpath(full_path)
        if real_full != real_exec_dir and not real_full.startswith(real_exec_dir + os.sep):
            return None

        return full_path if os.path.isfile(full_path) else None

    for pattern in OUTPUT_LABEL_PATTERNS:
        # If a pattern matches more than one line (e.g. a script logs its
        # own "Saved:" line for each step), prefer the last one — final
        # summary lines are typically printed after the interim ones.
        match = None
        for line in lines:
            m = pattern.search(line)
            if not m:
                continue
            resolved = resolve(m.group(1))
            if resolved:
                match = resolved
        if match:
            return match

    return None


def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(config):
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)


def load_cloud_config():
    if os.path.exists(CLOUD_CONFIG_PATH):
        try:
            with open(CLOUD_CONFIG_PATH, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_cloud_config(cfg):
    with open(CLOUD_CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
    log.info("Wrote %s (%d tenant(s))", CLOUD_CONFIG_PATH, len((cfg.get("cloud_tenants") or [])))


def load_training_config():
    if os.path.exists(TRAINING_CONFIG_PATH):
        try:
            with open(TRAINING_CONFIG_PATH, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_training_config(cfg):
    with open(TRAINING_CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
    class_count = len(cfg.get("classes") or [])
    student_count = sum(len(c.get("students") or []) for c in (cfg.get("classes") or []))
    log.info("Wrote %s (%d class(es), %d student(s))", TRAINING_CONFIG_PATH, class_count, student_count)


def load_nfr_provisioning_config():
    if os.path.exists(NFR_PROVISIONING_CONFIG_PATH):
        try:
            with open(NFR_PROVISIONING_CONFIG_PATH, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_nfr_provisioning_config(cfg):
    with open(NFR_PROVISIONING_CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
    log.info("Wrote %s (%d tenant(s))", NFR_PROVISIONING_CONFIG_PATH, len(cfg.get("tenants") or []))


def load_baselines_cache():
    if os.path.exists(BASELINES_CACHE_PATH):
        try:
            with open(BASELINES_CACHE_PATH, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_baselines_cache(cache):
    with open(BASELINES_CACHE_PATH, "w") as f:
        json.dump(cache, f, indent=2)
    log.info("Wrote %s (%d baseline(s), fetched_at=%s)", BASELINES_CACHE_PATH, len(cache.get("baselines") or []), cache.get("fetched_at"))


def _prune_deleted_training_students(training_cfg):
    """Drops any student whose tenant has already been deleted from
    Airlock out of the tracking list, and drops a class entirely once
    every one of its students has been cleaned up this way. This is the
    ONLY thing that ever removes a row from Training Instances' tracking —
    it only ever fires after "Delete tenant" (or a bulk delete) already
    succeeded against the real tenant, never before, so a tenant can't be
    forgotten about while it still exists in Airlock. Mutates
    training_cfg in place; returns True if anything changed, so the
    caller knows whether a save is needed."""
    classes = training_cfg.get("classes") or []
    changed = False
    kept_classes = []
    for cls in classes:
        students = cls.get("students") or []
        remaining = [s for s in students if s.get("delete_status") != "deleted"]
        if len(remaining) != len(students):
            changed = True
        cls["students"] = remaining
        if remaining:
            kept_classes.append(cls)
        else:
            changed = True
    if changed:
        training_cfg["classes"] = kept_classes
    return changed


def _prune_deleted_nfr_tenants(nfr_cfg):
    """Same rule as _prune_deleted_training_students, applied to NFR
    Provisioning's flat tenant list instead of Training's nested
    classes/students shape: a tenant only ever leaves tracking after its
    actual deletion in Airlock has already succeeded, never before, so a
    tenant can't go orphaned while this app has lost track of it. Mutates
    nfr_cfg in place; returns True if anything changed."""
    tenants = nfr_cfg.get("tenants") or []
    remaining = [t for t in tenants if t.get("delete_status") != "deleted"]
    changed = len(remaining) != len(tenants)
    if changed:
        nfr_cfg["tenants"] = remaining
    return changed


def migrate_legacy_cloud_config():
    """One-time migration: cloud_admin/cloud_tenants used to live inside
    the main config.json. Move them into their own dedicated file so
    this widget's data is fully isolated from everything else the app
    writes — never touched by, or touching, unrelated saves."""
    config = load_config()
    if "cloud_admin" not in config and "cloud_tenants" not in config:
        return  # nothing to migrate

    cloud_cfg = load_cloud_config()
    if "cloud_admin" in config and not cloud_cfg.get("cloud_admin"):
        cloud_cfg["cloud_admin"] = config["cloud_admin"]
    if "cloud_tenants" in config and not cloud_cfg.get("cloud_tenants"):
        cloud_cfg["cloud_tenants"] = config["cloud_tenants"]
    save_cloud_config(cloud_cfg)

    config.pop("cloud_admin", None)
    config.pop("cloud_tenants", None)
    save_config(config)
    print(f"[startup] Migrated NFR Tracking settings into their own file: {CLOUD_CONFIG_PATH}")


# Guards audit_sessions.json against concurrent access between HTTP
# request handlers and the background revert-scheduler thread.
AUDIT_SESSIONS_LOCK = threading.Lock()


def load_audit_sessions():
    with AUDIT_SESSIONS_LOCK:
        if os.path.exists(AUDIT_SESSIONS_PATH):
            try:
                with open(AUDIT_SESSIONS_PATH, "r") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                return []
        return []


def save_audit_sessions(sessions):
    with AUDIT_SESSIONS_LOCK:
        with open(AUDIT_SESSIONS_PATH, "w") as f:
            json.dump(sessions, f)


def get_scripts_dir():
    configured = load_config().get("api_scripts_dir", "").strip()
    scripts_dir = configured if configured else DEFAULT_API_SCRIPTS_DIR
    os.makedirs(scripts_dir, exist_ok=True)
    return scripts_dir


def get_script_timeout():
    configured = load_config().get("api_script_timeout", "").strip()
    if configured.isdigit() and int(configured) > 0:
        return int(configured)
    return DEFAULT_API_SCRIPT_TIMEOUT


# Default port for the Airlock Digital REST API, per Airlock's own docs.
DEFAULT_AIRLOCK_PORT = 3129


def get_active_airlock_profile(config=None):
    """Returns the currently active saved Airlock connection (a dict
    with id/label/tenant/port/api_key), or None if none is set."""
    config = config if config is not None else load_config()
    profiles = config.get("airlock_profiles") or []
    active_id = config.get("active_airlock_profile_id")
    for p in profiles:
        if p.get("id") == active_id:
            return p
    return None


def migrate_legacy_airlock_profile():
    """One-time migration: older versions of this app stored a single
    flat airlock_tenant/airlock_port/airlock_api_key in config.json.
    If that's all that's there and no connections have been saved yet,
    convert it into the first saved connection so nobody loses their
    existing setup on upgrade."""
    config = load_config()
    if config.get("airlock_profiles"):
        return  # already migrated (or already using the new system)

    tenant = (config.get("airlock_tenant") or "").strip()
    api_key = (config.get("airlock_api_key") or "").strip()
    if not tenant and not api_key:
        return  # nothing to migrate

    profile = {
        "id": str(uuid.uuid4()),
        "label": "Default",
        "tenant": tenant,
        "port": (config.get("airlock_port") or "").strip(),
        "api_key": api_key,
    }
    config["airlock_profiles"] = [profile]
    config["active_airlock_profile_id"] = profile["id"]
    config.pop("airlock_tenant", None)
    config.pop("airlock_api_key", None)
    config.pop("airlock_port", None)
    save_config(config)
    print(f"[startup] Migrated existing Airlock Digital settings into a saved connection: '{profile['label']}'")


def get_airlock_base_url():
    """Returns (base_url, error) based on the active saved connection."""
    profile = get_active_airlock_profile()
    if not profile:
        return None, "No active Airlock Digital connection. Add or select one in Settings."
    tenant = (profile.get("tenant") or "").strip()
    if not tenant:
        return None, "The active Airlock connection has no tenant set."
    port = (profile.get("port") or "").strip() or str(DEFAULT_AIRLOCK_PORT)
    # Allow the tenant field to already include a port (tenant:port) without
    # doubling up, in case someone pastes it in that form.
    host = tenant.split(":")[0]
    return f"https://{host}:{port}", None


def airlock_request(path, payload=None):
    """POSTs to the Airlock Digital REST API and returns (data, error).
    data is the parsed 'response' object on success; error is a plain,
    display-ready message on any failure (config, network, auth, or API-
    level error)."""
    base_url, err = get_airlock_base_url()
    if err:
        return None, err

    profile = get_active_airlock_profile()
    api_key = (profile.get("api_key") or "").strip() if profile else ""
    if not api_key:
        return None, "The active Airlock connection has no API key set."

    try:
        resp = requests.post(
            f"{base_url}{path}",
            json=payload or {},
            headers={"X-ApiKey": api_key, "Content-Type": "application/json"},
            timeout=20,
        )
    except requests.exceptions.SSLError as e:
        return None, f"SSL certificate error connecting to {base_url}: {e}"
    except requests.exceptions.ConnectionError as e:
        return None, f"Couldn't connect to {base_url}: {e}"
    except requests.exceptions.Timeout:
        return None, f"Request to {base_url}{path} timed out."
    except requests.exceptions.RequestException as e:
        return None, f"Request failed: {e}"

    if resp.status_code == 401 or resp.status_code == 403:
        try:
            detail = resp.json()
        except ValueError:
            detail = resp.text.strip()
        # Airlock's own error body usually distinguishes an invalid key
        # from a key that's valid but missing a required REST API role
        # for this endpoint — surface it rather than a generic message.
        return None, f"Airlock Digital rejected the request (status {resp.status_code}): {detail}"

    log.info("Airlock %s -> %s: %s", path, resp.status_code, resp.text[:2000])

    try:
        data = resp.json()
    except ValueError:
        return None, f"Airlock Digital returned a non-JSON response (status {resp.status_code})."

    if not resp.ok:
        return None, f"Airlock Digital API error (status {resp.status_code}): {data}"

    error_field = data.get("error")
    if error_field is not None and str(error_field).strip().lower() != "success":
        return None, f"Airlock Digital API error: {error_field}"

    return data.get("response", {}), None


def airlock_move_agents(dest_groupid, agent_ids):
    """Moves the given agent IDs to dest_groupid. Returns (ok, error)."""
    if not agent_ids:
        return True, None
    _, err = airlock_request("/v1/agent/move", {"groupid": dest_groupid, "agentid": agent_ids})
    return err is None, err


def load_iso_mapping():
    """Loads the editable ISO 27001 <-> Airlock control mapping.
    Returns (mapping_dict, error) — mapping_dict is {} on any failure,
    and error explains specifically why (missing file vs. invalid JSON
    vs. an OS-level read error), rather than a single generic message,
    since those need different fixes."""
    filename = os.path.basename(ISO_MAPPING_PATH)
    if not os.path.exists(ISO_MAPPING_PATH):
        return {}, (
            f"{filename} not found next to app.py. Make sure it was copied into the same "
            "folder as app.py — it doesn't get replaced as often as the other files, so it's "
            "easy to leave behind when updating."
        )
    try:
        with open(ISO_MAPPING_PATH, "r") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        return {}, f"{filename} contains invalid JSON: {e}"
    except OSError as e:
        return {}, f"Couldn't read {filename}: {e}"
    return data, None


# Statuses a rule can evaluate to. "unknown" means the field this rule
# depends on wasn't present in the policy response at all (e.g. an
# older Airlock version, or a typo in a hand-edited iso_mapping.json) —
# deliberately distinct from "unmet" so a report doesn't quietly claim
# a control failed when really the data just wasn't there to check.
STATUS_MEETS = "meets"
STATUS_PARTIAL = "partial"
STATUS_UNMET = "unmet"
STATUS_UNKNOWN = "unknown"
STATUS_ERROR = "error"

# Rank used to combine multiple sub-rule results in all_of/any_of —
# lower is "worse". Used to pick the overall status for a compound rule.
_STATUS_RANK = {STATUS_MEETS: 3, STATUS_PARTIAL: 2, STATUS_UNMET: 1, STATUS_UNKNOWN: 0, STATUS_ERROR: 0}


def evaluate_rule(rule, policy):
    """Evaluates one rule (a dict from iso_mapping.json) against a
    group's raw policy configuration dict (the 'response' object from
    /v1/group/policies). Returns (status, detail) where detail is a
    short human-readable explanation for the report/dashboard."""
    if not isinstance(rule, dict):
        return STATUS_ERROR, "Malformed rule."

    rule_type = rule.get("type")

    if rule_type == "manual":
        return STATUS_UNKNOWN, "Requires manual attestation — not automatically verifiable from policy data."

    if rule_type == "field_equals":
        field = rule.get("field")
        if field not in policy:
            return STATUS_UNKNOWN, f"Field '{field}' not present in policy response."
        value = policy.get(field)
        if value == rule.get("pass_value"):
            return STATUS_MEETS, f"{field} = {value}"
        if "partial_value" in rule and value == rule.get("partial_value"):
            return STATUS_PARTIAL, f"{field} = {value}"
        return STATUS_UNMET, f"{field} = {value}"

    if rule_type == "list_any_match":
        field = rule.get("field")
        if field not in policy:
            return STATUS_UNKNOWN, f"Field '{field}' not present in policy response."
        items = policy.get(field)
        if not isinstance(items, list):
            return STATUS_UNKNOWN, f"Field '{field}' is not a list."
        if not items:
            empty_status = rule.get("empty_status", STATUS_UNMET)
            return empty_status, f"'{field}' is empty."
        item_field = rule.get("item_field")
        match_value = rule.get("match_value")
        min_count = rule.get("min_count", 1)
        matches = sum(1 for it in items if isinstance(it, dict) and it.get(item_field) == match_value)
        if matches >= min_count:
            return STATUS_MEETS, f"{matches} of {len(items)} entr{'y' if len(items)==1 else 'ies'} in '{field}' match."
        return STATUS_PARTIAL, f"{matches} of {len(items)} entr{'y' if len(items)==1 else 'ies'} in '{field}' match (need {min_count})."

    if rule_type in ("all_of", "any_of"):
        sub_rules = rule.get("rules", [])
        if not sub_rules:
            return STATUS_ERROR, "Compound rule has no sub-rules."
        results = [evaluate_rule(r, policy) for r in sub_rules]
        statuses = [s for s, _ in results]
        details = "; ".join(d for _, d in results)
        if rule_type == "all_of":
            overall = min(statuses, key=lambda s: _STATUS_RANK[s])
        else:
            overall = max(statuses, key=lambda s: _STATUS_RANK[s])
        return overall, details

    return STATUS_ERROR, f"Unknown rule type '{rule_type}'."


def evaluate_group_against_mapping(policy, mapping):
    """Evaluates every control in the mapping against one group's raw
    policy configuration. Returns a list of {id, title, name, status,
    detail} dicts."""
    results = []
    for control in mapping.get("controls", []):
        status, detail = evaluate_rule(control.get("rule", {}), policy)
        results.append(
            {
                "id": control.get("id"),
                "title": control.get("title"),
                "name": control.get("name"),
                "theme": control.get("theme"),
                "status": status,
                "detail": detail,
            }
        )
    return results


# --- Custom Widgets: Partner Engagement Report (Cloud multi-tenant API) ---
#
# This talks to a completely different API surface than the rest of the
# app — Airlock Digital's Cloud/MSP management layer, not a single
# on-prem server. Auth uses a "UserApiKey" header (not "X-ApiKey" like
# the on-prem API), plus per-tenant "tenantID" and "Directoryid"
# headers. URLs follow https://<base_domain>/<module>/v1/<endpoint>,
# where the module segment varies by feature area (confirmed via live
# testing: "webfe" for most tenant data, "policy" for the policy list).
#
# Every endpoint/field name below was confirmed against real API
# responses during development — see project history for the captured
# samples this was built from.

CLOUD_MODULE_WEBFE = "webfe"
CLOUD_MODULE_POLICY = "policy"
CLOUD_MODULE_DIRECTORY = "directory"
CLOUD_MODULE_SECURITY = "security"
CLOUD_MODULE_QUEVIDER = "quevider"


def get_cloud_admin_config():
    cfg = load_cloud_config()
    return cfg.get("cloud_admin") or {}


def _cloud_send(url, headers, method, payload, log_label):
    """Shared HTTP + error handling for both Cloud API auth styles below.
    Returns (data, error); data is whatever json.loads gave back — usually
    a dict, but a bare string for the quevider job-status endpoint."""
    try:
        if method == "GET":
            resp = requests.get(url, headers=headers, timeout=20)
        else:
            resp = requests.post(url, json=payload or {}, headers=headers, timeout=20)
    except requests.exceptions.SSLError as e:
        return None, f"SSL certificate error connecting to {url}: {e}"
    except requests.exceptions.ConnectionError as e:
        return None, f"Couldn't connect to {url}: {e}"
    except requests.exceptions.Timeout:
        return None, f"Request to {url} timed out."
    except requests.exceptions.RequestException as e:
        return None, f"Request failed: {e}"

    log.info("Cloud API %s %s (%s) -> %s: %s", method, url, log_label, resp.status_code, resp.text[:1000])

    if resp.status_code in (401, 403):
        try:
            detail = resp.json()
        except ValueError:
            detail = resp.text.strip()
        return None, f"Cloud API rejected the request (status {resp.status_code}): {detail}"

    if resp.status_code == 405:
        return None, f"Cloud API rejected the HTTP method for this endpoint (405 Method Not Allowed) — tried {method}."

    try:
        data = resp.json()
    except ValueError:
        return None, f"Cloud API returned a non-JSON response (status {resp.status_code}): {resp.text[:300]}"

    if not resp.ok:
        return None, f"Cloud API error (status {resp.status_code}): {data}"

    return data, None


def cloud_api_request(module, endpoint, method="GET", payload=None, tenant_id="", directory_id=""):
    """Calls the Cloud multi-tenant API using the per-tenant read/write auth
    style ("UserApiKey" + tenantID/Directoryid headers) that NFR Tracking
    uses. Returns (data, error)."""
    cfg = get_cloud_admin_config()
    base_domain = (cfg.get("base_domain") or "").strip()
    api_key = (cfg.get("api_key") or "").strip()

    if not base_domain:
        return None, "No Cloud base domain configured. Add one in the Partner Engagement Report widget."
    if not api_key:
        return None, "No Cloud admin API key configured. Add one in the Partner Engagement Report widget."

    url = f"https://{base_domain}/{module}/v1/{endpoint}"
    headers = {
        "Content-Type": "application/json",
        "UserApiKey": api_key,
        "tenantID": tenant_id,
        "Directoryid": directory_id,
    }
    return _cloud_send(url, headers, method, payload, f"tenant={tenant_id}")


def cloud_tenant_api_request(module, endpoint, method="GET", payload=None, directory_id=""):
    """Calls the Cloud multi-tenant API's tenant-lifecycle auth style —
    "X-ApiKey" + "DirectoryID" headers, no per-tenant tenantID — confirmed
    from Ryan's Airlock_Training_Tenant_Automation_v1 bash toolkit, which
    already creates real tenants this way against AU/AM production. This
    is a genuinely different header shape than cloud_api_request above,
    not a typo; do not "fix" it to match. Reuses the same stored Cloud
    admin API key and base_domain; only the header names and the meaning
    of directory_id (a parent/MSP-level directory here, not any individual
    tenant's own directory_id) differ. Returns (data, error)."""
    cfg = get_cloud_admin_config()
    base_domain = (cfg.get("base_domain") or "").strip()
    api_key = (cfg.get("api_key") or "").strip()

    if not base_domain:
        return None, "No Cloud base domain configured. Add one in the Partner Engagement Report widget."
    if not api_key:
        return None, "No Cloud admin API key configured. Add one in the Partner Engagement Report widget."

    url = f"https://{base_domain}/{module}/v1/{endpoint}"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-ApiKey": api_key,
        "DirectoryID": directory_id,
    }
    return _cloud_send(url, headers, method, payload, f"directory={directory_id}")


def cloud_get_tenant_users(tenant_id, directory_id):
    data, err = cloud_api_request(CLOUD_MODULE_WEBFE, "tenant-user-list", tenant_id=tenant_id, directory_id=directory_id)
    if err:
        return None, err
    users = (((data or {}).get("TenantUserList") or {}).get("TenantUserList")) or []
    result = []
    for u in users:
        if not isinstance(u, dict):
            continue
        result.append(
            {
                "full_name": u.get("FullName") or f"{u.get('FirstName', '')} {u.get('LastName', '')}".strip(),
                "email": u.get("Email", ""),
                "last_accessed": u.get("LastAccessedDate", ""),
            }
        )
    return result, None


def cloud_get_managed_count(tenant_id, directory_id):
    # Confirmed via live testing: this one needs POST (with an empty
    # body), unlike tenant-user-list which needs GET — no consistent
    # rule across endpoints, so this has to be tracked per-endpoint.
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE,
        "tenant-policy-managed-count-list",
        method="POST",
        payload={},
        tenant_id=tenant_id,
        directory_id=directory_id,
    )
    if err:
        return None, err
    tcc = (((data or {}).get("TenantPolicyManagedCountList") or {}).get("TenantClientCount")) or {}
    return {"client_count": tcc.get("ClientCount", 0), "unmanaged_count": tcc.get("UnmanagedCount", 0)}, None


def cloud_get_policies(tenant_id, directory_id):
    data, err = cloud_api_request(
        CLOUD_MODULE_POLICY, "policy?limit=10000", tenant_id=tenant_id, directory_id=directory_id
    )
    if err:
        return None, err
    policies = data.get("data") if isinstance(data, dict) else None
    policies = policies or []
    result = []
    for p in policies:
        if not isinstance(p, dict):
            continue
        result.append(
            {
                "id": p.get("policyid") or p.get("id"),
                "name": p.get("name", ""),
                "auditmode": str(p.get("auditmode", "")),  # "0" = enforce, "1" = audit
            }
        )
    return result, None


def cloud_get_policy_client_count(tenant_id, directory_id, policy_id, policy_name):
    payload = {"TenantPolicyGroupList": [{"ID": policy_id, "Name": policy_name}], "atcp": None}
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE,
        "tenant-policy-clients-in-scope-list",
        method="POST",
        payload=payload,
        tenant_id=tenant_id,
        directory_id=directory_id,
    )
    if err:
        return None, err
    selected = (data or {}).get("TenantClientSelectedList") or []
    if selected and isinstance(selected[0], dict):
        return selected[0].get("InScope", 0), None
    return 0, None


def cloud_get_license_allocation(tenant_id, directory_id):
    payload = {"DirectoryLicenceAllocationList": {"DirectoryID": directory_id}, "atcp": None}
    data, err = cloud_api_request(
        CLOUD_MODULE_DIRECTORY,
        "directory-licence-allocation-list",
        method="POST",
        payload=payload,
        tenant_id=tenant_id,
        directory_id=directory_id,
    )
    if err:
        return None, err
    dlal = (data or {}).get("DirectoryLicenceAllocationList") or {}
    return dlal.get("DirectoryLicenceAllocated", 0), None


def cloud_get_directory_licence_capacity(directory_id):
    """Total licence capacity for a directory (the pool its own and its
    child directories'/tenants' allocations are drawn from) — confirmed via
    a real capture of the console's directory Settings page, NOT the
    directory-update save call: that one requires echoing the *entire*
    Directory object back (including its invite-email HTML templates and
    licence dates) just to read one field, which is a real-data-corruption
    risk for a simple read. `directory-search` is the genuinely read-only
    equivalent the page itself calls on load, alongside
    directory-licence-allocation-list, with no "successfully updated" side
    effect."""
    payload = {"DirectorySearch": {"DirectoryID": directory_id}, "atcp": None}
    data, err = cloud_api_request(
        CLOUD_MODULE_DIRECTORY,
        "directory-search",
        method="POST",
        payload=payload,
        tenant_id="",
        directory_id=directory_id,
    )
    if err:
        return None, err
    directories = ((data or {}).get("DirectorySearch") or {}).get("DirectoryList") or []
    if not directories or not isinstance(directories[0], dict):
        return None, "Directory not found in directory-search response."
    return directories[0].get("LicenceCapacity", 0), None


def cloud_collect_tenant_data(tenant_entry):
    """Pulls all four data points for one saved partner tenant. Never
    raises, and each data point is independent — a failure in one
    (e.g. license data) is recorded on its own error field rather than
    blanking out the whole tenant, since the four calls have nothing to
    do with each other."""
    tenant_id = tenant_entry.get("tenant_id", "")
    directory_id = tenant_entry.get("directory_id", "")
    label = tenant_entry.get("label", "")

    result = {
        "label": label,
        "tenant_id": tenant_id,
        "directory_id": directory_id,
        "users": [],
        "users_error": None,
        "client_count": 0,
        "unmanaged_count": 0,
        "agents_error": None,
        "audit_count": 0,
        "enforce_count": 0,
        "policy_errors": [],
        "license_allocated": None,
        "license_error": None,
    }

    users, err = cloud_get_tenant_users(tenant_id, directory_id)
    if err:
        result["users_error"] = err
    else:
        result["users"] = users

    counts, err = cloud_get_managed_count(tenant_id, directory_id)
    if err:
        result["agents_error"] = err
    else:
        result["client_count"] = counts["client_count"]
        result["unmanaged_count"] = counts["unmanaged_count"]

    policies, err = cloud_get_policies(tenant_id, directory_id)
    if err:
        result["policy_errors"].append(f"Couldn't load the policy list: {err}")
    else:
        audit_total = 0
        enforce_total = 0
        for p in policies:
            in_scope, perr = cloud_get_policy_client_count(tenant_id, directory_id, p["id"], p["name"])
            if perr:
                result["policy_errors"].append(f"{p['name']}: {perr}")
                continue
            if p["auditmode"] == "0":
                enforce_total += in_scope or 0
            else:
                audit_total += in_scope or 0
        result["audit_count"] = audit_total
        result["enforce_count"] = enforce_total

    license_allocated, err = cloud_get_license_allocation(tenant_id, directory_id)
    if err:
        result["license_error"] = err
    else:
        result["license_allocated"] = license_allocated

    return result


def run_cloud_partner_report(tenant_ids=None):
    cloud_cfg = load_cloud_config()
    tenants = cloud_cfg.get("cloud_tenants") or []
    if tenant_ids is not None:
        tenants = [t for t in tenants if t.get("id") in tenant_ids]
    if not tenants:
        return None, "No partner tenants selected. Choose at least one and try again."

    results = [cloud_collect_tenant_data(t) for t in tenants]
    return {"tenants": results, "generated_at": datetime.now().isoformat()}, None


# --- Custom Widgets: Training Instances (Cloud multi-tenant API) ---
#
# Phase 2 (2026-09): replaced the original design — pre-provisioning a
# fixed set of instances by hand and assigning one admin user onto each
# (see git history for that "Phase 1" code) — with creating a brand-new
# Airlock tenant per student on demand, then tearing it down again once
# the class is over. Ported from a working, standalone bash toolkit Ryan
# already runs against real Airlock AU/AM production
# (Airlock_Training_Tenant_Automation_v1: create_tenant.sh,
# poll_tenant_creation.sh, deploy_training_tenants.sh) — every
# endpoint/field/header name below matches those scripts, not a guess.
#
# This uses a DIFFERENT auth style than the rest of the Cloud API code
# above: "X-ApiKey" + "DirectoryID" headers (cloud_tenant_api_request),
# not "UserApiKey" + tenantID/Directoryid (cloud_api_request). The API
# key still needs TenantCreate/Titan/Rapid Admin authorization on the
# target directory — a plain per-tenant admin key is not enough. The
# directory_id here is the *parent* directory new tenants are created
# under (Ryan's confirmed value, stored as "creation_directory_id" in
# training_config.json) — NOT any individual tenant's own directory_id
# from cloud_config.json.
#
#   POST directory/v1/tenant-create-schedule
#     body {"TenantCreate": {"Tenant": {"Name","LicenceAllocation",
#           "Description"?,"AutoExpiry"? (RFC3339),...}, "Users": [
#           {"Email","FullName","FirstName","LastName"}]}}
#     -> {"TenantCreate": {"JobID","TenantID"}} — HTTP 200 means queued,
#        not that provisioning is complete.
#
#   GET  quevider/v1/job/{JobID}/status  -> bare JSON string status.
#     Terminal success: COMPLETED. Terminal failure: DEAD, CANCELLED,
#     PARTIAL. Retryable (keep polling): WAITING, PENDING, PROCESSING,
#     FAILED.
#
# Phase 3 (2026-09-18): added tenant deletion, confirmed via a real
# browser Network capture of deleting a test tenant in the Cloud console
# (the shipped scripts never included this call — it was genuinely
# uncaptured API surface until now):
#
#   POST directory/v1/tenant-delete
#     body {"TenantList": [{"ID": <tenant id>, "DirectoryID": <directory id>}], "atcp": None}
#     -> {"Atro": {..., "Status": 200, "ErrorOccured": false}, "TenantList": [...]}
#
# Same module ("directory") and same X-ApiKey/DirectoryID auth as tenant
# creation, so it reuses cloud_tenant_api_request(). Unlike creation,
# there's no JobID/polling step in the response — Atro.ErrorOccured ==
# false means the delete already happened. The payload technically
# accepts an array (TenantList), but NFR Tracking's own history includes
# a sibling batch-shaped Cloud API endpoint that returned a real 500 with
# more than one item despite accepting an array (see "Cloud API
# reverse-engineering" in PROJECT_SUMMARY.md) — so this always sends
# exactly one tenant per call rather than trusting multi-item support
# that's never actually been tested.

TRAINING_AUTO_EXPIRY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$")

TRAINING_TERMINAL_SUCCESS = "COMPLETED"
TRAINING_TERMINAL_FAILURE = ("DEAD", "CANCELLED", "PARTIAL")
TRAINING_RETRYABLE = ("WAITING", "PENDING", "PROCESSING", "FAILED")

# Only a tenant that actually exists (creation reached a terminal state,
# whether success or failure) is eligible for deletion — "pending"/
# "polling" have no stable tenant yet, and "create_failed" never got one.
TRAINING_DELETABLE_STATUSES = ("completed",) + TRAINING_TERMINAL_FAILURE

# Guards training_config.json against concurrent access between HTTP
# request handlers and the background job-poller thread below.
TRAINING_LOCK = threading.Lock()

# The reference baseline added to every new training tenant as part of
# provisioning ("Add Baseline from Reference" in the console). Airlock
# publishes a new monthly-patch baseline periodically, so this is only a
# fallback default — it's editable under Tenant creation settings and
# stored in training_config.json as "baseline_full_name". Must match a
# "FullName" value from a live tenant-baseline-reference-list call
# exactly (case-sensitive) or the lookup will report it not found.
DEFAULT_TRAINING_BASELINE_FULL_NAME = "Windows 11-25H2-x64-April 2026.tar.gz"

# The policy group the added baseline is assigned to, right after it's
# added. Confirmed via a real capture that Airlock auto-provisions a
# "Workstations" policy group (plus "Workstations Audit"/"Workstations
# Enforced" children) for every newly created tenant, so this default
# works out of the box — but it's editable in case a tenant's policy
# groups are ever renamed.
DEFAULT_TRAINING_POLICY_GROUP_NAME = "Workstations"

# The Parent value Airlock's console sends for top-level policy groups —
# confirmed constant across every real capture involving one, not tenant-
# or policy-specific.
POLICY_GLOBAL_SETTINGS_PARENT = "global-policy-settings"


def get_training_creation_settings():
    cfg = load_training_config()
    return {
        "directory_id": (cfg.get("creation_directory_id") or "").strip(),
        "default_licence_allocation": cfg.get("default_licence_allocation") or 25,
        "baseline_full_name": (cfg.get("baseline_full_name") or "").strip() or DEFAULT_TRAINING_BASELINE_FULL_NAME,
        "policy_group_name": (cfg.get("policy_group_name") or "").strip() or DEFAULT_TRAINING_POLICY_GROUP_NAME,
        # No built-in default for these two — unlike the baseline/policy
        # names above, there's no sensible generic fallback for "whose
        # account should be added to every new tenant". Blank just means
        # the automatic instructor-access step is skipped for now; see
        # cloud_provision_instructor_access.
        "instructor_full_name": (cfg.get("instructor_full_name") or "").strip(),
        "instructor_email": (cfg.get("instructor_email") or "").strip(),
        # Blank = leave each tenant's default blocked-file message alone
        # (the notification step is "skipped"). See Phase 8 below.
        "block_notification_message": (cfg.get("block_notification_message") or "").strip(),
    }


# Guards nfr_provisioning_config.json against concurrent access between
# HTTP request handlers and the background job-poller thread — same
# convention as TRAINING_LOCK, kept separate since the two widgets' data
# is independent (a slow NFR request shouldn't block a Training one).
NFR_PROVISION_LOCK = threading.Lock()


def get_nfr_provisioning_settings():
    """NFR Provisioning has its own directory_id and its own default
    license allocation (it's a different directory than Training's, and
    Ryan sets a licence count per NFR tenant rather than relying on one
    shared default) — but, by Ryan's own choice, it does NOT have its own
    baseline_full_name/policy_group_name: those are read live from
    Provision Training Instances' settings instead, so there's exactly
    one place to keep the "what baseline goes on a new tenant" answer up
    to date, matching how both widgets already share one Cloud admin key."""
    cfg = load_nfr_provisioning_config()
    training_settings = get_training_creation_settings()
    return {
        "directory_id": (cfg.get("directory_id") or "").strip(),
        "default_licence_allocation": cfg.get("default_licence_allocation") or 25,
        "baseline_full_name": training_settings["baseline_full_name"],
        "policy_group_name": training_settings["policy_group_name"],
        # Also shared with Training, and for the exact same reason Training
        # needs it: baseline-add/policy-assign are authenticated as the
        # Cloud admin key's OWN account, and that account has no tenant-
        # level role on a brand-new tenant until it's explicitly added to
        # it — see cloud_provision_instructor_access's docstring. Listing
        # people as NFR administrators at creation does NOT cover this;
        # those are the invited end users, not necessarily this account.
        "instructor_full_name": training_settings["instructor_full_name"],
        "instructor_email": training_settings["instructor_email"],
    }


def split_full_name(full_name):
    """Splits 'Jane Q. Doe' into ('Jane Q.', 'Doe') the same way the
    Airlock console's own Add User form does — first word(s) vs. last
    word. A single-word name has no last name, matching what the API
    accepted in testing (LastName can be blank)."""
    parts = full_name.strip().split()
    if not parts:
        return "", ""
    if len(parts) == 1:
        return parts[0], ""
    return " ".join(parts[:-1]), parts[-1]


# Phase 7 (2026-09-20): NFR Provisioning's real workflow turned out to be
# "make a sub-directory named after the tenant first, then create the
# tenant under it" — not create every NFR tenant flat under one shared
# directory. Confirmed via a real browser Network capture of Ryan's own
# Cloud console session creating a sub-directory:
#
#   POST directory/v1/directory-create
#     body {"DirectoryCreate": {
#       "Directory": {"Name","LicenceCapacity","DirectoryAdministratorUserName",
#         "DirectoryAdministratorEmail","UserDirectoryGroup","ParentDirectoryID",
#         "AutoExpiry"?,"LicenceDatesEnabled"?,"LicenceStartDatetime"?,"LicenceEndDatetime"?},
#       "User": {"FullName","Email","FirstName","LastName"},
#       "DirectoryGroup": {"ID"}}}
#
# A second capture (also 2026-09-20) confirmed a successful response:
# {"DirectoryCreate": {"Directory": {"ID": "<new directory id>", ...},
# "User": {...}}} — the new directory's ID lives at
# DirectoryCreate.Directory.ID, same place cloud_create_tenant's TenantID
# lives one level down. Interestingly, that response's Directory object
# doesn't echo back "AutoExpiry" at all (LicenceCapacity/LicenceDatesEnabled/
# LicenceStartDatetime/LicenceEndDatetime all come back, AutoExpiry
# doesn't) — sent as-is below anyway since it WAS part of the real
# outgoing request; not treated as an error that the response omits it.
#
# The one thing about that capture that's still NOT the same as every
# other confirmed Cloud API call in this file: auth. The browser sent
# "Authorization: Bearer <JWT>" — the console's own interactive Auth0
# session token (expires ~24h, tied to whoever's logged in) — not either
# of this app's two stored-API-key auth styles, and this app has no way to
# obtain or hold a credential like that. Below reuses the X-ApiKey/
# DirectoryID style already confirmed to work for this SAME "directory"
# module's other two lifecycle calls (tenant-create-schedule,
# tenant-delete), since that's the closest real evidence available — but
# this specific endpoint accepting the stored API key is still a bet, not
# a confirmed fact, until it's actually been tried with it.
#
# UserDirectoryGroup / DirectoryGroup.ID ("5f0536603377abf6ddc948c7") is
# hardcoded from that one real capture, the same way
# TRAINING_INSTRUCTOR_USER_GROUP_NAME's UUID was noted as a likely stable
# platform-wide default — there's no "list directory groups by name"
# endpoint anywhere in this app to look it up dynamically instead.
NFR_DIRECTORY_ADMIN_GROUP_ID = "5f0536603377abf6ddc948c7"


def cloud_create_directory(parent_directory_id, name, licence_capacity, admin_full_name, admin_email, auto_expiry_date=None):
    """Creates one sub-directory under parent_directory_id. admin_full_name/
    admin_email become its Directory Administrator — required, since the
    real capture always sent a User alongside the Directory in the same
    call; there's no evidence a directory can be created without one.
    auto_expiry_date, if given, is a plain "YYYY-MM-DD" string (matching
    an HTML date input) — the real capture paired a bare-date AutoExpiry
    with full RFC3339 start/end datetimes, start always "today" at
    midnight UTC. Returns (new_directory_id, None) or (None, error)."""
    first_name, last_name = split_full_name(admin_full_name or admin_email.split("@")[0])

    directory = {
        "Name": name,
        "LicenceCapacity": licence_capacity,
        "DirectoryAdministratorUserName": admin_full_name or admin_email,
        "DirectoryAdministratorEmail": admin_email,
        "UserDirectoryGroup": NFR_DIRECTORY_ADMIN_GROUP_ID,
        "ParentDirectoryID": parent_directory_id,
    }
    if auto_expiry_date:
        directory["AutoExpiry"] = auto_expiry_date
        directory["LicenceDatesEnabled"] = True
        directory["LicenceStartDatetime"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT00:00:00.000Z")
        directory["LicenceEndDatetime"] = f"{auto_expiry_date}T00:00:00.000Z"

    payload = {
        "DirectoryCreate": {
            "Directory": directory,
            "User": {
                "FullName": admin_full_name or admin_email,
                "Email": admin_email,
                "FirstName": first_name,
                "LastName": last_name,
            },
            "DirectoryGroup": {"ID": NFR_DIRECTORY_ADMIN_GROUP_ID},
        }
    }
    data, err = cloud_tenant_api_request(
        CLOUD_MODULE_DIRECTORY, "directory-create", method="POST", payload=payload, directory_id=parent_directory_id
    )
    if err:
        return None, err
    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return None, f"Cloud API reported an error creating the directory: {data}"

    # Confirmed via a real capture of a successful response — see the
    # Phase 7 comment above.
    new_directory_id = (((data or {}).get("DirectoryCreate") or {}).get("Directory") or {}).get("ID")
    if not new_directory_id:
        return None, f"Directory created, but its new Directory ID wasn't found in the response — response shape may have changed: {data}"
    return new_directory_id, None


# Confirmed via a real capture (request AND a full response this time, no
# guessing needed) of the Cloud console's own "choose a parent folder"
# picker:
#
#   POST directory/v1/directory-list
#     body {"Uncategorised": {"RapidSecurityProfileRefresh": false, "DirectoryCacheRefresh": false}, "atcp": null}
#     -> {"DirectoryList": {"DirectoryList": [{"ID","ParentDirectoryID","Name",
#          "LicenceCapacity","IsDeleted",...}, ...]}}
#
# Returns every directory the authenticated identity can see — not scoped
# by any DirectoryID header value (Ryan's own capture returned 73
# directories spanning several unrelated parent orgs, not just the NFR
# one) — flat, with ParentDirectoryID chaining each one to its parent (one
# root, "Airlock Digital", has ParentDirectoryID "000...000"). Auth
# headers weren't part of this capture; reuses the X-ApiKey/DirectoryID
# style now confirmed working for directory-create, same "directory"
# module, same account.
def cloud_list_directories(directory_id):
    data, err = cloud_tenant_api_request(
        CLOUD_MODULE_DIRECTORY, "directory-list", method="POST",
        payload={"Uncategorised": {"RapidSecurityProfileRefresh": False, "DirectoryCacheRefresh": False}, "atcp": None},
        directory_id=directory_id,
    )
    if err:
        return None, err
    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return None, f"Cloud API reported an error listing directories: {data}"
    directories = ((data or {}).get("DirectoryList") or {}).get("DirectoryList")
    if not isinstance(directories, list):
        return None, f"Directory list response missing DirectoryList.DirectoryList — response shape may have changed: {data}"
    return [d for d in directories if isinstance(d, dict) and not d.get("IsDeleted")], None


def _build_directory_paths(directories):
    """Turns the flat directory-list result into {id: "Root / Child / …"}
    breadcrumb strings, so two same-named folders under different parents
    (there's no guarantee names are unique — 73 real folders had no
    duplicates, but nothing enforces that) are still told apart in a
    dropdown. Tolerant of a broken or cyclic ParentDirectoryID chain (walks
    at most as many steps as there are directories, then gives up on that
    one entry rather than looping forever)."""
    by_id = {d["ID"]: d for d in directories if d.get("ID")}
    paths = {}

    def path_for(directory_id):
        if directory_id in paths:
            return paths[directory_id]
        chain = []
        seen = set()
        current = directory_id
        while current and current in by_id and current not in seen and len(seen) <= len(by_id):
            seen.add(current)
            chain.append(by_id[current].get("Name") or "(unnamed)")
            current = by_id[current].get("ParentDirectoryID")
        chain.reverse()
        result = " / ".join(chain) if chain else "(unknown)"
        paths[directory_id] = result
        return result

    for d in directories:
        if d.get("ID"):
            path_for(d["ID"])
    return paths


def cloud_create_tenant(directory_id, tenant_name, licence_allocation, administrators, description=None, auto_expiry=None):
    """Queues one tenant-creation job. administrators is a list of
    {"email","full_name"} dicts — every one is placed in the new tenant's
    Local Administrator group and gets a real invite email from Airlock.
    Returns ({"job_id","tenant_id"}, None) or (None, error)."""
    users = []
    for admin in administrators:
        email = (admin.get("email") or "").strip()
        full_name = (admin.get("full_name") or "").strip()
        first_name, last_name = split_full_name(full_name or email.split("@")[0])
        users.append({"Email": email, "FullName": full_name or email, "FirstName": first_name, "LastName": last_name})

    tenant = {"Name": tenant_name, "LicenceAllocation": licence_allocation}
    if description:
        tenant["Description"] = description
    if auto_expiry:
        tenant["AutoExpiry"] = auto_expiry

    payload = {"TenantCreate": {"Tenant": tenant, "Users": users}}
    data, err = cloud_tenant_api_request(
        CLOUD_MODULE_DIRECTORY, "tenant-create-schedule", method="POST", payload=payload, directory_id=directory_id
    )
    if err:
        return None, err

    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return None, f"Cloud API reported an error scheduling tenant creation: {data}"

    tenant_create = (data or {}).get("TenantCreate") or {}
    job_id = tenant_create.get("JobID")
    tenant_id = tenant_create.get("TenantID")
    if not job_id or not tenant_id:
        return None, f"Tenant creation response missing JobID/TenantID — response shape may have changed: {data}"

    return {"job_id": job_id, "tenant_id": tenant_id}, None


def cloud_poll_tenant_job(directory_id, job_id):
    """Checks one tenant-creation job's status. Returns (status, None) with
    status uppercased (e.g. "COMPLETED"), or (None, error) on a transport
    or shape problem — treated by the caller as a transient polling error,
    never as job failure."""
    data, err = cloud_tenant_api_request(CLOUD_MODULE_QUEVIDER, f"job/{job_id}/status", method="GET", directory_id=directory_id)
    if err:
        return None, err
    if not isinstance(data, str) or not data.strip():
        return None, f"Job status endpoint returned an unexpected response: {data}"
    return data.strip().upper(), None


def cloud_delete_tenant(directory_id, tenant_id):
    """Deletes one tenant. Synchronous — no JobID/polling step like
    creation has; Atro.ErrorOccured == false means it already happened.
    Returns (True, None) or (False, error)."""
    payload = {"TenantList": [{"ID": tenant_id, "DirectoryID": directory_id}], "atcp": None}
    data, err = cloud_tenant_api_request(CLOUD_MODULE_DIRECTORY, "tenant-delete", method="POST", payload=payload, directory_id=directory_id)
    if err:
        return False, err
    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return False, f"Cloud API reported an error deleting the tenant: {data}"
    return True, None


# Phase 6 (2026-09-19): closes a gap discovered via a real-world test —
# the fully-automatic baseline/policy chain below 403'd on every brand-new
# tenant (view_baselines/view_policies "Tenant Role(s) NOT Found"), because
# Airlock only grants the calling account those tenant-level roles the
# first time someone personally opens that tenant in the console. Ryan
# confirmed this by capturing exactly what the console does on that first
# visit: it shows an "Add Yourself to This Tenant" modal ("You don't have
# access to this tenant. To get access, add yourself...") and clicking
# "Add Me to Tenant" fires webfe/v1/tenant-user-create. The captured
# response's AccessLog is what makes this safe to automate: every
# TenantRoleCheckMessage says "NOT Found", but AccessGranted is still true
# because "Directory Role(s) Found, Inherited: true" — this endpoint
# accepts EITHER a tenant-level role OR an inherited directory-level one,
# which is exactly why it can run on a tenant nobody has ever opened, using
# whichever account's UserApiKey is configured (that account just needs
# adequate directory-level admin roles already — the same account this app
# already authenticates as for every other Cloud API call).
#
# The "Local User Group" dropdown in that modal is tenant-scoped — its
# real source is webfe/v1/tenant-user-group-list (confirmed via a real
# capture), NOT security/v1/directory-group-list, which was tried first
# and confirmed wrong: that one returns the calling user's own DIRECTORY-
# wide admin role groups (TenantAdmin/ReadOnly/BillingAdmin/etc.) with
# completely different IDs, and has no "LocalAdmin" entry at all.
TRAINING_INSTRUCTOR_USER_GROUP_NAME = "LocalAdmin"


def cloud_list_tenant_user_groups(tenant_id, directory_id):
    """Lists the user groups available on one tenant — confirmed via a
    real capture to be a GET with no body. Each entry's "ID" is a UUID
    matching what tenant-user-create's UserGroups array needs; a real
    capture showed the SAME UUID for "LocalAdmin" on two different
    tenants, suggesting it's a stable, platform-wide default, but this
    always looks it up by name per tenant rather than hardcoding that
    UUID — matching the project's established look-up-by-name pattern
    (baselines by FullName, policies by name). Returns
    (list_of_group_dicts, None) or (None, error)."""
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-user-group-list", method="GET", tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return None, err
    if not isinstance(data, dict):
        return None, f"Tenant user group list endpoint returned an unexpected response: {data}"
    if data.get("Atro", {}).get("ErrorOccured"):
        return None, f"Cloud API reported an error listing the tenant's user groups: {data}"
    groups = data.get("TenantUserGroupList")
    if not isinstance(groups, list):
        return None, f"Tenant user group list response missing TenantUserGroupList — response shape may have changed: {data}"
    return groups, None


def cloud_find_user_group_by_name(groups, name):
    """Finds one entry in a tenant-user-group-list result by exact "Name"
    match, e.g. "LocalAdmin". Returns the matching dict or None."""
    for entry in groups:
        if isinstance(entry, dict) and entry.get("Name") == name:
            return entry
    return None


def cloud_add_user_to_tenant(tenant_id, directory_id, full_name, email):
    """Adds one user to a tenant's Local Admin group — the exact same
    call ("tenant-user-create") Airlock's own console fires when an admin
    clicks "Add Me to Tenant" in the "Add Yourself to This Tenant" modal,
    confirmed via a real request+response capture (the response's
    AccessLog is what proved this only needs inherited directory-level
    roles, not pre-existing tenant ones — see the Phase 6 comment above).
    Looks up the "LocalAdmin" group's ID fresh each call rather than
    hardcoding the UUID from that capture. Returns (True, None) or
    (False, error)."""
    groups, err = cloud_list_tenant_user_groups(tenant_id, directory_id)
    if err:
        return False, err
    group = cloud_find_user_group_by_name(groups, TRAINING_INSTRUCTOR_USER_GROUP_NAME)
    if not group:
        return False, (
            f"User group '{TRAINING_INSTRUCTOR_USER_GROUP_NAME}' was not found on this tenant — "
            "Airlock's default user group naming may have changed."
        )
    first_name, last_name = split_full_name(full_name or email.split("@")[0])
    payload = {
        "TenantUserCreate": {
            "TenantUser": {
                "FullName": full_name or email,
                "Email": email,
                "UserGroups": [group["ID"]],
                "FirstName": first_name,
                "LastName": last_name,
            }
        }
    }
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-user-create", method="POST", payload=payload,
        tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return False, err
    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return False, f"Cloud API reported an error adding the instructor user: {data}"
    return True, None


def cloud_provision_instructor_access(tenant_id, directory_id, instructor_full_name, instructor_email):
    """Orchestrates granting the configured instructor account access to a
    newly-created tenant — the automated equivalent of Airlock's "Add
    Yourself to This Tenant" flow. Run as the very first provisioning step
    (before baseline-add and policy-assign) so the account making those
    later calls already has the tenant-level roles it needs, instead of
    relying on someone having opened the tenant in the console by hand
    first. Kept as one function so both the automatic post-creation
    trigger and the manual retry route share identical behavior. Returns
    (True, None) or (False, error)."""
    return cloud_add_user_to_tenant(tenant_id, directory_id, instructor_full_name, instructor_email)


def cloud_list_reference_baselines(tenant_id, directory_id):
    """Lists every reference/template baseline Airlock's console offers
    under "Add Baseline from Reference" — NOT filtered per-tenant or per
    OS; the API always returns its full ~180-entry catalog regardless of
    what's asked. Uses the same UserApiKey/tenantID/Directoryid auth style
    as NFR Tracking (confirmed via the AccessLog shape in a real capture —
    both TenantID and DirectoryID appear in the authorization context,
    unlike the tenant-lifecycle calls' X-ApiKey style). Returns
    (list_of_baseline_dicts, None) or (None, error)."""
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-baseline-reference-list", method="POST", payload={"atcp": None},
        tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return None, err
    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return None, f"Cloud API reported an error listing reference baselines: {data}"
    baselines = (data or {}).get("TenantReferenceBaselineList")
    if not isinstance(baselines, list):
        return None, f"Reference baseline list response missing TenantReferenceBaselineList — response shape may have changed: {data}"
    return baselines, None


def cloud_find_reference_baseline(baselines, full_name):
    """Finds one entry in a tenant-baseline-reference-list result by exact
    (case-sensitive) FullName match, e.g. 'Windows 11-25H2-x64-April
    2026.tar.gz'. Returns the matching dict or None."""
    for entry in baselines:
        if isinstance(entry, dict) and entry.get("FullName") == full_name:
            return entry
    return None


def _parse_baseline_patch_level(patch_level):
    """Parses a reference baseline's "PatchLevel" field (confirmed real
    examples: "April 2026", "February 2025") into a sortable (year, month)
    tuple. Returns None if it doesn't match that "Month YYYY" shape —
    confirmed via real captures to be how Windows/macOS entries work, but
    every Linux distro entry captured so far uses "RTM" or "Patched"
    instead (no real date at all), so this stays tolerant rather than
    assuming every catalog entry has a date to sort by."""
    if not patch_level or not isinstance(patch_level, str):
        return None
    for fmt in ("%B %Y", "%b %Y"):
        try:
            dt = datetime.strptime(patch_level.strip(), fmt)
            return (dt.year, dt.month)
        except ValueError:
            continue
    return None


# First attempt at this picker (see git history / PROJECT_SUMMARY.md) just
# grouped by "OperatingSystem" and picked the newest PatchLevel per group —
# fine for Windows (OperatingSystem stays "Windows 11" across every minor
# build, which lives in ServicePack instead) but wrong for Linux, where a
# real capture showed each distro's OWN minor version is its own
# OperatingSystem value (e.g. "CentOS 7.0.1406" and "CentOS 7.1.1503" are
# separate entries, not one "CentOS" with varying ServicePack) — so nothing
# collapsed and the picker listed 70+ buttons. This regex pulls just the
# leading distro name off a Linux OperatingSystem string for a coarser
# "family" grouping instead (confirmed real examples: AlmaLinux, CentOS,
# RHEL, Rocky, Ubuntu — all a single word before the version number).
_LINUX_DISTRO_NAME_RE = re.compile(r"^([A-Za-z]+)")

# Architecture spellings confirmed real across different catalog entries
# for the "same" 64-bit x86 architecture — Windows uses "x64", RHEL/CentOS
# use "x86_64", Rocky/AlmaLinux use "x86_x64". Treated as equivalent only
# for picking a recommended default; the exact original string is always
# what's sent to Airlock (via FullName), never normalized.
_X64_ARCHITECTURE_SPELLINGS = {"x64", "x86_64", "x86_x64"}


def _baseline_family(entry):
    """Buckets one reference-baseline catalog entry into a coarse
    "family" for the two-level Settings picker (pick a family, then pick
    a specific baseline within it) — based on real confirmed catalog data
    across Windows, Windows Server, macOS, and five Linux distros.
    Windows client and Windows Server are split into two families even
    though both share OSType "Windows", since they're different product
    lines a trainer would deliberately choose between; macOS is kept as
    one family since its release names (Big Sur, Catalina, ... Tahoe) are
    already a short, readable list; each Linux distro is its own family
    (see _LINUX_DISTRO_NAME_RE) since lumping every distro under one
    "Linux" family would be exactly the "too many to browse" problem this
    picker exists to avoid."""
    os_type = (entry.get("OSType") or "").strip()
    operating_system = (entry.get("OperatingSystem") or "").strip()
    if os_type == "MacOS":
        return "macOS"
    if os_type == "Windows":
        return "Windows Server" if operating_system.startswith("Windows Server") else "Windows"
    if os_type == "Linux":
        match = _LINUX_DISTRO_NAME_RE.match(operating_system)
        return match.group(1) if match else (operating_system or "Linux")
    # An OSType this app hasn't seen a real capture for yet — surfaced as
    # its own family (rather than silently dropped or miscategorized) so
    # it's immediately visible and easy to special-case once confirmed.
    return os_type or "Other"


def _format_baseline_label(entry):
    """Human-readable label for one catalog entry in the Settings
    picker's second dropdown, e.g. "Windows 11 25H2 x64 — April 2026" —
    built the same way the FullName itself is structured, minus the
    ".tar.gz" and dash-joining."""
    left = " ".join(str(v) for v in (entry.get("OperatingSystem"), entry.get("ServicePack"), entry.get("Architecture")) if v)
    patch_level = entry.get("PatchLevel")
    return f"{left} — {patch_level}" if patch_level else left


def cloud_group_baselines_by_family(baselines):
    """Groups the full reference-baseline catalog (~180 entries) by
    family (see _baseline_family) for the Settings picker's first
    dropdown, with each family's own entries sorted for a stable, readable
    order in the second dropdown. Non-dict entries are skipped rather
    than raising."""
    groups = {}
    for entry in baselines:
        if not isinstance(entry, dict):
            continue
        groups.setdefault(_baseline_family(entry), []).append(entry)
    for entries in groups.values():
        entries.sort(key=lambda e: (e.get("OperatingSystem") or "", e.get("ServicePack") or "", e.get("Architecture") or ""))
    return groups


def cloud_recommend_baseline_per_family(grouped_baselines):
    """Picks one "recommended" entry per family — the most recently
    patched (falling back to whatever's last alphabetically if nothing in
    the family has a parseable PatchLevel, e.g. an all-RTM Linux distro,
    so a recommendation still exists), with x64 preferred on an exact
    patch-level tie — to pre-select the Settings picker's second dropdown
    once a family is chosen. Returns {family: FullName}."""
    def sort_key(entry):
        parsed = _parse_baseline_patch_level(entry.get("PatchLevel"))
        is_x64 = (entry.get("Architecture") or "").strip().lower() in _X64_ARCHITECTURE_SPELLINGS
        return (parsed is not None, parsed or (0, 0), is_x64)

    return {
        family: max(entries, key=sort_key).get("FullName")
        for family, entries in grouped_baselines.items()
        if entries
    }


def cloud_create_baseline_from_reference(tenant_id, directory_id, baseline_entry):
    """Adds one reference baseline to a tenant ("Add Baseline from
    Reference"). baseline_entry must be the exact dict a live
    tenant-baseline-reference-list call returned for the target baseline —
    a real capture showed the console echoing the WHOLE entry back
    (including UI bookkeeping fields like _id_internal/originalSortOrder
    alongside OSType/FullName/etc.), so this passes it through unmodified
    rather than reconstructing a guessed subset of fields. Only ever sends
    one entry per call — TenantReferenceBaselineList is array-shaped, and
    this project has already confirmed elsewhere (tenant-policy-clients-
    in-scope-list) that a sibling batch-shaped endpoint can 500 on more
    than one item despite the schema allowing an array, so batching here
    is never assumed safe without its own test. Returns (True, None) or
    (False, error)."""
    entry = dict(baseline_entry)
    entry["selected"] = True
    payload = {"TenantReferenceBaselineList": [entry], "atcp": None}
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-baseline-reference-create", method="POST", payload=payload,
        tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return False, err
    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return False, f"Cloud API reported an error adding the baseline: {data}"
    return True, None


def cloud_add_baseline_to_tenant(tenant_id, directory_id, full_name):
    """Orchestrates the full "Add Baseline from Reference" step for one
    newly-created tenant: fetch the live reference catalog, find the
    configured baseline by FullName, add it. Kept as one function so both
    the automatic post-creation trigger and the manual retry route share
    identical behavior. Returns (True, None) or (False, error)."""
    baselines, err = cloud_list_reference_baselines(tenant_id, directory_id)
    if err:
        return False, err
    entry = cloud_find_reference_baseline(baselines, full_name)
    if not entry:
        return False, (
            f"Reference baseline '{full_name}' was not found in Airlock's current catalog — "
            "it may have been renamed or retired for a newer monthly release. "
            "Check Tenant creation settings and update the baseline name."
        )
    return cloud_create_baseline_from_reference(tenant_id, directory_id, entry)


def cloud_list_tenant_baselines(tenant_id, directory_id):
    """Lists baselines already sitting on a tenant — NOT the reference
    catalog (tenant-baseline-reference-list) — confirmed via a real
    capture to be a GET with no body, unlike most other webfe calls here,
    which is why this is tracked separately rather than assumed. Each
    entry includes an "ID" (a UUID — the form tenant-policy-update-changes
    needs as BaselineID, distinct from the numeric "Timestamp" value used
    internally in a policy's compiled enforced_baselines list) and a
    human "Name" (e.g. "Windows 11 25H2 x64 April 2026 (Reference)" — a
    different format than the reference catalog's "FullName"). Returns
    (list_of_baseline_dicts, None) or (None, error)."""
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-baseline-list", method="GET", tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return None, err
    if not isinstance(data, dict):
        return None, f"Tenant baseline list endpoint returned an unexpected response: {data}"
    if data.get("Atro", {}).get("ErrorOccured"):
        return None, f"Cloud API reported an error listing the tenant's baselines: {data}"
    baselines = data.get("TenantBaselineList")
    if not isinstance(baselines, list):
        return None, f"Tenant baseline list response missing TenantBaselineList — response shape may have changed: {data}"
    return baselines, None


def cloud_find_newest_tenant_baseline(baselines):
    """Picks the most recently created entry from a tenant-baseline-list
    result, by its "Timestamp" field (a numeric epoch-like value, easier
    and more robust to compare than parsing "Datetime" strings). Used
    right after adding exactly one baseline to a tenant, so "the newest
    one on this tenant" is unambiguously the one just added — no need to
    reconstruct its display Name from the reference entry's fields (which
    format differently: "Windows 11-25H2-x64-April 2026.tar.gz" as a
    FullName vs. "Windows 11 25H2 x64 April 2026 (Reference)" as a Name)
    and risk getting that transform wrong for some other OS. Returns the
    dict or None if the list is empty."""
    newest = None
    newest_ts = -1
    for entry in baselines:
        if not isinstance(entry, dict):
            continue
        try:
            ts = int(entry.get("Timestamp") or 0)
        except (TypeError, ValueError):
            continue
        if ts > newest_ts:
            newest_ts = ts
            newest = entry
    return newest


def cloud_build_policy_group_tree(tenant_id, directory_id, group_name):
    """Builds the minimal "Policy" tree object tenant-policy-update-changes
    needs to identify a policy group and cascade the change to its
    children — confirmed via a real capture to need at least ID/Name/
    Parent/children (the backend queued a GENERATE_DB job for the group
    AND both children found in that same tree). Deliberately omits the
    console's own cosmetic UI fields for this tree (icon/expanded/
    isChecked/htmlID/iconColor/rightClicked/iconSize) — nothing available
    to this app can derive real values for those, and they read as pure
    frontend tree-widget state rather than data the backend would
    validate; if a live test proves otherwise, add them back informed by
    that specific error rather than guessing now.

    Reuses cloud_get_policies() (already confirmed/shipped for the
    Partner Engagement Report widget — same policy/v1/policy?limit=10000
    call) rather than any new endpoint: a real capture showed that flat
    list already contains the group ("Workstations") and both its
    children ("Workstations Audit"/"Workstations Enforced") by name, and
    Ryan's own tenant-baseline-server-activity-list capture confirmed
    Airlock auto-provisions exactly this trio for every newly created
    tenant. Matches children by exact "<group_name> Audit"/"<group_name>
    Enforced" naming — the only pattern confirmed by a real capture.
    Returns (tree_dict, None) or (None, error) if the group isn't found."""
    policies, err = cloud_get_policies(tenant_id, directory_id)
    if err:
        return None, err

    group = next((p for p in policies if p.get("name") == group_name), None)
    if not group:
        return None, (
            f"Policy group '{group_name}' was not found on this tenant — "
            "check Tenant creation settings and update the policy group name."
        )

    child_names = (f"{group_name} Audit", f"{group_name} Enforced")
    children = [p for p in policies if p.get("name") in child_names]

    tree = {
        "ID": group["id"],
        "Name": group["name"],
        "Parent": POLICY_GLOBAL_SETTINGS_PARENT,
        "parentid": POLICY_GLOBAL_SETTINGS_PARENT,
        "children": [
            {"ID": c["id"], "Name": c["name"], "Parent": group["id"], "parentid": group["id"], "children": []}
            for c in children
        ],
    }
    return tree, None


def cloud_apply_baseline_to_policy_group(tenant_id, directory_id, policy_tree, baseline_id, baseline_name):
    """Assigns one baseline to one policy group ("Add Baseline from
    Reference" is step one; this is the separate "assign it to a policy"
    step Ryan flagged as a follow-up capture). Confirmed via a real
    capture: the Handler name, the Changes[].Data shape (echoing the
    group's own ID/Name/Parent alongside the new BaselineID), and that
    Airlock cascades a GENERATE_DB job to the group and every child found
    in the given Policy tree — hence cloud_build_policy_group_tree above
    needing the children included. ChangeReason/ChangeCategory/
    TrustBuilderRecommendationIDs are sent exactly as captured (empty
    defaults) — no live example of them being anything else. Only ever
    sends one change-group per call, matching the one real capture this
    was built from; never assumed safe to batch multiple policy groups'
    changes in one call without its own test. Returns (True, None) or
    (False, error)."""
    change_group = {
        "Policy": policy_tree,
        "Changes": [
            {
                "Handler": "TenantPolicyBaselineApproveUpdate",
                "Data": {
                    "ID": policy_tree["ID"],
                    "Name": baseline_name,
                    "Parent": POLICY_GLOBAL_SETTINGS_PARENT,
                    "BaselineID": baseline_id,
                },
            }
        ],
        "ChangeReason": "",
        "ChangeCategory": "",
        "TrustBuilderRecommendationIDs": [],
    }
    payload = {"TenantPolicyApplyChangeGroupList": [change_group], "atcp": None}
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-policy-update-changes", method="POST", payload=payload,
        tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return False, err
    if (data or {}).get("Atro", {}).get("ErrorOccured"):
        return False, f"Cloud API reported an error assigning the baseline to the policy group: {data}"
    return True, None


def cloud_assign_baseline_to_policy(tenant_id, directory_id, policy_group_name):
    """Orchestrates the full "assign the just-added baseline to a policy
    group" step: find the newest baseline on the tenant (the one just
    added), find the target policy group's tree, apply. Kept as one
    function so both the automatic post-baseline trigger and the manual
    retry route share identical behavior. Returns (True, None) or
    (False, error)."""
    baselines, err = cloud_list_tenant_baselines(tenant_id, directory_id)
    if err:
        return False, err
    newest = cloud_find_newest_tenant_baseline(baselines)
    if not newest:
        return False, "No baselines found on this tenant to assign — the baseline-add step may not have completed yet."

    tree, err = cloud_build_policy_group_tree(tenant_id, directory_id, policy_group_name)
    if err:
        return False, err

    return cloud_apply_baseline_to_policy_group(tenant_id, directory_id, tree, newest["ID"], newest["Name"])


# Phase 8 (2026-09-24): custom blocked-file notification message — the
# popup text an agent shows when it blocks something ("%filename% has been
# prevented from executing..."). Confirmed via a real HAR capture of Ryan
# editing it on "Workstations Enforced" in the Cloud console:
#
#   Load:  POST webfe/v1/tenant-policy-setting-list
#            {"TenantPolicyGroupList":[{<one policy group ref>}],"atcp":null}
#          -> TenantPolicySettingList[0] = the group's ENTIRE settings object
#             (audit mode, script control, OTP, proxy, cache, ...,
#             ClientNotification, NotificationMessage).
#   Save:  POST webfe/v1/tenant-policy-update-changes (same call as Phase 5)
#            Changes[0] = {"Handler":"TenantPolicySettingUpdate",
#                          "Data":{"ID","Parent","TenantPolicySettingList":[<whole object>]}}
#          -> console toast "Policy Saved, Updates to Clients Queued".
#
# Same UserApiKey/tenantID auth as Phase 5 (AccessLog: edit_policies).
# The save carries the WHOLE settings object, not a diff — so this always
# loads the group's current settings first and changes only
# NotificationMessage (+ forces ClientNotification on, by Ryan's choice,
# since the message is never shown otherwise). Diffing the console's own
# save against its load showed it sends back every loaded field EXCEPT the
# ones below (plus TargetVer minus its PolicyID) — mirrored exactly rather
# than guessing whether sending them would be harmless.
# Not a confirmed Airlock limit — just a sanity cap so a pasted wall of
# text doesn't get pushed onto every student tenant by accident.
BLOCK_NOTIFICATION_MESSAGE_MAX_LENGTH = 1000

POLICY_SETTING_FIELDS_OMITTED_ON_SAVE = (
    "ID",
    "AgentDownloadList",
    "CacheExpiryTime",
    "ClientToServerProxy",
    "CmdlineEnabled",
    "CommunicationList",
    "PowerShellLanguageMode",
    "ScriptCustom",
)


def cloud_find_enforced_policy_group(tenant_id, directory_id, group_name):
    """Finds "<group_name> Enforced" (by Ryan's choice, the only group the
    message is set on — it's where files are actually blocked) and returns
    a policy-group ref shaped like the console's own: ID/Name/Parent/
    parentid/children. Parent is the configured group's own ID, matching
    the real capture. Returns (ref, None) or (None, error)."""
    policies, err = cloud_get_policies(tenant_id, directory_id)
    if err:
        return None, err
    parent = next((p for p in policies if p.get("name") == group_name), None)
    if not parent:
        return None, (
            f"Policy group '{group_name}' was not found on this tenant — "
            "check Tenant creation settings and update the policy group name."
        )
    enforced_name = f"{group_name} Enforced"
    enforced = next((p for p in policies if p.get("name") == enforced_name), None)
    if not enforced:
        return None, f"Policy group '{enforced_name}' was not found on this tenant."
    return {
        "ID": enforced["id"],
        "Name": enforced["name"],
        "Parent": parent["id"],
        "parentid": parent["id"],
        "children": [],
    }, None


def cloud_get_policy_group_settings(tenant_id, directory_id, group_ref):
    """Loads one policy group's full settings object via
    tenant-policy-setting-list (one group per call — same batch caution as
    everywhere else). Returns (settings_dict, None) or (None, error)."""
    payload = {"TenantPolicyGroupList": [group_ref], "atcp": None}
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-policy-setting-list", method="POST", payload=payload,
        tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return None, err
    if not isinstance(data, dict):
        return None, f"Unexpected response loading policy settings: {data}"
    if (data.get("Atro") or {}).get("ErrorOccured"):
        return None, f"Cloud API reported an error loading policy settings: {data}"
    settings_list = data.get("TenantPolicySettingList") or []
    settings = next(
        (s for s in settings_list if isinstance(s, dict) and s.get("ID") == group_ref["ID"]),
        None,
    )
    if not settings:
        return None, f"No settings returned for policy group '{group_ref.get('Name')}'."
    return settings, None


def build_policy_settings_for_save(loaded_settings, notification_message):
    """Pure function: turns a loaded settings object into the exact shape
    the console saves, with only the notification fields changed. Never
    mutates the input."""
    settings = {k: v for k, v in loaded_settings.items() if k not in POLICY_SETTING_FIELDS_OMITTED_ON_SAVE}
    if isinstance(settings.get("TargetVer"), dict):
        settings["TargetVer"] = {k: v for k, v in settings["TargetVer"].items() if k != "PolicyID"}
    settings["ClientNotification"] = True
    settings["NotificationMessage"] = notification_message
    return settings


def cloud_save_policy_group_settings(tenant_id, directory_id, group_ref, settings):
    """Saves one policy group's settings via tenant-policy-update-changes
    (Handler TenantPolicySettingUpdate). Returns (True, None) or (False, error)."""
    change_group = {
        "Policy": group_ref,
        "Changes": [
            {
                "Handler": "TenantPolicySettingUpdate",
                "Data": {
                    "ID": group_ref["ID"],
                    "Parent": group_ref["Parent"],
                    "TenantPolicySettingList": [settings],
                },
            }
        ],
        "ChangeReason": "",
        "ChangeCategory": "",
        "TrustBuilderRecommendationIDs": [],
    }
    payload = {"TenantPolicyApplyChangeGroupList": [change_group], "atcp": None}
    data, err = cloud_api_request(
        CLOUD_MODULE_WEBFE, "tenant-policy-update-changes", method="POST", payload=payload,
        tenant_id=tenant_id, directory_id=directory_id,
    )
    if err:
        return False, err
    if (data or {}).get("Atro", {}).get("ErrorOccured") if isinstance(data, dict) else False:
        return False, f"Cloud API reported an error saving policy settings: {data}"
    return True, None


def cloud_set_block_notification_message(tenant_id, directory_id, policy_group_name, message):
    """Orchestrates the whole step: find "<group> Enforced", load its
    current settings, change only the notification message, save, then
    re-read and confirm the message actually stuck (cheap insurance, since
    the save echoes the whole settings object). Shared by the automatic
    chain and the manual retry route. Returns (True, None) or (False, error)."""
    group_ref, err = cloud_find_enforced_policy_group(tenant_id, directory_id, policy_group_name)
    if err:
        return False, err
    loaded, err = cloud_get_policy_group_settings(tenant_id, directory_id, group_ref)
    if err:
        return False, err
    settings = build_policy_settings_for_save(loaded, message)
    ok, err = cloud_save_policy_group_settings(tenant_id, directory_id, group_ref, settings)
    if not ok:
        return False, err
    check, err = cloud_get_policy_group_settings(tenant_id, directory_id, group_ref)
    if err:
        return False, f"Message saved, but re-reading it to confirm failed: {err}"
    if check.get("NotificationMessage") != message:
        return False, "Save reported success, but the policy group's notification message didn't change."
    return True, None


# Phase 6 follow-up (2026-09-19): confirmed via a real live test that
# granting instructor access (tenant-user-create) doesn't take effect on
# the very next API call — Ryan's automatic chain 403'd on
# tenant-baseline-reference-list ("Tenant Role(s) NOT Found: view_baselines")
# immediately after a successful instructor-access grant on a brand-new
# tenant, but manually clicking "Retry baseline" moments later (no other
# change) succeeded. This is a real propagation delay between Airlock
# granting a tenant-level role and that role being visible to a
# subsequent authorization check — not a bug in the create call, and not
# something guessed at: it only retries this exact confirmed error shape,
# never any other kind of failure (a genuinely wrong baseline/policy group
# name, a real permissions problem, a network error, etc. all still fail
# immediately as before).
TRAINING_ROLE_PROPAGATION_RETRY_ATTEMPTS = 3
TRAINING_ROLE_PROPAGATION_RETRY_DELAY_SECONDS = 3


def retry_on_role_propagation_delay(fn):
    """Calls fn() (a callable returning (ok, err)), retrying with a short
    delay ONLY when it fails with the specific "Tenant Role(s) NOT Found"
    403 shape — see the Phase 6 follow-up comment above. Any other
    failure returns immediately on the first attempt, unretried."""
    ok, err = fn()
    attempt = 1
    while not ok and err and "Tenant Role(s) NOT Found" in str(err) and attempt < TRAINING_ROLE_PROPAGATION_RETRY_ATTEMPTS:
        time.sleep(TRAINING_ROLE_PROPAGATION_RETRY_DELAY_SECONDS)
        ok, err = fn()
        attempt += 1
    return ok, err


def apply_training_block_notification(student, directory_id, policy_group_name, message, class_name):
    """Runs the Phase 8 step for one student and records the outcome on
    it (block_notification_status/_error/_created_at). "skipped" when no
    message is configured. Wrapped in retry_on_role_propagation_delay
    like baseline/policy — it needs the same freshly-granted tenant role
    (edit_policies). Returns (ok, err); ok is True for "skipped"."""
    if not message:
        student["block_notification_status"] = "skipped"
        student["block_notification_error"] = None
        return True, None
    ok, err = retry_on_role_propagation_delay(
        lambda: cloud_set_block_notification_message(student["tenant_id"], directory_id, policy_group_name, message)
    )
    if ok:
        student["block_notification_status"] = "completed"
        student["block_notification_error"] = None
        student["block_notification_created_at"] = datetime.now(timezone.utc).isoformat()
        log.info("Training Instances: set blocked-file notification message for %s (%s)", student.get("email"), class_name)
    else:
        student["block_notification_status"] = "error"
        student["block_notification_error"] = err
        log.info("Training Instances: blocked-file notification update failed for %s (%s): %s", student.get("email"), class_name, err)
    return ok, err


def process_pending_training_jobs():
    """Polls every student tenant still awaiting creation and updates its
    status in place. Never raises — one job's failure (or the Cloud API
    being briefly unreachable) never stops the rest from being checked,
    and a transient polling error leaves status alone to retry next tick
    rather than marking a perfectly fine job as failed.

    The moment a tenant's creation reaches COMPLETED, this also attempts,
    in order: (1) granting the configured instructor account access to the
    tenant (tracked via instructor_access_status/instructor_access_error —
    "skipped" rather than an error if no instructor name/email is
    configured yet), so whichever account this app authenticates as has
    the tenant-level roles the next two steps need without anyone having
    opened the tenant in the console by hand first; (2) adding the
    configured reference baseline (baseline_status/baseline_error); (3)
    once that succeeds, assigning it to the configured policy group
    (policy_assign_status/policy_assign_error) — both of these wrapped in
    retry_on_role_propagation_delay to absorb the confirmed real-world
    delay between step (1) granting a tenant-level role and that role
    actually being visible to a subsequent call. None of the three steps
    roll back or re-flag the tenant creation itself (the tenant is real
    either way, regardless of which of these fail), and each is tracked
    independently so it can be retried on its own from the class list —
    all three chained into the same provisioning flow, matching how Ryan
    actually uses this end to end."""
    training_cfg = load_training_config()
    directory_id = (training_cfg.get("creation_directory_id") or "").strip()
    baseline_full_name = (training_cfg.get("baseline_full_name") or "").strip() or DEFAULT_TRAINING_BASELINE_FULL_NAME
    policy_group_name = (training_cfg.get("policy_group_name") or "").strip() or DEFAULT_TRAINING_POLICY_GROUP_NAME
    instructor_full_name = (training_cfg.get("instructor_full_name") or "").strip()
    instructor_email = (training_cfg.get("instructor_email") or "").strip()
    block_notification_message = (training_cfg.get("block_notification_message") or "").strip()
    changed = False

    for cls in training_cfg.get("classes") or []:
        for student in cls.get("students") or []:
            if student.get("status") != "polling":
                continue
            job_id = student.get("job_id")
            if not job_id or not directory_id:
                continue

            status, err = cloud_poll_tenant_job(directory_id, job_id)
            if err:
                student["last_poll_error"] = err
                changed = True
                continue

            changed = True
            student["last_poll_error"] = None
            if status == TRAINING_TERMINAL_SUCCESS:
                student["status"] = "completed"
                student["completed_at"] = datetime.now(timezone.utc).isoformat()

                if instructor_full_name and instructor_email:
                    access_ok, access_err = cloud_provision_instructor_access(
                        student["tenant_id"], directory_id, instructor_full_name, instructor_email
                    )
                    if access_ok:
                        student["instructor_access_status"] = "completed"
                        student["instructor_access_error"] = None
                        student["instructor_access_created_at"] = datetime.now(timezone.utc).isoformat()
                        log.info("Training Instances: granted instructor access to tenant for %s (%s)", student.get("email"), cls.get("class_name"))
                    else:
                        student["instructor_access_status"] = "error"
                        student["instructor_access_error"] = access_err
                        log.info("Training Instances: instructor access grant failed for %s (%s): %s", student.get("email"), cls.get("class_name"), access_err)
                else:
                    # No instructor name/email configured yet — not an
                    # error, just means this step is opted out of for now
                    # (e.g. Ryan intends to open this tenant in the
                    # console by hand, as before this step existed).
                    student["instructor_access_status"] = "skipped"
                    student["instructor_access_error"] = None

                ok, baseline_err = retry_on_role_propagation_delay(
                    lambda: cloud_add_baseline_to_tenant(student["tenant_id"], directory_id, baseline_full_name)
                )
                if ok:
                    student["baseline_status"] = "completed"
                    student["baseline_error"] = None
                    student["baseline_created_at"] = datetime.now(timezone.utc).isoformat()
                    log.info("Training Instances: added baseline '%s' to tenant for %s (%s)", baseline_full_name, student.get("email"), cls.get("class_name"))

                    assign_ok, assign_err = retry_on_role_propagation_delay(
                        lambda: cloud_assign_baseline_to_policy(student["tenant_id"], directory_id, policy_group_name)
                    )
                    if assign_ok:
                        student["policy_assign_status"] = "completed"
                        student["policy_assign_error"] = None
                        student["policy_assign_created_at"] = datetime.now(timezone.utc).isoformat()
                        log.info("Training Instances: assigned baseline to policy group '%s' for %s (%s)", policy_group_name, student.get("email"), cls.get("class_name"))
                    else:
                        student["policy_assign_status"] = "error"
                        student["policy_assign_error"] = assign_err
                        log.info("Training Instances: policy assign failed for %s (%s): %s", student.get("email"), cls.get("class_name"), assign_err)
                else:
                    student["baseline_status"] = "error"
                    student["baseline_error"] = baseline_err
                    log.info("Training Instances: baseline add failed for %s (%s): %s", student.get("email"), cls.get("class_name"), baseline_err)

                # (4) Independent of the baseline steps — a policy
                # group's settings exist whether or not a baseline landed.
                apply_training_block_notification(
                    student, directory_id, policy_group_name, block_notification_message, cls.get("class_name")
                )
            elif status in TRAINING_TERMINAL_FAILURE:
                student["status"] = status.lower()
                student["completed_at"] = datetime.now(timezone.utc).isoformat()
            elif status in TRAINING_RETRYABLE:
                pass  # still in flight — unchanged, checked again next tick
            else:
                student["last_poll_error"] = f"Unknown Quevider status: {status}"

    if changed:
        save_training_config(training_cfg)


def process_pending_nfr_jobs():
    """NFR Provisioning's twin to process_pending_training_jobs above —
    same polling/chaining shape, including the instructor-access step:
    despite every listed administrator already being placed in the new
    tenant's Local Administrator group at creation time, the Cloud admin
    API key's OWN account (whichever account is granted instructor_full_name/
    instructor_email — shared from Training Instances' settings) still has
    no tenant-level role on a brand-new tenant until it's explicitly added
    to it, and baseline-add/policy-assign are authenticated as exactly that
    account. Confirmed the hard way: the first real NFR tenant
    ("TestNFRfakecompany") 403'd on tenant-baseline-reference-list with
    "Tenant Role(s) NOT Found: view_baselines" because this step didn't
    exist yet — listing people as administrators doesn't cover the
    API-calling identity itself. So once creation reaches COMPLETED, this
    chains: (1) granting the configured instructor account access
    (instructor_access_status/instructor_access_error — "skipped" if
    blank, same convention as Training), (2) adding the configured
    reference baseline, then (3) assigning it to the configured policy
    group — steps 2 and 3 wrapped in retry_on_role_propagation_delay for
    the separate, already-confirmed real propagation delay between (1)
    succeeding and its role becoming visible to (2). Every Cloud API call
    here uses the tenant's OWN recorded directory_id, not the widget's
    configured default — a tenant created in an override/sub-directory
    (see nfr_provisioning_tenants_create) lives there permanently. Never
    raises — one tenant's failure never stops the rest from being
    checked."""
    nfr_cfg = load_nfr_provisioning_config()
    settings = get_nfr_provisioning_settings()
    baseline_full_name = settings["baseline_full_name"]
    policy_group_name = settings["policy_group_name"]
    instructor_full_name = settings["instructor_full_name"]
    instructor_email = settings["instructor_email"]
    changed = False

    for tenant in nfr_cfg.get("tenants") or []:
        if tenant.get("status") != "polling":
            continue
        job_id = tenant.get("job_id")
        directory_id = (tenant.get("directory_id") or "").strip()
        if not job_id or not directory_id:
            continue

        status, err = cloud_poll_tenant_job(directory_id, job_id)
        if err:
            tenant["last_poll_error"] = err
            changed = True
            continue

        changed = True
        tenant["last_poll_error"] = None
        if status == TRAINING_TERMINAL_SUCCESS:
            tenant["status"] = "completed"
            tenant["completed_at"] = datetime.now(timezone.utc).isoformat()

            if instructor_full_name and instructor_email:
                access_ok, access_err = cloud_provision_instructor_access(
                    tenant["tenant_id"], directory_id, instructor_full_name, instructor_email
                )
                if access_ok:
                    tenant["instructor_access_status"] = "completed"
                    tenant["instructor_access_error"] = None
                    tenant["instructor_access_created_at"] = datetime.now(timezone.utc).isoformat()
                    log.info("NFR Provisioning: granted instructor access to tenant '%s'", tenant.get("tenant_name"))
                else:
                    tenant["instructor_access_status"] = "error"
                    tenant["instructor_access_error"] = access_err
                    log.info("NFR Provisioning: instructor access grant failed for '%s': %s", tenant.get("tenant_name"), access_err)
            else:
                tenant["instructor_access_status"] = "skipped"
                tenant["instructor_access_error"] = None

            ok, baseline_err = retry_on_role_propagation_delay(
                lambda: cloud_add_baseline_to_tenant(tenant["tenant_id"], directory_id, baseline_full_name)
            )
            if ok:
                tenant["baseline_status"] = "completed"
                tenant["baseline_error"] = None
                tenant["baseline_created_at"] = datetime.now(timezone.utc).isoformat()
                log.info("NFR Provisioning: added baseline '%s' to tenant '%s'", baseline_full_name, tenant.get("tenant_name"))

                assign_ok, assign_err = retry_on_role_propagation_delay(
                    lambda: cloud_assign_baseline_to_policy(tenant["tenant_id"], directory_id, policy_group_name)
                )
                if assign_ok:
                    tenant["policy_assign_status"] = "completed"
                    tenant["policy_assign_error"] = None
                    tenant["policy_assign_created_at"] = datetime.now(timezone.utc).isoformat()
                    log.info("NFR Provisioning: assigned baseline to policy group '%s' for tenant '%s'", policy_group_name, tenant.get("tenant_name"))
                else:
                    tenant["policy_assign_status"] = "error"
                    tenant["policy_assign_error"] = assign_err
                    log.info("NFR Provisioning: policy assign failed for tenant '%s': %s", tenant.get("tenant_name"), assign_err)
            else:
                tenant["baseline_status"] = "error"
                tenant["baseline_error"] = baseline_err
                log.info("NFR Provisioning: baseline add failed for tenant '%s': %s", tenant.get("tenant_name"), baseline_err)
        elif status in TRAINING_TERMINAL_FAILURE:
            tenant["status"] = status.lower()
            tenant["completed_at"] = datetime.now(timezone.utc).isoformat()
        elif status in TRAINING_RETRYABLE:
            pass  # still in flight — unchanged, checked again next tick
        else:
            tenant["last_poll_error"] = f"Unknown Quevider status: {status}"

    if changed:
        save_nfr_provisioning_config(nfr_cfg)


def training_scheduler_loop():
    while True:
        try:
            with TRAINING_LOCK:
                process_pending_training_jobs()
        except Exception as e:  # noqa: broad except — this loop must never die
            print(f"[training scheduler] error: {e}")
        try:
            with NFR_PROVISION_LOCK:
                process_pending_nfr_jobs()
        except Exception as e:  # noqa: broad except — this loop must never die
            print(f"[nfr provisioning scheduler] error: {e}")
        time.sleep(15)


def migrate_legacy_training_instances():
    """Phase 1 of this widget pre-provisioned a fixed list of instances and
    assigned one admin user onto each (tracked under 'instances'). Phase 2
    replaced that with creating a brand-new tenant per student instead,
    which needs a different config shape ('classes'). Rather than silently
    discarding Ryan's old instance list, keep it around read-only under
    'legacy_instances' — the widget no longer reads or writes it."""
    with TRAINING_LOCK:
        cfg = load_training_config()
        if "instances" not in cfg:
            return
        cfg["legacy_instances"] = cfg.pop("instances")
        cfg.pop("admin_group_name", None)
        save_training_config(cfg)
    print(f"[startup] Migrated legacy Training Instances data into 'legacy_instances' in {TRAINING_CONFIG_PATH}")


def parse_github_repo(value):
    """Accepts 'owner/repo' or a full https://github.com/owner/repo URL."""
    value = value.strip()
    if value.endswith(".git"):
        value = value[: -len(".git")]
    for prefix in ("https://github.com/", "http://github.com/", "github.com/"):
        if value.startswith(prefix):
            value = value[len(prefix):]
            break
    value = value.strip("/")
    parts = value.split("/")
    if len(parts) < 2 or not parts[0] or not parts[1]:
        raise ValueError("Repo must be in 'owner/repo' form, or a full GitHub URL.")
    return parts[0], parts[1]


def sync_github_scripts():
    """Downloads .py files from the configured GitHub repo into the local
    scripts folder. Only touches .py files it manages — any other files
    already sitting in the scripts folder (notes, configs, etc.) are left
    alone. Returns a dict describing the outcome; never raises.
    """
    config = load_config()
    if (config.get("github_sync_enabled", "") or "").strip().lower() != "true":
        return {"synced": False, "reason": "disabled"}

    repo = config.get("github_repo", "").strip()
    if not repo:
        return {"synced": False, "reason": "no repo configured"}

    branch = config.get("github_branch", "").strip() or "main"
    subdir = config.get("github_subdir", "").strip().strip("/")
    token = config.get("github_token", "").strip()

    try:
        owner, name = parse_github_repo(repo)
    except ValueError as e:
        return {"synced": False, "reason": str(e)}

    api_url = f"https://api.github.com/repos/{owner}/{name}/contents/{subdir}"
    headers = {"Accept": "application/vnd.github.v3+json"}
    if token:
        headers["Authorization"] = f"token {token}"

    try:
        resp = requests.get(api_url, headers=headers, params={"ref": branch}, timeout=15)
    except requests.exceptions.RequestException as e:
        return {"synced": False, "reason": f"GitHub request failed: {e}"}

    if not resp.ok:
        return {"synced": False, "reason": f"GitHub API error: {resp.status_code}"}

    items = resp.json()
    if not isinstance(items, list):
        return {"synced": False, "reason": "Configured path isn't a folder in this repo."}

    py_files = [item for item in items if item.get("type") == "file" and item["name"].endswith(".py")]

    scripts_dir = get_scripts_dir()
    downloaded = []
    errors = []
    for item in py_files:
        raw_url = item.get("download_url")
        if not raw_url:
            continue
        try:
            file_resp = requests.get(raw_url, headers=headers, timeout=15)
            file_resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            errors.append(f"{item['name']}: {e}")
            continue
        with open(os.path.join(scripts_dir, item["name"]), "wb") as f:
            f.write(file_resp.content)
        downloaded.append(item["name"])

    return {
        "synced": True,
        "downloaded": downloaded,
        "errors": errors,
        "location": f"{owner}/{name}@{branch}" + (f"/{subdir}" if subdir else ""),
    }


# --- Settings: Publish to GitHub ---
# The other direction from GitHub sync above — pushes this app's own
# source *out* to a repo instead of pulling scripts *in*. Deliberately a
# fixed, hand-maintained file list rather than a real .gitignore parser:
# this app has one, small, known set of source files, and being explicit
# here means a secret or runtime file (config.json, cloud_config.json,
# training_config.json, venv/, builds/, audit_sessions.json, logs) can
# never accidentally end up on the list just because someone dropped a
# new file next to app.py.
GITHUB_PUBLISH_FILES = [
    ".gitignore",
    "api_catalog.json",
    "app.py",
    "har_to_catalog.py",
    "iso_mapping.json",
    "PROJECT_SUMMARY.md",
    "QUICKSTART.md",
    "README.md",
    "requirements.txt",
    "run.bat",
    os.path.join("templates", "index.html"),
    os.path.join("templates", "api_reference.html"),
]


def collect_publish_files():
    """Returns (found, missing) where found is [(repo_path, abs_path), ...]
    for files in GITHUB_PUBLISH_FILES that currently exist on disk, and
    missing is the repo-relative paths that don't (e.g. no PROJECT_SUMMARY.md
    yet) — not fatal, just left out and reported back."""
    found = []
    missing = []
    for rel in GITHUB_PUBLISH_FILES:
        abs_path = os.path.join(BASE_DIR, rel)
        repo_path = rel.replace(os.sep, "/")
        if os.path.isfile(abs_path):
            found.append((repo_path, abs_path))
        else:
            missing.append(repo_path)
    return found, missing


# Base filename for the versioned zip this widget uploads — the actual
# name on GitHub is f"{GITHUB_PUBLISH_ZIP_BASENAME}_v{version}.zip".
# Hardcoded (not derived from the configured repo name) since this app
# only ever packages itself, whatever repo you choose to push it to.
GITHUB_PUBLISH_ZIP_BASENAME = "airlock-partner-consulting-toolkit"

# Assumed last version if this app has never recorded one itself — set
# to match the last manually-uploaded zip (v4.1), so the very first
# auto-suggested version in a fresh config.json is v4.2, not v0.1.
GITHUB_PUBLISH_SEED_VERSION = "4.1"


def build_publish_zip():
    """Zips up the current GITHUB_PUBLISH_FILES into an in-memory buffer
    — same file set and same top-level-folder layout as a manually built
    release package, so unzipping it drops a ready-to-run project folder.
    Returns (buffer, files_included, files_missing)."""
    files, missing = collect_publish_files()
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for repo_path, abs_path in files:
            zf.write(abs_path, arcname=f"{GITHUB_PUBLISH_ZIP_BASENAME}/{repo_path}")
    buf.seek(0)
    return buf, [p for p, _ in files], missing


def sanitize_publish_version(version):
    version = (version or "").strip()
    if not version:
        raise ValueError("A version number is required.")
    if "/" in version or "\\" in version:
        raise ValueError("Version can't contain slashes.")
    return version


def suggest_next_publish_version(last_version):
    """Best-effort bump of the last dot-separated numeric component, e.g.
    '4.1' -> '4.2', '4.9' -> '4.10'. Just a starting suggestion for the UI
    field (always editable) — falls back to returning the input unchanged
    if it doesn't end in a plain integer."""
    last_version = (last_version or "").strip()
    parts = last_version.split(".")
    if parts and parts[-1].isdigit():
        parts[-1] = str(int(parts[-1]) + 1)
        return ".".join(parts)
    return last_version


def github_publish_push(version, commit_message=None):
    """Zips up GITHUB_PUBLISH_FILES and pushes it as a single new,
    version-named file in the configured GitHub repo — one commit, via
    the Git Data API (blob -> tree -> commit -> ref update). Each version
    gets its own filename, so past versions already in the repo are left
    alone rather than overwritten — a running history, not just a latest.
    Never raises — returns (result_dict, None) or (None, error_message)."""
    config = load_config()
    repo = config.get("github_publish_repo", "").strip()
    if not repo:
        return None, "No publish repo configured."
    branch = config.get("github_publish_branch", "").strip() or "main"
    token = config.get("github_publish_token", "").strip()
    if not token:
        return None, "A personal access token with write access to the repo is required."

    try:
        owner, name = parse_github_repo(repo)
    except ValueError as e:
        return None, str(e)

    try:
        version = sanitize_publish_version(version)
    except ValueError as e:
        return None, str(e)

    zip_buf, files_included, files_missing = build_publish_zip()
    if not files_included:
        return None, "None of the expected project files were found on disk."
    zip_bytes = zip_buf.getvalue()
    zip_filename = f"{GITHUB_PUBLISH_ZIP_BASENAME}_v{version}.zip"

    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
    }
    api_base = f"https://api.github.com/repos/{owner}/{name}"

    # Look up the branch's current tip commit, if the branch already
    # exists — a brand-new repo/branch won't have one yet, and that's
    # fine: we just create the first commit with no parent.
    parent_sha = None
    base_tree_sha = None
    try:
        ref_resp = requests.get(f"{api_base}/git/ref/heads/{branch}", headers=headers, timeout=15)
    except requests.exceptions.RequestException as e:
        return None, f"GitHub request failed: {e}"

    if ref_resp.status_code == 200:
        parent_sha = ref_resp.json()["object"]["sha"]
        try:
            commit_resp = requests.get(f"{api_base}/git/commits/{parent_sha}", headers=headers, timeout=15)
            commit_resp.raise_for_status()
            base_tree_sha = commit_resp.json()["tree"]["sha"]
        except requests.exceptions.RequestException as e:
            return None, f"Couldn't read the branch's current commit: {e}"
    elif ref_resp.status_code != 404:
        return None, f"GitHub API error looking up branch: {ref_resp.status_code} {ref_resp.text[:200]}"

    # The zip is the one blob in this commit — base_tree carries every
    # other existing file (including past versions' zips) forward
    # untouched, so nothing has to be deleted or re-uploaded.
    blob_payload = {"content": base64.b64encode(zip_bytes).decode("ascii"), "encoding": "base64"}
    try:
        blob_resp = requests.post(f"{api_base}/git/blobs", headers=headers, json=blob_payload, timeout=60)
    except requests.exceptions.RequestException as e:
        return None, f"GitHub request failed uploading {zip_filename}: {e}"
    if not blob_resp.ok:
        return None, f"GitHub API error uploading {zip_filename}: {blob_resp.status_code} {blob_resp.text[:200]}"

    tree_payload = {
        "tree": [{"path": zip_filename, "mode": "100644", "type": "blob", "sha": blob_resp.json()["sha"]}]
    }
    if base_tree_sha:
        tree_payload["base_tree"] = base_tree_sha
    try:
        tree_resp = requests.post(f"{api_base}/git/trees", headers=headers, json=tree_payload, timeout=30)
    except requests.exceptions.RequestException as e:
        return None, f"GitHub request failed creating tree: {e}"
    if not tree_resp.ok:
        return None, f"GitHub API error creating tree: {tree_resp.status_code} {tree_resp.text[:200]}"
    new_tree_sha = tree_resp.json()["sha"]

    message = (commit_message or "").strip() or f"Publish v{version} ({datetime.now().strftime('%Y-%m-%d %H:%M')})"
    commit_payload = {"message": message, "tree": new_tree_sha}
    if parent_sha:
        commit_payload["parents"] = [parent_sha]
    try:
        new_commit_resp = requests.post(f"{api_base}/git/commits", headers=headers, json=commit_payload, timeout=30)
    except requests.exceptions.RequestException as e:
        return None, f"GitHub request failed creating commit: {e}"
    if not new_commit_resp.ok:
        return None, f"GitHub API error creating commit: {new_commit_resp.status_code} {new_commit_resp.text[:200]}"
    new_commit_sha = new_commit_resp.json()["sha"]

    # Existing branch: fast-forward its ref. Brand-new branch: create the ref.
    if parent_sha:
        try:
            update_resp = requests.patch(
                f"{api_base}/git/refs/heads/{branch}", headers=headers, json={"sha": new_commit_sha}, timeout=15
            )
        except requests.exceptions.RequestException as e:
            return None, f"GitHub request failed updating branch ref: {e}"
    else:
        try:
            update_resp = requests.post(
                f"{api_base}/git/refs",
                headers=headers,
                json={"ref": f"refs/heads/{branch}", "sha": new_commit_sha},
                timeout=15,
            )
        except requests.exceptions.RequestException as e:
            return None, f"GitHub request failed creating branch ref: {e}"
    if not update_resp.ok:
        return None, f"GitHub API error updating branch: {update_resp.status_code} {update_resp.text[:200]}"

    # Remember this as the last version published, so the Settings tab
    # can suggest the next one (4.1 -> 4.2 -> ...) without you having to
    # track it yourself. Re-loads config in case something else changed
    # it since the top of this function (a slow push, a concurrent save).
    config = load_config()
    config["github_publish_last_version"] = version
    save_config(config)

    return {
        "commit_sha": new_commit_sha,
        "commit_url": f"https://github.com/{owner}/{name}/commit/{new_commit_sha}",
        "zip_filename": zip_filename,
        "zip_url": f"https://github.com/{owner}/{name}/blob/{branch}/{zip_filename}",
        "files_included": files_included,
        "files_missing": files_missing,
        "branch": branch,
        "version": version,
    }, None


@app.route("/")
def index():
    return render_template("index.html")


# --- Custom Widgets: API Reference ---
# A self-contained reference page (its own HTML/CSS/JS, no calls back into
# this app) documenting every external API call this toolkit makes —
# generated once by hand from app.py's own request-building code, not
# derived live at request time. If the API surface changes, this file
# needs to be regenerated and re-saved here; it isn't kept in sync
# automatically.
API_REFERENCE_DOWNLOAD_NAME = "airlock-api-reference.html"


@app.route("/api-reference")
def api_reference_view():
    return render_template("api_reference.html")


@app.route("/api-reference/export")
def api_reference_export():
    return send_from_directory(
        os.path.join(BASE_DIR, "templates"),
        "api_reference.html",
        as_attachment=True,
        download_name=API_REFERENCE_DOWNLOAD_NAME,
        mimetype="text/html",
    )


@app.route("/run", methods=["POST"])
def run_code():
    data = request.get_json(silent=True) or {}
    code = data.get("code", "")

    if not isinstance(code, str) or not code.strip():
        return jsonify({"error": "No code provided."}), 400

    # Write the submitted code to a temporary file and run it as a
    # separate process, so it can't crash or hang the server itself.
    tmp_dir = tempfile.gettempdir()
    filename = os.path.join(tmp_dir, f"snippet_{uuid.uuid4().hex}.py")

    try:
        with open(filename, "w") as f:
            f.write(code)

        try:
            result = subprocess.run(
                [sys.executable, filename],
                capture_output=True,
                text=True,
                timeout=EXECUTION_TIMEOUT,
            )
            return jsonify(
                {
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "exit_code": result.returncode,
                    "timed_out": False,
                }
            )
        except subprocess.TimeoutExpired as e:
            return jsonify(
                {
                    "stdout": e.stdout or "",
                    "stderr": (e.stderr or "") + f"\n[Execution stopped: exceeded {EXECUTION_TIMEOUT}s time limit]",
                    "exit_code": None,
                    "timed_out": True,
                }
            )
    finally:
        if os.path.exists(filename):
            os.remove(filename)


@app.route("/compile", methods=["POST"])
def compile_code():
    data = request.get_json(silent=True) or {}
    code = data.get("code", "")

    if not isinstance(code, str) or not code.strip():
        return jsonify({"success": False, "error": "No code provided."}), 400

    # Name the output using today's date and time, e.g. script_20260714_143205.exe
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    exe_basename = f"script_{timestamp}"

    with tempfile.TemporaryDirectory() as work_dir:
        script_path = os.path.join(work_dir, "source.py")
        with open(script_path, "w") as f:
            f.write(code)

        cmd = [
            sys.executable, "-m", "PyInstaller",
            "--onefile",
            "--noconfirm",
            "--distpath", BUILDS_DIR,
            "--workpath", work_dir,
            "--specpath", work_dir,
            "--name", exe_basename,
            script_path,
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=COMPILE_TIMEOUT,
            )
        except FileNotFoundError:
            return jsonify(
                {
                    "success": False,
                    "error": "PyInstaller isn't installed. Run: pip install pyinstaller",
                }
            ), 500
        except subprocess.TimeoutExpired:
            return jsonify(
                {
                    "success": False,
                    "error": f"Compilation timed out after {COMPILE_TIMEOUT}s.",
                }
            ), 500

        # PyInstaller only appends .exe automatically on Windows.
        produced_name = exe_basename + (".exe" if os.name == "nt" else "")
        produced_path = os.path.join(BUILDS_DIR, produced_name)
        built_ok = result.returncode == 0 and os.path.exists(produced_path)

        return jsonify(
            {
                "success": built_ok,
                "filename": produced_name if built_ok else None,
                "download_url": f"/download/{produced_name}" if built_ok else None,
                # Keep logs short — PyInstaller output can be very long.
                "stdout": result.stdout[-3000:],
                "stderr": result.stderr[-3000:],
                "exit_code": result.returncode,
            }
        )


@app.route("/download/<path:filename>")
def download(filename):
    return send_from_directory(BUILDS_DIR, filename, as_attachment=True)


def key_preview(value):
    return ("•" * 8 + value[-4:]) if value else ""


@app.route("/config", methods=["GET"])
def get_config():
    config = load_config()
    vt_key = config.get("vt_api_key", "")
    github_token = config.get("github_token", "")
    github_publish_token = config.get("github_publish_token", "")

    active_profile = get_active_airlock_profile(config)
    airlock_key = (active_profile.get("api_key") if active_profile else "") or ""

    profiles = config.get("airlock_profiles") or []
    profiles_out = [
        {
            "id": p.get("id"),
            "label": p.get("label", ""),
            "tenant": p.get("tenant", ""),
            "port": p.get("port", "") or str(DEFAULT_AIRLOCK_PORT),
            "has_key": bool(p.get("api_key")),
            "key_preview": key_preview(p.get("api_key", "")),
        }
        for p in profiles
    ]

    return jsonify(
        {
            "vt_api_key": {"has_key": bool(vt_key), "key_preview": key_preview(vt_key)},
            # Reflects the active Airlock connection (see airlock_profiles
            # below for the full saved list) — kept under these names for
            # backward compatibility with the Scripts tab's info display.
            "airlock_api_key": {"has_key": bool(airlock_key), "key_preview": key_preview(airlock_key)},
            "airlock_tenant": (active_profile.get("tenant") if active_profile else "") or "",
            "airlock_port": (active_profile.get("port") if active_profile else "") or "",
            "airlock_profiles": profiles_out,
            "active_airlock_profile_id": config.get("active_airlock_profile_id"),
            "active_airlock_profile_label": (active_profile.get("label") if active_profile else "") or "",
            "api_scripts_dir": config.get("api_scripts_dir", ""),
            "api_scripts_dir_resolved": get_scripts_dir(),
            "api_script_timeout": config.get("api_script_timeout", ""),
            "api_script_timeout_resolved": get_script_timeout(),
            "github_sync_enabled": (config.get("github_sync_enabled", "") or "").strip().lower() == "true",
            "github_repo": config.get("github_repo", ""),
            "github_branch": config.get("github_branch", ""),
            "github_subdir": config.get("github_subdir", ""),
            "github_token": {"has_key": bool(github_token), "key_preview": key_preview(github_token)},
            "github_publish_repo": config.get("github_publish_repo", ""),
            "github_publish_branch": config.get("github_publish_branch", ""),
            "github_publish_token": {"has_key": bool(github_publish_token), "key_preview": key_preview(github_publish_token)},
            "github_publish_last_version": config.get("github_publish_last_version", "") or GITHUB_PUBLISH_SEED_VERSION,
            "github_publish_suggested_next_version": suggest_next_publish_version(
                config.get("github_publish_last_version", "") or GITHUB_PUBLISH_SEED_VERSION
            ),
            # Defaults to true (on) when unset, matching this app's
            # behavior before the toggle existed.
            "logging_enabled": (config.get("logging_enabled") if config.get("logging_enabled") is not None else "true").strip().lower() == "true",
        }
    )


VALID_CONFIG_FIELDS = {
    "vt_api_key", "api_scripts_dir", "api_script_timeout",
    "github_sync_enabled", "github_repo", "github_branch", "github_subdir", "github_token",
    "github_publish_repo", "github_publish_branch", "github_publish_token",
    "logging_enabled",
}
SECRET_CONFIG_FIELDS = {"vt_api_key", "github_token", "github_publish_token"}


@app.route("/config", methods=["POST"])
def set_config():
    data = request.get_json(silent=True) or {}

    # Supports either a single {"field": ..., "value": ...} update, or a
    # batch {"fields": {"a": "...", "b": "..."}} update in one request.
    if "fields" in data and isinstance(data["fields"], dict):
        updates = data["fields"]
    elif "field" in data:
        updates = {data.get("field"): data.get("value", "")}
    else:
        return jsonify({"error": "No fields provided."}), 400

    if not updates:
        return jsonify({"error": "No fields provided."}), 400

    for field, value in updates.items():
        if field not in VALID_CONFIG_FIELDS:
            return jsonify({"error": f"Unknown field '{field}'."}), 400
        if not isinstance(value, str):
            return jsonify({"error": f"Value for '{field}' must be a string."}), 400

    if "github_sync_enabled" in updates and updates["github_sync_enabled"].strip().lower() not in ("true", "false"):
        return jsonify({"error": "github_sync_enabled must be 'true' or 'false'."}), 400

    if "logging_enabled" in updates and updates["logging_enabled"].strip().lower() not in ("true", "false"):
        return jsonify({"error": "logging_enabled must be 'true' or 'false'."}), 400

    if "api_script_timeout" in updates:
        timeout_val = updates["api_script_timeout"].strip()
        if timeout_val and not (timeout_val.isdigit() and int(timeout_val) > 0):
            return jsonify({"error": "api_script_timeout must be a whole number of seconds greater than 0."}), 400

    config = load_config()
    for field, value in updates.items():
        config[field] = value.strip()
    save_config(config)

    # Apply immediately — no restart needed to see the effect.
    if "logging_enabled" in updates:
        configure_logging(updates["logging_enabled"].strip().lower() == "true")

    response = {"saved": True}
    if len(updates) == 1:
        only_field = next(iter(updates))
        response["field"] = only_field
        if only_field in SECRET_CONFIG_FIELDS:
            response["key_preview"] = key_preview(config[only_field])
        if only_field == "api_scripts_dir":
            response["api_scripts_dir_resolved"] = get_scripts_dir()
        if only_field == "api_script_timeout":
            response["api_script_timeout_resolved"] = get_script_timeout()
    else:
        response["fields"] = list(updates.keys())
        secret_updates = {f: key_preview(config[f]) for f in updates if f in SECRET_CONFIG_FIELDS}
        if secret_updates:
            response["key_previews"] = secret_updates
        if "api_scripts_dir" in updates:
            response["api_scripts_dir_resolved"] = get_scripts_dir()
        if "api_script_timeout" in updates:
            response["api_script_timeout_resolved"] = get_script_timeout()

    return jsonify(response)


@app.route("/config/reveal", methods=["POST"])
def reveal_config_value():
    # Returns a saved secret's real value so the Settings tab can copy it
    # to the clipboard. Only ever called by an explicit user click on a
    # Copy button — never included in the regular masked /config GET.
    data = request.get_json(silent=True) or {}
    field = data.get("field", "")

    if field not in SECRET_CONFIG_FIELDS:
        return jsonify({"error": "Invalid field."}), 400

    config = load_config()
    value = config.get(field, "")
    if not value:
        return jsonify({"error": "No key saved."}), 404

    return jsonify({"value": value})


@app.route("/api_scripts", methods=["GET"])
def list_api_scripts():
    scripts_dir = get_scripts_dir()
    try:
        scripts = sorted(
            f for f in os.listdir(scripts_dir)
            if f.endswith(".py") and os.path.isfile(os.path.join(scripts_dir, f))
        )
    except OSError as e:
        return jsonify({"error": f"Couldn't read scripts folder: {e}", "scripts": [], "location": scripts_dir}), 500
    return jsonify({"scripts": scripts, "location": scripts_dir})


@app.route("/sync", methods=["POST"])
def sync_now():
    result = sync_github_scripts()
    if not result["synced"]:
        return jsonify({"success": False, "error": result.get("reason", "Sync failed.")}), 400
    return jsonify(
        {
            "success": True,
            "downloaded": result["downloaded"],
            "errors": result["errors"],
            "location": result["location"],
        }
    )


@app.route("/github/publish/files", methods=["GET"])
def github_publish_files():
    found, missing = collect_publish_files()
    return jsonify({"files": [p for p, _ in found], "missing": missing})


@app.route("/github/publish", methods=["POST"])
def github_publish():
    data_in = request.get_json(silent=True) or {}
    version = data_in.get("version", "")
    commit_message = data_in.get("message", "")
    if not isinstance(version, str):
        return jsonify({"error": "version must be a string."}), 400
    if not isinstance(commit_message, str):
        return jsonify({"error": "message must be a string."}), 400

    result, err = github_publish_push(version, commit_message=commit_message)
    if err:
        return jsonify({"error": err}), 400
    return jsonify({"success": True, **result})


@app.route("/api_scripts/run", methods=["POST"])
def run_api_script():
    data = request.get_json(silent=True) or {}
    # "script" holds the script name optionally followed by command-line
    # arguments, e.g. "report.py --user jdoe --verbose".
    raw_input_str = data.get("script", "")

    if not isinstance(raw_input_str, str) or not raw_input_str.strip():
        return jsonify({"error": "No script selected."}), 400

    try:
        tokens = shlex.split(raw_input_str.strip())
    except ValueError as e:
        return jsonify({"error": f"Couldn't parse arguments: {e}"}), 400

    if not tokens:
        return jsonify({"error": "No script selected."}), 400

    script_name, script_args = tokens[0], tokens[1:]

    safe_name = os.path.basename(script_name)
    if not safe_name.endswith(".py"):
        return jsonify({"error": "Invalid script name."}), 400

    exec_dir = get_scripts_dir()
    script_path = os.path.join(exec_dir, safe_name)
    if not os.path.isfile(script_path):
        return jsonify({"error": f"Script not found: {safe_name}"}), 404

    config = load_config()
    active_profile = get_active_airlock_profile(config)
    env = os.environ.copy()
    env["AIRLOCK_API_KEY"] = (active_profile.get("api_key") if active_profile else "") or ""
    env["AIRLOCK_TENANT"] = (active_profile.get("tenant") if active_profile else "") or ""
    env["AIRLOCK_PORT"] = ((active_profile.get("port") if active_profile else "") or "") or str(DEFAULT_AIRLOCK_PORT)
    env["VT_API_KEY"] = config.get("vt_api_key", "")

    # Snapshot existing xlsx/xml/html files beforehand (including
    # subfolders, since scripts often write into a folder they create)
    # so we can tell which one the script produced or updated.
    before_mtimes = {}
    try:
        for root, _dirs, files in os.walk(exec_dir):
            for f in files:
                if f.lower().endswith(OUTPUT_FILE_EXTENSIONS):
                    fp = os.path.join(root, f)
                    before_mtimes[fp] = os.path.getmtime(fp)
    except OSError:
        pass

    run_start = time.time()
    script_timeout = get_script_timeout()

    try:
        result = subprocess.run(
            [sys.executable, script_path, *script_args],
            capture_output=True,
            text=True,
            timeout=script_timeout,
            cwd=exec_dir,
            env=env,
        )
        response = {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "exit_code": result.returncode,
            "timed_out": False,
        }
    except subprocess.TimeoutExpired as e:
        response = {
            "stdout": e.stdout or "",
            "stderr": (e.stderr or "") + f"\n[Execution stopped: exceeded {script_timeout}s time limit]",
            "exit_code": None,
            "timed_out": True,
        }

    # Detect the output file, preferring a path the script explicitly
    # announced in its own console output (most reliable — works even
    # when the file lives in a subfolder the script just created).
    output_file = extract_output_path_from_text(response.get("stdout", ""), exec_dir)
    if not output_file:
        output_file = extract_output_path_from_text(response.get("stderr", ""), exec_dir)

    if not output_file:
        # Fall back to spotting a new or freshly-modified xlsx/xml/html
        # file anywhere under the scripts folder, including subfolders.
        try:
            candidates = []
            for root, _dirs, files in os.walk(exec_dir):
                for f in files:
                    if not f.lower().endswith(OUTPUT_FILE_EXTENSIONS):
                        continue
                    fp = os.path.join(root, f)
                    mtime = os.path.getmtime(fp)
                    is_new_or_updated = fp not in before_mtimes or mtime > before_mtimes[fp]
                    if is_new_or_updated and mtime >= run_start - 1:
                        candidates.append((mtime, fp))
            if candidates:
                candidates.sort(reverse=True)
                output_file = candidates[0][1]
        except OSError:
            pass

    if output_file:
        response["output_file"] = output_file
        response["output_filename"] = os.path.basename(output_file)

    return jsonify(response)


@app.route("/open_file", methods=["POST"])
def open_file():
    data = request.get_json(silent=True) or {}
    path = data.get("path", "")

    if not isinstance(path, str) or not path.strip():
        return jsonify({"success": False, "error": "No path provided."}), 400

    real_path = os.path.realpath(path)
    allowed_roots = [os.path.realpath(get_scripts_dir())]
    if not any(real_path == root or real_path.startswith(root + os.sep) for root in allowed_roots):
        return jsonify({"success": False, "error": "That file is outside the allowed scripts/output folders."}), 403

    if not os.path.isfile(real_path):
        return jsonify({"success": False, "error": "File not found."}), 404

    try:
        if os.name == "nt":
            os.startfile(real_path)  # noqa: os.startfile only exists on Windows
        elif sys.platform == "darwin":
            subprocess.run(["open", real_path], check=False)
        else:
            subprocess.run(["xdg-open", real_path], check=False)
        return jsonify({"success": True})
    except OSError as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/virustotal/upload", methods=["POST"])
def virustotal_upload():
    data = request.get_json(silent=True) or {}
    filename = data.get("filename", "")

    if not isinstance(filename, str) or not filename.strip():
        return jsonify({"success": False, "error": "No filename provided."}), 400

    # Prevent path traversal — only allow files that actually live in BUILDS_DIR.
    safe_name = os.path.basename(filename)
    file_path = os.path.join(BUILDS_DIR, safe_name)
    if not os.path.exists(file_path):
        return jsonify({"success": False, "error": f"File not found: {safe_name}"}), 404

    api_key = load_config().get("vt_api_key", "")
    if not api_key:
        return jsonify(
            {"success": False, "error": "No VirusTotal API key configured. Add one in the Settings tab."}
        ), 400

    headers = {"x-apikey": api_key}
    file_size = os.path.getsize(file_path)

    try:
        if file_size > VT_LARGE_FILE_THRESHOLD:
            # Files over 32MB need a dedicated upload URL first.
            resp = requests.get(VT_UPLOAD_URL_ENDPOINT, headers=headers, timeout=30)
            resp.raise_for_status()
            upload_url = resp.json()["data"]
        else:
            upload_url = VT_FILES_URL

        with open(file_path, "rb") as f:
            resp = requests.post(
                upload_url,
                headers=headers,
                files={"file": (safe_name, f, "application/octet-stream")},
                timeout=120,
            )

        if resp.status_code == 401:
            return jsonify({"success": False, "error": "VirusTotal rejected the API key (unauthorized)."}), 401
        if resp.status_code == 429:
            return jsonify({"success": False, "error": "VirusTotal rate limit / quota exceeded."}), 429
        resp.raise_for_status()

        analysis_id = resp.json()["data"]["id"]
        vt_url = f"https://www.virustotal.com/gui/file-analysis/{analysis_id}"

        return jsonify({"success": True, "analysis_id": analysis_id, "vt_url": vt_url})

    except requests.exceptions.RequestException as e:
        return jsonify({"success": False, "error": f"VirusTotal request failed: {e}"}), 502


# --- Airlock Digital connections (multiple tenant/key pairs) ---

@app.route("/airlock/profiles", methods=["GET"])
def airlock_profiles_list():
    config = load_config()
    profiles = config.get("airlock_profiles") or []
    result = [
        {
            "id": p.get("id"),
            "label": p.get("label", ""),
            "tenant": p.get("tenant", ""),
            "port": p.get("port", "") or str(DEFAULT_AIRLOCK_PORT),
            "has_key": bool(p.get("api_key")),
            "key_preview": key_preview(p.get("api_key", "")),
        }
        for p in profiles
    ]
    return jsonify({"profiles": result, "active_id": config.get("active_airlock_profile_id")})


@app.route("/airlock/profiles", methods=["POST"])
def airlock_profiles_add():
    data_in = request.get_json(silent=True) or {}
    label = (data_in.get("label") or "").strip()
    tenant = (data_in.get("tenant") or "").strip()
    port = (data_in.get("port") or "").strip()
    api_key = (data_in.get("api_key") or "").strip()

    if not label:
        return jsonify({"error": "A label is required."}), 400
    if not tenant:
        return jsonify({"error": "A tenant is required."}), 400
    if not api_key:
        return jsonify({"error": "An API key is required."}), 400
    if port and not (port.isdigit() and 1 <= int(port) <= 65535):
        return jsonify({"error": "Port must be a whole number between 1 and 65535."}), 400

    config = load_config()
    profiles = config.get("airlock_profiles") or []

    if any(p.get("label", "").strip().lower() == label.lower() for p in profiles):
        return jsonify({"error": f"A connection named '{label}' already exists."}), 400

    profile = {"id": str(uuid.uuid4()), "label": label, "tenant": tenant, "port": port, "api_key": api_key}
    profiles.append(profile)
    config["airlock_profiles"] = profiles
    # If this is the very first connection saved, make it active automatically.
    if not config.get("active_airlock_profile_id"):
        config["active_airlock_profile_id"] = profile["id"]
    save_config(config)

    return jsonify({"success": True, "id": profile["id"], "key_preview": key_preview(api_key)})


@app.route("/airlock/profiles/update", methods=["POST"])
def airlock_profiles_update():
    data_in = request.get_json(silent=True) or {}
    profile_id = (data_in.get("id") or "").strip()

    config = load_config()
    profiles = config.get("airlock_profiles") or []
    profile = next((p for p in profiles if p.get("id") == profile_id), None)
    if not profile:
        return jsonify({"error": "Connection not found."}), 404

    if "label" in data_in:
        new_label = (data_in.get("label") or "").strip()
        if not new_label:
            return jsonify({"error": "Label cannot be empty."}), 400
        if any(
            p.get("id") != profile_id and p.get("label", "").strip().lower() == new_label.lower() for p in profiles
        ):
            return jsonify({"error": f"A connection named '{new_label}' already exists."}), 400
        profile["label"] = new_label

    if "tenant" in data_in:
        new_tenant = (data_in.get("tenant") or "").strip()
        if not new_tenant:
            return jsonify({"error": "Tenant cannot be empty."}), 400
        profile["tenant"] = new_tenant

    if "port" in data_in:
        new_port = (data_in.get("port") or "").strip()
        if new_port and not (new_port.isdigit() and 1 <= int(new_port) <= 65535):
            return jsonify({"error": "Port must be a whole number between 1 and 65535."}), 400
        profile["port"] = new_port

    new_key = (data_in.get("api_key") or "").strip()
    if new_key:
        profile["api_key"] = new_key

    save_config(config)
    return jsonify({"success": True, "key_preview": key_preview(profile.get("api_key", ""))})


@app.route("/airlock/profiles/activate", methods=["POST"])
def airlock_profiles_activate():
    data_in = request.get_json(silent=True) or {}
    profile_id = (data_in.get("id") or "").strip()

    config = load_config()
    profiles = config.get("airlock_profiles") or []
    if not any(p.get("id") == profile_id for p in profiles):
        return jsonify({"error": "Connection not found."}), 404

    config["active_airlock_profile_id"] = profile_id
    save_config(config)
    return jsonify({"success": True})


@app.route("/airlock/profiles/delete", methods=["POST"])
def airlock_profiles_delete():
    data_in = request.get_json(silent=True) or {}
    profile_id = (data_in.get("id") or "").strip()

    config = load_config()
    profiles = config.get("airlock_profiles") or []
    remaining = [p for p in profiles if p.get("id") != profile_id]
    if len(remaining) == len(profiles):
        return jsonify({"error": "Connection not found."}), 404

    config["airlock_profiles"] = remaining
    if config.get("active_airlock_profile_id") == profile_id:
        config["active_airlock_profile_id"] = remaining[0]["id"] if remaining else None
    save_config(config)
    return jsonify({"success": True, "active_id": config.get("active_airlock_profile_id")})


@app.route("/airlock/profiles/reveal", methods=["POST"])
def airlock_profiles_reveal():
    # Mirrors /config/reveal's pattern, but scoped to one saved
    # connection's key rather than a single flat config field.
    data_in = request.get_json(silent=True) or {}
    profile_id = (data_in.get("id") or "").strip()

    config = load_config()
    profiles = config.get("airlock_profiles") or []
    profile = next((p for p in profiles if p.get("id") == profile_id), None)
    if not profile:
        return jsonify({"error": "Connection not found."}), 404

    key = profile.get("api_key", "")
    if not key:
        return jsonify({"error": "No key saved for this connection."}), 404

    return jsonify({"value": key})


# --- Custom Widgets: Partner Engagement Report (Cloud config) ---

@app.route("/cloud/config", methods=["GET"])
def cloud_config_get():
    cfg = get_cloud_admin_config()
    api_key = cfg.get("api_key", "")
    return jsonify(
        {
            "base_domain": cfg.get("base_domain", ""),
            "has_key": bool(api_key),
            "key_preview": key_preview(api_key),
        }
    )


@app.route("/cloud/config", methods=["POST"])
def cloud_config_set():
    data_in = request.get_json(silent=True) or {}
    base_domain = data_in.get("base_domain")
    api_key = data_in.get("api_key")

    cloud_cfg = load_cloud_config()
    cfg = cloud_cfg.get("cloud_admin") or {}

    if base_domain is not None:
        cfg["base_domain"] = base_domain.strip()
    if api_key is not None and api_key.strip():
        cfg["api_key"] = api_key.strip()

    cloud_cfg["cloud_admin"] = cfg
    save_cloud_config(cloud_cfg)

    return jsonify({"success": True, "base_domain": cfg.get("base_domain", ""), "key_preview": key_preview(cfg.get("api_key", ""))})


@app.route("/cloud/config/reveal", methods=["POST"])
def cloud_config_reveal():
    cfg = get_cloud_admin_config()
    key = cfg.get("api_key", "")
    if not key:
        return jsonify({"error": "No key saved."}), 404
    return jsonify({"value": key})


@app.route("/cloud/tenants", methods=["GET"])
def cloud_tenants_list():
    cloud_cfg = load_cloud_config()
    return jsonify({"tenants": cloud_cfg.get("cloud_tenants") or []})


@app.route("/cloud/tenants", methods=["POST"])
def cloud_tenants_add():
    data_in = request.get_json(silent=True) or {}
    label = (data_in.get("label") or "").strip()
    tenant_id = (data_in.get("tenant_id") or "").strip()
    directory_id = (data_in.get("directory_id") or "").strip()

    if not label:
        return jsonify({"error": "A label is required."}), 400
    if not tenant_id:
        return jsonify({"error": "A Tenant ID is required."}), 400
    if not directory_id:
        return jsonify({"error": "A Directory ID is required."}), 400

    cloud_cfg = load_cloud_config()
    tenants = cloud_cfg.get("cloud_tenants") or []

    if any(t.get("label", "").strip().lower() == label.lower() for t in tenants):
        return jsonify({"error": f"A tenant named '{label}' already exists."}), 400

    entry = {"id": str(uuid.uuid4()), "label": label, "tenant_id": tenant_id, "directory_id": directory_id}
    tenants.append(entry)
    cloud_cfg["cloud_tenants"] = tenants
    log.info("Adding NFR tenant '%s' (%s total after add)", label, len(tenants))
    save_cloud_config(cloud_cfg)

    return jsonify({"success": True, "id": entry["id"]})


@app.route("/cloud/tenants/update", methods=["POST"])
def cloud_tenants_update():
    data_in = request.get_json(silent=True) or {}
    entry_id = (data_in.get("id") or "").strip()

    cloud_cfg = load_cloud_config()
    tenants = cloud_cfg.get("cloud_tenants") or []
    entry = next((t for t in tenants if t.get("id") == entry_id), None)
    if not entry:
        return jsonify({"error": "Tenant not found."}), 404

    if "label" in data_in:
        new_label = (data_in.get("label") or "").strip()
        if not new_label:
            return jsonify({"error": "Label cannot be empty."}), 400
        if any(t.get("id") != entry_id and t.get("label", "").strip().lower() == new_label.lower() for t in tenants):
            return jsonify({"error": f"A tenant named '{new_label}' already exists."}), 400
        entry["label"] = new_label
    if "tenant_id" in data_in:
        new_tid = (data_in.get("tenant_id") or "").strip()
        if not new_tid:
            return jsonify({"error": "Tenant ID cannot be empty."}), 400
        entry["tenant_id"] = new_tid
    if "directory_id" in data_in:
        new_did = (data_in.get("directory_id") or "").strip()
        if not new_did:
            return jsonify({"error": "Directory ID cannot be empty."}), 400
        entry["directory_id"] = new_did

    save_cloud_config(cloud_cfg)
    return jsonify({"success": True})


@app.route("/cloud/tenants/delete", methods=["POST"])
def cloud_tenants_delete():
    data_in = request.get_json(silent=True) or {}
    entry_id = (data_in.get("id") or "").strip()

    cloud_cfg = load_cloud_config()
    tenants = cloud_cfg.get("cloud_tenants") or []
    remaining = [t for t in tenants if t.get("id") != entry_id]
    if len(remaining) == len(tenants):
        return jsonify({"error": "Tenant not found."}), 404

    cloud_cfg["cloud_tenants"] = remaining
    log.info("Removing NFR tenant %s (%s total after remove)", entry_id, len(remaining))
    save_cloud_config(cloud_cfg)
    return jsonify({"success": True})


# --- Custom Widgets: Training Instances ---

@app.route("/training/config", methods=["GET"])
def training_config_get():
    return jsonify(get_training_creation_settings())


@app.route("/training/config", methods=["POST"])
def training_config_set():
    data_in = request.get_json(silent=True) or {}
    directory_id = (data_in.get("directory_id") or "").strip()
    licence_raw = data_in.get("default_licence_allocation")
    baseline_full_name = (data_in.get("baseline_full_name") or "").strip()
    policy_group_name = (data_in.get("policy_group_name") or "").strip()
    instructor_full_name = (data_in.get("instructor_full_name") or "").strip()
    instructor_email = (data_in.get("instructor_email") or "").strip()
    # Optional (blank = skip the step). Newlines are kept — the console's
    # own field is multi-line — only outer whitespace is trimmed.
    block_notification_message = (data_in.get("block_notification_message") or "").strip()

    if not directory_id:
        return jsonify({"error": "A Directory ID is required."}), 400
    if not re.match(r"^[0-9a-fA-F]{24}$", directory_id):
        return jsonify({"error": "Directory ID must be a 24-character hexadecimal object ID."}), 400
    try:
        licence = int(licence_raw)
        if licence <= 0:
            raise ValueError()
    except (TypeError, ValueError):
        return jsonify({"error": "Default licence allocation must be a positive whole number."}), 400
    # Blank just means "use the built-in default" (DEFAULT_TRAINING_BASELINE_FULL_NAME,
    # applied in get_training_creation_settings) — not an error, so existing
    # configs/tests that only ever set directory_id + licence keep working.
    if not baseline_full_name:
        baseline_full_name = DEFAULT_TRAINING_BASELINE_FULL_NAME
    if not policy_group_name:
        policy_group_name = DEFAULT_TRAINING_POLICY_GROUP_NAME
    # Instructor name/email are optional, unlike baseline/policy name —
    # there's no sensible generic default for "whose account should be
    # added to every tenant". Blank just skips that automatic step (see
    # cloud_provision_instructor_access). If an email IS given, a minimal
    # sanity check avoids a typo silently failing on every future tenant.
    if instructor_email and "@" not in instructor_email:
        return jsonify({"error": "Instructor email doesn't look like a valid email address."}), 400
    if len(block_notification_message) > BLOCK_NOTIFICATION_MESSAGE_MAX_LENGTH:
        return jsonify({"error": f"Blocked-file notification message must be {BLOCK_NOTIFICATION_MESSAGE_MAX_LENGTH} characters or fewer."}), 400

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        training_cfg["creation_directory_id"] = directory_id
        training_cfg["default_licence_allocation"] = licence
        training_cfg["baseline_full_name"] = baseline_full_name
        training_cfg["policy_group_name"] = policy_group_name
        training_cfg["instructor_full_name"] = instructor_full_name
        training_cfg["instructor_email"] = instructor_email
        training_cfg["block_notification_message"] = block_notification_message
        save_training_config(training_cfg)

    return jsonify({
        "success": True,
        "directory_id": directory_id,
        "default_licence_allocation": licence,
        "baseline_full_name": baseline_full_name,
        "policy_group_name": policy_group_name,
        "instructor_full_name": instructor_full_name,
        "instructor_email": instructor_email,
        "block_notification_message": block_notification_message,
    })


@app.route("/training/directory-licence", methods=["GET"])
def training_directory_licence_get():
    settings = get_training_creation_settings()
    directory_id = settings["directory_id"]
    if not directory_id:
        return jsonify({"error": "No Directory ID configured yet — set one under Tenant creation settings above."}), 400
    allocated, err = cloud_get_license_allocation("", directory_id)
    if err:
        return jsonify({"error": err}), 502
    # Capacity is a separate call (directory-search) and kept independent of
    # the allocated count above — same "never let one data point's failure
    # block another" convention as cloud_collect_tenant_data — so a capacity
    # lookup failure still lets the "allocated" number show on its own.
    capacity, capacity_err = cloud_get_directory_licence_capacity(directory_id)
    return jsonify({"allocated": allocated, "capacity": capacity, "capacity_error": capacity_err})


def _find_known_training_tenant_id(training_cfg):
    """Reference-baseline browsing needs SOME tenant_id to authenticate
    with (cloud_list_reference_baselines uses the same UserApiKey/tenantID
    auth style as every other webfe call here), even though the catalog
    itself isn't tenant-specific. Prefers a student whose tenant reached
    "completed" (most likely to actually have working baseline-view
    access by now, per the role-propagation-delay history above), falling
    back to any tenant_id at all. Returns "" if this app hasn't created
    any tenant yet."""
    fallback = ""
    for klass in training_cfg.get("classes") or []:
        for student in klass.get("students") or []:
            tid = student.get("tenant_id")
            if not tid:
                continue
            if student.get("status") == "completed":
                return tid
            if not fallback:
                fallback = tid
    return fallback


@app.route("/training/reference-baselines", methods=["GET"])
def training_reference_baselines_get():
    """Two-level browse data for the Settings picker: a family list (see
    _baseline_family) plus each family's own specific baselines, so
    picking a reference baseline out of the ~180-entry catalog means two
    short dropdowns (family, then baseline) instead of one screen-filling
    wall of buttons — Ryan's own request, after the first version of this
    picker (one button per OperatingSystem) turned out to render 70+
    buttons because Linux distros version much more granularly than
    Windows does. See PROJECT_SUMMARY.md for the full story."""
    settings = get_training_creation_settings()
    directory_id = settings["directory_id"]
    if not directory_id:
        return jsonify({"error": "No Directory ID configured yet — set one under Tenant creation settings above."}), 400

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        known_tenant_id = _find_known_training_tenant_id(training_cfg)

        # The catalog cache lives in its own file (baselines.json), not
        # training_config.json — Ryan's normal workflow is to delete every
        # training tenant after a class and start the next one from
        # scratch, and the catalog should keep serving the picker from
        # disk regardless of what happens to tenant tracking. One-time
        # migration: an older build of this app kept the cache inside
        # training_config.json under "cached_reference_baselines" — lift
        # it into baselines.json the first time this runs, then forget it
        # ever lived there.
        legacy_cached = training_cfg.pop("cached_reference_baselines", None)
        if legacy_cached:
            save_training_config(training_cfg)
            if not os.path.exists(BASELINES_CACHE_PATH):
                save_baselines_cache(legacy_cached)

        # Try with no tenant context first — some webfe calls in this app
        # (tenant-user-create) accept an inherited directory-level role in
        # place of a tenant-level one, so this may just work. If not, retry
        # against any tenant this app has already created, since the catalog
        # itself is confirmed NOT tenant-specific (same ~180 entries either
        # way) — only the auth check might need a real tenant to check against.
        baselines, err = cloud_list_reference_baselines("", directory_id)
        if err and known_tenant_id:
            baselines, err = cloud_list_reference_baselines(known_tenant_id, directory_id)

        cached_at = None
        if err:
            # No tenant currently exists to authenticate this specific
            # lookup with (common right after Training Instances' "Delete
            # all tenants" — or any delete — since a deleted tenant no
            # longer lingers in tracking to serve as an auth anchor once
            # it's gone; see _prune_deleted_training_students). Rather than
            # leave the baseline picker dead until the next tenant finishes
            # provisioning, fall back to whatever catalog was last fetched
            # successfully — the catalog itself isn't tenant-specific (same
            # ~180 entries either way), and barely changes month to month,
            # so a slightly stale copy is still accurate unless Airlock has
            # since published a new monthly build.
            cached = load_baselines_cache()
            if isinstance(cached, dict) and isinstance(cached.get("baselines"), list) and cached["baselines"]:
                baselines = cached["baselines"]
                cached_at = cached.get("fetched_at")
                err = None
            elif not known_tenant_id:
                # Swap the raw Cloud API error dump for a plain, friendly
                # explanation — the underlying 403 is expected here (no
                # tenant exists yet to authenticate the lookup with) and
                # isn't useful to show verbatim.
                err = "No baseline catalog available yet — create at least one class first, then reload this list."

        if err:
            return jsonify({"error": err}), 502

        if cached_at is None:
            # A fresh, successful live fetch — remember it in baselines.json
            # so the picker keeps working (from disk, no tenant required)
            # even after every tenant that could authenticate it is gone.
            save_baselines_cache({
                "baselines": baselines,
                "fetched_at": datetime.now(timezone.utc).isoformat(),
            })

    grouped = cloud_group_baselines_by_family(baselines)
    families = sorted(grouped.keys())
    baselines_by_family = {
        family: [{"full_name": e.get("FullName"), "label": _format_baseline_label(e)} for e in entries]
        for family, entries in grouped.items()
    }
    recommended_by_family = cloud_recommend_baseline_per_family(grouped)
    response = {
        "families": families,
        "baselines_by_family": baselines_by_family,
        "recommended_by_family": recommended_by_family,
    }
    if cached_at:
        response["cached_at"] = cached_at
    return jsonify(response)


@app.route("/training/classes", methods=["GET"])
def training_classes_list():
    with TRAINING_LOCK:
        training_cfg = load_training_config()
        if _prune_deleted_training_students(training_cfg):
            save_training_config(training_cfg)
    return jsonify({"classes": training_cfg.get("classes") or []})


@app.route("/training/classes", methods=["POST"])
def training_classes_create():
    data_in = request.get_json(silent=True) or {}
    class_name = (data_in.get("class_name") or "").strip()
    roster = data_in.get("roster") or []

    if not class_name:
        return jsonify({"error": "A class name is required."}), 400
    if not isinstance(roster, list) or not roster:
        return jsonify({"error": "Provide at least one roster row (name + email)."}), 400

    settings = get_training_creation_settings()
    directory_id = settings["directory_id"]
    if not directory_id:
        return jsonify({"error": "No Directory ID configured yet — set one under Tenant creation settings above."}), 400

    # Per-class licence override, auto-expiry, and description were removed
    # from the UI (Ryan: a class name is enough, auto-expiry didn't work in
    # practice) — every class now just uses the configured tenant licence
    # allocation, with no description or expiry set on the tenant.
    licence = settings["default_licence_allocation"]
    description = ""
    auto_expiry = ""

    cleaned_roster = []
    seen_emails = set()
    for row in roster:
        if not isinstance(row, dict):
            continue
        full_name = (row.get("full_name") or "").strip()
        email = (row.get("email") or "").strip()
        if not email:
            continue
        key = email.lower()
        if key in seen_emails:
            return jsonify({"error": f"Duplicate email in roster: {email}"}), 400
        seen_emails.add(key)
        cleaned_roster.append({"full_name": full_name, "email": email})

    if not cleaned_roster:
        return jsonify({"error": "No roster rows had an email address."}), 400

    students = []
    for person in cleaned_roster:
        students.append(
            {
                "id": str(uuid.uuid4()),
                "full_name": person["full_name"],
                "email": person["email"],
                "tenant_name": f"{class_name} — {person['full_name'] or person['email']}",
                "status": "pending",
                "job_id": None,
                "tenant_id": None,
                "error": None,
                "last_poll_error": None,
                "created_at": None,
                "completed_at": None,
                "instructor_access_status": None,
                "instructor_access_error": None,
                "instructor_access_created_at": None,
                "baseline_status": None,
                "baseline_error": None,
                "baseline_created_at": None,
                "policy_assign_status": None,
                "policy_assign_error": None,
                "policy_assign_created_at": None,
                "delete_status": None,
                "delete_error": None,
                "deleted_at": None,
            }
        )

    new_class = {
        "id": str(uuid.uuid4()),
        "class_name": class_name,
        "description": description,
        "licence_allocation": licence,
        "auto_expiry": auto_expiry or None,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "students": students,
    }

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        classes = training_cfg.get("classes") or []
        classes.append(new_class)
        training_cfg["classes"] = classes
        save_training_config(training_cfg)

        # Queue each student's tenant-creation job now (fast — just
        # schedules the job); the background scheduler thread polls them
        # to completion separately so this request doesn't block on
        # however long provisioning actually takes.
        for student in new_class["students"]:
            result, err = cloud_create_tenant(
                directory_id,
                student["tenant_name"],
                licence,
                [{"email": student["email"], "full_name": student["full_name"]}],
                description=description or None,
                auto_expiry=auto_expiry or None,
            )
            if err:
                student["status"] = "create_failed"
                student["error"] = err
                log.info("Training Instances: create failed for %s (%s): %s", student["email"], class_name, err)
                continue
            student["job_id"] = result["job_id"]
            student["tenant_id"] = result["tenant_id"]
            student["status"] = "polling"
            student["created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("Training Instances: queued tenant for %s (%s) -> job %s", student["email"], class_name, result["job_id"])

        save_training_config(training_cfg)

    return jsonify({"success": True, "class": new_class})


@app.route("/training/refresh", methods=["POST"])
def training_refresh():
    with TRAINING_LOCK:
        process_pending_training_jobs()
        training_cfg = load_training_config()
        if _prune_deleted_training_students(training_cfg):
            save_training_config(training_cfg)
    return jsonify({"classes": training_cfg.get("classes") or []})


@app.route("/training/classes/student/delete-tenant", methods=["POST"])
def training_student_delete_tenant():
    data_in = request.get_json(silent=True) or {}
    class_id = (data_in.get("class_id") or "").strip()
    student_id = (data_in.get("student_id") or "").strip()

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        directory_id = (training_cfg.get("creation_directory_id") or "").strip()
        classes = training_cfg.get("classes") or []
        target = next((c for c in classes if c.get("id") == class_id), None)
        if not target:
            return jsonify({"error": "Class not found."}), 404

        students = target.get("students") or []
        student = next((s for s in students if s.get("id") == student_id), None)
        if not student:
            return jsonify({"error": "Student not found."}), 404
        if student.get("delete_status") == "deleted":
            return jsonify({"error": "This tenant has already been deleted."}), 400
        if student.get("status") not in TRAINING_DELETABLE_STATUSES or not student.get("tenant_id"):
            return jsonify({"error": "This tenant isn't in a state that can be deleted (or was never created)."}), 400
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        ok, err = cloud_delete_tenant(directory_id, student["tenant_id"])
        if ok:
            student["delete_status"] = "deleted"
            student["delete_error"] = None
            student["deleted_at"] = datetime.now(timezone.utc).isoformat()
            log.info("Training Instances: deleted tenant for %s (%s)", student.get("email"), target.get("class_name"))
            # Once the tenant is actually gone in Airlock, drop the row from
            # tracking rather than leaving a "Deleted" entry sitting in the
            # list forever — and drop the class too if that was its last
            # student. This is the only path that ever removes a row; it
            # never runs before cloud_delete_tenant has actually succeeded.
            target["students"] = [s for s in students if s.get("id") != student_id]
            if not target["students"]:
                training_cfg["classes"] = [c for c in classes if c.get("id") != target.get("id")]
                log.info("Removed now-empty training class '%s' from tracking (every tenant deleted)", target.get("class_name"))
        else:
            student["delete_status"] = "delete_failed"
            student["delete_error"] = err
            log.info("Training Instances: delete failed for %s (%s): %s", student.get("email"), target.get("class_name"), err)

        save_training_config(training_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "student": student})


@app.route("/training/classes/student/retry-instructor-access", methods=["POST"])
def training_student_retry_instructor_access():
    """Manually (re)attempts granting the configured instructor account
    access to one student's tenant — for when the automatic post-creation
    attempt failed, was skipped because Settings didn't yet have an
    instructor name/email configured, or needs re-running after those
    were fixed. Shares cloud_provision_instructor_access with the
    automatic path in process_pending_training_jobs so behavior is
    identical either way."""
    data_in = request.get_json(silent=True) or {}
    class_id = (data_in.get("class_id") or "").strip()
    student_id = (data_in.get("student_id") or "").strip()

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        directory_id = (training_cfg.get("creation_directory_id") or "").strip()
        instructor_full_name = (training_cfg.get("instructor_full_name") or "").strip()
        instructor_email = (training_cfg.get("instructor_email") or "").strip()
        classes = training_cfg.get("classes") or []
        target = next((c for c in classes if c.get("id") == class_id), None)
        if not target:
            return jsonify({"error": "Class not found."}), 404

        students = target.get("students") or []
        student = next((s for s in students if s.get("id") == student_id), None)
        if not student:
            return jsonify({"error": "Student not found."}), 404
        if student.get("instructor_access_status") == "completed":
            return jsonify({"error": "Instructor access has already been granted on this tenant."}), 400
        if student.get("status") != "completed" or not student.get("tenant_id"):
            return jsonify({"error": "This tenant isn't in a state that can have instructor access granted (it must have finished provisioning)."}), 400
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400
        if not instructor_full_name or not instructor_email:
            return jsonify({"error": "No instructor name/email configured yet — set them under Tenant creation settings above."}), 400

        ok, err = cloud_provision_instructor_access(student["tenant_id"], directory_id, instructor_full_name, instructor_email)
        if ok:
            student["instructor_access_status"] = "completed"
            student["instructor_access_error"] = None
            student["instructor_access_created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("Training Instances: granted instructor access to tenant for %s (%s)", student.get("email"), target.get("class_name"))
        else:
            student["instructor_access_status"] = "error"
            student["instructor_access_error"] = err
            log.info("Training Instances: instructor access grant failed for %s (%s): %s", student.get("email"), target.get("class_name"), err)

        save_training_config(training_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "student": student})


@app.route("/training/classes/student/retry-baseline", methods=["POST"])
def training_student_retry_baseline():
    """Manually (re)attempts adding the configured reference baseline to
    one student's tenant — for when the automatic post-creation attempt
    failed (e.g. a transient Cloud API error, or the baseline name in
    Settings needed fixing first). Shares cloud_add_baseline_to_tenant
    with the automatic path in process_pending_training_jobs so behavior
    is identical either way."""
    data_in = request.get_json(silent=True) or {}
    class_id = (data_in.get("class_id") or "").strip()
    student_id = (data_in.get("student_id") or "").strip()

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        directory_id = (training_cfg.get("creation_directory_id") or "").strip()
        baseline_full_name = (training_cfg.get("baseline_full_name") or "").strip() or DEFAULT_TRAINING_BASELINE_FULL_NAME
        classes = training_cfg.get("classes") or []
        target = next((c for c in classes if c.get("id") == class_id), None)
        if not target:
            return jsonify({"error": "Class not found."}), 404

        students = target.get("students") or []
        student = next((s for s in students if s.get("id") == student_id), None)
        if not student:
            return jsonify({"error": "Student not found."}), 404
        if student.get("baseline_status") == "completed":
            return jsonify({"error": "A baseline has already been added to this tenant."}), 400
        if student.get("status") != "completed" or not student.get("tenant_id"):
            return jsonify({"error": "This tenant isn't in a state that can have a baseline added (it must have finished provisioning)."}), 400
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        ok, err = retry_on_role_propagation_delay(
            lambda: cloud_add_baseline_to_tenant(student["tenant_id"], directory_id, baseline_full_name)
        )
        if ok:
            student["baseline_status"] = "completed"
            student["baseline_error"] = None
            student["baseline_created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("Training Instances: added baseline '%s' to tenant for %s (%s)", baseline_full_name, student.get("email"), target.get("class_name"))
        else:
            student["baseline_status"] = "error"
            student["baseline_error"] = err
            log.info("Training Instances: baseline add failed for %s (%s): %s", student.get("email"), target.get("class_name"), err)

        save_training_config(training_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "student": student})


@app.route("/training/classes/student/retry-policy-assign", methods=["POST"])
def training_student_retry_policy_assign():
    """Manually (re)attempts assigning the tenant's (already-added)
    baseline to the configured policy group — for when the automatic
    post-baseline attempt failed (e.g. the policy group name in Settings
    needed fixing, or a transient Cloud API error). Requires the baseline
    step to have already succeeded — this step doesn't add a baseline
    itself, only assigns whichever one is newest on the tenant. Shares
    cloud_assign_baseline_to_policy with the automatic path in
    process_pending_training_jobs so behavior is identical either way."""
    data_in = request.get_json(silent=True) or {}
    class_id = (data_in.get("class_id") or "").strip()
    student_id = (data_in.get("student_id") or "").strip()

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        directory_id = (training_cfg.get("creation_directory_id") or "").strip()
        policy_group_name = (training_cfg.get("policy_group_name") or "").strip() or DEFAULT_TRAINING_POLICY_GROUP_NAME
        classes = training_cfg.get("classes") or []
        target = next((c for c in classes if c.get("id") == class_id), None)
        if not target:
            return jsonify({"error": "Class not found."}), 404

        students = target.get("students") or []
        student = next((s for s in students if s.get("id") == student_id), None)
        if not student:
            return jsonify({"error": "Student not found."}), 404
        if student.get("policy_assign_status") == "completed":
            return jsonify({"error": "The baseline has already been assigned to the policy group for this tenant."}), 400
        if student.get("baseline_status") != "completed" or not student.get("tenant_id"):
            return jsonify({"error": "This tenant doesn't have a baseline added yet — add or retry that first."}), 400
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        ok, err = retry_on_role_propagation_delay(
            lambda: cloud_assign_baseline_to_policy(student["tenant_id"], directory_id, policy_group_name)
        )
        if ok:
            student["policy_assign_status"] = "completed"
            student["policy_assign_error"] = None
            student["policy_assign_created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("Training Instances: assigned baseline to policy group '%s' for %s (%s)", policy_group_name, student.get("email"), target.get("class_name"))
        else:
            student["policy_assign_status"] = "error"
            student["policy_assign_error"] = err
            log.info("Training Instances: policy assign failed for %s (%s): %s", student.get("email"), target.get("class_name"), err)

        save_training_config(training_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "student": student})


@app.route("/training/classes/student/retry-block-notification", methods=["POST"])
def training_student_retry_block_notification():
    """Manually (re)applies the configured blocked-file notification
    message to one student's tenant ("<policy group> Enforced"). Unlike
    policy-assign, doesn't depend on the baseline steps — only on the
    tenant existing. Re-applying after success is allowed (e.g. the
    message was edited in Settings afterwards)."""
    data_in = request.get_json(silent=True) or {}
    class_id = (data_in.get("class_id") or "").strip()
    student_id = (data_in.get("student_id") or "").strip()

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        directory_id = (training_cfg.get("creation_directory_id") or "").strip()
        policy_group_name = (training_cfg.get("policy_group_name") or "").strip() or DEFAULT_TRAINING_POLICY_GROUP_NAME
        message = (training_cfg.get("block_notification_message") or "").strip()
        target = next((c for c in training_cfg.get("classes") or [] if c.get("id") == class_id), None)
        if not target:
            return jsonify({"error": "Class not found."}), 404
        student = next((s for s in target.get("students") or [] if s.get("id") == student_id), None)
        if not student:
            return jsonify({"error": "Student not found."}), 404
        if student.get("status") != "completed" or not student.get("tenant_id"):
            return jsonify({"error": "This tenant hasn't finished being created yet."}), 400
        if student.get("delete_status") == "deleted":
            return jsonify({"error": "This tenant has been deleted."}), 400
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400
        if not message:
            return jsonify({"error": "No blocked-file notification message is configured — set one under Tenant creation settings first."}), 400

        ok, err = apply_training_block_notification(student, directory_id, policy_group_name, message, target.get("class_name"))
        save_training_config(training_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "student": student})


@app.route("/training/classes/delete-tenants", methods=["POST"])
def training_class_delete_tenants():
    """Deletes every eligible (terminal-status, not-yet-deleted) tenant in
    one class in a single action — the "end of class" cleanup button.
    Never raises on one tenant's failure; every tenant is attempted and
    the per-tenant outcome is reported back."""
    data_in = request.get_json(silent=True) or {}
    class_id = (data_in.get("class_id") or "").strip()

    with TRAINING_LOCK:
        training_cfg = load_training_config()
        directory_id = (training_cfg.get("creation_directory_id") or "").strip()
        classes = training_cfg.get("classes") or []
        target = next((c for c in classes if c.get("id") == class_id), None)
        if not target:
            return jsonify({"error": "Class not found."}), 404
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        results = []
        for student in target.get("students") or []:
            if student.get("delete_status") == "deleted":
                continue
            if student.get("status") not in TRAINING_DELETABLE_STATUSES or not student.get("tenant_id"):
                continue

            ok, err = cloud_delete_tenant(directory_id, student["tenant_id"])
            if ok:
                student["delete_status"] = "deleted"
                student["delete_error"] = None
                student["deleted_at"] = datetime.now(timezone.utc).isoformat()
            else:
                student["delete_status"] = "delete_failed"
                student["delete_error"] = err
            results.append({"student_id": student.get("id"), "email": student.get("email"), "success": ok, "error": None if ok else err})

        # Now that every deletable tenant in this class has actually been
        # attempted against Airlock, drop the ones that succeeded out of
        # tracking (and the class itself, if that was every student in it)
        # — see _prune_deleted_training_students.
        _prune_deleted_training_students(training_cfg)
        save_training_config(training_cfg)

    return jsonify({"results": results})


@app.route("/training/classes/delete-all-tenants", methods=["POST"])
def training_delete_all_tenants():
    """Deletes every eligible (terminal-status, not-yet-deleted) tenant
    across every class in one action — the "clean up everything" button,
    for when several classes have piled up and all of them are over.
    Never raises on one tenant's failure; every tenant is attempted and
    the per-tenant outcome is reported back. A row is only ever dropped
    from tracking after cloud_delete_tenant has actually succeeded for
    it — never before — so a tenant can't be forgotten about while it
    still exists in Airlock; see _prune_deleted_training_students."""
    with TRAINING_LOCK:
        training_cfg = load_training_config()
        directory_id = (training_cfg.get("creation_directory_id") or "").strip()
        classes = training_cfg.get("classes") or []
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        results = []
        for target in classes:
            for student in target.get("students") or []:
                if student.get("delete_status") == "deleted":
                    continue
                if student.get("status") not in TRAINING_DELETABLE_STATUSES or not student.get("tenant_id"):
                    continue

                ok, err = cloud_delete_tenant(directory_id, student["tenant_id"])
                if ok:
                    student["delete_status"] = "deleted"
                    student["delete_error"] = None
                    student["deleted_at"] = datetime.now(timezone.utc).isoformat()
                else:
                    student["delete_status"] = "delete_failed"
                    student["delete_error"] = err
                results.append(
                    {
                        "class_id": target.get("id"),
                        "class_name": target.get("class_name"),
                        "student_id": student.get("id"),
                        "email": student.get("email"),
                        "success": ok,
                        "error": None if ok else err,
                    }
                )

        _prune_deleted_training_students(training_cfg)
        save_training_config(training_cfg)

    return jsonify({"results": results})


# --- SE Tools: NFR Provisioning ---
#
# Ryan's own framing: "similar to Provision Training Instances but instead
# of deploying multiple instances each with one user, it will be one
# instance with a list of multiple users added as local admins." So this
# reuses every piece of Training Instances' Cloud API plumbing above
# (cloud_create_tenant, cloud_poll_tenant_job, cloud_delete_tenant,
# cloud_add_baseline_to_tenant, cloud_assign_baseline_to_policy,
# retry_on_role_propagation_delay) unchanged — the only real difference is
# shape: one tenant per "create" call instead of one per roster row, with
# every administrator on that one tenant's Users list (cloud_create_tenant
# already supported a multi-item administrators list; Training just never
# had a reason to pass more than one), and no separate "grant instructor
# access" step, since the administrators are already Local Admins on the
# tenant the moment it's created.
#
# Deliberately NOT built: a live dropdown of every tenant that exists in
# the configured directory. Ryan asked for this "if possible" — no Cloud
# API call that lists tenants by directory has been captured anywhere in
# this app yet (NFR Tracking's own partner tenant list, the closest thing,
# is entered by hand, not fetched). The list below only ever shows tenants
# this widget itself created and is tracking, the same honest limitation
# NFR Tracking already has. If a live listing is wanted, it needs its own
# real browser-capture session against the Cloud console's directory/
# tenant list page first, the same way tenant-delete was captured — not a
# guessed endpoint.

@app.route("/nfr-provisioning/config", methods=["GET"])
def nfr_provisioning_config_get():
    return jsonify(get_nfr_provisioning_settings())


@app.route("/nfr-provisioning/config", methods=["POST"])
def nfr_provisioning_config_set():
    data_in = request.get_json(silent=True) or {}
    directory_id = (data_in.get("directory_id") or "").strip()
    licence_raw = data_in.get("default_licence_allocation")

    if not directory_id:
        return jsonify({"error": "A Directory ID is required."}), 400
    if not re.match(r"^[0-9a-fA-F]{24}$", directory_id):
        return jsonify({"error": "Directory ID must be a 24-character hexadecimal object ID."}), 400
    try:
        licence = int(licence_raw)
        if licence <= 0:
            raise ValueError()
    except (TypeError, ValueError):
        return jsonify({"error": "Default licence allocation must be a positive whole number."}), 400

    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        nfr_cfg["directory_id"] = directory_id
        nfr_cfg["default_licence_allocation"] = licence
        save_nfr_provisioning_config(nfr_cfg)

    settings = get_nfr_provisioning_settings()
    return jsonify({"success": True, **settings})


@app.route("/nfr-provisioning/directory-licence", methods=["GET"])
def nfr_provisioning_directory_licence_get():
    settings = get_nfr_provisioning_settings()
    directory_id = settings["directory_id"]
    if not directory_id:
        return jsonify({"error": "No Directory ID configured yet — set one under Tenant creation settings above."}), 400
    allocated, err = cloud_get_license_allocation("", directory_id)
    if err:
        return jsonify({"error": err}), 502
    capacity, capacity_err = cloud_get_directory_licence_capacity(directory_id)
    return jsonify({"allocated": allocated, "capacity": capacity, "capacity_error": capacity_err})


@app.route("/nfr-provisioning/directories", methods=["GET"])
def nfr_provisioning_directories_list():
    """Every directory the Cloud admin key can see, with a readable
    breadcrumb path, plus which ones are favorited — so a tenant can be
    provisioned under any folder, not just the one configured above (Ryan's
    own request, after starting out with NFR Provisioning hardcoded to one
    directory)."""
    settings = get_nfr_provisioning_settings()
    # Needs SOME directory_id to send as the X-ApiKey/DirectoryID header's
    # value (see cloud_list_directories) even though the result isn't
    # actually scoped by it — the configured NFR directory is as good a
    # value as any, but this call works even before one's been set, by
    # falling back to an all-zero placeholder.
    directory_id = settings["directory_id"] or "000000000000000000000000"

    directories, err = cloud_list_directories(directory_id)
    if err:
        return jsonify({"error": err}), 502

    paths = _build_directory_paths(directories)
    result = sorted(
        (
            {"id": d["ID"], "name": d.get("Name") or "(unnamed)", "parent_id": d.get("ParentDirectoryID"), "path": paths.get(d["ID"], d.get("Name"))}
            for d in directories
            if d.get("ID")
        ),
        key=lambda d: d["path"].lower(),
    )

    nfr_cfg = load_nfr_provisioning_config()
    favorite_ids = nfr_cfg.get("favorite_directory_ids") or []
    return jsonify({"directories": result, "favorite_ids": favorite_ids})


@app.route("/nfr-provisioning/directories/favorite", methods=["POST"])
def nfr_provisioning_directory_favorite_set():
    data_in = request.get_json(silent=True) or {}
    directory_id = (data_in.get("directory_id") or "").strip()
    favorite = bool(data_in.get("favorite"))

    if not directory_id:
        return jsonify({"error": "A directory_id is required."}), 400

    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        favorite_ids = nfr_cfg.get("favorite_directory_ids") or []
        if favorite and directory_id not in favorite_ids:
            favorite_ids.append(directory_id)
        elif not favorite and directory_id in favorite_ids:
            favorite_ids = [d for d in favorite_ids if d != directory_id]
        nfr_cfg["favorite_directory_ids"] = favorite_ids
        save_nfr_provisioning_config(nfr_cfg)

    return jsonify({"success": True, "favorite_ids": favorite_ids})


@app.route("/nfr-provisioning/tenants", methods=["GET"])
def nfr_provisioning_tenants_list():
    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        if _prune_deleted_nfr_tenants(nfr_cfg):
            save_nfr_provisioning_config(nfr_cfg)
    return jsonify({"tenants": nfr_cfg.get("tenants") or []})


@app.route("/nfr-provisioning/tenants", methods=["POST"])
def nfr_provisioning_tenants_create():
    """Creates one NFR tenant. Every subsequent action on it (poll, grant
    instructor access, add baseline, assign policy, delete) uses the
    directory_id recorded on the tenant itself, not whatever the widget's
    settings say at that later moment — see directory_id_override below.
    """
    data_in = request.get_json(silent=True) or {}
    tenant_name = (data_in.get("tenant_name") or "").strip()
    administrators_in = data_in.get("administrators") or []
    licence_raw = data_in.get("licence_allocation")
    # Which folder to provision under — picked from the directory picker
    # (nfr_provisioning_directories_list), not hardcoded to the widget's
    # one configured directory anymore (Ryan's own follow-up request).
    # Falls back to the configured directory when the picker didn't send
    # one, so older cached page state / a blank picker still works.
    parent_directory_id_in = (data_in.get("parent_directory_id") or "").strip()
    directory_id_override = (data_in.get("directory_id_override") or "").strip()
    create_subdirectory = bool(data_in.get("create_subdirectory"))
    directory_auto_expiry = (data_in.get("directory_auto_expiry") or "").strip()

    if not tenant_name:
        return jsonify({"error": "A tenant name is required."}), 400
    if not isinstance(administrators_in, list) or not administrators_in:
        return jsonify({"error": "Add at least one administrator (name + email)."}), 400
    if create_subdirectory and directory_id_override:
        return jsonify({"error": "Choose either creating a new sub-directory or a Directory ID override, not both."}), 400
    if parent_directory_id_in and not re.match(r"^[0-9a-fA-F]{24}$", parent_directory_id_in):
        return jsonify({"error": "Selected parent folder has an invalid Directory ID."}), 400
    if directory_id_override and not re.match(r"^[0-9a-fA-F]{24}$", directory_id_override):
        return jsonify({"error": "Directory ID override must be a 24-character hexadecimal object ID."}), 400

    settings = get_nfr_provisioning_settings()
    parent_directory_id = parent_directory_id_in or settings["directory_id"]
    if not parent_directory_id and not directory_id_override:
        return jsonify({"error": "No parent folder selected, and no Directory ID configured under Tenant creation settings to fall back to."}), 400

    # Licence allocation is a per-tenant field here (Ryan's own request —
    # "a field to allocate licenses to the new tenant"), unlike Training
    # where every class just uses one shared default. Blank/omitted falls
    # back to the configured default so the field doesn't have to be
    # filled in every time. Resolved before directory creation below since
    # a new sub-directory's own licence capacity is set to match.
    if licence_raw in (None, ""):
        licence = settings["default_licence_allocation"]
    else:
        try:
            licence = int(licence_raw)
            if licence <= 0:
                raise ValueError()
        except (TypeError, ValueError):
            return jsonify({"error": "Licence allocation must be a positive whole number."}), 400

    directory_auto_created = False
    if create_subdirectory:
        # Ryan's actual workflow: one sub-directory per NFR tenant, named
        # to match, created under the configured parent directory — see
        # cloud_create_directory's Phase 7 comment for what's confirmed
        # about this call and what isn't. Its Directory Administrator is
        # whichever account Training Instances' settings has configured as
        # instructor — the same account the baseline/policy steps below
        # already depend on having tenant-level access, so this doubles as
        # that account's entry point into everything under this directory.
        instructor_full_name = settings["instructor_full_name"]
        instructor_email = settings["instructor_email"]
        if not instructor_full_name or not instructor_email:
            return jsonify({
                "error": "Creating a sub-directory needs a Directory Administrator — "
                "set an instructor name/email under Provision Training Instances' Tenant creation settings first."
            }), 400
        if directory_auto_expiry and not re.match(r"^\d{4}-\d{2}-\d{2}$", directory_auto_expiry):
            return jsonify({"error": "Directory auto-expiry must be a date (YYYY-MM-DD)."}), 400

        new_directory_id, dir_err = cloud_create_directory(
            parent_directory_id, tenant_name, licence, instructor_full_name, instructor_email,
            auto_expiry_date=directory_auto_expiry or None,
        )
        if dir_err:
            return jsonify({"error": f"Failed to create sub-directory '{tenant_name}': {dir_err}"}), 502
        directory_id = new_directory_id
        directory_auto_created = True
        log.info("NFR Provisioning: created sub-directory '%s' -> %s", tenant_name, directory_id)
    elif directory_id_override:
        directory_id = directory_id_override
    else:
        directory_id = parent_directory_id

    administrators = []
    seen_emails = set()
    for row in administrators_in:
        if not isinstance(row, dict):
            continue
        full_name = (row.get("full_name") or "").strip()
        email = (row.get("email") or "").strip()
        if not email:
            continue
        key = email.lower()
        if key in seen_emails:
            return jsonify({"error": f"Duplicate email in administrators: {email}"}), 400
        seen_emails.add(key)
        administrators.append({"full_name": full_name, "email": email})

    if not administrators:
        return jsonify({"error": "No administrator rows had an email address."}), 400

    new_tenant = {
        "id": str(uuid.uuid4()),
        "tenant_name": tenant_name,
        "administrators": administrators,
        "licence_allocation": licence,
        "directory_id": directory_id,
        "directory_auto_created": directory_auto_created,
        "status": "pending",
        "job_id": None,
        "tenant_id": None,
        "error": None,
        "last_poll_error": None,
        "created_at": None,
        "completed_at": None,
        "instructor_access_status": None,
        "instructor_access_error": None,
        "instructor_access_created_at": None,
        "baseline_status": None,
        "baseline_error": None,
        "baseline_created_at": None,
        "policy_assign_status": None,
        "policy_assign_error": None,
        "policy_assign_created_at": None,
        "delete_status": None,
        "delete_error": None,
        "deleted_at": None,
    }

    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        tenants = nfr_cfg.get("tenants") or []
        tenants.append(new_tenant)
        nfr_cfg["tenants"] = tenants
        save_nfr_provisioning_config(nfr_cfg)

        # One tenant-creation job for every administrator at once — see the
        # section comment above for why this differs from Training's
        # one-job-per-roster-row loop.
        result, err = cloud_create_tenant(directory_id, tenant_name, licence, administrators)
        if err:
            new_tenant["status"] = "create_failed"
            new_tenant["error"] = err
            log.info("NFR Provisioning: create failed for '%s': %s", tenant_name, err)
        else:
            new_tenant["job_id"] = result["job_id"]
            new_tenant["tenant_id"] = result["tenant_id"]
            new_tenant["status"] = "polling"
            new_tenant["created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("NFR Provisioning: queued tenant '%s' -> job %s", tenant_name, result["job_id"])

        save_nfr_provisioning_config(nfr_cfg)

    return jsonify({"success": True, "tenant": new_tenant})


@app.route("/nfr-provisioning/refresh", methods=["POST"])
def nfr_provisioning_refresh():
    with NFR_PROVISION_LOCK:
        process_pending_nfr_jobs()
        nfr_cfg = load_nfr_provisioning_config()
        if _prune_deleted_nfr_tenants(nfr_cfg):
            save_nfr_provisioning_config(nfr_cfg)
    return jsonify({"tenants": nfr_cfg.get("tenants") or []})


@app.route("/nfr-provisioning/tenants/delete", methods=["POST"])
def nfr_provisioning_tenant_delete():
    data_in = request.get_json(silent=True) or {}
    tenant_row_id = (data_in.get("tenant_row_id") or "").strip()

    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        tenants = nfr_cfg.get("tenants") or []
        tenant = next((t for t in tenants if t.get("id") == tenant_row_id), None)
        if not tenant:
            return jsonify({"error": "Tenant not found."}), 404
        if tenant.get("delete_status") == "deleted":
            return jsonify({"error": "This tenant has already been deleted."}), 400
        if tenant.get("status") not in TRAINING_DELETABLE_STATUSES or not tenant.get("tenant_id"):
            return jsonify({"error": "This tenant isn't in a state that can be deleted (or was never created)."}), 400
        # Falls back to the widget's configured directory only for a tenant
        # created before per-tenant directory_id tracking existed — every
        # tenant created since always has its own.
        directory_id = (tenant.get("directory_id") or nfr_cfg.get("directory_id") or "").strip()
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        ok, err = cloud_delete_tenant(directory_id, tenant["tenant_id"])
        if ok:
            tenant["delete_status"] = "deleted"
            tenant["delete_error"] = None
            tenant["deleted_at"] = datetime.now(timezone.utc).isoformat()
            log.info("NFR Provisioning: deleted tenant '%s'", tenant.get("tenant_name"))
            # Same rule as Training: a row only ever leaves tracking after
            # its actual deletion has already succeeded — see
            # _prune_deleted_nfr_tenants.
            nfr_cfg["tenants"] = [t for t in tenants if t.get("id") != tenant_row_id]
        else:
            tenant["delete_status"] = "delete_failed"
            tenant["delete_error"] = err
            log.info("NFR Provisioning: delete failed for '%s': %s", tenant.get("tenant_name"), err)

        save_nfr_provisioning_config(nfr_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "tenant": tenant})


@app.route("/nfr-provisioning/tenants/delete-all", methods=["POST"])
def nfr_provisioning_tenants_delete_all():
    """Deletes every eligible (terminal-status, not-yet-deleted) NFR
    tenant in one action — same "clean up everything" convention as
    Training's "Delete all tenants" button. Never raises on one tenant's
    failure; every tenant is attempted and the per-tenant outcome is
    reported back."""
    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        tenants = nfr_cfg.get("tenants") or []

        results = []
        for tenant in tenants:
            if tenant.get("delete_status") == "deleted":
                continue
            if tenant.get("status") not in TRAINING_DELETABLE_STATUSES or not tenant.get("tenant_id"):
                continue
            directory_id = (tenant.get("directory_id") or nfr_cfg.get("directory_id") or "").strip()
            if not directory_id:
                results.append(
                    {"tenant_row_id": tenant.get("id"), "tenant_name": tenant.get("tenant_name"), "success": False, "error": "No Directory ID recorded for this tenant."}
                )
                continue

            ok, err = cloud_delete_tenant(directory_id, tenant["tenant_id"])
            if ok:
                tenant["delete_status"] = "deleted"
                tenant["delete_error"] = None
                tenant["deleted_at"] = datetime.now(timezone.utc).isoformat()
            else:
                tenant["delete_status"] = "delete_failed"
                tenant["delete_error"] = err
            results.append(
                {"tenant_row_id": tenant.get("id"), "tenant_name": tenant.get("tenant_name"), "success": ok, "error": None if ok else err}
            )

        _prune_deleted_nfr_tenants(nfr_cfg)
        save_nfr_provisioning_config(nfr_cfg)

    return jsonify({"results": results})


@app.route("/nfr-provisioning/tenants/retry-instructor-access", methods=["POST"])
def nfr_provisioning_tenant_retry_instructor_access():
    """Manually (re)attempts granting the configured instructor account
    access to one NFR tenant — for when the automatic post-creation
    attempt failed, was skipped because Training Instances' settings
    didn't have an instructor name/email configured yet, or needs
    re-running after those were fixed. This is the step that was missing
    entirely when "TestNFRfakecompany" first hit the baseline 403 — see
    process_pending_nfr_jobs' docstring."""
    data_in = request.get_json(silent=True) or {}
    tenant_row_id = (data_in.get("tenant_row_id") or "").strip()

    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        settings = get_nfr_provisioning_settings()
        instructor_full_name = settings["instructor_full_name"]
        instructor_email = settings["instructor_email"]
        tenants = nfr_cfg.get("tenants") or []
        tenant = next((t for t in tenants if t.get("id") == tenant_row_id), None)
        if not tenant:
            return jsonify({"error": "Tenant not found."}), 404
        if tenant.get("instructor_access_status") == "completed":
            return jsonify({"error": "Instructor access has already been granted on this tenant."}), 400
        if tenant.get("status") != "completed" or not tenant.get("tenant_id"):
            return jsonify({"error": "This tenant isn't in a state that can have instructor access granted (it must have finished provisioning)."}), 400
        directory_id = (tenant.get("directory_id") or nfr_cfg.get("directory_id") or "").strip()
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400
        if not instructor_full_name or not instructor_email:
            return jsonify({"error": "No instructor name/email configured yet — set them under Provision Training Instances' Tenant creation settings."}), 400

        ok, err = cloud_provision_instructor_access(tenant["tenant_id"], directory_id, instructor_full_name, instructor_email)
        if ok:
            tenant["instructor_access_status"] = "completed"
            tenant["instructor_access_error"] = None
            tenant["instructor_access_created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("NFR Provisioning: granted instructor access to tenant '%s'", tenant.get("tenant_name"))
        else:
            tenant["instructor_access_status"] = "error"
            tenant["instructor_access_error"] = err
            log.info("NFR Provisioning: instructor access grant failed for '%s': %s", tenant.get("tenant_name"), err)

        save_nfr_provisioning_config(nfr_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "tenant": tenant})


@app.route("/nfr-provisioning/tenants/retry-baseline", methods=["POST"])
def nfr_provisioning_tenant_retry_baseline():
    data_in = request.get_json(silent=True) or {}
    tenant_row_id = (data_in.get("tenant_row_id") or "").strip()

    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        settings = get_nfr_provisioning_settings()
        baseline_full_name = settings["baseline_full_name"]
        tenants = nfr_cfg.get("tenants") or []
        tenant = next((t for t in tenants if t.get("id") == tenant_row_id), None)
        if not tenant:
            return jsonify({"error": "Tenant not found."}), 404
        if tenant.get("baseline_status") == "completed":
            return jsonify({"error": "A baseline has already been added to this tenant."}), 400
        if tenant.get("status") != "completed" or not tenant.get("tenant_id"):
            return jsonify({"error": "This tenant isn't in a state that can have a baseline added (it must have finished provisioning)."}), 400
        directory_id = (tenant.get("directory_id") or nfr_cfg.get("directory_id") or "").strip()
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        ok, err = retry_on_role_propagation_delay(
            lambda: cloud_add_baseline_to_tenant(tenant["tenant_id"], directory_id, baseline_full_name)
        )
        if ok:
            tenant["baseline_status"] = "completed"
            tenant["baseline_error"] = None
            tenant["baseline_created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("NFR Provisioning: added baseline '%s' to tenant '%s'", baseline_full_name, tenant.get("tenant_name"))
        else:
            tenant["baseline_status"] = "error"
            tenant["baseline_error"] = err
            log.info("NFR Provisioning: baseline add failed for '%s': %s", tenant.get("tenant_name"), err)

        save_nfr_provisioning_config(nfr_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "tenant": tenant})


@app.route("/nfr-provisioning/tenants/retry-policy-assign", methods=["POST"])
def nfr_provisioning_tenant_retry_policy_assign():
    data_in = request.get_json(silent=True) or {}
    tenant_row_id = (data_in.get("tenant_row_id") or "").strip()

    with NFR_PROVISION_LOCK:
        nfr_cfg = load_nfr_provisioning_config()
        settings = get_nfr_provisioning_settings()
        policy_group_name = settings["policy_group_name"]
        tenants = nfr_cfg.get("tenants") or []
        tenant = next((t for t in tenants if t.get("id") == tenant_row_id), None)
        if not tenant:
            return jsonify({"error": "Tenant not found."}), 404
        if tenant.get("policy_assign_status") == "completed":
            return jsonify({"error": "The baseline has already been assigned to the policy group for this tenant."}), 400
        if tenant.get("baseline_status") != "completed" or not tenant.get("tenant_id"):
            return jsonify({"error": "This tenant doesn't have a baseline added yet — add or retry that first."}), 400
        directory_id = (tenant.get("directory_id") or nfr_cfg.get("directory_id") or "").strip()
        if not directory_id:
            return jsonify({"error": "No Directory ID configured."}), 400

        ok, err = retry_on_role_propagation_delay(
            lambda: cloud_assign_baseline_to_policy(tenant["tenant_id"], directory_id, policy_group_name)
        )
        if ok:
            tenant["policy_assign_status"] = "completed"
            tenant["policy_assign_error"] = None
            tenant["policy_assign_created_at"] = datetime.now(timezone.utc).isoformat()
            log.info("NFR Provisioning: assigned baseline to policy group '%s' for tenant '%s'", policy_group_name, tenant.get("tenant_name"))
        else:
            tenant["policy_assign_status"] = "error"
            tenant["policy_assign_error"] = err
            log.info("NFR Provisioning: policy assign failed for '%s': %s", tenant.get("tenant_name"), err)

        save_nfr_provisioning_config(nfr_cfg)

    return jsonify({"success": ok, "error": None if ok else err, "tenant": tenant})


# --- Custom Widgets: Timed Audit Mode ---

@app.route("/airlock/groups", methods=["GET"])
def airlock_groups():
    data, err = airlock_request("/v1/group")
    if err:
        return jsonify({"error": err, "groups": []}), 400

    # Be defensive about the exact response shape — normally it's
    # {"groups": [...]}, but fall back to finding any list in the
    # response, or treating the response itself as the list.
    if isinstance(data, dict):
        groups = data.get("groups")
        if groups is None:
            groups = next((v for v in data.values() if isinstance(v, list)), [])
    elif isinstance(data, list):
        groups = data
    else:
        groups = []

    result = []
    for g in groups:
        if not isinstance(g, dict):
            continue
        groupid = g.get("groupid") or g.get("id") or g.get("group_id")
        if not groupid:
            continue
        name = (
            g.get("name") or g.get("groupname") or g.get("group_name") or g.get("title")
            or f"(unnamed — {groupid[:8]})"
        )
        result.append({"groupid": groupid, "name": name})
    result.sort(key=lambda g: g["name"].lower())

    response = {"groups": result}
    if not result and groups:
        # Airlock returned data but nothing matched the fields we expect —
        # echo a raw sample so the mismatch is visible right in the widget
        # rather than requiring a look at the server's terminal log.
        first = groups[0]
        response["raw_sample"] = first if isinstance(first, dict) else str(first)
        log.warning("Airlock /v1/group returned data but no groups parsed. Raw sample: %s", first)

    return jsonify(response)


@app.route("/airlock/agents", methods=["POST"])
def airlock_agents():
    data_in = request.get_json(silent=True) or {}
    groupid = data_in.get("groupid", "").strip()
    if not groupid:
        return jsonify({"error": "No groupid provided.", "agents": []}), 400

    data, err = airlock_request("/v1/agent/find", {"groupid": groupid})
    if err:
        return jsonify({"error": err, "agents": []}), 400

    if isinstance(data, dict):
        agents = data.get("agents")
        if agents is None:
            agents = next((v for v in data.values() if isinstance(v, list)), [])
    elif isinstance(data, list):
        agents = data
    else:
        agents = []

    result = []
    for a in agents:
        if not isinstance(a, dict):
            continue
        agentid = a.get("agentid") or a.get("id")
        if not agentid:
            continue
        # Defensive filter: only include agents actually in the requested
        # group, in case the API doesn't filter server-side on this field.
        agent_groupid = a.get("groupid")
        if agent_groupid and agent_groupid != groupid:
            continue
        result.append(
            {
                "agentid": agentid,
                "hostname": a.get("hostname") or agentid,
                "username": a.get("username", ""),
                "os": a.get("os", ""),
            }
        )
    result.sort(key=lambda a: a["hostname"].lower())

    response = {"agents": result}
    if not result and agents:
        first = agents[0]
        response["raw_sample"] = first if isinstance(first, dict) else str(first)
        log.warning("Airlock /v1/agent/find returned data but no agents parsed. Raw sample: %s", first)

    return jsonify(response)


def process_due_audit_sessions():
    """Reverts any Timed Audit Mode session whose timer has expired.
    Also retries sessions stuck in 'revert_failed' from a prior attempt —
    a failed revert should keep being retried, not silently give up,
    since that would leave endpoints in audit mode indefinitely."""
    sessions = load_audit_sessions()
    now = datetime.now(timezone.utc)
    changed = False

    for s in sessions:
        if s.get("status") not in ("active", "revert_failed"):
            continue
        try:
            expires_at = datetime.fromisoformat(s["expires_at"])
        except (KeyError, ValueError, TypeError):
            continue
        if expires_at > now:
            continue

        ok, err = airlock_move_agents(s["source_groupid"], s["agent_ids"])
        changed = True
        if ok:
            s["status"] = "reverted"
            s["reverted_at"] = now.isoformat()
            s["revert_error"] = None
        else:
            s["status"] = "revert_failed"
            s["revert_error"] = err

    if changed:
        save_audit_sessions(sessions)


def audit_scheduler_loop():
    while True:
        try:
            process_due_audit_sessions()
        except Exception as e:  # noqa: broad except — this loop must never die
            print(f"[audit scheduler] error: {e}")
        time.sleep(20)


@app.route("/audit/sessions", methods=["GET"])
def audit_sessions_list():
    return jsonify({"sessions": load_audit_sessions()})


@app.route("/audit/start", methods=["POST"])
def audit_start():
    data_in = request.get_json(silent=True) or {}
    source_groupid = (data_in.get("source_groupid") or "").strip()
    source_group_name = (data_in.get("source_group_name") or "").strip() or source_groupid
    dest_groupid = (data_in.get("dest_groupid") or "").strip()
    dest_group_name = (data_in.get("dest_group_name") or "").strip() or dest_groupid
    agent_ids = data_in.get("agent_ids") or []
    agent_labels = data_in.get("agent_labels") or []
    duration_seconds = data_in.get("duration_seconds")

    if not source_groupid or not dest_groupid:
        return jsonify({"error": "Source and destination groups are required."}), 400
    if source_groupid == dest_groupid:
        return jsonify({"error": "Source and destination groups must be different."}), 400
    if not isinstance(agent_ids, list) or not agent_ids or not all(isinstance(a, str) and a for a in agent_ids):
        return jsonify({"error": "Select at least one agent to move."}), 400
    if not isinstance(duration_seconds, (int, float)) or duration_seconds <= 0:
        return jsonify({"error": "duration_seconds must be a positive number."}), 400

    ok, err = airlock_move_agents(dest_groupid, agent_ids)
    if not ok:
        return jsonify({"error": f"Move to '{dest_group_name}' failed: {err}"}), 502

    now = datetime.now(timezone.utc)
    session = {
        "id": str(uuid.uuid4()),
        "source_groupid": source_groupid,
        "source_group_name": source_group_name,
        "dest_groupid": dest_groupid,
        "dest_group_name": dest_group_name,
        "agent_ids": agent_ids,
        "agent_labels": agent_labels if len(agent_labels) == len(agent_ids) else agent_ids,
        "created_at": now.isoformat(),
        "expires_at": (now + timedelta(seconds=duration_seconds)).isoformat(),
        "status": "active",
        "revert_error": None,
        "reverted_at": None,
    }

    sessions = load_audit_sessions()
    sessions.append(session)
    save_audit_sessions(sessions)

    return jsonify({"success": True, "session": session})


@app.route("/audit/cancel", methods=["POST"])
def audit_cancel():
    data_in = request.get_json(silent=True) or {}
    session_id = (data_in.get("id") or "").strip()
    if not session_id:
        return jsonify({"error": "No session id provided."}), 400

    sessions = load_audit_sessions()
    session = next((s for s in sessions if s.get("id") == session_id), None)
    if not session:
        return jsonify({"error": "Session not found."}), 404
    if session.get("status") not in ("active", "revert_failed"):
        return jsonify({"error": f"Session is already '{session.get('status')}'."}), 400

    ok, err = airlock_move_agents(session["source_groupid"], session["agent_ids"])
    if not ok:
        session["status"] = "revert_failed"
        session["revert_error"] = err
        save_audit_sessions(sessions)
        return jsonify({"error": f"Revert failed: {err}"}), 502

    session["status"] = "reverted"
    session["reverted_at"] = datetime.now(timezone.utc).isoformat()
    session["revert_error"] = None
    save_audit_sessions(sessions)

    return jsonify({"success": True, "session": session})


# --- Custom Widgets: ISO 27001 Compliance Assessment ---

@app.route("/iso/mapping", methods=["GET"])
def iso_mapping_get():
    mapping, err = load_iso_mapping()
    if err:
        return jsonify({"error": err, "controls": []}), 500
    return jsonify(mapping)


CATEGORY_FULLY = "fully_compliant"
CATEGORY_PARTIAL = "partially_compliant"
CATEGORY_NON = "non_compliant"
CATEGORY_UNKNOWN = "not_assessed"

CATEGORY_LABELS = {
    CATEGORY_FULLY: "Fully Compliant",
    CATEGORY_PARTIAL: "Partially Compliant",
    CATEGORY_NON: "Non-Compliant",
    CATEGORY_UNKNOWN: "Not Assessed",
}
CATEGORY_COLORS = {
    CATEGORY_FULLY: "#1e7e34",
    CATEGORY_PARTIAL: "#b8860b",
    CATEGORY_NON: "#c53929",
    CATEGORY_UNKNOWN: "#6b6b70",
}


def categorize_group(controls):
    """Rolls up a group's per-control results into one overall bucket.
    Only controls with a definitive automated result (meets/partial/
    unmet) count toward this — 'manual' controls without a confirmed
    rule yet are excluded so an unscored control can't silently drag a
    group into 'non-compliant'."""
    scored = [c for c in controls if c.get("status") in (STATUS_MEETS, STATUS_PARTIAL, STATUS_UNMET)]
    if not scored:
        return CATEGORY_UNKNOWN
    if all(c["status"] == STATUS_MEETS for c in scored):
        return CATEGORY_FULLY
    if all(c["status"] == STATUS_UNMET for c in scored):
        return CATEGORY_NON
    return CATEGORY_PARTIAL


def get_group_agent_count(groupid):
    """Returns (count, error)."""
    data, err = airlock_request("/v1/agent/find", {"groupid": groupid})
    if err:
        return None, err
    # Some Airlock responses use an explicit null (not a missing key or
    # empty list) for "agents" when a group has zero agents — .get()'s
    # default only covers a missing key, so 'or []' is needed to also
    # catch the null case.
    agents = (data.get("agents") if isinstance(data, dict) else None) or []
    return len(agents), None


def build_svg_donut_chart(segments, size=220, stroke_width=34):
    """segments: list of (label, pct, color) tuples with pct in 0-100.
    Returns a self-contained SVG donut chart string — no external
    dependencies or network access needed, so it renders identically in
    the live dashboard and in a downloaded, offline HTML report."""
    segments = [s for s in segments if s[1] > 0]
    radius = (size - stroke_width) / 2
    cx = cy = size / 2

    if not segments:
        return (
            f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" xmlns="http://www.w3.org/2000/svg">'
            f'<circle cx="{cx}" cy="{cy}" r="{radius}" fill="none" stroke="#eceef2" stroke-width="{stroke_width}"/>'
            f"</svg>"
        )

    circumference = 2 * math.pi * radius
    parts = [f'<circle cx="{cx}" cy="{cy}" r="{radius}" fill="none" stroke="#eceef2" stroke-width="{stroke_width}"/>']
    offset = 0.0
    for _, pct, color in segments:
        dash = circumference * (pct / 100.0)
        gap = circumference - dash
        parts.append(
            f'<circle cx="{cx}" cy="{cy}" r="{radius}" fill="none" stroke="{color}" '
            f'stroke-width="{stroke_width}" stroke-dasharray="{dash:.2f} {gap:.2f}" '
            f'stroke-dashoffset="{-offset:.2f}" transform="rotate(-90 {cx} {cy})"/>'
        )
        offset += dash

    return f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" xmlns="http://www.w3.org/2000/svg">{"".join(parts)}</svg>'


def build_compliance_summary(group_results):
    """Rolls per-group categories up into endpoint-weighted percentages
    across the whole fleet, plus a ready-to-embed SVG chart."""
    totals = {CATEGORY_FULLY: 0, CATEGORY_PARTIAL: 0, CATEGORY_NON: 0, CATEGORY_UNKNOWN: 0}
    missing_agent_count = 0

    for g in group_results:
        count = g.get("agent_count")
        if count is None:
            missing_agent_count += 1
            continue
        category = g.get("category", CATEGORY_UNKNOWN)
        totals[category] = totals.get(category, 0) + count

    total_agents = sum(totals.values())

    segments = []
    for cat in (CATEGORY_FULLY, CATEGORY_PARTIAL, CATEGORY_NON, CATEGORY_UNKNOWN):
        count = totals[cat]
        pct = round((count / total_agents * 100), 1) if total_agents else 0.0
        segments.append(
            {
                "category": cat,
                "label": CATEGORY_LABELS[cat],
                "color": CATEGORY_COLORS[cat],
                "agent_count": count,
                "percent": pct,
            }
        )

    chart_svg = build_svg_donut_chart([(s["label"], s["percent"], s["color"]) for s in segments])

    return {
        "total_agents": total_agents,
        "groups_missing_agent_count": missing_agent_count,
        "segments": segments,
        "chart_svg": chart_svg,
    }


def run_iso_assessment():
    """Pulls every Airlock policy group, evaluates each against the ISO
    mapping, and returns (result_dict, error). error is a plain message
    if the group listing itself failed; per-group policy-fetch failures
    are instead recorded per-group in the result so one bad group
    doesn't block the whole assessment."""
    mapping, err = load_iso_mapping()
    if err:
        return None, err
    if not mapping.get("controls"):
        return None, f"{os.path.basename(ISO_MAPPING_PATH)} was found and is valid JSON, but has no controls defined."

    data, err = airlock_request("/v1/group")
    if err:
        return None, err

    groups = (data.get("groups") if isinstance(data, dict) else None) or []
    groups = [g for g in groups if isinstance(g, dict) and g.get("groupid")]

    group_results = []
    for g in groups:
        groupid = g["groupid"]
        name = g.get("name") or f"(unnamed — {groupid[:8]})"

        policy_data, policy_err = airlock_request("/v1/group/policies", {"groupid": groupid})
        if policy_err:
            group_results.append(
                {
                    "groupid": groupid,
                    "name": name,
                    "error": policy_err,
                    "controls": [],
                    "category": CATEGORY_UNKNOWN,
                    "agent_count": None,
                    "agent_count_error": None,
                }
            )
            continue

        controls = evaluate_group_against_mapping(policy_data or {}, mapping)
        category = categorize_group(controls)
        agent_count, agent_count_error = get_group_agent_count(groupid)

        group_results.append(
            {
                "groupid": groupid,
                "name": name,
                "error": None,
                "controls": controls,
                "category": category,
                "agent_count": agent_count,
                "agent_count_error": agent_count_error,
            }
        )

    summary = build_compliance_summary(group_results)

    return {"controls": mapping["controls"], "groups": group_results, "summary": summary}, None


@app.route("/iso/assessment", methods=["GET"])
def iso_assessment():
    result, err = run_iso_assessment()
    if err:
        return jsonify({"error": err}), 400
    return jsonify(result)


def build_iso_report_html(assessment):
    """Builds a self-contained HTML report summarizing the ISO
    assessment. Returns the HTML as a string — light-background and
    print-friendly, since this is meant to be handed to a client (and
    can be printed to PDF straight from the browser if needed)."""
    status_colors = {
        STATUS_MEETS: ("#1e7e34", "#e3f5ea"),
        STATUS_PARTIAL: ("#8a6d1b", "#fdf3d9"),
        STATUS_UNMET: ("#c53929", "#fbe6e3"),
        STATUS_UNKNOWN: ("#6b6b70", "#eceef2"),
        STATUS_ERROR: ("#6b6b70", "#eceef2"),
    }
    status_labels = {
        STATUS_MEETS: "Meets",
        STATUS_PARTIAL: "Partial",
        STATUS_UNMET: "Not met",
        STATUS_UNKNOWN: "Unknown",
        STATUS_ERROR: "Error",
    }

    def esc(value):
        return html.escape(str(value if value is not None else ""))

    def badge(status):
        color, bg = status_colors.get(status, status_colors[STATUS_UNKNOWN])
        label = status_labels.get(status, status)
        return f'<span class="badge" style="color:{color};background:{bg};">{esc(label)}</span>'

    controls = assessment.get("controls", [])
    groups = assessment.get("groups", [])
    summary = assessment.get("summary", {})

    category_colors = CATEGORY_COLORS
    category_labels = CATEGORY_LABELS

    def category_badge(category):
        color = category_colors.get(category, "#6b6b70")
        label = category_labels.get(category, category)
        return f'<span class="badge" style="color:#fff;background:{color};">{esc(label)}</span>'

    controls_html = "".join(
        f'<div class="control-summary">'
        f'<div class="control-summary-title">{esc(c.get("title"))} — {esc(c.get("name"))}</div>'
        f'<div class="control-summary-desc">{esc(c.get("description"))}</div>'
        f"</div>"
        for c in controls
    )

    group_blocks = []
    for g in groups:
        if g.get("error"):
            group_blocks.append(
                f'<div class="group-card"><div class="group-name">{esc(g.get("name"))}</div>'
                f'<div class="group-error">Couldn\'t assess this group: {esc(g.get("error"))}</div></div>'
            )
            continue

        agent_count = g.get("agent_count")
        agent_note = f"{agent_count} endpoint(s)" if agent_count is not None else "endpoint count unavailable"

        rows = "".join(
            f"<tr><td><strong>{esc(cr.get('title'))}</strong> — {esc(cr.get('name'))}"
            f'<div class="detail">{esc(cr.get("detail"))}</div></td>'
            f"<td>{badge(cr.get('status'))}</td></tr>"
            for cr in g.get("controls", [])
        )
        group_blocks.append(
            f'<div class="group-card">'
            f'<div class="group-name">{esc(g.get("name"))} {category_badge(g.get("category"))}</div>'
            f'<div class="group-meta">{esc(agent_note)}</div>'
            f"<table>{rows}</table></div>"
        )
    groups_html = "".join(group_blocks)

    chart_svg = summary.get("chart_svg", "")
    legend_html = "".join(
        f'<div class="legend-row"><span class="legend-swatch" style="background:{s["color"]};"></span>'
        f'{esc(s["label"])}: <strong>{s["percent"]}%</strong> ({s["agent_count"]} endpoint{"s" if s["agent_count"] != 1 else ""})</div>'
        for s in summary.get("segments", [])
    )
    missing = summary.get("groups_missing_agent_count", 0)
    missing_note = f" {missing} group(s) excluded — endpoint count unavailable." if missing else ""
    chart_section = f"""
  <h2>Endpoint compliance breakdown</h2>
  <div class="chart-row">
    <div class="chart-svg">{chart_svg}</div>
    <div class="chart-legend">
      {legend_html}
      <div class="chart-meta">Based on {summary.get("total_agents", 0)} managed endpoint(s) across {len(groups)} group(s).{esc(missing_note)}</div>
    </div>
  </div>
"""

    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ISO 27001 Alignment — Airlock Digital Policy Assessment</title>
<style>
  body {{
    font-family: -apple-system, "Segoe UI", Helvetica, Arial, sans-serif;
    background: #ffffff;
    color: #1e1e1e;
    max-width: 900px;
    margin: 40px auto;
    padding: 0 20px 60px;
    line-height: 1.5;
  }}
  h1 {{ font-size: 22px; margin-bottom: 4px; }}
  h2 {{ font-size: 17px; border-bottom: 1px solid #d0d0d5; padding-bottom: 6px; margin-top: 32px; }}
  .meta {{ color: #6b6b70; font-size: 13px; margin-bottom: 20px; }}
  .disclaimer {{
    background: #f4f4f5;
    border-left: 4px solid #5b9dff;
    padding: 12px 16px;
    font-size: 13px;
    color: #444;
    margin-bottom: 28px;
  }}
  .control-summary {{ margin-bottom: 14px; }}
  .control-summary-title {{ font-weight: 600; font-size: 14px; }}
  .control-summary-desc {{ color: #555; font-size: 13px; margin-top: 2px; }}
  .group-card {{
    border: 1px solid #d0d0d5;
    border-radius: 6px;
    padding: 16px 18px;
    margin-bottom: 16px;
    page-break-inside: avoid;
  }}
  .group-name {{ font-weight: 600; font-size: 15px; margin-bottom: 10px; }}
  .group-error {{ color: #c53929; font-size: 13px; }}
  .group-meta {{ color: #6b6b70; font-size: 12px; margin-bottom: 10px; }}
  .chart-row {{
    display: flex;
    align-items: center;
    gap: 28px;
    flex-wrap: wrap;
    margin-bottom: 8px;
  }}
  .chart-legend {{ flex: 1; min-width: 220px; }}
  .legend-row {{ display: flex; align-items: center; gap: 8px; font-size: 13px; margin-bottom: 6px; }}
  .legend-swatch {{ width: 12px; height: 12px; border-radius: 3px; flex-shrink: 0; }}
  .chart-meta {{ color: #6b6b70; font-size: 12px; margin-top: 8px; }}
  table {{ width: 100%; border-collapse: collapse; }}
  td {{ padding: 8px 4px; border-top: 1px solid #eceef2; font-size: 13px; vertical-align: top; }}
  tr:first-child td {{ border-top: none; }}
  .detail {{ color: #6b6b70; font-size: 12px; margin-top: 2px; }}
  .badge {{
    display: inline-block;
    font-size: 11px;
    font-weight: 600;
    padding: 3px 10px;
    border-radius: 10px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    white-space: nowrap;
  }}
  @media print {{
    body {{ margin: 0 auto; }}
    .group-card {{ break-inside: avoid; }}
  }}
</style>
</head>
<body>
  <h1>ISO 27001 Alignment — Airlock Digital Policy Assessment</h1>
  <div class="meta">Generated: {esc(generated_at)}</div>
  <div class="disclaimer">
    This report shows how Airlock Digital's policy configuration provides evidence toward
    specific ISO/IEC 27001:2022 Annex A controls. It covers only the subset of controls that
    an endpoint application-control product can speak to directly — it is not a substitute for
    a full ISMS audit, and does not by itself constitute or guarantee ISO 27001 certification.
  </div>
  {chart_section}
  <h2>Controls assessed</h2>
  {controls_html}

  <h2>Results by policy group</h2>
  {groups_html}
</body>
</html>
"""


@app.route("/iso/report", methods=["GET"])
def iso_report():
    result, err = run_iso_assessment()
    if err:
        return jsonify({"error": err}), 400

    try:
        html_report = build_iso_report_html(result)
    except Exception as e:
        return jsonify({"error": f"Couldn't generate report: {e}"}), 500

    filename = f"ISO27001_Airlock_Report_{datetime.now().strftime('%Y%m%d_%H%M')}.html"
    response = app.response_class(html_report, mimetype="text/html")
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


def build_cloud_partner_report_html(report_data):
    """Builds a self-contained HTML report summarizing partner tenant
    engagement/utilization across the Cloud multi-tenant environment.
    Opens directly in a browser tab rather than downloading, so this
    stays inline (no Content-Disposition: attachment)."""

    def esc(value):
        return html.escape(str(value if value is not None else ""))

    def fmt_date(iso_str):
        if not iso_str:
            return "Never"
        try:
            dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
            return dt.strftime("%Y-%m-%d %H:%M UTC")
        except (ValueError, TypeError):
            return str(iso_str)

    tenants = report_data.get("tenants", [])
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    summary_rows = []
    detail_sections = []

    for t in tenants:
        label = t.get("label", "")

        total_agents = t.get("client_count", 0)
        allocated = t.get("license_allocated")
        has_license_data = allocated is not None and not t.get("license_error")
        utilization = round((total_agents / allocated * 100), 1) if has_license_data and allocated else None
        users = t.get("users", [])
        last_logins = [u.get("last_accessed") for u in users if u.get("last_accessed")]
        most_recent = max(last_logins) if last_logins else ""

        agents_cell = str(total_agents) if not t.get("agents_error") else '<span class="error-cell">Error</span>'
        license_cell = (
            f"{total_agents}/{allocated}" if has_license_data else '<span class="error-cell">Unavailable</span>'
        )
        utilization_cell = f"{utilization}%" if utilization is not None else "—"
        users_cell = str(len(users)) if not t.get("users_error") else '<span class="error-cell">Error</span>'
        login_cell = esc(fmt_date(most_recent)) if not t.get("users_error") else "—"

        summary_rows.append(
            f"<tr>"
            f"<td>{esc(label)}</td>"
            f"<td>{agents_cell}</td>"
            f"<td>{t.get('enforce_count', 0)}</td>"
            f"<td>{t.get('audit_count', 0)}</td>"
            f"<td>{license_cell}</td>"
            f"<td>{utilization_cell}</td>"
            f"<td>{users_cell}</td>"
            f"<td>{login_cell}</td>"
            f"</tr>"
        )

        users_sorted = sorted(users, key=lambda u: u.get("last_accessed") or "", reverse=True)
        user_rows = "".join(
            f"<tr><td>{esc(u.get('full_name'))}</td><td>{esc(u.get('email'))}</td>"
            f"<td>{esc(fmt_date(u.get('last_accessed')))}</td></tr>"
            for u in users_sorted
        )

        error_notes = []
        if t.get("users_error"):
            error_notes.append(f"Users: {t['users_error']}")
        if t.get("agents_error"):
            error_notes.append(f"Agent counts: {t['agents_error']}")
        if t.get("license_error"):
            error_notes.append(f"License data: {t['license_error']}")
        if t.get("policy_errors"):
            error_notes.append("Policy breakdown: " + "; ".join(t["policy_errors"]))
        error_block = (
            "".join(f'<p class="error-cell">{esc(n)}</p>' for n in error_notes) if error_notes else ""
        )

        license_summary = f"{total_agents}/{allocated} licenses used ({utilization}%)" if has_license_data else "license data unavailable"

        detail_sections.append(
            f"""<details>
  <summary>{esc(label)} &mdash; {agents_cell if not t.get('agents_error') else '?'} agent(s), {len(users) if not t.get('users_error') else '?'} user(s)</summary>
  <div class="detail-body">
    <div class="detail-stats">
      <span><strong>{t.get('enforce_count', 0)}</strong> enforcing</span>
      <span><strong>{t.get('audit_count', 0)}</strong> audit-only</span>
      <span><strong>{t.get('unmanaged_count', 0)}</strong> unmanaged</span>
      <span>{esc(license_summary)}</span>
    </div>
    {error_block}
    <table>
      <thead><tr><th>User</th><th>Email</th><th>Last login</th></tr></thead>
      <tbody>{user_rows}</tbody>
    </table>
  </div>
</details>"""
        )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Partner Engagement &amp; Utilization Report</title>
<style>
  /* Same palette as the Partner Consulting Toolkit console itself,
     so this report feels like it came out of the same app. */
  :root {{
    --bg: #12173c;
    --panel: #1b2358;
    --border: #333e82;
    --text: #e8eaf6;
    --accent: #5b9dff;
    --muted: #8a91c4;
  }}
  body {{
    font-family: -apple-system, "Segoe UI", Helvetica, Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    max-width: 960px;
    margin: 40px auto;
    padding: 0 20px 60px;
    line-height: 1.5;
  }}
  h1 {{ font-size: 22px; margin-bottom: 4px; color: var(--text); }}
  h2 {{ font-size: 17px; border-bottom: 1px solid var(--border); padding-bottom: 6px; margin-top: 32px; color: var(--text); }}
  .meta {{ color: var(--muted); font-size: 13px; margin-bottom: 24px; }}
  table {{ width: 100%; border-collapse: collapse; margin-top: 12px; background: var(--panel); border-radius: 6px; overflow: hidden; }}
  th, td {{ padding: 8px 10px; border-top: 1px solid var(--border); font-size: 13px; text-align: left; vertical-align: top; }}
  thead th {{ border-top: none; border-bottom: 2px solid var(--accent); color: var(--text); background: rgba(91, 157, 255, 0.1); }}
  tr:first-child td {{ border-top: none; }}
  .error-cell {{ color: #ff8a8a; }}
  details {{
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 12px 16px;
    margin-bottom: 12px;
    background: var(--panel);
  }}
  summary {{ cursor: pointer; font-weight: 600; font-size: 14px; color: var(--text); }}
  summary::marker {{ color: var(--accent); }}
  .detail-body {{ margin-top: 12px; }}
  .detail-stats {{ display: flex; gap: 20px; flex-wrap: wrap; font-size: 13px; color: var(--muted); margin-bottom: 8px; }}
  .detail-stats strong {{ color: var(--accent); }}
  @media print {{
    :root {{
      --bg: #ffffff;
      --panel: #ffffff;
      --border: #d0d0d5;
      --text: #1e1e1e;
      --accent: #2f5fae;
      --muted: #6b6b70;
    }}
    body {{ margin: 0 auto; }}
    table {{ background: none; }}
    thead th {{ background: none; }}
    details {{ break-inside: avoid; background: none; }}
    details:not([open]) summary ~ * {{ display: block !important; }}
  }}
</style>
</head>
<body>
  <h1>Partner Engagement &amp; Utilization Report</h1>
  <div class="meta">Generated: {esc(generated_at)}</div>

  <h2>Summary</h2>
  <table>
    <thead>
      <tr><th>Tenant</th><th>Total agents</th><th>Enforce</th><th>Audit</th><th>Licenses used/allocated</th><th>Utilization</th><th>Users</th><th>Most recent login</th></tr>
    </thead>
    <tbody>
      {"".join(summary_rows)}
    </tbody>
  </table>

  <h2>Tenant detail</h2>
  {"".join(detail_sections)}
</body>
</html>
"""


def _cloud_report_fmt_date(iso_str):
    """Shared date formatting for the xlsx/xml exports — same behavior
    as the inline fmt_date() in build_cloud_partner_report_html."""
    if not iso_str:
        return "Never"
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M UTC")
    except (ValueError, TypeError):
        return str(iso_str)


def build_cloud_partner_report_workbook(report_data):
    """Builds an .xlsx workbook mirroring the HTML report: a Summary
    sheet across all tenants, plus one sheet per tenant with its full
    user list. Returns a BytesIO ready to hand to send_file()."""
    tenants = report_data.get("tenants", [])
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1B2358", end_color="1B2358", fill_type="solid")

    wb = Workbook()
    summary_ws = wb.active
    summary_ws.title = "Summary"

    summary_ws.append(["Partner Engagement & Utilization Report"])
    summary_ws["A1"].font = Font(bold=True, size=14)
    summary_ws.append([f"Generated: {generated_at}"])
    summary_ws.append([])

    headers = [
        "Tenant", "Total agents", "Enforce", "Audit", "Licenses used",
        "Licenses allocated", "Utilization %", "Users", "Most recent login", "Notes",
    ]
    header_row = summary_ws.max_row + 1
    summary_ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        cell = summary_ws.cell(row=header_row, column=col_idx)
        cell.font = header_font
        cell.fill = header_fill

    for t in tenants:
        total_agents = t.get("client_count", 0)
        allocated = t.get("license_allocated")
        has_license_data = allocated is not None and not t.get("license_error")
        utilization = round((total_agents / allocated * 100), 1) if has_license_data and allocated else None
        users = t.get("users", [])
        last_logins = [u.get("last_accessed") for u in users if u.get("last_accessed")]
        most_recent = max(last_logins) if last_logins else ""

        notes = []
        if t.get("users_error"):
            notes.append(f"Users: {t['users_error']}")
        if t.get("agents_error"):
            notes.append(f"Agent counts: {t['agents_error']}")
        if t.get("license_error"):
            notes.append(f"License data: {t['license_error']}")
        if t.get("policy_errors"):
            notes.append("Policy breakdown: " + "; ".join(t["policy_errors"]))

        summary_ws.append([
            t.get("label", ""),
            "Error" if t.get("agents_error") else total_agents,
            t.get("enforce_count", 0),
            t.get("audit_count", 0),
            total_agents if has_license_data else "Unavailable",
            allocated if has_license_data else "Unavailable",
            utilization if utilization is not None else "—",
            "Error" if t.get("users_error") else len(users),
            "—" if t.get("users_error") else _cloud_report_fmt_date(most_recent),
            "; ".join(notes),
        ])

    summary_ws.column_dimensions["A"].width = 24
    for col_idx, header in enumerate(headers[1:], start=2):
        summary_ws.column_dimensions[get_column_letter(col_idx)].width = max(14, len(header) + 4)
    summary_ws.column_dimensions[get_column_letter(len(headers))].width = 50

    # One sheet per tenant with the full user list — sheet names are
    # capped at 31 chars and can't collide, so sanitize and dedupe.
    used_sheet_names = {"Summary"}
    for t in tenants:
        label = t.get("label") or "Tenant"
        base_name = re.sub(r"[\[\]:*?/\\]", "_", label)[:31] or "Tenant"
        safe_name = base_name
        suffix = 2
        while safe_name in used_sheet_names:
            trim = 31 - len(f" ({suffix})")
            safe_name = f"{base_name[:trim]} ({suffix})"
            suffix += 1
        used_sheet_names.add(safe_name)

        ws = wb.create_sheet(title=safe_name)
        ws.append([f"{label} — Users"])
        ws["A1"].font = Font(bold=True, size=12)
        ws.append([])
        user_header_row = ws.max_row + 1
        ws.append(["Full name", "Email", "Last login"])
        for col_idx in range(1, 4):
            cell = ws.cell(row=user_header_row, column=col_idx)
            cell.font = header_font
            cell.fill = header_fill

        users_sorted = sorted(t.get("users", []), key=lambda u: u.get("last_accessed") or "", reverse=True)
        for u in users_sorted:
            ws.append([u.get("full_name", ""), u.get("email", ""), _cloud_report_fmt_date(u.get("last_accessed"))])

        if t.get("users_error"):
            ws.append([])
            ws.append([f"Users unavailable: {t['users_error']}"])

        ws.column_dimensions["A"].width = 28
        ws.column_dimensions["B"].width = 32
        ws.column_dimensions["C"].width = 22

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def build_cloud_partner_report_xml(report_data):
    """Builds an XML document mirroring the HTML/Excel reports — one
    <Tenant> element per partner tenant, with its users nested inside
    and any per-field errors called out explicitly rather than just
    omitted, same philosophy as the HTML report's error notes."""
    tenants = report_data.get("tenants", [])
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    root = ET.Element("PartnerEngagementReport", {"generated": generated_at})

    for t in tenants:
        total_agents = t.get("client_count", 0)
        allocated = t.get("license_allocated")
        has_license_data = allocated is not None and not t.get("license_error")
        utilization = round((total_agents / allocated * 100), 1) if has_license_data and allocated else None
        users = t.get("users", [])
        last_logins = [u.get("last_accessed") for u in users if u.get("last_accessed")]
        most_recent = max(last_logins) if last_logins else ""

        tenant_el = ET.SubElement(root, "Tenant", {
            "label": t.get("label", ""),
            "tenantId": t.get("tenant_id", ""),
            "directoryId": t.get("directory_id", ""),
        })

        ET.SubElement(tenant_el, "TotalAgents", {"error": "true" if t.get("agents_error") else "false"}).text = str(total_agents)
        ET.SubElement(tenant_el, "Enforce").text = str(t.get("enforce_count", 0))
        ET.SubElement(tenant_el, "Audit").text = str(t.get("audit_count", 0))

        license_el = ET.SubElement(tenant_el, "License", {"available": "true" if has_license_data else "false"})
        ET.SubElement(license_el, "Used").text = str(total_agents) if has_license_data else ""
        ET.SubElement(license_el, "Allocated").text = str(allocated) if has_license_data else ""
        ET.SubElement(license_el, "UtilizationPercent").text = "" if utilization is None else str(utilization)

        ET.SubElement(tenant_el, "MostRecentLogin").text = "" if t.get("users_error") else _cloud_report_fmt_date(most_recent)

        users_el = ET.SubElement(tenant_el, "Users", {"error": t.get("users_error") or ""})
        for u in sorted(users, key=lambda u: u.get("last_accessed") or "", reverse=True):
            user_el = ET.SubElement(users_el, "User")
            ET.SubElement(user_el, "FullName").text = u.get("full_name") or ""
            ET.SubElement(user_el, "Email").text = u.get("email") or ""
            ET.SubElement(user_el, "LastLogin").text = _cloud_report_fmt_date(u.get("last_accessed"))

        errors_el = ET.SubElement(tenant_el, "Errors")
        if t.get("agents_error"):
            ET.SubElement(errors_el, "Error", {"field": "agent_counts"}).text = t["agents_error"]
        if t.get("license_error"):
            ET.SubElement(errors_el, "Error", {"field": "license"}).text = t["license_error"]
        if t.get("users_error"):
            ET.SubElement(errors_el, "Error", {"field": "users"}).text = t["users_error"]
        for perr in t.get("policy_errors") or []:
            ET.SubElement(errors_el, "Error", {"field": "policy"}).text = perr

    raw = ET.tostring(root, encoding="unicode")
    pretty = minidom.parseString(raw).toprettyxml(indent="  ")
    # minidom's toprettyxml scatters blank lines between elements; drop
    # them so the output is clean without losing the indentation.
    return "\n".join(line for line in pretty.split("\n") if line.strip()) + "\n"


@app.route("/cloud/report/export/xlsx", methods=["POST"])
def cloud_report_export_xlsx():
    data_in = request.get_json(silent=True) or {}
    tenant_ids = data_in.get("tenant_ids")

    result, err = run_cloud_partner_report(tenant_ids=tenant_ids)
    if err:
        return jsonify({"error": err}), 400

    try:
        buf = build_cloud_partner_report_workbook(result)
    except Exception as e:
        return jsonify({"error": f"Couldn't generate Excel export: {e}"}), 500

    filename = f"Partner_Engagement_Report_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=filename,
    )


@app.route("/cloud/report/export/xml", methods=["POST"])
def cloud_report_export_xml():
    data_in = request.get_json(silent=True) or {}
    tenant_ids = data_in.get("tenant_ids")

    result, err = run_cloud_partner_report(tenant_ids=tenant_ids)
    if err:
        return jsonify({"error": err}), 400

    try:
        xml_report = build_cloud_partner_report_xml(result)
    except Exception as e:
        return jsonify({"error": f"Couldn't generate XML export: {e}"}), 500

    filename = f"Partner_Engagement_Report_{datetime.now().strftime('%Y%m%d_%H%M')}.xml"
    response = app.response_class(xml_report, mimetype="application/xml")
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


@app.route("/cloud/report", methods=["POST"])
def cloud_report():
    data_in = request.get_json(silent=True) or {}
    tenant_ids = data_in.get("tenant_ids")

    result, err = run_cloud_partner_report(tenant_ids=tenant_ids)
    if err:
        return jsonify({"error": err}), 400

    try:
        html_report = build_cloud_partner_report_html(result)
    except Exception as e:
        return jsonify({"error": f"Couldn't generate report: {e}"}), 500

    # Opens directly in a browser tab, unlike the ISO report's forced
    # download — no Content-Disposition header.
    return app.response_class(html_report, mimetype="text/html")


if __name__ == "__main__":
    # Apply the saved logging preference — configure_logging(True) ran
    # at import time as a safe default, this reflects whatever the user
    # actually last chose in Settings.
    _startup_config = load_config()
    _logging_pref = _startup_config.get("logging_enabled")
    configure_logging(True if _logging_pref is None else _logging_pref.strip().lower() == "true")

    # Print exactly where this instance reads/writes its config files —
    # the fastest way to catch a "running from the wrong folder" mixup,
    # which looks identical to a data-loss bug from the outside.
    print(f"[startup] Working directory: {BASE_DIR}")
    print(f"[startup] Main config: {CONFIG_PATH}")
    print(f"[startup] NFR Tracking config: {CLOUD_CONFIG_PATH}")

    # One-time migration for anyone upgrading from a single flat
    # Airlock tenant/key into the multi-connection system.
    migrate_legacy_airlock_profile()

    # One-time migration: NFR Tracking's admin credential and tenant
    # list used to live inside the main config.json — move them into
    # their own dedicated file.
    migrate_legacy_cloud_config()

    # One-time migration: Training Instances' old fixed-instance-list
    # design (Phase 1) is replaced by creating a new tenant per student —
    # archive whatever Phase 1 data exists rather than discarding it.
    migrate_legacy_training_instances()

    # If GitHub sync is enabled, pull the latest scripts down before serving
    # so the API Calls tab reflects the current repo state on startup.
    startup_sync = sync_github_scripts()
    if startup_sync.get("synced"):
        print(f"[startup sync] Pulled {len(startup_sync['downloaded'])} script(s) from {startup_sync['location']}")
    elif startup_sync.get("reason") not in ("disabled", "no repo configured"):
        print(f"[startup sync] Skipped: {startup_sync.get('reason')}")

    # Catch up on any Timed Audit Mode sessions that expired while the app
    # wasn't running, then start the background thread that watches for
    # future expirations.
    process_due_audit_sessions()
    threading.Thread(target=audit_scheduler_loop, daemon=True).start()

    # Start the background thread that polls in-flight Training Instances
    # tenant-creation jobs to completion (create_tenant.sh's Python
    # equivalent runs synchronously in the request; this is
    # poll_tenant_creation.sh's equivalent, running continuously).
    threading.Thread(target=training_scheduler_loop, daemon=True).start()

    # host="127.0.0.1" keeps this reachable only from your own machine.
    app.run(host="127.0.0.1", port=5000, debug=False)
