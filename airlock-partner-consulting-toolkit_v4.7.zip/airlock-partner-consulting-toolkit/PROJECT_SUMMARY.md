# Airlock Partner Consulting Toolkit — Project Summary

Read this first in a new conversation to get up to speed quickly. It covers what's
built, why it's built the way it is, and mistakes already made once — no need to
repeat them.

## What this is

A local Flask app (`app.py` + `templates/index.html`, single-page frontend) for an
Airlock Digital partner/consultant. Runs on `127.0.0.1:5000` only, single user,
plaintext local config files (deliberate — this is a personal tool, not multi-user
or internet-facing).

Lives at `Documents\airlock-partner-consulting-toolkit` (moved up one level from an
old `airlock-partner-consulting-toolkit_Migrate\airlock-partner-consulting-toolkit`
nesting on 2026-09-04 — just a folder rename/move, no code changes involved).

## Tabs / features, in the order they were built

1. **Editor** — run/compile Python snippets, upload compiled .exe to VirusTotal.
2. **Scripts** — run local Airlock Digital scripts with env vars
   (`AIRLOCK_API_KEY`/`TENANT`/`PORT`, `VT_API_KEY`) injected from the active
   connection. Auto-detects an output file from a script's own stdout
   (`HTML report:`, `Saved:`, etc.) and offers to open it.
3. **Custom Widgets** tab, tile-list-and-detail-panel UI (click a tile on the left,
   its content opens on the right):
   - **Timed Audit Mode** — move Airlock agents to an audit group temporarily,
     auto-revert on a timer (persists across app restarts).
   - **ISO 27001 Compliance** — evaluates policy groups against a small,
     *editable* set of ISO 27001 controls (`iso_mapping.json`), some with real
     automated rules, others explicitly marked `manual` (honest placeholders,
     not guessed logic). Produces a live dashboard plus a downloadable,
     self-contained HTML report with an endpoint-weighted SVG donut chart
     (weighted by agent count, not just group count).
   - **NFR Tracking** (originally "Partner Engagement Report") — pulls user
     activity, agent counts, audit/enforce split, and license utilization
     across partner tenants in Airlock's **Cloud multi-tenant API** — a
     completely different, undocumented API surface from the on-prem REST API
     the rest of the app uses. See "Cloud API reverse-engineering" below.
     The partner tenant list is collapsible (`<details>`, collapsed by
     default) with a live summary line (e.g. "12 tenants — 8 selected") so you
     don't have to scroll a long tenant list just to generate a report;
     Select all/none and the add-tenant form stay outside it. The generated
     report uses the app's own dark color palette (`--bg`/`--panel`/`--accent`
     etc., same values as `templates/index.html`) instead of plain white/black,
     with a light-theme override for `@media print` so it doesn't waste ink.
     Alongside "Generate report" (opens the HTML report in a new tab), two
     export buttons pull the same data as **Excel** (`.xlsx` — a Summary sheet
     across all tenants plus one sheet per tenant listing its users) or
     **XML** (`.xml` — a `<PartnerEngagementReport>` document with per-tenant
     `<Users>` and explicit `<Errors>` elements, so a failed data pull for one
     tenant is called out rather than silently dropped). All three formats are
     built from `run_cloud_partner_report()` in `app.py`, so they can never
     drift out of sync with each other.
   - **Training Instances** — creates a brand-new Airlock tenant per student
     for a class (Phase 2 design; replaced a Phase 1 design that
     pre-provisioned a fixed instance list and assigned users onto it — see
     "Where things stand" below). Ported from a working, standalone bash
     toolkit (`Airlock_Training_Tenant_Automation_v1`) already used against
     real Airlock AU/AM production. Reuses the same Cloud admin API key as
     NFR Tracking, but tenant creation authenticates with a different header
     pair (`X-ApiKey`/`DirectoryID`, not `UserApiKey`/`tenantID`). Creating a
     class queues one tenant-creation job per roster row
     (`directory/v1/tenant-create-schedule`); a background thread polls each
     job (`quevider/v1/job/{JobID}/status`) every 15 seconds to a terminal
     state, so the UI never has to block on however long provisioning takes.
     Tenant deletion (Phase 3, `directory/v1/tenant-delete`) is now wired up
     too — per student ("Delete tenant") or for a whole class at once
     ("Delete N tenants") once a tenant's creation reached a terminal state.
     It's permanent, always confirmed first, and sends exactly one tenant
     per call even though the payload accepts an array (see "Cloud API
     reverse-engineering" below for why). "Remove from list" stays a
     separate, non-destructive action that never touches Airlock.
     Baseline provisioning (Phase 4) is also wired up: the moment a
     tenant reaches `Completed`, the app automatically adds a configured
     reference baseline to it (`webfe/v1/tenant-baseline-reference-list`
     to fetch the catalog, `webfe/v1/tenant-baseline-reference-create` to
     add the match) — these two calls use the *same* `UserApiKey`
     auth style as NFR Tracking, unlike tenant create/delete/poll, which
     was confirmed (not assumed) from a real capture's `AccessLog`. The
     target baseline is a `FullName` string configurable under Tenant
     creation settings, since Airlock's catalog gets a new monthly-patch
     build periodically. A baseline failure is tracked independently of
     the tenant itself and can be retried per student without touching
     the tenant. Policy assignment (Phase 5) chains right after: once a
     baseline is added, the app resolves it to its tenant-scoped ID
     (`webfe/v1/tenant-baseline-list`), finds the target policy group's
     ID and Audit/Enforced children via the already-shipped
     `policy/v1/policy?limit=10000` call, then assigns it
     (`webfe/v1/tenant-policy-update-changes`) — same auth style again,
     this time confirmed straight from real request headers. The target
     policy group name is also configurable under Tenant creation
     settings (default `Workstations`, which Airlock auto-provisions on
     every new tenant). A policy-assign failure is tracked independently
     of both the baseline and the tenant, retriable on its own.
     Instructor access provisioning (Phase 6) runs first, before both of
     the above: a real-world test showed the automatic chain 403ing on
     every brand-new tenant, because Airlock only grants the calling
     account tenant-level roles the first time someone personally opens
     that tenant in the console. This step replicates that first-visit
     action automatically (`webfe/v1/tenant-user-group-list` to find the
     tenant's "LocalAdmin" group by name, `webfe/v1/tenant-user-create`
     to add the configured instructor to it — the same call the
     console's own "Add Me to Tenant" button fires), using a configurable
     **Instructor full name**/**Instructor email** under Tenant creation
     settings (blank skips the step rather than erroring). A real live
     test then showed the granted role doesn't take effect instantly —
     an automatic baseline-add right after a successful grant still
     403'd, but a manual retry moments later succeeded — so both the
     automatic chain and the manual retry routes now wrap the baseline-
     add and policy-assign calls in a small retry-with-delay helper
     (`retry_on_role_propagation_delay`) that only retries this specific,
     confirmed "Tenant Role(s) NOT Found" error shape, up to 3 times, 3
     seconds apart. See "Where things stand" below for the full story of
     how both of these were found. The "New class" form now only asks for a
     class name and a roster (per-class licence override, auto-expiry, and
     description were removed as unnecessary); "Tenant creation settings"
     shows a live "Licenses allocated: N of M available" descriptor above
     the (renamed) **Tenant license allocation** field — the "N" reuses the
     same Cloud API call NFR Tracking already used, and the "M" comes from
     a second, independent, genuinely read-only call (`directory-search`),
     each able to fail without blocking the other. The **Reference
     baseline (FullName)** field now has a "Suggested baselines" quick-pick
     row above it — the single most recently patched entry per OS, curated
     client-side from the full ~180-entry catalog this app already
     fetches, so browsing doesn't mean scrolling hundreds of entries; the
     field itself stays free-text for anything not in the curated list.
4. **Settings** tab — same tile-list-and-detail-panel UI as Custom Widgets
   (deliberately restructured to match it). Cards: VirusTotal API, Airlock API
   Settings (multi-connection manager), Script folder & execution, GitHub sync,
   **Publish to GitHub**, Logging.
   - **Publish to GitHub** is the opposite direction from GitHub sync — it
     pushes this app's own source *out* to a repo of your choice (same repo
     as sync, or a different one) instead of pulling scripts in. Packages a
     fixed, hand-maintained file list (`GITHUB_PUBLISH_FILES` in `app.py`:
     `app.py`, `templates/index.html`, `iso_mapping.json`, `README.md`,
     `PROJECT_SUMMARY.md`, `requirements.txt`, `run.bat`, `.gitignore`)
     into a single versioned zip (`airlock-partner-consulting-toolkit_v<version>.zip`,
     pushed to the repo root) rather than committing files individually —
     `config.json`, `cloud_config.json`, `training_config.json`, `venv/`,
     `builds/`, `api_scripts/`, and `audit_sessions.json` are structurally
     excluded, not just skipped by convention. The version number
     auto-increments from the last push but stays editable, and every past
     version is kept — a push never overwrites or deletes an older zip.
     Builds one commit via GitHub's Git Data API (blob → tree → commit →
     ref), and handles both an existing branch (fast-forward) and a
     brand-new repo/branch (no parent commit) the first time you publish
     into one. Needs a token with **write** access (classic `repo` scope,
     or fine-grained `Contents: Read and write`, on a repo actually
     included under that token's "Repository access") — a stricter
     requirement than GitHub sync's read-only, optional-for-public-repos
     token.

## Key design decisions

- **Multiple Airlock connections, not one.** Each saved connection bundles
  label + tenant + port + API key as one unit, so a key can never get paired
  with the wrong tenant. One is "active" at a time; switching it takes effect
  immediately across every widget, no restart. Switching from *either*
  Settings or the Scripts tab keeps both in sync, and notifies any
  already-opened widget (Timed Audit Mode, ISO) to refresh stale
  connection-dependent data rather than silently showing data from the
  previous connection.
- **Per-feature config files, not one shared blob.** `config.json` (core
  settings + Airlock connections), `cloud_config.json` (NFR Tracking's admin
  credential + tenant list — deliberately separated after a real persistence
  issue, see Pitfalls), `training_config.json` (Training Instances' own
  tenant-creation settings + class/student tracking), `iso_mapping.json` (ISO
  control rules, git-tracked, meant to be hand-edited), `audit_sessions.json`
  (Timed Audit Mode runtime state). All the *.json config files are
  pretty-printed (`indent=2`) so they're actually readable if someone opens
  them by hand.
- **Rule engine for ISO controls, not hardcoded logic.** `iso_mapping.json`
  defines controls declaratively (`field_equals`, `list_any_match`, `all_of`,
  `manual`); a control with no confirmed field mapping is `manual`, and shows
  as "unknown" rather than a fabricated pass/fail. Manual controls are
  excluded from the compliance-category rollup so an unscored control can't
  silently drag a group into "non-compliant."
- **Reports are self-contained HTML**, not PDF/Word — open in any browser,
  print-to-PDF if needed, no extra dependencies. ISO report downloads; NFR
  Tracking report opens directly in a new tab once data is ready (see
  Pitfalls — this was originally wrong). NFR Tracking additionally offers
  Excel and XML export of the same underlying data, for people who want to
  pivot/filter it or feed it into something else rather than just read it.
- **Logging is toggleable and dual-destination** — Settings → Logging turns
  terminal + rotating `app.log` (5MB, 3 backups) on/off together, live, no
  restart. On by default.

## Cloud API reverse-engineering (NFR Tracking widget)

This was the hardest part of the project — Airlock's Cloud multi-tenant
management API has essentially no public documentation. Found by manually
capturing browser Network tab traffic (Thunder Client for testing, HAR
export for bulk documentation) while using the actual web console.

**What was learned, for reference:**
- Auth: `UserApiKey` header (not `X-ApiKey`, that's the on-prem API), plus
  per-call `tenantID` and `Directoryid` headers. Directory ID is **not fixed**
  — it genuinely varies per partner tenant, confirmed on two different real
  tenants.
- URL shape: `https://<base_domain>/<module>/v1/<endpoint>`. At least four
  modules exist (`willard`, `webfe`, `policy`, `directory`), each hosting
  different endpoints — **the module isn't guessable from the endpoint name**.
  `directory-licence-allocation-list`'s module (`directory`) was wrongly
  assumed to be `webfe` initially and caused a real 404 bug in production use.
- **HTTP method is not consistent across endpoints** — some need GET, some
  need POST (even ones with no meaningful request body). Wrong-method calls
  return 405, which is easy to conflate with an auth problem if you're not
  looking closely.
- Sending more than one item in a batch-shaped request
  (`tenant-policy-clients-in-scope-list` with multiple `TenantPolicyGroupList`
  entries) triggered a `500 Internal Server Error` — the backend doesn't
  handle it, despite the payload accepting an array. Stick to one item per
  call unless multi-item support is explicitly confirmed working.
- A tool (`document_api_from_har.py`, delivered separately from the toolkit
  zip — meant to live in the user's Script Folder) turns a HAR capture into
  an interactive, Swagger-style HTML reference: sidebar grouped by module,
  sample curl command per endpoint, secrets redacted to placeholders. Runs
  incrementally — merges new captures into the same file, filling gaps
  without erasing or duplicating what's already documented.

## Pitfalls hit and already fixed — avoid repeating these

1. **`dict.get(key, default)` doesn't catch an explicit `null`.** Bit us
   twice with real Airlock/Cloud API responses that returned `"agents": null`
   instead of omitting the key or using `[]`. Fix: `(data.get(x) or [])`, not
   `data.get(x, [])`, for any field sourced from a third-party API.
2. **Folder/process mixups look exactly like data-loss bugs.** More than
   once, what looked like a persistence bug was actually the running
   `app.py` and the config file being inspected living in different folders,
   or an old server process still running on port 5000. Fix applied: the app
   now prints its exact working directory and config file paths at startup —
   check that first before assuming a save is broken.
3. **Don't guess API method/module from a sibling endpoint.** Every wrong
   guess in the Cloud API integration came from assuming a new endpoint would
   behave like one already confirmed. Test each one for real.
4. **A report that opens a browser tab before the data is ready is a bug,
   not a nice-to-have fix.** Originally opened the tab immediately then
   filled it in async — user stared at a blank page for minutes on a slow
   multi-tenant pull. Fixed: fetch first, open the tab (via blob URL) only
   once the response is actually in hand; falls back to a clickable link if
   the browser's popup blocker catches the delayed `window.open()`. The
   Excel/XML export buttons follow the same pattern — data is fetched fully
   before a download is triggered.
5. **When two tabs share the same CSS classes for visual consistency, scope
   their JS event handlers independently.** Settings and Custom Widgets both
   use `.widget-tile`/`.widget-detail-panel` for identical styling — their
   click handlers are scoped to `#tab-settings` / `#tab-widgets`
   respectively so opening one never collapses the other.
6. **Terminal log output is the single most effective debugging tool in this
   project.** Every real bug (the null-vs-missing crash, the wrong HTTP
   method, the wrong module) was found by adding a log line and asking for
   the terminal output — not by guessing from symptoms alone.
7. **Flask's dev server doesn't hot-reload.** After any `app.py` or
   `templates/index.html` edit, fully stop the running server and restart it
   (`run.bat` again, or `python app.py`) — otherwise you'll be staring at old
   behavior and wondering why a fix "didn't work."

## Where things stand

Fully working, tested against real Airlock environments (not just synthetic
data) at every step. No known open bugs as of this summary.

Session 2026-09-04 added to NFR Tracking: a collapsible partner tenant list
with a live selected-count summary, a report re-themed to match the app's own
dark palette (with a light print override), and Excel/XML export alongside
the existing HTML report — all three built from the same
`run_cloud_partner_report()` data so they stay in sync. Also moved the
project folder up a level, from `Documents\airlock-partner-consulting-toolkit_Migrate\airlock-partner-consulting-toolkit`
to just `Documents\airlock-partner-consulting-toolkit` (folder move only, no
code changes).

Session 2026-09-08 added the **Publish to GitHub** Settings card — pushes
this app's own source files to a GitHub repo as a single commit via the Git
Data API, using a fixed file list so secrets/runtime files can't end up in
it by accident. See the Settings tab bullet above for details. Verified with
the Flask test client and mocked GitHub API responses covering: pushing to
an existing branch, publishing into a brand-new repo/branch with no prior
commits, a missing-token error, and a malformed repo string — plus a full
template render to confirm the new card doesn't break page load.

Session 2026-09-18 replaced Training Instances' Phase 1 design (a fixed list
of pre-provisioned instances, hand-added with their own Tenant/Group ID, with
roster rows assigned onto them one admin account at a time) with Phase 2:
creating a brand-new Airlock tenant per student on demand, ported from a
working bash toolkit (`Airlock_Training_Tenant_Automation_v1`) already
verified against real Airlock AU/AM production. This confirmed a *third*
Cloud API auth style beyond the two already known — `X-ApiKey` +
`DirectoryID` headers for `directory/v1/tenant-create-schedule` (queues a
job) and a new `quevider` module for `job/{JobID}/status` polling — distinct
from NFR Tracking's `UserApiKey` + `tenantID`/`Directoryid` style. A
background thread (`training_scheduler_loop`, same pattern as the existing
Timed Audit Mode scheduler) polls every in-flight job every 15 seconds so
the widget never blocks on however long provisioning takes; the frontend
polls the class list every 15 seconds too, to reflect live status. Phase 1's
old `training_config.json` data is preserved, not deleted, under a
`legacy_instances` key on first startup after the upgrade. Verified with a
Flask test client and mocked Cloud API responses (26 tests) covering: both
Cloud auth header shapes side by side (to guard against ever conflating
them), successful and failed tenant creation, every Quevider status
(`COMPLETED`, `DEAD`, `WAITING`, an unrecognized value, a transport error
that must NOT be treated as job failure), one student failing to queue
without blocking the rest of the class, duplicate-email and bad-auto-expiry
validation, and removal guards that block deleting a class/student while
still mid-creation. Deleting a tenant is explicitly NOT implemented — the
source toolkit doesn't have that call either — flagged as a Phase 3
follow-up once that endpoint is captured the same way NFR Tracking's and
Phase 1's calls were (a real browser Network capture).

This session also caught two other docs that had drifted out of date from
undocumented prior-session work: Publish to GitHub had already been reworked
from one-commit-per-file to a single versioned zip with full version
history, and Training Instances' Phase 1 had shipped without ever being
written up here. Both are now reflected above and in `README.md`.

Later the same session (2026-09-18), Ryan ran Phase 2 end to end against
real Airlock production — created a test class with two real tenants,
watched both reach `Completed`, then captured a real browser Network
request for deleting a test tenant in the Cloud console and shared it back.
That confirmed Phase 3: `POST directory/v1/tenant-delete`, body
`{"TenantList":[{"ID","DirectoryID"}],"atcp":null}`, same module and
`X-ApiKey`/`DirectoryID` auth as tenant creation, synchronous (no
JobID/polling — `Atro.ErrorOccured == false` means it already happened).
Built `cloud_delete_tenant()` and two new routes — per-student
(`/training/classes/student/delete-tenant`) and per-class bulk
(`/training/classes/delete-tenants`) — both gated to tenants whose creation
reached a terminal state (`completed`/`dead`/`cancelled`/`partial`) and
always sending exactly one tenant per call, since a sibling batch-shaped
Cloud API endpoint (`tenant-policy-clients-in-scope-list`, see "Cloud API
reverse-engineering" above) was previously confirmed to 500 with more than
one item despite accepting an array. The UI now shows a "Delete tenant" /
"Retry delete" button per student and a "Delete N tenants" button per
class, both with an irreversible-action confirm dialog, plus a separate
`delete_status`/`delete_error`/`deleted_at` per student so a failed delete
never overwrites the original creation status. "Remove from list" (local
tracking only) now warns when the tenant it's removing was never actually
deleted in Airlock, rather than staying silent about it. Verified with 12
more tests (38 total for this widget) built directly against Ryan's real
captured response shape, covering: the exact request/response shape,
Atro-level and HTTP-level delete failures, blocked deletes for a tenant
still creating or that never got created, idempotent re-delete rejection,
bulk delete skipping already-deleted tenants without an extra API call, and
that removing a deleted tenant's tracking row still works afterward.

Session 2026-09-19 added Training Instances' Phase 4: automatic baseline
provisioning. Ryan wanted every new training tenant to get a Windows
Workstation baseline as part of provisioning, starting with "Add Baseline
from Reference" in the console's Baselines tab. Two real browser Network
captures confirmed the calls: `POST webfe/v1/tenant-baseline-reference-list`
(payload just `{"atcp":null}` — always returns Airlock's full ~180-entry
reference catalog, not filtered per-request) to find the target baseline by
`FullName`, then `POST webfe/v1/tenant-baseline-reference-create` (payload
`{"TenantReferenceBaselineList":[<the matched entry, echoed back
whole>],"atcp":null}`) to add it. The captured create-call's cURL headers
settled an open question from this project's "Cloud API reverse-engineering"
history: this pair uses the *same* `UserApiKey` + `tenantID`/`Directoryid`
auth style as NFR Tracking (confirmed from the real headers, not inferred
from the AccessLog shape alone as first suspected) — genuinely different
from tenant create/poll/delete's `X-ApiKey`/`DirectoryID` style, so
`cloud_api_request()` is reused here, not `cloud_tenant_api_request()`.
There was also a naming snag: Ryan's stated target, "Windows 11 24H2 x64
April 2026", doesn't exist in the real catalog — the only x64/April 2026
Windows 11 entry is `ServicePack: "25H2"`, and the only true 24H2 entries
are ARM64/older patch levels. Confirmed with Ryan before building: he meant
25H2. Built `cloud_list_reference_baselines()`, `cloud_find_reference_baseline()`
(exact, case-sensitive `FullName` match), `cloud_create_baseline_from_reference()`
(passes the matched catalog entry through unmodified rather than guessing
which of its fields — including a few UI-bookkeeping ones the real capture
showed, like `_id_internal`/`originalSortOrder` — actually matter server-side),
and `cloud_add_baseline_to_tenant()` orchestrating all three. Per Ryan's
choice: baseline creation is automatic the moment
`process_pending_training_jobs()` sees a tenant reach `Completed` (not a
separate manual step), and the target `FullName` is a Settings field
(`baseline_full_name`, default `Windows 11-25H2-x64-April 2026.tar.gz`)
rather than fixed in code, since Airlock publishes a new monthly-patch
baseline periodically. A baseline failure never affects the tenant's own
status — it's tracked independently via `baseline_status`/`baseline_error`/
`baseline_created_at` per student, with "Add baseline"/"Retry baseline"
available per student (new route:
`/training/classes/student/retry-baseline`) once a baseline hasn't already
succeeded. Only ever sends one baseline per create call, same caution as
tenant deletion. Verified with 20 more tests (58 total for this widget)
built against Ryan's real captured request/response shapes, covering the
plain functions in isolation, the automatic on-completion trigger (success
and failure paths, confirming a baseline failure doesn't touch tenant
status), the manual retry route and its guards (already-added, tenant not
yet completed, no Directory ID), and that existing students/classes with no
baseline data at all still render and behave correctly (backward
compatibility with pre-Phase-4 `training_config.json` data).

Later the same session (2026-09-19), Ryan captured the follow-up step he'd
flagged: assigning the newly-added baseline to a policy group — completing
his original ask ("add baselines to the windows Workstation Policy
groups"). This took several rounds of real captures to pin down, since two
different `webfe` endpoints turned out to be UI-state-sync/telemetry calls
rather than data sources (`tenant-policy-table-list`'s response carried no
policy data at all — just the generic Atro ack shape — despite its request
payload looking like it should). Chrome DevTools' body-search (Ctrl+Shift+F
across all captured responses) is what actually found the real source:
`policy?limit=10000`, an endpoint this app already calls
(`cloud_get_policies()`, shipped for Partner Engagement Report), turned out
to already return every policy including the target group by name — no new
endpoint needed for that part. The real write call, `POST
webfe/v1/tenant-policy-update-changes`, was confirmed via a full cURL
capture: its `Policy` field echoes the entire tree (group + children) back
including console-only cosmetic UI fields (icon/expanded/isChecked/etc.)
this app can't derive real values for, so `cloud_build_policy_group_tree()`
sends only the real structural fields (ID/Name/Parent/children) and skips
guessing at the rest — if a live run ever proves the API needs one of
those, that'll be a clear error to fix from, not a guess made now. A
second capture (`GET webfe/v1/tenant-baseline-list`) resolves the just-
added baseline to the UUID-form `BaselineID` the assign call needs — a
genuinely different identifier than the numeric value seen in the
baseline-create response's `TenantBAdded` field (that numeric value turned
out to be the same as `tenant-baseline-list`'s `Timestamp` field, not a
separate ID scheme). Rather than reconstruct the baseline's display name
from the reference catalog's differently-formatted `FullName`, the app
just picks the most-recently-created entry on the tenant, since exactly
one baseline is ever added immediately before this lookup runs. Built
`cloud_list_tenant_baselines()`, `cloud_find_newest_tenant_baseline()`,
`cloud_build_policy_group_tree()`, `cloud_apply_baseline_to_policy_group()`,
and `cloud_assign_baseline_to_policy()` orchestrating all three; chained
automatically right after a successful baseline add in
`process_pending_training_jobs()`, with a matching manual retry route
(`/training/classes/student/retry-policy-assign`) for when only this step
needs another attempt. The target policy group name is a new
`policy_group_name` Settings field (default `Workstations`, confirmed via
a real capture — including its `tenant-baseline-server-activity-list`
activity log — to be what Airlock auto-provisions, alongside
`Workstations Audit`/`Workstations Enforced` children, for every newly
created tenant). Assigning to the parent group cascades a database-
regeneration job to both children automatically — confirmed via the real
capture's `QueviderQueue`, which showed three jobs (group + both children)
from one API call, not three separate assignments. Fixed a latent crash
class while building this: `cloud_get_policies()` and the new
`cloud_list_tenant_baselines()` both used `(data or {}).get(...)`, which
raises `AttributeError` if `data` is a truthy non-dict (e.g. the bare
status string the quevider job-status endpoint returns) — now both check
`isinstance(data, dict)` first. Verified with 20 more tests (78 total for
this widget) built against Ryan's real captured shapes, covering the plain
functions in isolation (including the non-dict-response crash guard), the
full chained automatic flow (baseline succeeds → policy assign attempts →
both tracked independently), the manual retry route and its guards
(already-assigned, baseline not yet added, no Directory ID), and that a
policy-assign failure never touches the baseline's or tenant's own status.

Still the same session (2026-09-19), Ryan ran the freshly-built Phase 4/5
chain against a genuinely brand-new tenant for the first time and hit a
403 on `tenant-baseline-reference-list`: `TenantRoleCheckMessage: "Tenant
Role(s) NOT Found: view_baselines"`, for Ryan's own `UserID`. This was a
real architectural gap, not a code bug — every prior capture in this
feature had been taken from tenants Ryan had already personally opened in
the console, which masked the fact that Airlock doesn't grant the calling
account's tenant-level roles automatically at tenant-creation time via the
API. Two diagnostic theories were proposed (plain retry vs. open the
tenant in console once, then retry); Ryan confirmed the second: "When you
launch a tenant for the first time, it not only launches it, but it
autopopulates myself as a new user admin account. After that, it works."
Rather than guess at a fix, Ryan captured the console's own "Add Yourself
to This Tenant" modal — the exact thing that fires on that first visit —
by opening a genuinely never-before-visited tenant with the Network tab
open. The modal itself ("You don't have access to this tenant. To get
access, add yourself...") confirmed this is a deliberate, distinct action,
not a passive side effect: clicking "Add Me to Tenant" fires `POST
webfe/v1/tenant-user-create`, payload
`{"TenantUserCreate":{"TenantUser":{"FullName","Email","FirstName",
"LastName","UserGroups":[<group id>]}}}`. The captured response's
`AccessLog` is what made this safe to automate on a tenant nobody has
opened: every `TenantRoleCheckMessage` said "NOT Found", but
`AccessGranted` was `true` anyway because of `"Directory Role(s) Found,
Inherited: true"` — this endpoint accepts either a tenant-level role or an
inherited directory-level one, and the account this app authenticates as
already has adequate directory-level admin roles. One wrong turn along the
way: the modal's "Local User Group" dropdown was first assumed to come
from `security/v1/directory-group-list` (already visible in the page-load
capture), but that endpoint's real response had no "LocalAdmin" entry at
all and completely different IDs — it turned out to return the calling
user's own *directory-wide* admin role groups, unrelated to the tenant-
scoped dropdown. The real source, `webfe/v1/tenant-user-group-list`, was
found by checking the very first page-load capture again for a
similarly-named call that had been overlooked; a second real capture of it
confirmed the field shape (`TenantUserGroupList[].{ID,Name,Roles,
Policies}`) and, interestingly, the same `LocalAdmin` UUID on two
completely different tenants — suggesting it may be a stable, platform-
wide default, though the app still looks it up by name every time rather
than trusting that. Ryan also proposed the fix's shape himself: rather
than a one-off manual step, add a configurable **Instructor full
name**/**Instructor email** to Settings and auto-grant that account access
to every new tenant automatically — explicitly so this becomes portable to
other instructors later ("I eventually want to share this tool with other
instructors"), where sharing just means pointing those two fields (and the
Cloud admin API key) at someone else's identity. Built
`cloud_list_tenant_user_groups()`, `cloud_find_user_group_by_name()`,
`cloud_add_user_to_tenant()`, and `cloud_provision_instructor_access()`
orchestrating all three; chained as the very first automatic step in
`process_pending_training_jobs()` — before baseline-add and policy-assign,
since those are exactly the steps this unblocks — with its own
`instructor_access_status`/`instructor_access_error`/
`instructor_access_created_at` per student (a `"skipped"` status, not an
error, when the Settings fields are left blank) and a matching manual
retry route (`/training/classes/student/retry-instructor-access`). A
failure here never blocks baseline/policy from being attempted anyway,
since they may still succeed some other way. Verified with 21 more tests
(99 total for this widget) built against Ryan's real captured request and
response shapes for both endpoints, covering the plain functions in
isolation, the full automatic chain (instructor access → baseline →
policy, in that order, including the "skipped" and failure-doesn't-block
paths), the manual retry route and its guards, and config validation
(malformed instructor email rejected, blank fields accepted as an
intentional opt-out).

Immediately after shipping Phase 6, Ryan ran it live against a genuinely
brand-new tenant (never opened in the console) and hit almost the finish
line: instructor access was granted successfully, but the automatic
baseline-add attempted right after it still 403'd with the exact same
`Tenant Role(s) NOT Found: view_baselines` error as before Phase 6
existed. This was a real, distinct problem from the one Phase 6 solved —
not a sign the fix didn't work, but that Airlock's tenant-level role grant
isn't visible to the very next API call. To isolate which, Ryan was asked
to just click "Retry baseline" on that same student with no other change —
it succeeded immediately. That confirmed a real propagation delay between
granting a tenant-level role and it taking effect elsewhere in Airlock's
backend, not a fundamentally broken grant. (One live capture had hinted at
a possible mechanism for this — the console's own post-grant flow calls
`security/v1/user-spa-profile-load` with a field literally named
`RapidSecurityProfileRefresh`, suggesting a cached permission profile that
needs an explicit refresh — but since only the *request* shape for that
call had been captured, not its response, and the plain-retry test alone
was enough to confirm and fix the actual symptom, that specific call was
left uninvestigated rather than bolted on unconfirmed.) Fixed with a small,
narrowly-scoped retry helper, `retry_on_role_propagation_delay()`: it
retries a call up to 3 times, 3 seconds apart, but ONLY when the failure
matches this exact confirmed error text ("Tenant Role(s) NOT Found") —
any other kind of failure (wrong group name, real permissions problem,
network error) still surfaces immediately on the first attempt, unretried,
same as before. Wrapped around both the baseline-add and policy-assign
calls, in both the automatic chain and their manual retry routes, since
either could plausibly hit the same propagation window. Verified with 7
more tests (106 total for this widget): the retry helper in isolation
(succeeds first try, retries and recovers, gives up after max attempts,
never retries a different error), the automatic chain absorbing one
transient 403 transparently, the automatic chain still failing cleanly
(and remaining manually retriable) when every attempt 403s, and the manual
retry route itself absorbing one transient 403. `time.sleep` is mocked in
every test so none of this actually pauses the test suite.

With the confirmed hands-off provisioning chain complete ("OK, that worked
perfectly."), Ryan asked for a UI cleanup pass on Training Instances' "New
class" form and "Tenant creation settings" section. Removed three fields
from "New class" — **Licence allocation per tenant** (`training-class-
licence`), **Auto-expiry** (`training-class-expiry`, which Ryan confirmed
never actually worked), and **Description** (`training-class-description`)
— on the reasoning that a class name is sufficient; every class now just
uses the configured tenant licence allocation, with no per-class override,
expiry, or description sent to Airlock. `training_classes_create()` was
simplified to match — it no longer reads or validates `licence_allocation`/
`auto_expiry`/`description` from the request body at all (a stale client
still sending them is silently ignored, not rejected). Renamed **Default
licence allocation** to **Tenant license allocation** (UI label only — the
backend key stays `default_licence_allocation`). Added a live descriptor
above that field showing how many licenses are currently allocated to the
configured directory, sourced from a real capture Ryan supplied: `POST
directory/v1/directory-licence-allocation-list` (module `directory`,
payload `{"DirectoryLicenceAllocationList":{"DirectoryID":"<id>"},
"atcp":null}`, response `DirectoryLicenceAllocationList.
DirectoryLicenceAllocated`) — this exact call was already implemented as
`cloud_get_license_allocation()` for the Partner Engagement Report widget's
NFR tracking, confirmed byte-for-byte against Ryan's fresh capture, so no
new Cloud API reverse-engineering was needed. Only a new route,
`GET /training/directory-licence`, was added to expose it to this widget
(using the configured `creation_directory_id`, directory-scoped so
`tenant_id=""`), plus the frontend fetch/render wired to run on Settings
load and again right after a successful config save (in case the Directory
ID just changed). Verified with 3 new tests covering the route (missing-
directory error, success against the real captured response shape, Cloud
API error passthrough) and one updated test replacing the now-obsolete
bad-auto-expiry rejection test with one confirming legacy
licence/description/auto-expiry fields are silently ignored rather than
erroring (109 total for this widget).

Ryan then asked to extend the descriptor to "N of M available" rather than
just the allocated count, and supplied a real capture for the "M" (total
capacity) half: `POST directory/v1/directory-update`, response containing
`DirectoryUpdate.Directory.LicenceCapacity: 101`. Before wiring it up, a
safety check on that specific capture caught that it was actually the
console's directory-Settings *Save* flow, not a page load — confirmed by
the very next captured call being `hermes/v1/message-create` with
`"Content":"Directory was successfully updated"`, a toast that only fires
after a successful write. Reading `LicenceCapacity` from `directory-update`
would have meant POSTing the *entire* Directory object back — including
both invite-email HTML templates and the licence date range — just to read
one field, a real risk of corrupting live directory/billing settings for
what should be a harmless display value, so this was flagged to Ryan rather
than built as asked. Ryan then captured the directory Settings page's
plain load (screenshot: "CTF Events (6 allocated | 101 capacity)" header),
which pointed at `tenant-search`, still not the right source; the technique
that actually found it was the same Chrome DevTools Ctrl+Shift+F
across-all-responses body search used earlier this project to find
`tenant-user-group-list` for instructor access — searching a fresh page
load for `LicenceCapacity` surfaced `POST directory/v1/directory-search`
(payload `{"DirectorySearch":{"DirectoryID":"<id>"},"atcp":null}`, response
`DirectorySearch.DirectoryList[0].LicenceCapacity`), a genuinely read-only
call fired alongside `directory-licence-allocation-list` on that same page
load, with no update-toast side effect. Built
`cloud_get_directory_licence_capacity()` (same auth style, `tenant_id=""`,
directory-scoped) and wired it into `/training/directory-licence`
alongside the existing allocated-count call, as two independent lookups —
a capacity failure returns the allocated count on its own (`capacity:
null`, `capacity_error` set) rather than failing the whole descriptor,
matching the "each data point is independent" convention
`cloud_collect_tenant_data` already established for NFR Tracking. The
frontend descriptor now reads "Licenses allocated: *N* of *M* available"
when both succeed, falling back to just "Licenses allocated: *N*" if the
capacity half fails. Verified with 2 more tests (111 total for this
widget): the combined success case (confirming both real payload shapes in
one request), and capacity failing independently without blocking the
allocated count.

With both license descriptors done, Ryan raised a separate ask: the
**Reference baseline (FullName)** field is a free-text box, but the real
catalog is ~180 entries — he didn't want to list them all, just "the most
recent baseline for each OS" as a quick-pick. Rather than build blind,
this was scoped with two quick questions first: whether the picker should
replace the text field or sit above it as quick-pick buttons that just
fill the field in (Ryan chose the latter — keeps the field free-text as an
escape hatch for the other ~170+ entries), and whether "per OS" should
mean full OS+version (Windows 11 and Windows 10 as separate picks) or just
high-level family (one "Windows" pick) — Ryan chose full OS+version, matching
how the console's own catalog lists them. Built `_parse_baseline_patch_level()`
(parses the confirmed real `PatchLevel` shape, e.g. `"April 2026"`, into a
sortable year/month tuple, tolerantly returning `None` for anything that
doesn't match rather than crashing, since only Windows entries are
confirmed to use this format) and `cloud_pick_recent_baselines_by_os()`
(groups the full catalog by `OperatingSystem`, keeps the newest `PatchLevel`
per group, prefers x64 on an exact tie, and still surfaces an unparseable
entry rather than dropping it) — both operate on data
`cloud_list_reference_baselines()` already fetches, so no new Cloud API
reverse-engineering was needed for the curation logic itself.

The one open question was auth: `tenant-baseline-reference-list` uses the
same per-tenant `UserApiKey`/`tenantID` role-check as the baseline-add call
it backs, but the Settings page needing this list has no specific tenant in
mind — Ryan hasn't necessarily created one recently, or ever, on a fresh
install. Rather than guess, the route (`GET /training/reference-baselines`)
tries with a blank tenant_id first (on the chance it behaves like
`tenant-user-create`, which accepts an inherited directory-level role in
place of a tenant-level one), and only if that's refused falls back to
`_find_known_training_tenant_id()` — any tenant this app has already
created, preferring one whose status is `completed`. If neither works
(most likely: no training tenant exists yet at all), the real Cloud API
error is surfaced with an explicit note to create a class first, rather
than silently failing — consistent with this project's practice of
surfacing genuine errors instead of masking assumptions that might be
wrong. This is the one piece of this feature not yet confirmed against a
live response; if it turns out blank tenant_id 403s and the fallback tenant
doesn't have `view_baselines` either, Ryan's next live-test report will
show exactly which branch needs adjusting, same as every other gap this
project has closed. The frontend shows a small button per suggested
baseline (e.g. "Windows 11 25H2 x64 — April 2026") in a row above the
FullName field, plus a manual "⟳ Refresh" button; clicking a suggestion
just sets the text field's value, so nothing about baseline validation,
matching, or the create call itself changed. Verified with 18 new tests
(129 total for this widget): patch-level parsing (full and abbreviated
month names, unparseable, blank/missing), the grouping/picking logic (one
pick per OS, correct newest-patch-level selection, x64 tie-break,
unparseable entries still surfacing, non-dict entries ignored, empty
catalog), the known-tenant-id fallback helper in isolation, and the
route's three paths (blank tenant_id succeeds first try, blank fails and
falls back to a known tenant successfully, both fail with no known tenant
and the error explicitly mentions needing a training tenant first).

Ryan then reported a real bug in that quick-pick row via screenshot: "LOL,
I think we may tried to make this too friendly" — grouping by
`OperatingSystem` had produced 70+ ungrouped buttons, not a short "most
popular" list. The root cause was the grouping assumption itself: it held
for Windows (`OperatingSystem` stays constant across minor versions, e.g.
`"Windows 11"`, with the minor build in `ServicePack`) but not for Linux,
where every distro embeds its own minor version *inside*
`OperatingSystem` (`"CentOS 7.0.1406"` and `"CentOS 7.1.1503"` are two
distinct `OperatingSystem` strings), so nothing collapsed for
CentOS/RHEL/Rocky/AlmaLinux/Ubuntu. Ryan's own suggestion — an OS dropdown
followed by a second dropdown of just that OS's baselines — matched the
fix. Rather than guess a new grouping heuristic from the button labels
alone, this was rebuilt from real data: Ryan supplied real captured
catalog entries across every family (Windows client, Windows Server,
macOS, AlmaLinux, CentOS, RHEL, Rocky), confirming `OSType` is exactly one
of `"Windows"`/`"Linux"`/`"MacOS"` (that capitalization, not `"macOS"`),
that `Architecture`'s x64 spelling varies by vendor (`"x64"` for Windows,
`"x86_64"` for RHEL/CentOS, `"x86_x64"` for Rocky/AlmaLinux), and that
`ServicePack` can legitimately be the literal string `"None"`. From that,
`cloud_pick_recent_baselines_by_os()` was replaced with
`_baseline_family()` (macOS's `OSType` collapses to one `"macOS"` family;
Windows's `OSType` splits into `"Windows"` vs. `"Windows Server"` by
whether `OperatingSystem` starts with `"Windows Server"`, since both
share the same `OSType`; Linux's `OSType` uses the leading letters of
`OperatingSystem` via regex to get one family per distro; anything else
surfaces under its own `OSType` rather than being dropped),
`cloud_group_baselines_by_family()`, and
`cloud_recommend_baseline_per_family()` (same newest-`PatchLevel`-wins,
x64-tiebreak logic as before, just applied per family instead of per
`OperatingSystem`). `/training/reference-baselines` now returns
`families`, `baselines_by_family`, and `recommended_by_family`; the
frontend replaced the single button row with two `<select>` elements —
family, then specific baseline within it, with the recommended entry
marked "(recommended)" and pre-selected, auto-filling the FullName field
the moment a family is chosen. The auth logic (blank tenant_id first,
falling back to a known training tenant) carried over unchanged. Verified
with 9 new/replaced tests (138 total for this widget, using the real
multi-family sample data Ryan provided verbatim rather than synthetic
fixtures): family derivation for every confirmed `OSType`/`OperatingSystem`
combination including the Windows/Windows Server split, grouping entries
into families, and per-family recommendation picking.

Ryan then live-tested the two-dropdown picker end to end and hit a real
bug: no matter which baseline he picked, new tenants kept getting the
default Windows 11 one instead. Rather than guess, this was traced from
his own `cmd` window logging (turned on specifically to debug this) —
the log line `Training Instances: added baseline 'Windows
11-25H2-x64-April 2026.tar.gz' to tenant for ...` on a run where he'd
picked something else proved the *saved config* still held the default,
not a bug in the add/assign logic itself. Root cause: picking from the
two dropdowns only fills the (free-text) FullName field — like every
other field in the "Tenant creation settings" panel, it isn't applied
until the single shared "Save settings" button is clicked, and Ryan
hadn't realized that was a separate step. A second live test, after
actually clicking Save, added `macOS Tahoe-26.x-M-April 2026.tar.gz` and
assigned it to Workstations successfully — confirming the add/assign
chain itself was correct all along, and also incidentally confirming the
one previously-open question from the paragraph above:
`/training/reference-baselines`'s blank-tenant_id-first auth attempt
*does* 403 in practice (`TenantID: "000000000000000000000000"`,
`ErrorMessage: "Incorrect permissions for accessing
/webfe/v1/tenant-baseline-reference-list"`), and the fallback to a known
training tenant picks it up cleanly right after — exactly the untested
branch this project flagged and never guessed at.

Since a missed Save silently falls back to stale settings for every
subsequent tenant, and tenant creation immediately emails the student's
account, a passive hint felt too weak. Added a settings-wide dirty
tracker (`trainingCaptureConfigSnapshot()` / `trainingConfigIsDirty()`
in the frontend) that snapshots all six "Tenant creation settings" field
values on load and after a successful save, shows a persistent "⚠
Unsaved changes" warning near the Save button whenever any of them
drifts from that snapshot (the baseline dropdowns update it manually
after their programmatic `.value` assignment, since that doesn't fire a
DOM "input" event), and — the actual guard — makes "Create tenants"
refuse outright with a clear message if anything is unsaved, rather than
silently using whatever was last actually saved. Frontend-only change;
all 138 tests unaffected (verified by re-running the full suite).

Natural next steps, if picked up again: if a live run ever
shows the `Policy` tree's omitted cosmetic UI fields are actually
required, add them back informed by that specific error; extend
`iso_mapping.json` with more automated controls (several are still
`manual` pending confirmed field mappings); possibly extend NFR Tracking
with more Cloud API data points now that the auth/module/method pattern
is understood; and if this toolkit is ever actually handed to a second
instructor, confirm in practice that just changing the Cloud admin API
key plus the Instructor full name/email fields is really sufficient,
since that's been designed for but not yet tested against a second real
Airlock user account.

Session 2026-09-24 (v5.2) added Training Instances' Phase 8: a custom
**blocked-file notification message** (the popup an agent shows when it
blocks a file) pushed to every new tenant. Built from a real HAR capture
of Ryan editing it on "Workstations Enforced" in the console. No new
endpoint was needed for the save — it's the same `webfe/v1/tenant-policy-update-changes`
call Phase 5 uses, with a different change handler
(`"Handler": "TenantPolicySettingUpdate"`, `Data: {ID, Parent,
TenantPolicySettingList: [<settings>]}`); the load is `POST
webfe/v1/tenant-policy-setting-list` (one policy group per call), both
`UserApiKey`/`tenantID` auth (`edit_policies` role). One false lead first:
`tenant-policy-blocklist-list` only lists blocklist entries, not the
message. The important catch: the save carries the policy group's
**entire** settings object (audit mode, script control, OTP durations,
proxy, cache, …), not a diff, so a naive save could silently reset other
policy settings. `cloud_set_block_notification_message()` therefore loads
the group's current settings, changes only `NotificationMessage` (and
forces `ClientNotification: true`, by Ryan's choice, since otherwise the
message is never shown), saves, then re-reads to confirm the message
stuck. Diffing the console's save against its load showed it omits a
handful of fields (`ID`, `AgentDownloadList`, `CacheExpiryTime`,
`ClientToServerProxy`, `CmdlineEnabled`, `CommunicationList`,
`PowerShellLanguageMode`, `ScriptCustom`, and `TargetVer.PolicyID`) —
mirrored exactly in `POLICY_SETTING_FIELDS_OMITTED_ON_SAVE` /
`build_policy_settings_for_save()` rather than guessing. Settings are per
policy group; by Ryan's choice only `"<Policy group> Enforced"` is
updated (where blocks actually happen). Applies to Training Instances
only, not NFR Provisioning. New Settings field **Blocked-file
notification message** (`block_notification_message`; blank = step
"skipped"; 1000-char sanity cap), part of the unsaved-changes guard. Runs
as step 4 of the automatic chain, independent of baseline success, wrapped
in `retry_on_role_propagation_delay`; tracked via
`block_notification_status`/`_error`/`_created_at`, with a "Block message
set" checklist badge and a per-student Set/Retry/Re-apply button (new
route `/training/classes/student/retry-block-notification`; re-apply is
allowed after success so an edited message can be re-pushed). Verified
with 22 tests built on the real HAR shapes, including a byte-for-byte
match between the app's built payload and the console's own save.

Note: this summary predates some work visible in the folder (NFR
Provisioning incl. Phase 7 sub-directory creation, `har_to_catalog.py`,
`api_catalog.json`, `QUICKSTART.md`) — those aren't written up here yet.
